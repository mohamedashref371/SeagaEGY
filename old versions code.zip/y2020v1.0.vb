﻿Public Class Sega
    Dim sg As String = My.Computer.FileSystem.SpecialDirectories.AllUsersApplicationData.Replace("1.99.371.3317", "")
    Dim gh3, gh4 As String
    Dim dh As String = "ص^جdؤ8قْ¬O„‍#‏ˆرN¦¬±jˆ™جEـç:xGZëôپذ…ڈ"
    Dim L1, L2, L22, L222, L3 As String
    Dim La1, La2, La3, La7, La8, La9 As String
    Dim Lab1, Lab2, Lab3, Lab4, Lab5, Lab6, Lab7, Lab8, Lab9 As String
    Dim Lb4, Lb5, Lb6, Lb7, Lb8, Lb9 As String
    Dim Lx1, Lx2, Lx3, Lx4, Lx5, Lx6 As String
    Dim di As String = "0" : Dim de As String = "0"
    Dim rt As String
    Dim see, see2 As String
    Dim bl As String
    Dim lwz, lwc As String
    Dim gn, gd, gu As String
    Dim vh As String = "0"
    Dim xz As String
    Dim die As String
    Dim sn As String
    Dim flw As String
    Dim kf As String
    Dim sf As String
    Dim Ldu As String
    Dim ss As String
    Dim zn As String
    Dim er As String
    Dim s1 As String
    Dim n1, r1 As String
    Dim ll1 As String
    Dim qu As String
    Dim img As String
    Dim Le1, Le2, Le3, Le7, Le8, Le9 As Integer
    Dim s0 As Integer
    Dim n0, r0 As Integer
    Dim o1 As Integer
    Dim oo1 As String
    Dim sfh As Integer
    Dim clr As Integer
    Dim wn9 As Integer
    Dim wn3 As Integer
    Dim ll As Integer = 4
    Dim lo As New Point

    Private Sub Sega_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        My.Computer.FileSystem.DeleteDirectory(My.Computer.FileSystem.SpecialDirectories.AllUsersApplicationData, FileIO.DeleteDirectoryOption.DeleteAllContents)
        If My.Computer.FileSystem.DirectoryExists(sg.Replace("SEAGA EGY 2019", "SEEGA EGY 2018")) Then
            My.Computer.FileSystem.DeleteDirectory(sg, FileIO.DeleteDirectoryOption.DeleteAllContents)
            My.Computer.FileSystem.RenameDirectory(sg.Replace("SEAGA EGY 2019", "SEEGA EGY 2018"), "SEAGA EGY 2019")
        End If
        If My.Computer.FileSystem.DirectoryExists(sg + "Save") Then
            If My.Computer.FileSystem.DirectoryExists(sg + "NewSave") Then
                My.Computer.FileSystem.DeleteDirectory(sg + "NewSave", FileIO.DeleteDirectoryOption.DeleteAllContents)
            End If
            My.Computer.FileSystem.RenameDirectory(sg + "Save", "NewSave")
            ld.Enabled = True
        Else
            If My.Computer.FileSystem.DirectoryExists(sg + "NewSave") Then
                ld.Enabled = True
            End If
        End If
        Ros(e)
        L2 = "3" : L22 = "3" : L222 = "3" : L3 = "2"
        Lb4 = "4" : Lb5 = "5" : Lb6 = "6" : Lb7 = "7" : Lb8 = "8" : Lb9 = "9"
        Lx1 = "1" : Lx2 = "2" : Lx3 = "3" : Lx4 = "4" : Lx5 = "5" : Lx6 = "6"
        rt = "0"
        see = "1" : see2 = "1"
        bl = "0"
        lwz = "2" : lwc = "2"
        gn = "0" : gd = "0"
        sn = "2"
        flw = "1"
        kf = "1"
        sf = "1"
        Ldu = "0"
        ss = "0"
        zn = "0"
        er = "0"
        s1 = ""
        n1 = "" : r1 = ""
        ll1 = "0"
        qu = "0"
        img = "0"
        s0 = -1
        n0 = -1 : r0 = -1
        o1 = "0"
        sfh = "1"
        clr = "245"
        Text = Text.Replace(".371.3317", "")
    End Sub

    Private Sub nm12_Key(sender As Object, e As KeyEventArgs) Handles nm1.KeyDown, nm2.KeyDown, fst.KeyDown
        If e.KeyCode = Keys.F11 Then
            kf = "1"
            nm1.Visible = False
            nm2.Visible = False
            fst.Visible = False
            nm1.Visible = True
            nm2.Visible = True
            If sfh = "5" Then
                fst.Visible = True
            End If
        End If
        If kf = "1" Then
            If e.KeyCode = Keys.F2 Then
                If sv.Enabled = True Then
                    sve(e)
                End If
            ElseIf e.KeyCode = Keys.F4 Then
                If ld.Enabled = True Then
                    lde(e)
                End If
            ElseIf e.KeyCode = Keys.F8 Then
                If clr < 255 Then
                    clr += 1
                End If
                clr2(e)
            ElseIf e.KeyCode = Keys.F6 Then
                If clr > 185 Then
                    clr -= 1
                End If
                clr2(e)
            ElseIf e.KeyCode = Keys.F9 Then
                Sega2.Show()
            ElseIf e.KeyCode = Keys.F10 Then
                If Bu9.Visible = True Then
                    h(e)
                End If
            ElseIf e.KeyCode = Keys.F5 Then
                If ok1.Visible = True Then
                    If ok1.Checked = False Or ok2.Checked = False Then
                        ok1.Checked = True
                        ok2.Checked = True
                    Else
                        ok1.Checked = False
                        If Cmpt.Checked = False Then
                            ok2.Checked = False
                        End If
                    End If
                End If
            ElseIf e.KeyCode = Keys.F7 Then
                img2(e)
            ElseIf e.KeyCode = Keys.F12 Then
                B5(e)
            ElseIf e.KeyCode = Keys.F1 Then
                B3(e)
            ElseIf e.KeyCode = Keys.F3 Then
                Res(e)
            End If
        End If
    End Sub

    Private Sub Sega_Key(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown, MyClass.KeyDown, Me.KeyDown, Bu1.KeyDown, Bu2.KeyDown, Bu3.KeyDown, Bu4.KeyDown, Bu5.KeyDown, Bu6.KeyDown, Bu7.KeyDown, Bu8.KeyDown, Bu9.KeyDown, B10.KeyDown, B11.KeyDown, XO.KeyDown, OX.KeyDown, CB1.KeyDown, bmp.KeyDown, Cmpt.KeyDown, wlf.KeyDown, nd.KeyDown, rd.KeyDown, ok1.KeyDown, ok2.KeyDown, NoS.KeyDown, VaH.KeyDown, ns.KeyDown, sv.KeyDown, ld.KeyDown, rh.KeyDown, rr.KeyDown, rl.KeyDown, rv.KeyDown, sv1.KeyDown, ld1.KeyDown, RB1.KeyDown, RB2.KeyDown, RB3.KeyDown
        If kf = "1" Then
            If e.KeyCode = Keys.NumPad7 Or e.KeyCode = Keys.Q Then
                If Lab1 = "1" Then
                    zx1(e)
                ElseIf Lab2 = "1" Then
                    zx2(e)
                ElseIf Lab3 = "1" Then
                    zx3(e)
                ElseIf Lab4 = "1" Then
                    as1(e)
                ElseIf Lab5 = "1" Then
                    as2(e)
                ElseIf Lab6 = "1" Then
                    as3(e)
                ElseIf Lab7 = "1" Then
                    cv1(e)
                ElseIf Lab8 = "1" Then
                    cv2(e)
                ElseIf Lab9 = "1" Then
                    cv3(e)
                End If
            ElseIf e.KeyCode = Keys.NumPad8 Or e.KeyCode = Keys.W Then
                If Lab1 = "2" Then
                    zx1(e)
                ElseIf Lab2 = "2" Then
                    zx2(e)
                ElseIf Lab3 = "2" Then
                    zx3(e)
                ElseIf Lab4 = "2" Then
                    as1(e)
                ElseIf Lab5 = "2" Then
                    as2(e)
                ElseIf Lab6 = "2" Then
                    as3(e)
                ElseIf Lab7 = "2" Then
                    cv1(e)
                ElseIf Lab8 = "2" Then
                    cv2(e)
                ElseIf Lab9 = "2" Then
                    cv3(e)
                End If
            ElseIf e.KeyCode = Keys.NumPad9 Or e.KeyCode = Keys.E Then
                If Lab1 = "3" Then
                    zx1(e)
                ElseIf Lab2 = "3" Then
                    zx2(e)
                ElseIf Lab3 = "3" Then
                    zx3(e)
                ElseIf Lab4 = "3" Then
                    as1(e)
                ElseIf Lab5 = "3" Then
                    as2(e)
                ElseIf Lab6 = "3" Then
                    as3(e)
                ElseIf Lab7 = "3" Then
                    cv1(e)
                ElseIf Lab8 = "3" Then
                    cv2(e)
                ElseIf Lab9 = "3" Then
                    cv3(e)
                End If
            ElseIf e.KeyCode = Keys.NumPad4 Or e.KeyCode = Keys.A Then
                If Lab1 = "4" Then
                    zx1(e)
                ElseIf Lab2 = "4" Then
                    zx2(e)
                ElseIf Lab3 = "4" Then
                    zx3(e)
                ElseIf Lab4 = "4" Then
                    as1(e)
                ElseIf Lab5 = "4" Then
                    as2(e)
                ElseIf Lab6 = "4" Then
                    as3(e)
                ElseIf Lab7 = "4" Then
                    cv1(e)
                ElseIf Lab8 = "4" Then
                    cv2(e)
                ElseIf Lab9 = "4" Then
                    cv3(e)
                End If
            ElseIf e.KeyCode = Keys.NumPad5 Or e.KeyCode = Keys.S Then
                If Lab1 = "5" Then
                    zx1(e)
                ElseIf Lab2 = "5" Then
                    zx2(e)
                ElseIf Lab3 = "5" Then
                    zx3(e)
                ElseIf Lab4 = "5" Then
                    as1(e)
                ElseIf Lab5 = "5" Then
                    as2(e)
                ElseIf Lab6 = "5" Then
                    as3(e)
                ElseIf Lab7 = "5" Then
                    cv1(e)
                ElseIf Lab8 = "5" Then
                    cv2(e)
                ElseIf Lab9 = "5" Then
                    cv3(e)
                End If
            ElseIf e.KeyCode = Keys.NumPad6 Or e.KeyCode = Keys.D Then
                If Lab1 = "6" Then
                    zx1(e)
                ElseIf Lab2 = "6" Then
                    zx2(e)
                ElseIf Lab3 = "6" Then
                    zx3(e)
                ElseIf Lab4 = "6" Then
                    as1(e)
                ElseIf Lab5 = "6" Then
                    as2(e)
                ElseIf Lab6 = "6" Then
                    as3(e)
                ElseIf Lab7 = "6" Then
                    cv1(e)
                ElseIf Lab8 = "6" Then
                    cv2(e)
                ElseIf Lab9 = "6" Then
                    cv3(e)
                End If
            ElseIf e.KeyCode = Keys.NumPad1 Or e.KeyCode = Keys.Z Then
                If Lab1 = "7" Then
                    zx1(e)
                ElseIf Lab2 = "7" Then
                    zx2(e)
                ElseIf Lab3 = "7" Then
                    zx3(e)
                ElseIf Lab4 = "7" Then
                    as1(e)
                ElseIf Lab5 = "7" Then
                    as2(e)
                ElseIf Lab6 = "7" Then
                    as3(e)
                ElseIf Lab7 = "7" Then
                    cv1(e)
                ElseIf Lab8 = "7" Then
                    cv2(e)
                ElseIf Lab9 = "7" Then
                    cv3(e)
                End If
            ElseIf e.KeyCode = Keys.NumPad2 Or e.KeyCode = Keys.X Then
                If Lab1 = "8" Then
                    zx1(e)
                ElseIf Lab2 = "8" Then
                    zx2(e)
                ElseIf Lab3 = "8" Then
                    zx3(e)
                ElseIf Lab4 = "8" Then
                    as1(e)
                ElseIf Lab5 = "8" Then
                    as2(e)
                ElseIf Lab6 = "8" Then
                    as3(e)
                ElseIf Lab7 = "8" Then
                    cv1(e)
                ElseIf Lab8 = "8" Then
                    cv2(e)
                ElseIf Lab9 = "8" Then
                    cv3(e)
                End If
            ElseIf e.KeyCode = Keys.NumPad3 Or e.KeyCode = Keys.C Then
                If Lab1 = "9" Then
                    zx1(e)
                ElseIf Lab2 = "9" Then
                    zx2(e)
                ElseIf Lab3 = "9" Then
                    zx3(e)
                ElseIf Lab4 = "9" Then
                    as1(e)
                ElseIf Lab5 = "9" Then
                    as2(e)
                ElseIf Lab6 = "9" Then
                    as3(e)
                ElseIf Lab7 = "9" Then
                    cv1(e)
                ElseIf Lab8 = "9" Then
                    cv2(e)
                ElseIf Lab9 = "9" Then
                    cv3(e)
                End If
            ElseIf e.KeyCode = Keys.F2 Or e.KeyCode = Keys.O Then
                If sv.Enabled = True Then
                    sve(e)
                End If
            ElseIf e.KeyCode = Keys.F4 Or e.KeyCode = Keys.L Then
                If ld.Enabled = True Then
                    lde(e)
                End If
            ElseIf e.KeyCode = Keys.R Then
                If sv.Enabled = True Then
                    sve1(e)
                End If
            ElseIf e.KeyCode = Keys.F Then
                lde1(e)
            ElseIf e.KeyCode = Keys.F8 Then
                If clr < 255 Then
                    clr += 1
                End If
                clr2(e)
            ElseIf e.KeyCode = Keys.F6 Then
                If clr > 185 Then
                    clr -= 1
                End If
                clr2(e)
            ElseIf e.KeyCode = Keys.M Or e.KeyCode = Keys.F9 Then
                Sega2.Show()
            ElseIf e.KeyCode = Keys.H Or e.KeyCode = Keys.F10 Then
                If Bu9.Visible = True Then
                    h(e)
                End If
            ElseIf e.KeyCode = Keys.F5 Then
                If ok1.Visible = True Then
                    If ok1.Checked = False Or ok2.Checked = False Then
                        ok1.Checked = True
                        ok2.Checked = True
                    Else
                        ok1.Checked = False
                        If Cmpt.Checked = False Then
                            ok2.Checked = False
                        End If
                    End If
                End If
            ElseIf e.KeyCode = Keys.F7 Then
                img2(e)
            ElseIf e.KeyCode = Keys.G Then
                g(e)
            ElseIf e.KeyCode = Keys.U Then
                If nd.Enabled = True Then
                    u(e)
                End If
            ElseIf e.KeyCode = Keys.I Then
                If rd.Enabled = True Then
                    r(e)
                End If
            ElseIf e.KeyCode = Keys.T Then
                If Cmpt.Checked = False Then
                    Cmpt.Checked = True
                ElseIf Cmpt.Checked = True And bl = "0" Then
                    Cmpt.Checked = False
                End If
            ElseIf e.KeyCode = Keys.Y Then
                If ll = "7" Then
                    ll = "0"
                Else
                    ll += 1
                End If
                bmpn(e)
            ElseIf e.KeyCode = Keys.F12 Then
                B5(e)
            ElseIf e.KeyCode = Keys.D1 Then
                sfh = "1"
                B67(e)
            ElseIf e.KeyCode = Keys.D2 Then
                sfh = "2"
                B67(e)
            ElseIf e.KeyCode = Keys.D3 Then
                sfh = "3"
                B67(e)
            ElseIf e.KeyCode = Keys.D4 Then
                sfh = "4"
                B67(e)
            ElseIf e.KeyCode = Keys.D5 Then
                sfh = "5"
                B67(e)
            ElseIf e.KeyCode = Keys.D6 Then
                sfh = "6"
                B67(e)
            ElseIf e.KeyCode = Keys.P Then
                If Bu4.Visible = True Then
                    B4(e)
                End If
            ElseIf e.KeyCode = Keys.B Or e.KeyCode = Keys.F1 Then
                B3(e)
            ElseIf e.KeyCode = Keys.N Or e.KeyCode = Keys.F3 Then
                Res(e)
            ElseIf e.KeyCode = Keys.J Then
                If VaH.Checked = True Then
                    VaH.Checked = False
                Else
                    VaH.Checked = True
                End If
            ElseIf e.KeyCode = Keys.K Then
                If NoS.Checked = True Then
                    NoS.Checked = False
                Else
                    NoS.Checked = True
                End If
                Bn(e)
            ElseIf e.KeyCode = Keys.V And My.Computer.FileSystem.FileExists(sg + "New Text Document.txt") Then
                If Bu9.Visible = True Then
                    sve(e)
                    h(e)
                End If
            End If
        End If
        If e.KeyCode = Keys.F11 Then
            If kf = "1" Then
                kf = "0"
            Else
                kf = "1"
            End If
        End If
    End Sub

    Sub clr2(ByVal e As EventArgs)
        Dim cl As Color = Color.FromArgb(clr, clr, clr)
        BackColor = cl
        nm1.BackColor = cl
        nm2.BackColor = cl
        bmp.BackColor = cl
        ns.BackColor = cl
        wlf.BackColor = cl
        fst.BackColor = cl
    End Sub

    Sub img2(ByVal e As EventArgs)
        On Error Resume Next
        If img = "0" Then
            If OFD2.ShowDialog() = DialogResult.OK Then
                BackgroundImage = Image.FromFile(OFD2.FileName)
                img = "1"
            End If
        Else
            BackgroundImage = Nothing
            img = "0"
        End If
    End Sub

    Sub bmpn(ByVal e As EventArgs)
        If ll = "0" Then
            If Bu8.Text = "عربي" Then
                bmp.Text = "Stupid"
            Else
                bmp.Text = "غبي"
            End If
            thu.Text = "5%"
        ElseIf ll = "1" Then
            If Bu8.Text = "عربي" Then
                bmp.Text = "Beginner"
            Else
                bmp.Text = "مبتدئ"
            End If
            thu.Text = "20%"
        ElseIf ll = "2" Then
            If Bu8.Text = "عربي" Then
                bmp.Text = "Medium"
            Else
                bmp.Text = "متوسط"
            End If
            thu.Text = "40%"
        ElseIf ll = "3" Then
            If Bu8.Text = "عربي" Then
                bmp.Text = "Good"
            Else
                bmp.Text = "جيد"
            End If
            thu.Text = "55%"
        ElseIf ll = "4" Then
            If Bu8.Text = "عربي" Then
                bmp.Text = "Advanced"
            Else
                bmp.Text = "متقدم"
            End If
            thu.Text = "70%"
        ElseIf ll = "5" Then
            If Bu8.Text = "عربي" Then
                bmp.Text = "Very Good"
            Else
                bmp.Text = "جيد جدا"
            End If
            thu.Text = "80%"
        ElseIf ll = "6" Then
            If Bu8.Text = "عربي" Then
                bmp.Text = "Excellent"
            Else
                bmp.Text = "ممتاز"
            End If
            thu.Text = "90%"
        ElseIf ll = "7" Then
            If Bu8.Text = "عربي" Then
                bmp.Text = "Professional"
            Else
                bmp.Text = "محترف"
            End If
            thu.Text = "100%"
        End If
    End Sub

    Private Sub bmp_TextChanged(sender As Object, e As EventArgs) Handles bmp.TextChanged
        bmpn(e)
    End Sub

    Private Sub bmp_SelectedIndexChanged(sender As Object, e As EventArgs) Handles bmp.SelectedIndexChanged
        If bmp.Text = "Stupid" Or bmp.Text = "غبي" Then
            ll = "0"
        ElseIf bmp.Text = "Beginner" Or bmp.Text = "مبتدئ" Then
            ll = "1"
        ElseIf bmp.Text = "Medium" Or bmp.Text = "متوسط" Then
            ll = "2"
        ElseIf bmp.Text = "Good" Or bmp.Text = "جيد" Then
            ll = "3"
        ElseIf bmp.Text = "Advanced" Or bmp.Text = "متقدم" Then
            ll = "4"
        ElseIf bmp.Text = "Very Good" Or bmp.Text = "جيد جدا" Then
            ll = "5"
        ElseIf bmp.Text = "Excellent" Or bmp.Text = "ممتاز" Then
            ll = "6"
        ElseIf bmp.Text = "Professional" Or bmp.Text = "محترف" Then
            ll = "7"
        End If
        bmpn(e)
    End Sub

    Sub zx1(ByVal e As EventArgs)
        If L2 = "0" Then
            If La1 = "0" Then
                z1.BackgroundImage = My.Resources.zx23
            Else
                z1.BackgroundImage = My.Resources.zx2
            End If
            If La2 = "0" Then
                z2.BackgroundImage = My.Resources.zx3
            Else
                z2.BackgroundImage = My.Resources.zx
            End If
            If La3 = "0" Then
                z3.BackgroundImage = My.Resources.zx3
            Else
                z3.BackgroundImage = My.Resources.zx
            End If
            a1.Visible = True
            a2.Visible = True
            a3.Visible = True
            L1 = "1"
        End If
    End Sub

    Sub zx2(ByVal e As EventArgs)
        If L2 = "0" Then
            If La1 = "0" Then
                z1.BackgroundImage = My.Resources.zx3
            Else
                z1.BackgroundImage = My.Resources.zx
            End If
            If La2 = "0" Then
                z2.BackgroundImage = My.Resources.zx23
            Else
                z2.BackgroundImage = My.Resources.zx2
            End If
            If La3 = "0" Then
                z3.BackgroundImage = My.Resources.zx3
            Else
                z3.BackgroundImage = My.Resources.zx
            End If
            a1.Visible = True
            a2.Visible = True
            a3.Visible = True
            L1 = "2"
        End If
    End Sub

    Sub zx3(ByVal e As EventArgs)
        If L2 = "0" Then
            If La1 = "0" Then
                z1.BackgroundImage = My.Resources.zx3
            Else
                z1.BackgroundImage = My.Resources.zx
            End If
            If La2 = "0" Then
                z2.BackgroundImage = My.Resources.zx3
            Else
                z2.BackgroundImage = My.Resources.zx
            End If
            If La3 = "0" Then
                z3.BackgroundImage = My.Resources.zx23
            Else
                z3.BackgroundImage = My.Resources.zx2
            End If
            a1.Visible = True
            a2.Visible = True
            a3.Visible = True
            L1 = "3"
        End If
    End Sub

    Sub cv1(ByVal e As EventArgs)
        If Cmpt.Checked = False Then
            If L2 = "1" Then
                If La7 = "0" Then
                    c1.BackgroundImage = My.Resources.cv23
                Else
                    c1.BackgroundImage = My.Resources.cv2
                End If
                If La8 = "0" Then
                    c2.BackgroundImage = My.Resources.cv3
                Else
                    c2.BackgroundImage = My.Resources.cv
                End If
                If La9 = "0" Then
                    c3.BackgroundImage = My.Resources.cv3
                Else
                    c3.BackgroundImage = My.Resources.cv
                End If
                a1.Visible = True
                a2.Visible = True
                a3.Visible = True
                L1 = "7"
            End If
        End If
    End Sub

    Sub cv2(ByVal e As EventArgs)
        If Cmpt.Checked = False Then
            If L2 = "1" Then
                If La7 = "0" Then
                    c1.BackgroundImage = My.Resources.cv3
                Else
                    c1.BackgroundImage = My.Resources.cv
                End If
                If La8 = "0" Then
                    c2.BackgroundImage = My.Resources.cv23
                Else
                    c2.BackgroundImage = My.Resources.cv2
                End If
                If La9 = "0" Then
                    c3.BackgroundImage = My.Resources.cv3
                Else
                    c3.BackgroundImage = My.Resources.cv
                End If
                a1.Visible = True
                a2.Visible = True
                a3.Visible = True
                L1 = "8"
            End If
        End If
    End Sub

    Sub cv3(ByVal e As EventArgs)
        If Cmpt.Checked = False Then
            If L2 = "1" Then
                If La7 = "0" Then
                    c1.BackgroundImage = My.Resources.cv3
                Else
                    c1.BackgroundImage = My.Resources.cv
                End If
                If La8 = "0" Then
                    c2.BackgroundImage = My.Resources.cv3
                Else
                    c2.BackgroundImage = My.Resources.cv
                End If
                If La9 = "0" Then
                    c3.BackgroundImage = My.Resources.cv23
                Else
                    c3.BackgroundImage = My.Resources.cv2
                End If
                a1.Visible = True
                a2.Visible = True
                a3.Visible = True
                L1 = "9"
            End If
        End If
    End Sub

    Sub ox1(ByVal e As EventArgs)
        If L2 = "0" Then
            PB1.BackgroundImage = My.Resources.zx
            OX.BackgroundImage = My.Resources.cv
        ElseIf L2 = "1" Then
            PB1.BackgroundImage = My.Resources.cv
            OX.BackgroundImage = My.Resources.zx
        End If
    End Sub

    Sub as1(ByVal e As EventArgs)
        If a1.Visible = True Then
            n0 += 2
            a1.Visible = False
            a2.Visible = False
            a3.Visible = False
            If L1 = "1" Then
                z1.BackgroundImage = My.Resources.zx
                lo = z1.Location : z1.Location = a1.Location : a1.Location = lo
                rt = Lab4 : Lab4 = Lab1 : Lab1 = rt
                La1 = "1"
                stp1.Text = stp1.Text + 1
                L2 = "1"
                n1 = n1 + "1 "
                Le1 += 1
            ElseIf L1 = "2" Then
                z2.BackgroundImage = My.Resources.zx
                lo = z2.Location : z2.Location = a1.Location : a1.Location = lo
                rt = Lab4 : Lab4 = Lab2 : Lab2 = rt
                La2 = "1"
                stp1.Text = stp1.Text + 1
                L2 = "1"
                n1 = n1 + "2 "
                Le2 += 1
            ElseIf L1 = "3" Then
                z3.BackgroundImage = My.Resources.zx
                lo = z3.Location : z3.Location = a1.Location : a1.Location = lo
                rt = Lab4 : Lab4 = Lab3 : Lab3 = rt
                La3 = "1"
                stp1.Text = stp1.Text + 1
                L2 = "1"
                n1 = n1 + "3 "
                Le3 += 1
            ElseIf L1 = "7" Then
                c1.BackgroundImage = My.Resources.cv
                lo = c1.Location : c1.Location = a1.Location : a1.Location = lo
                l47(e)
                La7 = "1"
                stp2.Text = stp2.Text + 1
                L2 = "0"
                n1 = n1 + "4 "
                Le7 += 1
            ElseIf L1 = "8" Then
                c2.BackgroundImage = My.Resources.cv
                lo = c2.Location : c2.Location = a1.Location : a1.Location = lo
                l48(e)
                La8 = "1"
                stp2.Text = stp2.Text + 1
                L2 = "0"
                n1 = n1 + "5 "
                Le8 += 1
            ElseIf L1 = "9" Then
                c3.BackgroundImage = My.Resources.cv
                lo = c3.Location : c3.Location = a1.Location : a1.Location = lo
                l49(e)
                La9 = "1"
                stp2.Text = stp2.Text + 1
                L2 = "0"
                n1 = n1 + "6 "
                Le9 += 1
            End If
            L1 = "0"
            r0 = -1 : r1 = ""
            rf(e) : ne(e) : ws(e) : Wn(e) : ox1(e)
        End If
    End Sub

    Sub as2(ByVal e As EventArgs)
        If a2.Visible = True Then
            n0 += 2
            a1.Visible = False
            a2.Visible = False
            a3.Visible = False
            If L1 = "1" Then
                z1.BackgroundImage = My.Resources.zx
                lo = z1.Location : z1.Location = a2.Location : a2.Location = lo
                rt = Lab5 : Lab5 = Lab1 : Lab1 = rt
                La1 = "1"
                stp1.Text = stp1.Text + 1
                L2 = "1"
                n1 = n1 + "7 "
                Le1 += 1
            ElseIf L1 = "2" Then
                z2.BackgroundImage = My.Resources.zx
                lo = z2.Location : z2.Location = a2.Location : a2.Location = lo
                rt = Lab5 : Lab5 = Lab2 : Lab2 = rt
                La2 = "1"
                stp1.Text = stp1.Text + 1
                L2 = "1"
                n1 = n1 + "8 "
                Le2 += 1
            ElseIf L1 = "3" Then
                z3.BackgroundImage = My.Resources.zx
                lo = z3.Location : z3.Location = a2.Location : a2.Location = lo
                rt = Lab5 : Lab5 = Lab3 : Lab3 = rt
                La3 = "1"
                stp1.Text = stp1.Text + 1
                L2 = "1"
                n1 = n1 + "9 "
                Le3 += 1
            ElseIf L1 = "7" Then
                c1.BackgroundImage = My.Resources.cv
                lo = c1.Location : c1.Location = a2.Location : a2.Location = lo
                l57(e)
                La7 = "1"
                stp2.Text = stp2.Text + 1
                L2 = "0"
                n1 = n1 + "10"
                Le7 += 1
            ElseIf L1 = "8" Then
                c2.BackgroundImage = My.Resources.cv
                lo = c2.Location : c2.Location = a2.Location : a2.Location = lo
                l58(e)
                La8 = "1"
                stp2.Text = stp2.Text + 1
                L2 = "0"
                n1 = n1 + "11"
                Le8 += 1
            ElseIf L1 = "9" Then
                c3.BackgroundImage = My.Resources.cv
                lo = c3.Location : c3.Location = a2.Location : a2.Location = lo
                l59(e)
                La9 = "1"
                stp2.Text = stp2.Text + 1
                L2 = "0"
                n1 = n1 + "12"
                Le9 += 1
            End If
            L1 = "0"
            r0 = -1 : r1 = ""
            rf(e) : ne(e) : ws(e) : Wn(e) : ox1(e)
        End If
    End Sub

    Sub as3(ByVal e As EventArgs)
        If a3.Visible = True Then
            n0 += 2
            a1.Visible = False
            a2.Visible = False
            a3.Visible = False
            If L1 = "1" Then
                z1.BackgroundImage = My.Resources.zx
                lo = z1.Location : z1.Location = a3.Location : a3.Location = lo
                rt = Lab6 : Lab6 = Lab1 : Lab1 = rt
                La1 = "1"
                stp1.Text = stp1.Text + 1
                L2 = "1"
                n1 = n1 + "13"
                Le1 += 1
            ElseIf L1 = "2" Then
                z2.BackgroundImage = My.Resources.zx
                lo = z2.Location : z2.Location = a3.Location : a3.Location = lo
                rt = Lab6 : Lab6 = Lab2 : Lab2 = rt
                La2 = "1"
                stp1.Text = stp1.Text + 1
                L2 = "1"
                n1 = n1 + "14"
                Le2 += 1
            ElseIf L1 = "3" Then
                z3.BackgroundImage = My.Resources.zx
                lo = z3.Location : z3.Location = a3.Location : a3.Location = lo
                rt = Lab6 : Lab6 = Lab3 : Lab3 = rt
                La3 = "1"
                stp1.Text = stp1.Text + 1
                L2 = "1"
                n1 = n1 + "15"
                Le3 += 1
            ElseIf L1 = "7" Then
                c1.BackgroundImage = My.Resources.cv
                lo = c1.Location : c1.Location = a3.Location : a3.Location = lo
                l67(e)
                La7 = "1"
                stp2.Text = stp2.Text + 1
                L2 = "0"
                n1 = n1 + "16"
                Le7 += 1
            ElseIf L1 = "8" Then
                c2.BackgroundImage = My.Resources.cv
                lo = c2.Location : c2.Location = a3.Location : a3.Location = lo
                l68(e)
                La8 = "1"
                stp2.Text = stp2.Text + 1
                L2 = "0"
                n1 = n1 + "17"
                Le8 += 1
            ElseIf L1 = "9" Then
                c3.BackgroundImage = My.Resources.cv
                lo = c3.Location : c3.Location = a3.Location : a3.Location = lo
                l69(e)
                La9 = "1"
                stp2.Text = stp2.Text + 1
                L2 = "0"
                n1 = n1 + "18"
                Le9 += 1
            End If
            L1 = "0"
            r0 = -1 : r1 = ""
            rf(e) : ne(e) : ws(e) : Wn(e) : ox1(e)
        End If
    End Sub

    Private Sub sgM(sender As Object, e As EventArgs) Handles MyBase.MouseEnter, MyClass.MouseEnter, Me.MouseEnter, PB1.MouseEnter, PB2.MouseEnter, PB4.MouseEnter, PB5.MouseEnter, PB6.MouseEnter, PB7.MouseEnter, PB8.MouseEnter, PB9.MouseEnter, P10.MouseEnter, P11.MouseEnter, wt.MouseEnter, plyr1.MouseEnter, plyr2.MouseEnter, nm1.MouseEnter, nm2.MouseEnter, wn1.MouseEnter, wn2.MouseEnter, stp1.MouseEnter, stp2.MouseEnter, Cmpt.MouseEnter, bmp.MouseEnter, ok1.MouseEnter, ok2.MouseEnter, VaH.MouseEnter, NoS.MouseEnter, CB1.MouseEnter, lns.MouseEnter, ns.MouseEnter, wlf.MouseEnter, Lf.MouseEnter, fst.MouseDown, nd.MouseEnter, rd.MouseEnter, rr.MouseEnter, rl.MouseEnter, rh.MouseEnter, rv.MouseEnter, sv.MouseEnter, ld.MouseEnter, sv1.MouseEnter, ld1.MouseEnter, Bu1.MouseEnter, Bu2.MouseEnter, Bu3.MouseEnter, Bu4.MouseEnter, Bu5.MouseEnter, Bu6.MouseEnter, Bu7.MouseEnter, Bu8.MouseEnter, Bu9.MouseEnter, B10.MouseEnter, B11.MouseEnter, XO.MouseEnter, OX.MouseEnter, a1.MouseDown, a2.MouseDown, a3.MouseDown, z1.Click, z2.Click, z3.Click, c1.Click, c2.Click, c3.Click
        If Ldu = "1" Then
            Ldu = "0"
        End If
    End Sub

    Private Sub z1_Click(sender As Object, e As MouseEventArgs) Handles z1.MouseDown
        If L2 = "0" Then
            Ldu = "1"
            zx1(e)
        Else
            Ldu = "0"
        End If
    End Sub

    Private Sub z2_Click(sender As Object, e As MouseEventArgs) Handles z2.MouseDown
        If L2 = "0" Then
            Ldu = "1"
            zx2(e)
        Else
            Ldu = "0"
        End If
    End Sub

    Private Sub z3_Click(sender As Object, e As MouseEventArgs) Handles z3.MouseDown
        If L2 = "0" Then
            Ldu = "1"
            zx3(e)
        Else
            Ldu = "0"
        End If
    End Sub

    Private Sub c1_Click(sender As Object, e As MouseEventArgs) Handles c1.MouseDown
        If L2 = "1" And Cmpt.Checked = False Then
            Ldu = "1"
            cv1(e)
        Else
            Ldu = "0"
        End If
    End Sub

    Private Sub c2_Click(sender As Object, e As MouseEventArgs) Handles c2.MouseDown
        If L2 = "1" And Cmpt.Checked = False Then
            Ldu = "1"
            cv2(e)
        Else
            Ldu = "0"
        End If
    End Sub

    Private Sub c3_Click(sender As Object, e As MouseEventArgs) Handles c3.MouseDown
        If L2 = "1" And Cmpt.Checked = False Then
            Ldu = "1"
            cv3(e)
        Else
            Ldu = "0"
        End If
    End Sub

    Private Sub a1_Click(sender As Object, e As EventArgs) Handles a1.Click
        as1(e)
    End Sub

    Private Sub a1_Clic(sender As Object, e As EventArgs) Handles a1.MouseMove, a1.MouseEnter, a1.MouseHover
        If Ldu = "1" Then
            as1(e)
        End If
    End Sub

    Private Sub a2_Click(sender As Object, e As EventArgs) Handles a2.Click
        as2(e)
    End Sub

    Private Sub a2_Clic(sender As Object, e As EventArgs) Handles a2.MouseMove, a2.MouseEnter, a2.MouseHover
        If Ldu = "1" Then
            as2(e)
        End If
    End Sub

    Private Sub a3_Click(sender As Object, e As EventArgs) Handles a3.Click
        as3(e)
    End Sub

    Private Sub a3_Clic(sender As Object, e As EventArgs) Handles a3.MouseMove, a3.MouseEnter, a3.MouseHover
        If Ldu = "1" Then
            as3(e)
        End If
    End Sub

    Private Sub Bu2_Click(sender As Object, e As EventArgs) Handles Bu2.Click
        Res(e)
    End Sub

    Private Sub Bu1_Click(sender As Object, e As EventArgs) Handles Bu1.Click
        If Bu8.Text = "English" Then
            Sega2.Text = "حول"
            Sega2.ckh.Text = "إضغط هنا  لتحميل آخر إصدار من اللعبة"
            Sega2.ckh.Location = New Point(120, 9)
        End If
        Sega2.Show()
    End Sub

    Sub ne(ByVal e As EventArgs)
        nd.Enabled = True
        nd.BackgroundImage = My.Resources.nd
    End Sub

    Sub re(ByVal e As EventArgs)
        rd.Enabled = True
        rd.BackgroundImage = My.Resources.rd
    End Sub

    Sub nf(ByVal e As EventArgs)
        nd.Enabled = False
        nd.BackgroundImage = My.Resources.undo
    End Sub

    Sub rf(ByVal e As EventArgs)
        rd.Enabled = False
        rd.BackgroundImage = My.Resources.redo
    End Sub

    Private Sub NoS_Click(sender As Object, e As EventArgs) Handles NoS.Click
        Bn(e)
    End Sub

    Sub Bn(ByVal e As EventArgs)
        If NoS.Checked = True Then
            If Bu8.Text = "عربي" Then
                If MsgBox(("- If you activate this feature, the number of steps of both players must be equal to win one of you.
- No one likes this feature because it is difficult and boring ...
- Are you sure you want to enable this feature ?!"), vbYesNo + vbQuestion, "Warning...") = MsgBoxResult.Yes Then
                Else
                    NoS.Checked = False
                End If
            Else
                If MsgBox(("- لو قمت بتفعيل هذه الخاصية،  يجب ان تكون عدد خطوات كلا اللاعبين متساوية ليفوز واحد منكما.
- لا احد يحب هذه الخاصية لأنها صعبة ومملة ...
- هل انت متأكد من انك تريد تفعيل هذه الخاصية ?!"), vbYesNo + vbQuestion + vbMsgBoxRight + vbMsgBoxRtlReading, "تحذير...") = MsgBoxResult.Yes Then
                Else
                    NoS.Checked = False
                End If
            End If
            If L3 = "0" Or L3 = "1" Then
                Wn(e)
            End If
        Else
            Wn(e)
        End If
    End Sub

    Private Sub NoS_CheckedChanged(sender As Object, e As EventArgs) Handles NoS.CheckedChanged
        If NoS.Checked = True Then
            stp1.Visible = True
            stp2.Visible = True
        Else
            stp1.Visible = False
            stp2.Visible = False
        End If
    End Sub

    Sub Ros(ByVal e As EventArgs)
        La1 = "0" : La2 = "0" : La3 = "0" : La7 = "0" : La8 = "0" : La9 = "0"
        Lab1 = "1" : Lab2 = "2" : Lab3 = "3" : Lab4 = "4" : Lab5 = "5" : Lab6 = "6" : Lab7 = "7" : Lab8 = "8" : Lab9 = "9"
        Le1 = "0" : Le2 = "0" : Le3 = "0" : Le7 = "0" : Le8 = "0" : Le9 = "0"
        L1 = "0"
        lo = New Point(0, 0)
    End Sub

    Sub Res(ByVal e As EventArgs)
        If bl = "0" Then
            Ros(e)
            If sf = "2" Then
                La1 = "1" : La2 = "1" : La3 = "1" : La7 = "1" : La8 = "1" : La9 = "1"
                Lab1 = "1" : Lab2 = "8" : Lab3 = "3" : Lab4 = "4" : Lab5 = "5" : Lab6 = "6" : Lab7 = "7" : Lab8 = "2" : Lab9 = "9"
                Le1 = "1" : Le2 = "1" : Le3 = "1" : Le7 = "1" : Le8 = "1" : Le9 = "1"
            ElseIf sf = "3" Then
                La1 = "1" : La2 = "1" : La3 = "1" : La7 = "1" : La8 = "1" : La9 = "1"
                Lab1 = "2" : Lab2 = "4" : Lab3 = "9" : Lab4 = "3" : Lab5 = "5" : Lab6 = "7" : Lab7 = "1" : Lab8 = "6" : Lab9 = "8"
                Le1 = "1" : Le2 = "1" : Le3 = "1" : Le7 = "1" : Le8 = "1" : Le9 = "1"
            End If
            stp1.Text = "0" : stp2.Text = "0"
            n0 = "-1" : r0 = "-1"
            n1 = "" : r1 = ""
            If ok1.Checked = True And ok2.Checked = True Then
                o1 = "1"
                ok1.Text = "OK +1"
                ok2.Text = "OK +1"
            Else
                o1 = "0"
                ok1.Text = "OK"
                ok2.Text = "OK"
            End If
            If Bu8.Text = "English" Then
                ok1.Text = ok1.Text.Replace("OK", "موافق")
                ok2.Text = ok2.Text.Replace("OK", "موافق")
            End If
            loc(e) : nf(e) : rf(e)
            If Bu8.Text = "عربي" Then
                Bu4.Text = "Start"
            Else
                Bu4.Text = "إبدأ"
            End If
            T1.Stop()
            L2 = L22
            If L22 = "3" Then
                Bu4.Visible = True
                PB1.BackgroundImage = Nothing
            Else
                Bu4.Visible = False
                ox1(e)
            End If
            L3 = "2"
        End If
    End Sub

    Sub wn19(ByVal e As EventArgs)
        If (La1 = "1" And La2 = "1" And La3 = "1") And (((Lab1 = "1" Or Lab2 = "1" Or Lab3 = "1") And (Lab1 = "2" Or Lab2 = "2" Or Lab3 = "2") And (Lab1 = "3" Or Lab2 = "3" Or Lab3 = "3")) Or ((Lab1 = "4" Or Lab2 = "4" Or Lab3 = "4") And (Lab1 = "5" Or Lab2 = "5" Or Lab3 = "5") And (Lab1 = "6" Or Lab2 = "6" Or Lab3 = "6")) Or ((Lab1 = "7" Or Lab2 = "7" Or Lab3 = "7") And (Lab1 = "8" Or Lab2 = "8" Or Lab3 = "8") And (Lab1 = "9" Or Lab2 = "9" Or Lab3 = "9")) Or ((Lab1 = "1" Or Lab2 = "1" Or Lab3 = "1") And (Lab1 = "4" Or Lab2 = "4" Or Lab3 = "4") And (Lab1 = "7" Or Lab2 = "7" Or Lab3 = "7")) Or ((Lab1 = "2" Or Lab2 = "2" Or Lab3 = "2") And (Lab1 = "5" Or Lab2 = "5" Or Lab3 = "5") And (Lab1 = "8" Or Lab2 = "8" Or Lab3 = "8")) Or ((Lab1 = "3" Or Lab2 = "3" Or Lab3 = "3") And (Lab1 = "6" Or Lab2 = "6" Or Lab3 = "6") And (Lab1 = "9" Or Lab2 = "9" Or Lab3 = "9")) Or ((VaH.Checked = False) And (((Lab1 = "1" Or Lab2 = "1" Or Lab3 = "1") And (Lab1 = "5" Or Lab2 = "5" Or Lab3 = "5") And (Lab1 = "9" Or Lab2 = "9" Or Lab3 = "9")) Or ((Lab1 = "3" Or Lab2 = "3" Or Lab3 = "3") And (Lab1 = "5" Or Lab2 = "5" Or Lab3 = "5") And (Lab1 = "7" Or Lab2 = "7" Or Lab3 = "7"))))) Then
            lwz = "0"
        Else
            lwz = "2"
        End If
        If (La7 = "1" And La8 = "1" And La9 = "1") And (((Lab7 = "1" Or Lab8 = "1" Or Lab9 = "1") And (Lab7 = "2" Or Lab8 = "2" Or Lab9 = "2") And (Lab7 = "3" Or Lab8 = "3" Or Lab9 = "3")) Or ((Lab7 = "4" Or Lab8 = "4" Or Lab9 = "4") And (Lab7 = "5" Or Lab8 = "5" Or Lab9 = "5") And (Lab7 = "6" Or Lab8 = "6" Or Lab9 = "6")) Or ((Lab7 = "7" Or Lab8 = "7" Or Lab9 = "7") And (Lab7 = "8" Or Lab8 = "8" Or Lab9 = "8") And (Lab7 = "9" Or Lab8 = "9" Or Lab9 = "9")) Or ((Lab7 = "1" Or Lab8 = "1" Or Lab9 = "1") And (Lab7 = "4" Or Lab8 = "4" Or Lab9 = "4") And (Lab7 = "7" Or Lab8 = "7" Or Lab9 = "7")) Or ((Lab7 = "2" Or Lab8 = "2" Or Lab9 = "2") And (Lab7 = "5" Or Lab8 = "5" Or Lab9 = "5") And (Lab7 = "8" Or Lab8 = "8" Or Lab9 = "8")) Or ((Lab7 = "3" Or Lab8 = "3" Or Lab9 = "3") And (Lab7 = "6" Or Lab8 = "6" Or Lab9 = "6") And (Lab7 = "9" Or Lab8 = "9" Or Lab9 = "9")) Or ((VaH.Checked = False) And (((Lab7 = "1" Or Lab8 = "1" Or Lab9 = "1") And (Lab7 = "5" Or Lab8 = "5" Or Lab9 = "5") And (Lab7 = "9" Or Lab8 = "9" Or Lab9 = "9")) Or ((Lab7 = "3" Or Lab8 = "3" Or Lab9 = "3") And (Lab7 = "5" Or Lab8 = "5" Or Lab9 = "5") And (Lab7 = "7" Or Lab8 = "7" Or Lab9 = "7"))))) Then
            lwc = "1"
        Else
            lwc = "2"
        End If
    End Sub

    Sub wn37(ByVal e As EventArgs)
        If flw = "1" Then
            If lwz = "0" Then
                L2 = "0"
                L22 = "0"
            Else
                L2 = "1"
                L22 = "1"
            End If
        ElseIf flw = "2" Then
            If lwz = "0" Then
                L2 = "1"
                L22 = "1"
            Else
                L2 = "0"
                L22 = "0"
            End If
        ElseIf flw = "3" Then
            If L22 = "0" Then
                L2 = "1"
                L22 = "1"
            Else
                L2 = "0"
                L22 = "0"
            End If
        ElseIf flw = "4" Then
            Bu4.Visible = True
            L222 = "0" : L22 = "3" : L2 = "3"
            sv.Enabled = False
            sv1.Visible = False
            Bu9.Visible = False
            XO.Visible = False
            OX.Visible = False
            CB1.Visible = False
            CB1.Checked = False
            CB1.Appearance = Appearance.Button
            qu = "0"
            hp.Visible = False
            ok1.Visible = False
            ok2.Visible = False
            PB1.BackgroundImage = Nothing
        ElseIf flw = "5" Then
            Dim rand = New Random
            Dim x As Integer
            x = rand.Next(0, 2)
            Dim z As String = x
            If z = "0" Then
                L2 = "0"
                L22 = "0"
            Else
                L2 = "1"
                L22 = "1"
            End If
        End If
    End Sub

    Sub wlfn(ByVal e As EventArgs)
        If flw = "1" Then
            If Bu8.Text = "عربي" Then
                wlf.Text = "The winner plays first"
            Else
                wlf.Text = "الفائز يلعب أولا"
            End If
        ElseIf flw = "2" Then
            If Bu8.Text = "عربي" Then
                wlf.Text = "The loser plays first"
            Else
                wlf.Text = "الخاسر يلعب أولا"
            End If
        ElseIf flw = "3" Then
            If Bu8.Text = "عربي" Then
                wlf.Text = "Who played first, plays second next time"
            Else
                wlf.Text = "الذي لعب أولا يلعب آخرا المرة القادمة"
            End If
        ElseIf flw = "4" Then
            If Bu8.Text = "عربي" Then
                wlf.Text = "Choose who will play first by lot"
            Else
                wlf.Text = "إختيار من سيلعب أولا بالقرعة"
            End If
        ElseIf flw = "5" Then
            If Bu8.Text = "عربي" Then
                wlf.Text = "Choose who will play first automatically"
            Else
                wlf.Text = "إختيار من سيلعب أولا تلقائيا"
            End If
        End If
    End Sub

    Private Sub wlf_TextChanged(sender As Object, e As EventArgs) Handles wlf.TextChanged
        wlfn(e)
    End Sub

    Private Sub wlf_SelectedIndexChanged(sender As Object, e As EventArgs) Handles wlf.SelectedIndexChanged
        If wlf.Text = "The winner plays first" Or wlf.Text = "الفائز يلعب أولا" Then
            flw = "1"
        ElseIf wlf.Text = "The loser plays first" Or wlf.Text = "الخاسر يلعب أولا" Then
            flw = "2"
        ElseIf wlf.Text = "Who played first, plays second next time" Or wlf.Text = "الذي لعب أولا يلعب آخرا المرة القادمة" Then
            flw = "3"
        ElseIf wlf.Text = "Choose who will play first by lot" Or wlf.Text = "إختيار من سيلعب أولا بالقرعة" Then
            flw = "4"
        ElseIf wlf.Text = "Choose who will play first automatically" Or wlf.Text = "إختيار من سيلعب أولا تلقائيا" Then
            flw = "5"
        End If
        wlfn(e)
    End Sub

    Sub Wn(ByVal e As EventArgs)
        wn19(e)
        If NoS.Checked = False Or (NoS.Checked = True And stp1.Text = stp2.Text And L3 = "2") Then
            If lwz = "0" And lwc = "2" Then
                wn1.Text = wn1.Text + 1
                z1.BackgroundImage = My.Resources.zx4
                z2.BackgroundImage = My.Resources.zx4
                z3.BackgroundImage = My.Resources.zx4
                If nm1.Text = "" Then
                    If Cmpt.Checked = True Then
                        If Bu8.Text = "عربي" Then
                            MsgBox(("You won, Player"), vbInformation, "Excellent")
                        Else
                            MsgBox(("انت فزت يا Player"), vbInformation + vbMsgBoxRight + vbMsgBoxRtlReading, "ممتاز")
                        End If
                    Else
                        If Bu8.Text = "عربي" Then
                            MsgBox(("You won, Player1"), vbInformation, "Excellent")
                        Else
                            MsgBox(("انت فزت يا Player1"), vbInformation + vbMsgBoxRight + vbMsgBoxRtlReading, "ممتاز")
                        End If
                    End If
                Else
                    If Bu8.Text = "عربي" Then
                        MsgBox(("You won, " + nm1.Text), vbInformation, "Excellent")
                    Else
                        MsgBox(("انت فزت يا " + nm1.Text), vbInformation + vbMsgBoxRight + vbMsgBoxRtlReading, "ممتاز")
                    End If
                End If
                wn37(e)
                Res(e)
            End If
            If lwc = "1" And lwz = "2" Then
                wn2.Text = wn2.Text + 1
                c1.BackgroundImage = My.Resources.cv4
                c2.BackgroundImage = My.Resources.cv4
                c3.BackgroundImage = My.Resources.cv4
                If nm2.Text = "" Then
                    If Cmpt.Checked = True Then
                        If Bu8.Text = "عربي" Then
                            MsgBox(("You won, Computer"), vbInformation, "Excellent")
                        Else
                            MsgBox(("انت فزت يا Computer"), vbInformation + vbMsgBoxRight + vbMsgBoxRtlReading, "ممتاز")
                        End If
                    Else
                        If Bu8.Text = "عربي" Then
                            MsgBox(("You won, Player2"), vbInformation, "Excellent")
                        Else
                            MsgBox(("انت فزت يا Player2"), vbInformation + vbMsgBoxRight + vbMsgBoxRtlReading, "ممتاز")
                        End If
                    End If
                Else
                    If Bu8.Text = "عربي" Then
                        MsgBox(("You won, " + nm2.Text), vbInformation, "Excellent")
                    Else
                        MsgBox(("انت فزت يا " + nm2.Text), vbInformation + vbMsgBoxRight + vbMsgBoxRtlReading, "ممتاز")
                    End If
                End If
                wn37(e)
                Res(e)
            End If
        ElseIf (stp1.Text IsNot stp2.Text) And NoS.Checked = True And L3 = "2" Then
            If lwz = "0" Then
                If stp1.Text = stp2.Text + 1 And L2 = "1" Then
                    L3 = "0"
                End If
                z1.BackgroundImage = My.Resources.zx4
                z2.BackgroundImage = My.Resources.zx4
                z3.BackgroundImage = My.Resources.zx4
            End If
            If lwc = "1" Then
                If stp2.Text = stp1.Text + 1 And L2 = "0" Then
                    L3 = "1"
                End If
                c1.BackgroundImage = My.Resources.cv4
                c2.BackgroundImage = My.Resources.cv4
                c3.BackgroundImage = My.Resources.cv4
            End If
        ElseIf L3 = "0" Or L3 = "1" Then
            If stp1.Text = stp2.Text Then
                If L3 = "0" Then
                    If lwc = "1" Then
                        La1 = "0" : La2 = "0" : La3 = "0" : La7 = "0" : La8 = "0" : La9 = "0"
                        n0 = "-1" : r0 = "-1"
                        n1 = "" : r1 = ""
                        Le1 = "0" : Le2 = "0" : Le3 = "0" : Le7 = "0" : Le8 = "0" : Le9 = "0"
                        nf(e)
                        rf(e)
                        L3 = "2"
                        z1.BackgroundImage = My.Resources.zx3
                        z2.BackgroundImage = My.Resources.zx3
                        z3.BackgroundImage = My.Resources.zx3
                        c1.BackgroundImage = My.Resources.cv3
                        c2.BackgroundImage = My.Resources.cv3
                        c3.BackgroundImage = My.Resources.cv3
                        If sn = "1" Then
                            L2 = "0"
                            PB1.BackgroundImage = My.Resources.zx
                            OX.BackgroundImage = My.Resources.cv
                        Else
                            L2 = "1"
                            PB1.BackgroundImage = My.Resources.cv
                            OX.BackgroundImage = My.Resources.zx
                        End If
                    Else
                        wn1.Text = wn1.Text + 1
                        If nm1.Text = "" Then
                            If Cmpt.Checked = True Then
                                If Bu8.Text = "عربي" Then
                                    MsgBox(("You won, Player"), vbInformation, "Excellent")
                                Else
                                    MsgBox(("انت فزت يا Player"), vbInformation + vbMsgBoxRight + vbMsgBoxRtlReading, "ممتاز")
                                End If
                            Else
                                If Bu8.Text = "عربي" Then
                                    MsgBox(("You won, Player1"), vbInformation, "Excellent")
                                Else
                                    MsgBox(("انت فزت يا Player1"), vbInformation + vbMsgBoxRight + vbMsgBoxRtlReading, "ممتاز")
                                End If
                            End If
                        Else
                            If Bu8.Text = "عربي" Then
                                MsgBox(("You won, " + nm1.Text), vbInformation, "Excellent")
                            Else
                                MsgBox(("انت فزت يا " + nm1.Text), vbInformation + vbMsgBoxRight + vbMsgBoxRtlReading, "ممتاز")
                            End If
                        End If
                        wn37(e)
                        Res(e)
                    End If
                ElseIf L3 = "1" Then
                    If lwz = "0" Then
                        La1 = "0" : La2 = "0" : La3 = "0" : La7 = "0" : La8 = "0" : La9 = "0"
                        n0 = "-1" : r0 = "-1"
                        n1 = "" : r1 = ""
                        Le1 = "0" : Le2 = "0" : Le3 = "0" : Le7 = "0" : Le8 = "0" : Le9 = "0"
                        nf(e)
                        rf(e)
                        L3 = "2"
                        z1.BackgroundImage = My.Resources.zx3
                        z2.BackgroundImage = My.Resources.zx3
                        z3.BackgroundImage = My.Resources.zx3
                        c1.BackgroundImage = My.Resources.cv3
                        c2.BackgroundImage = My.Resources.cv3
                        c3.BackgroundImage = My.Resources.cv3
                        If sn = "1" Then
                            L2 = "1"
                            PB1.BackgroundImage = My.Resources.cv
                            OX.BackgroundImage = My.Resources.zx
                        Else
                            L2 = "0"
                            PB1.BackgroundImage = My.Resources.zx
                            OX.BackgroundImage = My.Resources.cv
                        End If
                    Else
                        wn2.Text = wn2.Text + 1
                        If nm2.Text = "" Then
                            If Cmpt.Checked = True Then
                                If Bu8.Text = "عربي" Then
                                    MsgBox(("You won, Computer"), vbInformation, "Excellent")
                                Else
                                    MsgBox(("انت فزت يا Computer"), vbInformation + vbMsgBoxRight + vbMsgBoxRtlReading, "ممتاز")
                                End If
                            Else
                                If Bu8.Text = "عربي" Then
                                    MsgBox(("You won, Player2"), vbInformation, "Excellent")
                                Else
                                    MsgBox(("انت فزت يا Player2"), vbInformation + vbMsgBoxRight + vbMsgBoxRtlReading, "ممتاز")
                                End If
                            End If
                        Else
                            If Bu8.Text = "عربي" Then
                                MsgBox(("You won, " + nm2.Text), vbInformation, "Excellent")
                            Else
                                MsgBox(("انت فزت يا " + nm2.Text), vbInformation + vbMsgBoxRight + vbMsgBoxRtlReading, "ممتاز")
                            End If
                        End If
                        wn37(e)
                        Res(e)
                    End If
                End If
            Else
                L3 = "2"
                Wn(e)
            End If
        End If
    End Sub

    Private Sub VaH_CheckedChanged(sender As Object, e As EventArgs) Handles VaH.CheckedChanged
        If VaH.Checked = False Then
            If L3 = "2" Then
                Wn(e)
            End If
        Else
            If (((Lab1 = "1" Or Lab2 = "1" Or Lab3 = "1") And (Lab1 = "5" Or Lab2 = "5" Or Lab3 = "5") And (Lab1 = "9" Or Lab2 = "9" Or Lab3 = "9")) Or ((Lab1 = "3" Or Lab2 = "3" Or Lab3 = "3") And (Lab1 = "5" Or Lab2 = "5" Or Lab3 = "5") And (Lab1 = "7" Or Lab2 = "7" Or Lab3 = "7"))) Or (((Lab7 = "1" Or Lab8 = "1" Or Lab9 = "1") And (Lab7 = "5" Or Lab8 = "5" Or Lab9 = "5") And (Lab7 = "9" Or Lab8 = "9" Or Lab9 = "9")) Or ((Lab7 = "3" Or Lab8 = "3" Or Lab9 = "3") And (Lab7 = "5" Or Lab8 = "5" Or Lab9 = "5") And (Lab7 = "7" Or Lab8 = "7" Or Lab9 = "7"))) Then
                L3 = "2"
                loc(e)
            End If
        End If
    End Sub

    Private Sub Bu3_Click(sender As Object, e As EventArgs) Handles Bu3.Click
        B3(e)
    End Sub

    Sub B3(ByVal e As EventArgs)
        If bl = "0" Then
            sf = "1"
            Res(e)
            wn1.Text = "0"
            wn2.Text = "0"
            L2 = "3"
            L22 = "3"
            PB1.BackgroundImage = Nothing
            sv.Enabled = False
            sv1.Visible = False
            If Bu4.Visible = True Then
                nm1.Text = "Player1"
                nm2.Text = "Player2"
                VaH.Checked = True
                Cmpt.Checked = False
            End If
            Bu4.Visible = True
            NoS.Checked = False
            Bu9.Visible = False
            XO.Visible = False
            OX.Visible = False
            CB1.Visible = False
            CB1.Checked = False
            CB1.Appearance = Appearance.Button
            qu = "0"
            hp.Visible = False
            ok1.Visible = False
            ok2.Visible = False
            im1.Visible = True
            im2.Visible = True
            im3.Visible = True
            RB1.Visible = True
            RB2.Visible = True
            RB3.Visible = True
            ws(e)
        End If
    End Sub

    Private Sub Bu4_Click(sender As Object, e As EventArgs) Handles Bu4.Click
        B4(e)
    End Sub

    Sub B4(ByVal e As EventArgs)
        If Bu4.Text = "Start" Or Bu4.Text = "إبدأ" Then
            If Bu8.Text = "عربي" Then
                Bu4.Text = "Stop"
            Else
                Bu4.Text = "توقف"
            End If
            Dim rand = New Random
            Dim x As Integer
            x = rand.Next(0, 2)
            L222 = x
            If L222 = "0" Then
                PB1.BackgroundImage = My.Resources.zx
            ElseIf L222 = "1" Then
                PB1.BackgroundImage = My.Resources.cv
            End If
            T1.Start()
        Else
            T1.Stop()
            Bu4.Visible = False
            If Bu8.Text = "عربي" Then
                Bu4.Text = "Start"
            Else
                Bu4.Text = "إبدأ"
            End If
            L2 = L222
            L22 = L222
            L222 = "3"
            Bu9.Visible = True
            ox1(e)
            CB1.Visible = True
            hp.Visible = True
            ok1.Visible = True
            ok2.Visible = True
            hp.Visible = True
            If ok2.Checked = False And Cmpt.Checked = True Then
                ok2.Checked = True
            End If
            im1.Visible = False
            im2.Visible = False
            im3.Visible = False
            RB1.Visible = False
            RB2.Visible = False
            RB3.Visible = False
            sv.Enabled = True
            If sfh = "2" Then
                sv1.Visible = True
            End If
        End If
    End Sub

    Private Sub T1_Tick(sender As Object, e As EventArgs) Handles T1.Tick
        If L222 = "0" Then
            L222 = "1"
            PB1.BackgroundImage = My.Resources.cv
        ElseIf L222 = "1" Then
            L222 = "0"
            PB1.BackgroundImage = My.Resources.zx
        End If
    End Sub

    Sub lcn2(ByVal e As EventArgs)
        If nm2.Text = "Player2" Or nm2.Text = "" Then
            nm2.Text = "Computer"
        End If
        If nm1.Text = "Player1" Or nm1.Text = "" Then
            nm1.Text = "Player"
        End If
    End Sub

    Sub lcn1(ByVal e As EventArgs)
        If nm2.Text = "Computer" Or nm2.Text = "" Then
            nm2.Text = "Player2"
        End If
        If nm1.Text = "Player" Or nm1.Text = "" Then
            nm1.Text = "Player1"
        End If
    End Sub

    Private Sub Cmpt_CheckedChanged(sender As Object, e As EventArgs) Handles Cmpt.CheckedChanged
        If bl = "0" Then
            If Cmpt.Checked = True Then
                If L2 = "1" Then
                    L1 = "0"
                    a1.Visible = False
                    a2.Visible = False
                    a3.Visible = False
                End If
                lcn2(e)
                ok2.Enabled = False
                If ok2.Visible = True Then
                    ok2.Checked = True
                End If
                T3.Start()
            Else
                lcn1(e)
                ok2.Enabled = True
                T2.Stop()
                T3.Stop()
            End If
        Else
            Cmpt.Checked = True
        End If
    End Sub

    Sub loc(ByVal e As EventArgs)
        If La7 = "1" Then
            If L1 = "7" Then
                c1.BackgroundImage = My.Resources.cv2
            Else
                c1.BackgroundImage = My.Resources.cv
            End If
        Else
            If L1 = "7" Then
                c1.BackgroundImage = My.Resources.cv23
            Else
                c1.BackgroundImage = My.Resources.cv3
            End If
        End If
        If La8 = "1" Then
            If L1 = "8" Then
                c2.BackgroundImage = My.Resources.cv2
            Else
                c2.BackgroundImage = My.Resources.cv
            End If
        Else
            If L1 = "8" Then
                c2.BackgroundImage = My.Resources.cv23
            Else
                c2.BackgroundImage = My.Resources.cv3
            End If
        End If
        If La9 = "1" Then
            If L1 = "9" Then
                c3.BackgroundImage = My.Resources.cv2
            Else
                c3.BackgroundImage = My.Resources.cv
            End If
        Else
            If L1 = "9" Then
                c3.BackgroundImage = My.Resources.cv23
            Else
                c3.BackgroundImage = My.Resources.cv3
            End If
        End If
        If La1 = "1" Then
            If L1 = "1" Then
                z1.BackgroundImage = My.Resources.zx2
            Else
                z1.BackgroundImage = My.Resources.zx
            End If
        Else
            If L1 = "1" Then
                z1.BackgroundImage = My.Resources.zx23
            Else
                z1.BackgroundImage = My.Resources.zx3
            End If
        End If
        If La2 = "1" Then
            If L1 = "2" Then
                z2.BackgroundImage = My.Resources.zx2
            Else
                z2.BackgroundImage = My.Resources.zx
            End If
        Else
            If L1 = "2" Then
                z2.BackgroundImage = My.Resources.zx23
            Else
                z2.BackgroundImage = My.Resources.zx3
            End If
        End If
        If La3 = "1" Then
            If L1 = "3" Then
                z3.BackgroundImage = My.Resources.zx2
            Else
                z3.BackgroundImage = My.Resources.zx
            End If
        Else
            If L1 = "3" Then
                z3.BackgroundImage = My.Resources.zx23
            Else
                z3.BackgroundImage = My.Resources.zx3
            End If
        End If
        If L1 = "0" Then
            a1.Visible = False
            a2.Visible = False
            a3.Visible = False
        Else
            a1.Visible = True
            a2.Visible = True
            a3.Visible = True
        End If
        Dim p1 As New Point(77, 80)
        Dim p2 As New Point(195, 80)
        Dim p3 As New Point(314, 80)
        Dim p4 As New Point(77, 192)
        Dim p5 As New Point(195, 192)
        Dim p6 As New Point(314, 192)
        Dim p7 As New Point(77, 304)
        Dim p8 As New Point(195, 304)
        Dim p9 As New Point(314, 304)
        If Lab7 = "1" Then
            c1.Location = p1
        ElseIf Lab7 = "2" Then
            c1.Location = p2
        ElseIf Lab7 = "3" Then
            c1.Location = p3
        ElseIf Lab7 = "4" Then
            c1.Location = p4
        ElseIf Lab7 = "5" Then
            c1.Location = p5
        ElseIf Lab7 = "6" Then
            c1.Location = p6
        ElseIf Lab7 = "7" Then
            c1.Location = p7
        ElseIf Lab7 = "8" Then
            c1.Location = p8
        ElseIf Lab7 = "9" Then
            c1.Location = p9
        End If
        If Lab8 = "1" Then
            c2.Location = p1
        ElseIf Lab8 = "2" Then
            c2.Location = p2
        ElseIf Lab8 = "3" Then
            c2.Location = p3
        ElseIf Lab8 = "4" Then
            c2.Location = p4
        ElseIf Lab8 = "5" Then
            c2.Location = p5
        ElseIf Lab8 = "6" Then
            c2.Location = p6
        ElseIf Lab8 = "7" Then
            c2.Location = p7
        ElseIf Lab8 = "8" Then
            c2.Location = p8
        ElseIf Lab8 = "9" Then
            c2.Location = p9
        End If
        If Lab9 = "1" Then
            c3.Location = p1
        ElseIf Lab9 = "2" Then
            c3.Location = p2
        ElseIf Lab9 = "3" Then
            c3.Location = p3
        ElseIf Lab9 = "4" Then
            c3.Location = p4
        ElseIf Lab9 = "5" Then
            c3.Location = p5
        ElseIf Lab9 = "6" Then
            c3.Location = p6
        ElseIf Lab9 = "7" Then
            c3.Location = p7
        ElseIf Lab9 = "8" Then
            c3.Location = p8
        ElseIf Lab9 = "9" Then
            c3.Location = p9
        End If
        If Lab1 = "1" Then
            z1.Location = p1
        ElseIf Lab1 = "2" Then
            z1.Location = p2
        ElseIf Lab1 = "3" Then
            z1.Location = p3
        ElseIf Lab1 = "4" Then
            z1.Location = p4
        ElseIf Lab1 = "5" Then
            z1.Location = p5
        ElseIf Lab1 = "6" Then
            z1.Location = p6
        ElseIf Lab1 = "7" Then
            z1.Location = p7
        ElseIf Lab1 = "8" Then
            z1.Location = p8
        ElseIf Lab1 = "9" Then
            z1.Location = p9
        End If
        If Lab2 = "1" Then
            z2.Location = p1
        ElseIf Lab2 = "2" Then
            z2.Location = p2
        ElseIf Lab2 = "3" Then
            z2.Location = p3
        ElseIf Lab2 = "4" Then
            z2.Location = p4
        ElseIf Lab2 = "5" Then
            z2.Location = p5
        ElseIf Lab2 = "6" Then
            z2.Location = p6
        ElseIf Lab2 = "7" Then
            z2.Location = p7
        ElseIf Lab2 = "8" Then
            z2.Location = p8
        ElseIf Lab2 = "9" Then
            z2.Location = p9
        End If
        If Lab3 = "1" Then
            z3.Location = p1
        ElseIf Lab3 = "2" Then
            z3.Location = p2
        ElseIf Lab3 = "3" Then
            z3.Location = p3
        ElseIf Lab3 = "4" Then
            z3.Location = p4
        ElseIf Lab3 = "5" Then
            z3.Location = p5
        ElseIf Lab3 = "6" Then
            z3.Location = p6
        ElseIf Lab3 = "7" Then
            z3.Location = p7
        ElseIf Lab3 = "8" Then
            z3.Location = p8
        ElseIf Lab3 = "9" Then
            z3.Location = p9
        End If
        If Lab4 = "1" Then
            a1.Location = p1
        ElseIf Lab4 = "2" Then
            a1.Location = p2
        ElseIf Lab4 = "3" Then
            a1.Location = p3
        ElseIf Lab4 = "4" Then
            a1.Location = p4
        ElseIf Lab4 = "5" Then
            a1.Location = p5
        ElseIf Lab4 = "6" Then
            a1.Location = p6
        ElseIf Lab4 = "7" Then
            a1.Location = p7
        ElseIf Lab4 = "8" Then
            a1.Location = p8
        ElseIf Lab4 = "9" Then
            a1.Location = p9
        End If
        If Lab5 = "1" Then
            a2.Location = p1
        ElseIf Lab5 = "2" Then
            a2.Location = p2
        ElseIf Lab5 = "3" Then
            a2.Location = p3
        ElseIf Lab5 = "4" Then
            a2.Location = p4
        ElseIf Lab5 = "5" Then
            a2.Location = p5
        ElseIf Lab5 = "6" Then
            a2.Location = p6
        ElseIf Lab5 = "7" Then
            a2.Location = p7
        ElseIf Lab5 = "8" Then
            a2.Location = p8
        ElseIf Lab5 = "9" Then
            a2.Location = p9
        End If
        If Lab6 = "1" Then
            a3.Location = p1
        ElseIf Lab6 = "2" Then
            a3.Location = p2
        ElseIf Lab6 = "3" Then
            a3.Location = p3
        ElseIf Lab6 = "4" Then
            a3.Location = p4
        ElseIf Lab6 = "5" Then
            a3.Location = p5
        ElseIf Lab6 = "6" Then
            a3.Location = p6
        ElseIf Lab6 = "7" Then
            a3.Location = p7
        ElseIf Lab6 = "8" Then
            a3.Location = p8
        ElseIf Lab6 = "9" Then
            a3.Location = p9
        End If
        If Bu4.Visible = True Then
            im1.Visible = True
            im2.Visible = True
            im3.Visible = True
            RB1.Visible = True
            RB2.Visible = True
            RB3.Visible = True
        Else
            im1.Visible = False
            im2.Visible = False
            im3.Visible = False
            RB1.Visible = False
            RB2.Visible = False
            RB3.Visible = False
        End If
        If sf = "1" Then
            RB1.Checked = True
        ElseIf sf = "2" Then
            RB2.Checked = True
        ElseIf sf = "3" Then
            RB3.Checked = True
        End If
        wn19(e)
        If lwz = "0" Then
            z1.BackgroundImage = My.Resources.zx4
            z2.BackgroundImage = My.Resources.zx4
            z3.BackgroundImage = My.Resources.zx4
        End If
        If lwc = "1" Then
            c1.BackgroundImage = My.Resources.cv4
            c2.BackgroundImage = My.Resources.cv4
            c3.BackgroundImage = My.Resources.cv4
        End If
        ox1(e)
        ws(e)
    End Sub

    Sub ws(ByVal e As EventArgs)
        If wn1.Text >= 100 Then
            wn1.Location = New Point(-3, 60)
        ElseIf wn1.Text >= 10 Then
            wn1.Location = New Point(5, 60)
        Else
            wn1.Location = New Point(12, 60)
        End If
        If wn2.Text >= 100 Then
            wn2.Location = New Point(408, 60)
        ElseIf wn2.Text >= 10 Then
            wn2.Location = New Point(415, 60)
        Else
            wn2.Location = New Point(423, 60)
        End If
        If stp1.Text >= 100 Then
            stp1.Location = New Point(3, 101)
        ElseIf stp1.Text >= 10 Then
            stp1.Location = New Point(9, 101)
        Else
            stp1.Location = New Point(15, 101)
        End If
        If stp2.Text >= 100 Then
            stp2.Location = New Point(414, 101)
        ElseIf stp2.Text >= 10 Then
            stp2.Location = New Point(420, 101)
        Else
            stp2.Location = New Point(426, 101)
        End If
    End Sub

    Sub l47(ByVal e As EventArgs)
        rt = Lab4 : Lab4 = Lab7 : Lab7 = rt
    End Sub

    Sub l48(ByVal e As EventArgs)
        rt = Lab4 : Lab4 = Lab8 : Lab8 = rt
    End Sub

    Sub l49(ByVal e As EventArgs)
        rt = Lab4 : Lab4 = Lab9 : Lab9 = rt
    End Sub

    Sub l57(ByVal e As EventArgs)
        rt = Lab5 : Lab5 = Lab7 : Lab7 = rt
    End Sub

    Sub l58(ByVal e As EventArgs)
        rt = Lab5 : Lab5 = Lab8 : Lab8 = rt
    End Sub

    Sub l59(ByVal e As EventArgs)
        rt = Lab5 : Lab5 = Lab9 : Lab9 = rt
    End Sub

    Sub l67(ByVal e As EventArgs)
        rt = Lab6 : Lab6 = Lab7 : Lab7 = rt
    End Sub

    Sub l68(ByVal e As EventArgs)
        rt = Lab6 : Lab6 = Lab8 : Lab8 = rt
    End Sub

    Sub l69(ByVal e As EventArgs)
        rt = Lab6 : Lab6 = Lab9 : Lab9 = rt
    End Sub

    Sub za(ByVal e As EventArgs)
        If (((Lab1 = "1" And La1 = "1") Or (Lab2 = "1" And La2 = "1") Or (Lab3 = "1" And La3 = "1")) And ((Lab1 = "2" And La1 = "1") Or (Lab2 = "2" And La2 = "1") Or (Lab3 = "2" And La3 = "1")) And (Lab4 = "3" Or Lab5 = "3" Or Lab6 = "3")) Or (((Lab1 = "1" And La1 = "1") Or (Lab2 = "1" And La2 = "1") Or (Lab3 = "1" And La3 = "1")) And ((Lab1 = "3" And La1 = "1") Or (Lab2 = "3" And La2 = "1") Or (Lab3 = "3" And La3 = "1")) And (Lab4 = "2" Or Lab5 = "2" Or Lab6 = "2")) Or (((Lab1 = "2" And La1 = "1") Or (Lab2 = "2" And La2 = "1") Or (Lab3 = "2" And La3 = "1")) And ((Lab1 = "3" And La1 = "1") Or (Lab2 = "3" And La2 = "1") Or (Lab3 = "3" And La3 = "1")) And (Lab4 = "1" Or Lab5 = "1" Or Lab6 = "1")) Or (((Lab1 = "4" And La1 = "1") Or (Lab2 = "4" And La2 = "1") Or (Lab3 = "4" And La3 = "1")) And ((Lab1 = "5" And La1 = "1") Or (Lab2 = "5" And La2 = "1") Or (Lab3 = "5" And La3 = "1")) And (Lab4 = "6" Or Lab5 = "6" Or Lab6 = "6")) Or (((Lab1 = "4" And La1 = "1") Or (Lab2 = "4" And La2 = "1") Or (Lab3 = "4" And La3 = "1")) And ((Lab1 = "6" And La1 = "1") Or (Lab2 = "6" And La2 = "1") Or (Lab3 = "6" And La3 = "1")) And (Lab4 = "5" Or Lab5 = "5" Or Lab6 = "5")) Or (((Lab1 = "5" And La1 = "1") Or (Lab2 = "5" And La2 = "1") Or (Lab3 = "5" And La3 = "1")) And ((Lab1 = "6" And La1 = "1") Or (Lab2 = "6" And La2 = "1") Or (Lab3 = "6" And La3 = "1")) And (Lab4 = "4" Or Lab5 = "4" Or Lab6 = "4")) Or (((Lab1 = "7" And La1 = "1") Or (Lab2 = "7" And La2 = "1") Or (Lab3 = "7" And La3 = "1")) And ((Lab1 = "8" And La1 = "1") Or (Lab2 = "8" And La2 = "1") Or (Lab3 = "8" And La3 = "1")) And (Lab4 = "9" Or Lab5 = "9" Or Lab6 = "9")) Or (((Lab1 = "7" And La1 = "1") Or (Lab2 = "7" And La2 = "1") Or (Lab3 = "7" And La3 = "1")) And ((Lab1 = "9" And La1 = "1") Or (Lab2 = "9" And La2 = "1") Or (Lab3 = "9" And La3 = "1")) And (Lab4 = "8" Or Lab5 = "8" Or Lab6 = "8")) Or (((Lab1 = "8" And La1 = "1") Or (Lab2 = "8" And La2 = "1") Or (Lab3 = "8" And La3 = "1")) And ((Lab1 = "9" And La1 = "1") Or (Lab2 = "9" And La2 = "1") Or (Lab3 = "9" And La3 = "1")) And (Lab4 = "7" Or Lab5 = "7" Or Lab6 = "7")) Or (((Lab1 = "3" And La1 = "1") Or (Lab2 = "3" And La2 = "1") Or (Lab3 = "3" And La3 = "1")) And ((Lab1 = "6" And La1 = "1") Or (Lab2 = "6" And La2 = "1") Or (Lab3 = "6" And La3 = "1")) And (Lab4 = "9" Or Lab5 = "9" Or Lab6 = "9")) Or (((Lab1 = "3" And La1 = "1") Or (Lab2 = "3" And La2 = "1") Or (Lab3 = "3" And La3 = "1")) And ((Lab1 = "9" And La1 = "1") Or (Lab2 = "9" And La2 = "1") Or (Lab3 = "9" And La3 = "1")) And (Lab4 = "6" Or Lab5 = "6" Or Lab6 = "6")) Or (((Lab1 = "6" And La1 = "1") Or (Lab2 = "6" And La2 = "1") Or (Lab3 = "6" And La3 = "1")) And ((Lab1 = "9" And La1 = "1") Or (Lab2 = "9" And La2 = "1") Or (Lab3 = "9" And La3 = "1")) And (Lab4 = "3" Or Lab5 = "3" Or Lab6 = "3")) Or (((Lab1 = "2" And La1 = "1") Or (Lab2 = "2" And La2 = "1") Or (Lab3 = "2" And La3 = "1")) And ((Lab1 = "5" And La1 = "1") Or (Lab2 = "5" And La2 = "1") Or (Lab3 = "5" And La3 = "1")) And (Lab4 = "8" Or Lab5 = "8" Or Lab6 = "8")) Or (((Lab1 = "2" And La1 = "1") Or (Lab2 = "2" And La2 = "1") Or (Lab3 = "2" And La3 = "1")) And ((Lab1 = "8" And La1 = "1") Or (Lab2 = "8" And La2 = "1") Or (Lab3 = "8" And La3 = "1")) And (Lab4 = "5" Or Lab5 = "5" Or Lab6 = "5")) Or (((Lab1 = "5" And La1 = "1") Or (Lab2 = "5" And La2 = "1") Or (Lab3 = "5" And La3 = "1")) And ((Lab1 = "8" And La1 = "1") Or (Lab2 = "8" And La2 = "1") Or (Lab3 = "8" And La3 = "1")) And (Lab4 = "2" Or Lab5 = "2" Or Lab6 = "2")) Or (((Lab1 = "1" And La1 = "1") Or (Lab2 = "1" And La2 = "1") Or (Lab3 = "1" And La3 = "1")) And ((Lab1 = "4" And La1 = "1") Or (Lab2 = "4" And La2 = "1") Or (Lab3 = "4" And La3 = "1")) And (Lab4 = "7" Or Lab5 = "7" Or Lab6 = "7")) Or (((Lab1 = "1" And La1 = "1") Or (Lab2 = "1" And La2 = "1") Or (Lab3 = "1" And La3 = "1")) And ((Lab1 = "7" And La1 = "1") Or (Lab2 = "7" And La2 = "1") Or (Lab3 = "7" And La3 = "1")) And (Lab4 = "4" Or Lab5 = "4" Or Lab6 = "4")) Or (((Lab1 = "4" And La1 = "1") Or (Lab2 = "4" And La2 = "1") Or (Lab3 = "4" And La3 = "1")) And ((Lab1 = "7" And La1 = "1") Or (Lab2 = "7" And La2 = "1") Or (Lab3 = "7" And La3 = "1")) And (Lab4 = "1" Or Lab5 = "1" Or Lab6 = "1")) Or (VaH.Checked = False And ((((Lab1 = "1" And La1 = "1") Or (Lab2 = "1" And La2 = "1") Or (Lab3 = "1" And La3 = "1")) And ((Lab1 = "5" And La1 = "1") Or (Lab2 = "5" And La2 = "1") Or (Lab3 = "5" And La3 = "1")) And (Lab4 = "9" Or Lab5 = "9" Or Lab6 = "9")) Or (((Lab1 = "1" And La1 = "1") Or (Lab2 = "1" And La2 = "1") Or (Lab3 = "1" And La3 = "1")) And ((Lab1 = "9" And La1 = "1") Or (Lab2 = "9" And La2 = "1") Or (Lab3 = "9" And La3 = "1")) And (Lab4 = "5" Or Lab5 = "5" Or Lab6 = "5")) Or (((Lab1 = "5" And La1 = "1") Or (Lab2 = "5" And La2 = "1") Or (Lab3 = "5" And La3 = "1")) And ((Lab1 = "9" And La1 = "1") Or (Lab2 = "9" And La2 = "1") Or (Lab3 = "9" And La3 = "1")) And (Lab4 = "1" Or Lab5 = "1" Or Lab6 = "1")) Or (((Lab1 = "3" And La1 = "1") Or (Lab2 = "3" And La2 = "1") Or (Lab3 = "3" And La3 = "1")) And ((Lab1 = "5" And La1 = "1") Or (Lab2 = "5" And La2 = "1") Or (Lab3 = "5" And La3 = "1")) And (Lab4 = "7" Or Lab5 = "7" Or Lab6 = "7")) Or (((Lab1 = "3" And La1 = "1") Or (Lab2 = "3" And La2 = "1") Or (Lab3 = "3" And La3 = "1")) And ((Lab1 = "7" And La1 = "1") Or (Lab2 = "7" And La2 = "1") Or (Lab3 = "7" And La3 = "1")) And (Lab4 = "5" Or Lab5 = "5" Or Lab6 = "5")) Or (((Lab1 = "5" And La1 = "1") Or (Lab2 = "5" And La2 = "1") Or (Lab3 = "5" And La3 = "1")) And ((Lab1 = "7" And La1 = "1") Or (Lab2 = "7" And La2 = "1") Or (Lab3 = "7" And La3 = "1")) And (Lab4 = "3" Or Lab5 = "3" Or Lab6 = "3")))) Then
            zn = "1"
        Else
            zn = "0"
        End If
    End Sub

    Sub tt2(ByVal e As EventArgs)
        Lb4 = Lab4 : Lb5 = Lab5 : Lb6 = Lab6 : Lb7 = Lab7 : Lb8 = Lab8 : Lb9 = Lab9
        Dim ran = New Random
        Dim xx As Integer
        If ll = "0" Or ll = "3" Or ll = "6" Then
            xx = ran.Next(1, 3)
        ElseIf ll = "1" Or ll = "5" Then
            xx = ran.Next(1, 5)
        End If
        If xx = "2" And ll = "0" Then
        Else : sw(e)
        End If
        If (ll1 = "1" Or ll = "4" Or ll = "5" Or ll = "6" Or ll = "7") And (Lb7 = Lab7 And Lb8 = Lab8 And Lb9 = Lab9) Then
            s3(e)
        End If
        If (ll1 = "1" Or ((ll = "6" Or ll = "5") And xx = "1") Or ll = "7") And Lb7 = Lab7 And Lb8 = Lab8 And Lb9 = Lab9 Then
            If (La1 = "0" And La2 = "0" And La3 = "0") Or (VaH.Checked = True And La7 = "0" And La8 = "0" And La9 = "0") Then
            Else
                cmptr(e)
            End If
        End If
        If (ll1 = "1" Or (ll = "1" And xx = "1") Or ll = "2" Or ll = "3" Or ll = "4" Or ll = "5" Or ll = "6" Or ll = "7") And (Lb7 = Lab7 And Lb8 = Lab8 And Lb9 = Lab9) Then
            za(e)
            If zn = "1" Then
                s2(e)
            End If
        End If
        If (ll1 = "1" Or (ll = "3" And xx = "1") Or ll = "4" Or ll = "5" Or ll = "6" Or ll = "7") And Lb7 = Lab7 And Lb8 = Lab8 And Lb9 = Lab9 Then
            If (((Lab1 = "1" And La1 = "1") Or (Lab2 = "1" And La2 = "1") Or (Lab3 = "1" And La3 = "1")) And ((Lab1 = "2" And La1 = "1") Or (Lab2 = "2" And La2 = "1") Or (Lab3 = "2" And La3 = "1")) And (Lab7 = "3" Or Lab8 = "3" Or Lab9 = "3")) Or (((Lab1 = "1" And La1 = "1") Or (Lab2 = "1" And La2 = "1") Or (Lab3 = "1" And La3 = "1")) And ((Lab1 = "3" And La1 = "1") Or (Lab2 = "3" And La2 = "1") Or (Lab3 = "3" And La3 = "1")) And (Lab7 = "2" Or Lab8 = "2" Or Lab9 = "2")) Or (((Lab1 = "2" And La1 = "1") Or (Lab2 = "2" And La2 = "1") Or (Lab3 = "2" And La3 = "1")) And ((Lab1 = "3" And La1 = "1") Or (Lab2 = "3" And La2 = "1") Or (Lab3 = "3" And La3 = "1")) And (Lab7 = "1" Or Lab8 = "1" Or Lab9 = "1")) Or (((Lab1 = "4" And La1 = "1") Or (Lab2 = "4" And La2 = "1") Or (Lab3 = "4" And La3 = "1")) And ((Lab1 = "5" And La1 = "1") Or (Lab2 = "5" And La2 = "1") Or (Lab3 = "5" And La3 = "1")) And (Lab7 = "6" Or Lab8 = "6" Or Lab9 = "6")) Or (((Lab1 = "4" And La1 = "1") Or (Lab2 = "4" And La2 = "1") Or (Lab3 = "4" And La3 = "1")) And ((Lab1 = "6" And La1 = "1") Or (Lab2 = "6" And La2 = "1") Or (Lab3 = "6" And La3 = "1")) And (Lab7 = "5" Or Lab8 = "5" Or Lab9 = "5")) Or (((Lab1 = "5" And La1 = "1") Or (Lab2 = "5" And La2 = "1") Or (Lab3 = "5" And La3 = "1")) And ((Lab1 = "6" And La1 = "1") Or (Lab2 = "6" And La2 = "1") Or (Lab3 = "6" And La3 = "1")) And (Lab7 = "4" Or Lab8 = "4" Or Lab9 = "4")) Or (((Lab1 = "7" And La1 = "1") Or (Lab2 = "7" And La2 = "1") Or (Lab3 = "7" And La3 = "1")) And ((Lab1 = "8" And La1 = "1") Or (Lab2 = "8" And La2 = "1") Or (Lab3 = "8" And La3 = "1")) And (Lab7 = "9" Or Lab8 = "9" Or Lab9 = "9")) Or (((Lab1 = "7" And La1 = "1") Or (Lab2 = "7" And La2 = "1") Or (Lab3 = "7" And La3 = "1")) And ((Lab1 = "9" And La1 = "1") Or (Lab2 = "9" And La2 = "1") Or (Lab3 = "9" And La3 = "1")) And (Lab7 = "8" Or Lab8 = "8" Or Lab9 = "8")) Or (((Lab1 = "8" And La1 = "1") Or (Lab2 = "8" And La2 = "1") Or (Lab3 = "8" And La3 = "1")) And ((Lab1 = "9" And La1 = "1") Or (Lab2 = "9" And La2 = "1") Or (Lab3 = "9" And La3 = "1")) And (Lab7 = "7" Or Lab8 = "7" Or Lab9 = "7")) Or (((Lab1 = "3" And La1 = "1") Or (Lab2 = "3" And La2 = "1") Or (Lab3 = "3" And La3 = "1")) And ((Lab1 = "6" And La1 = "1") Or (Lab2 = "6" And La2 = "1") Or (Lab3 = "6" And La3 = "1")) And (Lab7 = "9" Or Lab8 = "9" Or Lab9 = "9")) Or (((Lab1 = "3" And La1 = "1") Or (Lab2 = "3" And La2 = "1") Or (Lab3 = "3" And La3 = "1")) And ((Lab1 = "9" And La1 = "1") Or (Lab2 = "9" And La2 = "1") Or (Lab3 = "9" And La3 = "1")) And (Lab7 = "6" Or Lab8 = "6" Or Lab9 = "6")) Or (((Lab1 = "6" And La1 = "1") Or (Lab2 = "6" And La2 = "1") Or (Lab3 = "6" And La3 = "1")) And ((Lab1 = "9" And La1 = "1") Or (Lab2 = "9" And La2 = "1") Or (Lab3 = "9" And La3 = "1")) And (Lab7 = "3" Or Lab8 = "3" Or Lab9 = "3")) Or (((Lab1 = "2" And La1 = "1") Or (Lab2 = "2" And La2 = "1") Or (Lab3 = "2" And La3 = "1")) And ((Lab1 = "5" And La1 = "1") Or (Lab2 = "5" And La2 = "1") Or (Lab3 = "5" And La3 = "1")) And (Lab7 = "8" Or Lab8 = "8" Or Lab9 = "8")) Or (((Lab1 = "2" And La1 = "1") Or (Lab2 = "2" And La2 = "1") Or (Lab3 = "2" And La3 = "1")) And ((Lab1 = "8" And La1 = "1") Or (Lab2 = "8" And La2 = "1") Or (Lab3 = "8" And La3 = "1")) And (Lab7 = "5" Or Lab8 = "5" Or Lab9 = "5")) Or (((Lab1 = "5" And La1 = "1") Or (Lab2 = "5" And La2 = "1") Or (Lab3 = "5" And La3 = "1")) And ((Lab1 = "8" And La1 = "1") Or (Lab2 = "8" And La2 = "1") Or (Lab3 = "8" And La3 = "1")) And (Lab7 = "2" Or Lab8 = "2" Or Lab9 = "2")) Or (((Lab1 = "1" And La1 = "1") Or (Lab2 = "1" And La2 = "1") Or (Lab3 = "1" And La3 = "1")) And ((Lab1 = "4" And La1 = "1") Or (Lab2 = "4" And La2 = "1") Or (Lab3 = "4" And La3 = "1")) And (Lab7 = "7" Or Lab8 = "7" Or Lab9 = "7")) Or (((Lab1 = "1" And La1 = "1") Or (Lab2 = "1" And La2 = "1") Or (Lab3 = "1" And La3 = "1")) And ((Lab1 = "7" And La1 = "1") Or (Lab2 = "7" And La2 = "1") Or (Lab3 = "7" And La3 = "1")) And (Lab7 = "4" Or Lab8 = "4" Or Lab9 = "4")) Or (((Lab1 = "4" And La1 = "1") Or (Lab2 = "4" And La2 = "1") Or (Lab3 = "4" And La3 = "1")) And ((Lab1 = "7" And La1 = "1") Or (Lab2 = "7" And La2 = "1") Or (Lab3 = "7" And La3 = "1")) And (Lab7 = "1" Or Lab8 = "1" Or Lab9 = "1")) Or (VaH.Checked = False And ((((Lab1 = "1" And La1 = "1") Or (Lab2 = "1" And La2 = "1") Or (Lab3 = "1" And La3 = "1")) And ((Lab1 = "5" And La1 = "1") Or (Lab2 = "5" And La2 = "1") Or (Lab3 = "5" And La3 = "1")) And (Lab7 = "9" Or Lab8 = "9" Or Lab9 = "9")) Or (((Lab1 = "1" And La1 = "1") Or (Lab2 = "1" And La2 = "1") Or (Lab3 = "1" And La3 = "1")) And ((Lab1 = "9" And La1 = "1") Or (Lab2 = "9" And La2 = "1") Or (Lab3 = "9" And La3 = "1")) And (Lab7 = "5" Or Lab8 = "5" Or Lab9 = "5")) Or (((Lab1 = "5" And La1 = "1") Or (Lab2 = "5" And La2 = "1") Or (Lab3 = "5" And La3 = "1")) And ((Lab1 = "9" And La1 = "1") Or (Lab2 = "9" And La2 = "1") Or (Lab3 = "9" And La3 = "1")) And (Lab7 = "1" Or Lab8 = "1" Or Lab9 = "1")) Or (((Lab1 = "3" And La1 = "1") Or (Lab2 = "3" And La2 = "1") Or (Lab3 = "3" And La3 = "1")) And ((Lab1 = "5" And La1 = "1") Or (Lab2 = "5" And La2 = "1") Or (Lab3 = "5" And La3 = "1")) And (Lab7 = "7" Or Lab8 = "7" Or Lab9 = "7")) Or (((Lab1 = "3" And La1 = "1") Or (Lab2 = "3" And La2 = "1") Or (Lab3 = "3" And La3 = "1")) And ((Lab1 = "7" And La1 = "1") Or (Lab2 = "7" And La2 = "1") Or (Lab3 = "7" And La3 = "1")) And (Lab7 = "5" Or Lab8 = "5" Or Lab9 = "5")) Or (((Lab1 = "5" And La1 = "1") Or (Lab2 = "5" And La2 = "1") Or (Lab3 = "5" And La3 = "1")) And ((Lab1 = "7" And La1 = "1") Or (Lab2 = "7" And La2 = "1") Or (Lab3 = "7" And La3 = "1")) And (Lab7 = "3" Or Lab8 = "3" Or Lab9 = "3")))) Then
                s2(e)
            End If
        End If
        If (Lb7 = Lab7) And (Lb8 = Lab8) And (Lb9 = Lab9) Then
            Dim rand = New Random
            Dim x As Integer
            x = rand.Next(1, 10)
            Dim z As String = x
            If (La7 = "0" And La8 = "0" And La9 = "0") Or (La7 = "1" And La8 = "1" And La9 = "1") Then
                If z = "1" Then
                    l47(e)
                ElseIf z = "2" Then
                    l48(e)
                ElseIf z = "3" Then
                    l49(e)
                ElseIf z = "4" Then
                    l57(e)
                ElseIf z = "5" Then
                    l58(e)
                ElseIf z = "6" Then
                    l59(e)
                ElseIf z = "7" Then
                    l67(e)
                ElseIf z = "8" Then
                    l68(e)
                ElseIf z = "9" Then
                    l69(e)
                ElseIf z = "10" Then
                    l69(e)
                End If
            Else
                If La7 = "0" And La8 = "1" And La9 = "1" Then
                    If z = "1" Or z = "2" Or z = "3" Then
                        l47(e)
                    ElseIf z = "4" Or z = "5" Or z = "6" Then
                        l57(e)
                    ElseIf z = "7" Or z = "8" Or z = "9" Or z = "10" Then
                        l67(e)
                    End If
                ElseIf La8 = "0" And La7 = "1" And La9 = "1" Then
                    If z = "1" Or z = "2" Or z = "3" Then
                        l48(e)
                    ElseIf z = "4" Or z = "5" Or z = "6" Then
                        l58(e)
                    ElseIf z = "7" Or z = "8" Or z = "9" Or z = "10" Then
                        l68(e)
                    End If
                ElseIf La9 = "0" And La8 = "1" And La7 = "1" Then
                    If z = "1" Or z = "2" Or z = "3" Then
                        l49(e)
                    ElseIf z = "4" Or z = "5" Or z = "6" Then
                        l59(e)
                    ElseIf z = "7" Or z = "8" Or z = "9" Or z = "10" Then
                        l69(e)
                    End If
                Else
                    Dim ra = New Random
                    Dim hg As Integer
                    hg = ran.Next(1, 7)
                    Dim j As String = hg
                    If La7 = "0" And La8 = "0" And La9 = "1" Then
                        If j = "1" Then
                            l47(e)
                        ElseIf j = "2" Then
                            l57(e)
                        ElseIf j = "3" Then
                            l67(e)
                        ElseIf j = "4" Then
                            l48(e)
                        ElseIf j = "5" Then
                            l58(e)
                        ElseIf j = "6" Or j = "7" Then
                            l68(e)
                        End If
                    ElseIf La8 = "0" And La9 = "0" And La7 = "1" Then
                        If j = "1" Then
                            l48(e)
                        ElseIf j = "2" Then
                            l58(e)
                        ElseIf j = "3" Then
                            l68(e)
                        ElseIf j = "4" Then
                            l49(e)
                        ElseIf j = "5" Then
                            l59(e)
                        ElseIf j = "6" Or j = "7" Then
                            l69(e)
                        End If
                    ElseIf La9 = "0" And La7 = "0" And La8 = "1" Then
                        If j = "1" Then
                            l49(e)
                        ElseIf j = "2" Then
                            l59(e)
                        ElseIf j = "3" Then
                            l69(e)
                        ElseIf j = "4" Then
                            l47(e)
                        ElseIf j = "5" Then
                            l57(e)
                        ElseIf j = "6" Or j = "7" Then
                            l67(e)
                        End If
                    End If
                End If
            End If
        End If
    End Sub

    Sub ie1(ByVal e As EventArgs)
        If see = "1" Then
            l47(e)
            see = "2"
        ElseIf see = "2" Then
            l48(e)
            see = "3"
        ElseIf see = "3" Then
            l49(e)
            see = "4"
        ElseIf see = "4" Then
            l57(e)
            see = "5"
        ElseIf see = "5" Then
            l58(e)
            see = "6"
        ElseIf see = "6" Then
            l59(e)
            see = "7"
        ElseIf see = "7" Then
            l67(e)
            see = "8"
        ElseIf see = "8" Then
            l68(e)
            see = "9"
        ElseIf see = "9" Then
            l69(e)
            see = "10"
        End If
    End Sub

    Sub sw2(ByVal e As EventArgs)
        If ((Lab7 = "1" Or Lab8 = "1" Or Lab9 = "1") And (Lab7 = "2" Or Lab8 = "2" Or Lab9 = "2") And (Lab7 = "3" Or Lab8 = "3" Or Lab9 = "3")) Or ((Lab7 = "7" Or Lab8 = "7" Or Lab9 = "7") And (Lab7 = "8" Or Lab8 = "8" Or Lab9 = "8") And (Lab7 = "9" Or Lab8 = "9" Or Lab9 = "9")) Or ((Lab7 = "1" Or Lab8 = "1" Or Lab9 = "1") And (Lab7 = "4" Or Lab8 = "4" Or Lab9 = "4") And (Lab7 = "7" Or Lab8 = "7" Or Lab9 = "7")) Or ((Lab7 = "3" Or Lab8 = "3" Or Lab9 = "3") And (Lab7 = "6" Or Lab8 = "6" Or Lab9 = "6") And (Lab7 = "9" Or Lab8 = "9" Or Lab9 = "9")) Then
            gu = "1"
        Else
            gu = "0"
        End If
    End Sub

    Sub sw(ByVal e As EventArgs)
        ie1(e)
        If stp1.Text = stp2.Text And NoS.Checked = True And (VaH.Checked = False And (((Lab7 = "1" Or Lab8 = "1" Or Lab9 = "1") And (Lab7 = "5" Or Lab8 = "5" Or Lab9 = "5") And (Lab7 = "9" Or Lab8 = "9" Or Lab9 = "9")) Or ((Lab7 = "3" Or Lab8 = "3" Or Lab9 = "3") And (Lab7 = "5" Or Lab8 = "5" Or Lab9 = "5") And (Lab7 = "7" Or Lab8 = "7" Or Lab9 = "7")))) Then
            gn = "1"
        Else
            gn = "0"
        End If
        If ((La7 = "1" And La8 = "1" And (see = "4" Or see = "7" Or see = "10")) Or (La7 = "1" And La9 = "1" And (see = "3" Or see = "6" Or see = "9")) Or (La8 = "1" And La9 = "1" And (see = "2" Or see = "5" Or see = "8"))) Then
            sw2(e)
            If gn = "1" Then
                gd = "2"
            ElseIf (((Lab7 = "4" Or Lab8 = "4" Or Lab9 = "4") And (Lab7 = "5" Or Lab8 = "5" Or Lab9 = "5") And (Lab7 = "6" Or Lab8 = "6" Or Lab9 = "6")) Or ((Lab7 = "2" Or Lab8 = "2" Or Lab9 = "2") And (Lab7 = "5" Or Lab8 = "5" Or Lab9 = "5") And (Lab7 = "8" Or Lab8 = "8" Or Lab9 = "8")) Or gu = "1" Or ((VaH.Checked = False) And (((Lab7 = "1" Or Lab8 = "1" Or Lab9 = "1") And (Lab7 = "5" Or Lab8 = "5" Or Lab9 = "5") And (Lab7 = "9" Or Lab8 = "9" Or Lab9 = "9")) Or ((Lab7 = "3" Or Lab8 = "3" Or Lab9 = "3") And (Lab7 = "5" Or Lab8 = "5" Or Lab9 = "5") And (Lab7 = "7" Or Lab8 = "7" Or Lab9 = "7"))))) Then
                gd = "1"
            Else
                gd = "0"
            End If
        Else
            gd = "0"
        End If
        gn = "0"
        Lab4 = Lb4 : Lab5 = Lb5 : Lab6 = Lb6 : Lab7 = Lb7 : Lab8 = Lb8 : Lab9 = Lb9
        If gd = "2" Then
            gd = "0"
            s0 = "-1"
            s0 += 1
            s1 = ""
            Dim q1 As Integer = see - 1
            Dim q2 As String = q1
            s1 += q2
            see = "10"
        Else
            If gd = "1" Then
                gd = "0"
                If see = "10" Then
                    s0 += 1
                    Dim q1 As Integer = see - 1
                    Dim q2 As String = q1
                    s1 += q2
                Else
                    s0 += 1
                    Dim q1 As Integer = see - 1
                    Dim q2 As String = q1
                    s1 += q2
                    sw(e)
                End If
            Else
                If see = "10" Then
                Else
                    sw(e)
                End If
            End If
        End If
        If see = "10" Then
            see = "1"
            p2(e)
        End If
    End Sub

    Sub s2(ByVal e As EventArgs)
        ie1(e)
        za(e)
        Lab4 = Lb4 : Lab5 = Lb5 : Lab6 = Lb6 : Lab7 = Lb7 : Lab8 = Lb8 : Lab9 = Lb9
        If zn = "1" Then
            If see = "10" Then
            Else : s2(e)
            End If
        Else
            If see = "10" Then
                s0 += 1
                Dim q1 As Integer = see - 1
                Dim q2 As String = q1
                s1 += q2
            Else
                s0 += 1
                Dim q1 As Integer = see - 1
                Dim q2 As String = q1
                s1 += q2            
                s2(e)
            End If
        End If
        If see = "10" Then
            see = "1"
            p2(e)
        End If
    End Sub

    Sub ie2(ByVal e As EventArgs)
        If see = "1" Then
            l47(e)
            If La7 = "0" Then
                La7 = "1"
                die = "7"
            End If
            see = "2"
        ElseIf see = "2" Then
            l48(e)
            If La8 = "0" Then
                La8 = "1"
                die = "8"
            End If
            see = "3"
        ElseIf see = "3" Then
            l49(e)
            If La9 = "0" Then
                La9 = "1"
                die = "9"
            End If
            see = "4"
        ElseIf see = "4" Then
            l57(e)
            If La7 = "0" Then
                La7 = "1"
                die = "7"
            End If
            see = "5"
        ElseIf see = "5" Then
            l58(e)
            If La8 = "0" Then
                La8 = "1"
                die = "8"
            End If
            see = "6"
        ElseIf see = "6" Then
            l59(e)
            If La9 = "0" Then
                La9 = "1"
                die = "9"
            End If
            see = "7"
        ElseIf see = "7" Then
            l67(e)
            If La7 = "0" Then
                La7 = "1"
                die = "7"
            End If
            see = "8"
        ElseIf see = "8" Then
            l68(e)
            If La8 = "0" Then
                La8 = "1"
                die = "8"
            End If
            see = "9"
        ElseIf see = "9" Then
            l69(e)
            If La9 = "0" Then
                La9 = "1"
                die = "9"
            End If
            see = "10"
        End If
    End Sub

    Sub s3(ByVal e As EventArgs)
        wn9 = 0
        Dim w93 As Integer = 0
        die = "0"
        ie2(e)
        za(e)
        If zn = "0" Then
            If ((Lab7 = "1" Or Lab8 = "1" Or Lab9 = "1") And (Lab7 = "2" Or Lab8 = "2" Or Lab9 = "2") And (Lab4 = "3" Or Lab5 = "3" Or Lab6 = "3")) Or ((Lab7 = "1" Or Lab8 = "1" Or Lab9 = "1") And (Lab7 = "3" Or Lab8 = "3" Or Lab9 = "3") And (Lab4 = "2" Or Lab5 = "2" Or Lab6 = "2")) Or ((Lab7 = "2" Or Lab8 = "2" Or Lab9 = "2") And (Lab7 = "3" Or Lab8 = "3" Or Lab9 = "3") And (Lab4 = "1" Or Lab5 = "1" Or Lab6 = "1")) Or ((Lab7 = "4" Or Lab8 = "4" Or Lab9 = "4") And (Lab7 = "5" Or Lab8 = "5" Or Lab9 = "5") And (Lab4 = "6" Or Lab5 = "6" Or Lab6 = "6")) Or ((Lab7 = "4" Or Lab8 = "4" Or Lab9 = "4") And (Lab7 = "6" Or Lab8 = "6" Or Lab9 = "6") And (Lab4 = "5" Or Lab5 = "5" Or Lab6 = "5")) Or ((Lab7 = "5" Or Lab8 = "5" Or Lab9 = "5") And (Lab7 = "6" Or Lab8 = "6" Or Lab9 = "6") And (Lab4 = "4" Or Lab5 = "4" Or Lab6 = "4")) Or ((Lab7 = "7" Or Lab8 = "7" Or Lab9 = "7") And (Lab7 = "8" Or Lab8 = "8" Or Lab9 = "8") And (Lab4 = "9" Or Lab5 = "9" Or Lab6 = "9")) Or ((Lab7 = "7" Or Lab8 = "7" Or Lab9 = "7") And (Lab7 = "9" Or Lab8 = "9" Or Lab9 = "9") And (Lab4 = "8" Or Lab5 = "8" Or Lab6 = "8")) Or ((Lab7 = "8" Or Lab8 = "8" Or Lab9 = "8") And (Lab7 = "9" Or Lab8 = "9" Or Lab9 = "9") And (Lab4 = "7" Or Lab5 = "7" Or Lab6 = "7")) Then
                wn9 += 1
            End If
            If ((Lab7 = "3" Or Lab8 = "3" Or Lab9 = "3") And (Lab7 = "6" Or Lab8 = "6" Or Lab9 = "6") And (Lab4 = "9" Or Lab5 = "9" Or Lab6 = "9")) Or ((Lab7 = "3" Or Lab8 = "3" Or Lab9 = "3") And (Lab7 = "9" Or Lab8 = "9" Or Lab9 = "9") And (Lab4 = "6" Or Lab5 = "6" Or Lab6 = "6")) Or ((Lab7 = "6" Or Lab8 = "6" Or Lab9 = "6") And (Lab7 = "9" Or Lab8 = "9" Or Lab9 = "9") And (Lab4 = "3" Or Lab5 = "3" Or Lab6 = "3")) Or ((Lab7 = "2" Or Lab8 = "2" Or Lab9 = "2") And (Lab7 = "5" Or Lab8 = "5" Or Lab9 = "5") And (Lab4 = "8" Or Lab5 = "8" Or Lab6 = "8")) Or ((Lab7 = "2" Or Lab8 = "2" Or Lab9 = "2") And (Lab7 = "8" Or Lab8 = "8" Or Lab9 = "8") And (Lab4 = "5" Or Lab5 = "5" Or Lab6 = "5")) Or ((Lab7 = "5" Or Lab8 = "5" Or Lab9 = "5") And (Lab7 = "8" Or Lab8 = "8" Or Lab9 = "8") And (Lab4 = "2" Or Lab5 = "2" Or Lab6 = "2")) Or ((Lab7 = "1" Or Lab8 = "1" Or Lab9 = "1") And (Lab7 = "4" Or Lab8 = "4" Or Lab9 = "4") And (Lab4 = "7" Or Lab5 = "7" Or Lab6 = "7")) Or ((Lab7 = "1" Or Lab8 = "1" Or Lab9 = "1") And (Lab7 = "7" Or Lab8 = "7" Or Lab9 = "7") And (Lab4 = "4" Or Lab5 = "4" Or Lab6 = "4")) Or ((Lab7 = "4" Or Lab8 = "4" Or Lab9 = "4") And (Lab7 = "7" Or Lab8 = "7" Or Lab9 = "7") And (Lab4 = "1" Or Lab5 = "1" Or Lab6 = "1")) Then
                wn9 += 1
            End If
            If VaH.Checked = False Then
                If ((Lab7 = "1" Or Lab8 = "1" Or Lab9 = "1") And (Lab7 = "5" Or Lab8 = "5" Or Lab9 = "5") And (Lab4 = "9" Or Lab5 = "9" Or Lab6 = "9")) Or ((Lab7 = "1" Or Lab8 = "1" Or Lab9 = "1") And (Lab7 = "9" Or Lab8 = "9" Or Lab9 = "9") And (Lab4 = "5" Or Lab5 = "5" Or Lab6 = "5")) Or ((Lab7 = "5" Or Lab8 = "5" Or Lab9 = "5") And (Lab7 = "9" Or Lab8 = "9" Or Lab9 = "9") And (Lab4 = "1" Or Lab5 = "1" Or Lab6 = "1")) Then
                    wn9 += 1
                End If
                If ((Lab7 = "3" Or Lab8 = "3" Or Lab9 = "3") And (Lab7 = "5" Or Lab8 = "5" Or Lab9 = "5") And (Lab4 = "7" Or Lab5 = "7" Or Lab6 = "7")) Or ((Lab7 = "3" Or Lab8 = "3" Or Lab9 = "3") And (Lab7 = "7" Or Lab8 = "7" Or Lab9 = "7") And (Lab4 = "5" Or Lab5 = "5" Or Lab6 = "5")) Or ((Lab7 = "5" Or Lab8 = "5" Or Lab9 = "5") And (Lab7 = "7" Or Lab8 = "7" Or Lab9 = "7") And (Lab4 = "3" Or Lab5 = "3" Or Lab6 = "3")) Then
                    wn9 += 1
                End If
                If La1 = "0" Or La2 = "0" Or La3 = "0" Then
                    If ((Lab7 = "1" Or Lab8 = "1" Or Lab9 = "1") And (Lab7 = "2" Or Lab8 = "2" Or Lab9 = "2") And (Lab1 = "3" Or Lab2 = "3" Or Lab3 = "3")) Or ((Lab7 = "1" Or Lab8 = "1" Or Lab9 = "1") And (Lab7 = "3" Or Lab8 = "3" Or Lab9 = "3") And (Lab1 = "2" Or Lab2 = "2" Or Lab3 = "2")) Or ((Lab7 = "2" Or Lab8 = "2" Or Lab9 = "2") And (Lab7 = "3" Or Lab8 = "3" Or Lab9 = "3") And (Lab1 = "1" Or Lab2 = "1" Or Lab3 = "1")) Or ((Lab7 = "4" Or Lab8 = "4" Or Lab9 = "4") And (Lab7 = "5" Or Lab8 = "5" Or Lab9 = "5") And (Lab1 = "6" Or Lab2 = "6" Or Lab3 = "6")) Or ((Lab7 = "4" Or Lab8 = "4" Or Lab9 = "4") And (Lab7 = "6" Or Lab8 = "6" Or Lab9 = "6") And (Lab1 = "5" Or Lab2 = "5" Or Lab3 = "5")) Or ((Lab7 = "5" Or Lab8 = "5" Or Lab9 = "5") And (Lab7 = "6" Or Lab8 = "6" Or Lab9 = "6") And (Lab1 = "4" Or Lab2 = "4" Or Lab3 = "4")) Or ((Lab7 = "7" Or Lab8 = "7" Or Lab9 = "7") And (Lab7 = "8" Or Lab8 = "8" Or Lab9 = "8") And (Lab1 = "9" Or Lab2 = "9" Or Lab3 = "9")) Or ((Lab7 = "7" Or Lab8 = "7" Or Lab9 = "7") And (Lab7 = "9" Or Lab8 = "9" Or Lab9 = "9") And (Lab1 = "8" Or Lab2 = "8" Or Lab3 = "8")) Or ((Lab7 = "8" Or Lab8 = "8" Or Lab9 = "8") And (Lab7 = "9" Or Lab8 = "9" Or Lab9 = "9") And (Lab1 = "7" Or Lab2 = "7" Or Lab3 = "7")) Then
                        w93 += 1
                    End If
                    If ((Lab7 = "3" Or Lab8 = "3" Or Lab9 = "3") And (Lab7 = "6" Or Lab8 = "6" Or Lab9 = "6") And (Lab1 = "9" Or Lab2 = "9" Or Lab3 = "9")) Or ((Lab7 = "3" Or Lab8 = "3" Or Lab9 = "3") And (Lab7 = "9" Or Lab8 = "9" Or Lab9 = "9") And (Lab1 = "6" Or Lab2 = "6" Or Lab3 = "6")) Or ((Lab7 = "6" Or Lab8 = "6" Or Lab9 = "6") And (Lab7 = "9" Or Lab8 = "9" Or Lab9 = "9") And (Lab1 = "3" Or Lab2 = "3" Or Lab3 = "3")) Or ((Lab7 = "2" Or Lab8 = "2" Or Lab9 = "2") And (Lab7 = "5" Or Lab8 = "5" Or Lab9 = "5") And (Lab1 = "8" Or Lab2 = "8" Or Lab3 = "8")) Or ((Lab7 = "2" Or Lab8 = "2" Or Lab9 = "2") And (Lab7 = "8" Or Lab8 = "8" Or Lab9 = "8") And (Lab1 = "5" Or Lab2 = "5" Or Lab3 = "5")) Or ((Lab7 = "5" Or Lab8 = "5" Or Lab9 = "5") And (Lab7 = "8" Or Lab8 = "8" Or Lab9 = "8") And (Lab1 = "2" Or Lab2 = "2" Or Lab3 = "2")) Or ((Lab7 = "1" Or Lab8 = "1" Or Lab9 = "1") And (Lab7 = "4" Or Lab8 = "4" Or Lab9 = "4") And (Lab1 = "7" Or Lab2 = "7" Or Lab3 = "7")) Or ((Lab7 = "1" Or Lab8 = "1" Or Lab9 = "1") And (Lab7 = "7" Or Lab8 = "7" Or Lab9 = "7") And (Lab1 = "4" Or Lab2 = "4" Or Lab3 = "4")) Or ((Lab7 = "4" Or Lab8 = "4" Or Lab9 = "4") And (Lab7 = "7" Or Lab8 = "7" Or Lab9 = "7") And (Lab1 = "1" Or Lab2 = "1" Or Lab3 = "1")) Then
                        w93 += 1
                    End If
                    If ((Lab7 = "1" Or Lab8 = "1" Or Lab9 = "1") And (Lab7 = "5" Or Lab8 = "5" Or Lab9 = "5") And (Lab1 = "9" Or Lab2 = "9" Or Lab3 = "9")) Or ((Lab7 = "1" Or Lab8 = "1" Or Lab9 = "1") And (Lab7 = "9" Or Lab8 = "9" Or Lab9 = "9") And (Lab1 = "5" Or Lab2 = "5" Or Lab3 = "5")) Or ((Lab7 = "5" Or Lab8 = "5" Or Lab9 = "5") And (Lab7 = "9" Or Lab8 = "9" Or Lab9 = "9") And (Lab1 = "1" Or Lab2 = "1" Or Lab3 = "1")) Then
                        w93 += 1
                    End If
                    If ((Lab7 = "3" Or Lab8 = "3" Or Lab9 = "3") And (Lab7 = "5" Or Lab8 = "5" Or Lab9 = "5") And (Lab1 = "7" Or Lab2 = "7" Or Lab3 = "7")) Or ((Lab7 = "3" Or Lab8 = "3" Or Lab9 = "3") And (Lab7 = "7" Or Lab8 = "7" Or Lab9 = "7") And (Lab1 = "5" Or Lab2 = "5" Or Lab3 = "5")) Or ((Lab7 = "5" Or Lab8 = "5" Or Lab9 = "5") And (Lab7 = "7" Or Lab8 = "7" Or Lab9 = "7") And (Lab1 = "3" Or Lab2 = "3" Or Lab3 = "3")) Then
                        w93 += 1
                    End If
                    If La7 = "0" Or La8 = "0" Or La9 = "0" Then
                        bdl(e)
                        xz = "0"
                        xzxz(e)
                        bdl(e)
                    End If
                End If
            End If
        End If
        ' MsgBox("er:" + er + " . " + "see:" + see + " . " + "wn9:" + wn9 + " . " + "w93:" + w93)
        If ((La7 = "1" And La8 = "1" And La9 = "1") And (wn9 >= 2 Or w93 = "3" Or w93 = "4")) Or wn9 = "9" Then
            If see = "10" Then
                s0 += 1
                Dim q1 As Integer = see - 1
                Dim q2 As String = q1
                s1 += q2
                Lab4 = Lb4 : Lab5 = Lb5 : Lab6 = Lb6 : Lab7 = Lb7 : Lab8 = Lb8 : Lab9 = Lb9
                If die = "9" Then
                    La9 = "0"
                End If
                die = "0"
            Else
                s0 += 1
                Dim q1 As Integer = see - 1
                Dim q2 As String = q1
                s1 += q2
                Lab4 = Lb4 : Lab5 = Lb5 : Lab6 = Lb6 : Lab7 = Lb7 : Lab8 = Lb8 : Lab9 = Lb9
                If die = "7" Then
                    La7 = "0"
                End If
                If die = "8" Then
                    La8 = "0"
                End If
                If die = "9" Then
                    La9 = "0"
                End If
                die = "0"
                wn9 = "0"
                w93 = "0"
                s3(e)
            End If
        Else
            If see = "10" Then
                Lab4 = Lb4 : Lab5 = Lb5 : Lab6 = Lb6 : Lab7 = Lb7 : Lab8 = Lb8 : Lab9 = Lb9
                If die = "9" Then
                    La9 = "0"
                End If
                die = "0"
            Else
                Lab4 = Lb4 : Lab5 = Lb5 : Lab6 = Lb6 : Lab7 = Lb7 : Lab8 = Lb8 : Lab9 = Lb9
                If die = "7" Then
                    La7 = "0"
                End If
                If die = "8" Then
                    La8 = "0"
                End If
                If die = "9" Then
                    La9 = "0"
                End If
                die = "0"
                wn9 = "0"
                w93 = "0"
                s3(e)
            End If
        End If
        If see = "10" Then
            wn9 = "0"
            w93 = "0"
            see = "1"
            p2(e)
        End If
    End Sub

    Sub cmptr(ByVal e As EventArgs)
        die = "0"
        ie2(e)
        za(e)
        If zn = "1" Then
            ss = "1"
        Else
            Lx1 = Lab1 : Lx2 = Lab2 : Lx3 = Lab3 : Lx4 = Lab4 : Lx5 = Lab5 : Lx6 = Lab6
            zxzx(e)
        End If
        If die = "7" Then
            La7 = "0"
        End If
        If die = "8" Then
            La8 = "0"
        End If
        If die = "9" Then
            La9 = "0"
        End If
        die = "0"
        If ss = "1" Then
        Else
            s0 += 1
            Dim q1 As Integer = see - 1
            Dim q2 As String = q1
            s1 += q2
            sw2(e)
            If gu = "1" Then
                vh = q2
            End If
        End If
        Lab4 = Lb4 : Lab5 = Lb5 : Lab6 = Lb6 : Lab7 = Lb7 : Lab8 = Lb8 : Lab9 = Lb9
        If see = "10" Then
            see = "1"
            If er = "0" And s0 = "-1" Then
                er = "1"
                cmptr(e)
            ElseIf er = "1" And s0 = "-1" Then
                er = "2"
                cmptr(e)
            ElseIf er = "2" And s0 = "-1" Then
                er = "3"
                cmptr(e)
            Else
                er = "0"
                If VaH.Checked = False And s0 >= 1 And vh <> "0" Then
                    s0 -= 1
                    s1 = s1.Replace(vh, "")
                End If
                vh = "0"
                p2(e)
            End If
        Else
            cmptr(e)
        End If
    End Sub

    Sub zxzx(ByVal e As EventArgs)
        wn3 = 0
        Dim w39 As Integer = 0
        Dim die2 As Integer = 0
        If see2 = "1" Then
            rt = Lab4 : Lab4 = Lab1 : Lab1 = rt
            If La1 = "0" Then
                La1 = "1"
                die2 = "1"
            End If
            see2 = "2"
        ElseIf see2 = "2" Then
            rt = Lab4 : Lab4 = Lab2 : Lab2 = rt
            If La2 = "0" Then
                La2 = "1"
                die2 = "2"
            End If
            see2 = "3"
        ElseIf see2 = "3" Then
            rt = Lab4 : Lab4 = Lab3 : Lab3 = rt
            If La3 = "0" Then
                La3 = "1"
                die2 = "3"
            End If
            see2 = "4"
        ElseIf see2 = "4" Then
            rt = Lab5 : Lab5 = Lab1 : Lab1 = rt
            If La1 = "0" Then
                La1 = "1"
                die2 = "1"
            End If
            see2 = "5"
        ElseIf see2 = "5" Then
            rt = Lab5 : Lab5 = Lab2 : Lab2 = rt
            If La2 = "0" Then
                La2 = "1"
                die2 = "2"
            End If
            see2 = "6"
        ElseIf see2 = "6" Then
            rt = Lab5 : Lab5 = Lab3 : Lab3 = rt
            If La3 = "0" Then
                La3 = "1"
                die2 = "3"
            End If
            see2 = "7"
        ElseIf see2 = "7" Then
            rt = Lab6 : Lab6 = Lab1 : Lab1 = rt
            If La1 = "0" Then
                La1 = "1"
                die2 = "1"
            End If
            see2 = "8"
        ElseIf see2 = "8" Then
            rt = Lab6 : Lab6 = Lab2 : Lab2 = rt
            If La2 = "0" Then
                La2 = "1"
                die2 = "2"
            End If
            see2 = "9"
        ElseIf see2 = "9" Then
            rt = Lab6 : Lab6 = Lab3 : Lab3 = rt
            If La3 = "0" Then
                La3 = "1"
                die2 = "3"
            End If
            see2 = "10"
        End If
        If (((Lab7 = "1" And La7 = "1") Or (Lab8 = "1" And La8 = "1") Or (Lab9 = "1" And La9 = "1")) And ((Lab7 = "2" And La7 = "1") Or (Lab8 = "2" And La8 = "1") Or (Lab9 = "2" And La9 = "1")) And (Lab4 = "3" Or Lab5 = "3" Or Lab6 = "3")) Or (((Lab7 = "1" And La7 = "1") Or (Lab8 = "1" And La8 = "1") Or (Lab9 = "1" And La9 = "1")) And ((Lab7 = "3" And La7 = "1") Or (Lab8 = "3" And La8 = "1") Or (Lab9 = "3" And La9 = "1")) And (Lab4 = "2" Or Lab5 = "2" Or Lab6 = "2")) Or (((Lab7 = "2" And La7 = "1") Or (Lab8 = "2" And La8 = "1") Or (Lab9 = "2" And La9 = "1")) And ((Lab7 = "3" And La7 = "1") Or (Lab8 = "3" And La8 = "1") Or (Lab9 = "3" And La9 = "1")) And (Lab4 = "1" Or Lab5 = "1" Or Lab6 = "1")) Or (((Lab7 = "4" And La7 = "1") Or (Lab8 = "4" And La8 = "1") Or (Lab9 = "4" And La9 = "1")) And ((Lab7 = "5" And La7 = "1") Or (Lab8 = "5" And La8 = "1") Or (Lab9 = "5" And La9 = "1")) And (Lab4 = "6" Or Lab5 = "6" Or Lab6 = "6")) Or (((Lab7 = "4" And La7 = "1") Or (Lab8 = "4" And La8 = "1") Or (Lab9 = "4" And La9 = "1")) And ((Lab7 = "6" And La7 = "1") Or (Lab8 = "6" And La8 = "1") Or (Lab9 = "6" And La9 = "1")) And (Lab4 = "5" Or Lab5 = "5" Or Lab6 = "5")) Or (((Lab7 = "5" And La7 = "1") Or (Lab8 = "5" And La8 = "1") Or (Lab9 = "5" And La9 = "1")) And ((Lab7 = "6" And La7 = "1") Or (Lab8 = "6" And La8 = "1") Or (Lab9 = "6" And La9 = "1")) And (Lab4 = "4" Or Lab5 = "4" Or Lab6 = "4")) Or (((Lab7 = "7" And La7 = "1") Or (Lab8 = "7" And La8 = "1") Or (Lab9 = "7" And La9 = "1")) And ((Lab7 = "8" And La7 = "1") Or (Lab8 = "8" And La8 = "1") Or (Lab9 = "8" And La9 = "1")) And (Lab4 = "9" Or Lab5 = "9" Or Lab6 = "9")) Or (((Lab7 = "7" And La7 = "1") Or (Lab8 = "7" And La8 = "1") Or (Lab9 = "7" And La9 = "1")) And ((Lab7 = "9" And La7 = "1") Or (Lab8 = "9" And La8 = "1") Or (Lab9 = "9" And La9 = "1")) And (Lab4 = "8" Or Lab5 = "8" Or Lab6 = "8")) Or (((Lab7 = "8" And La7 = "1") Or (Lab8 = "8" And La8 = "1") Or (Lab9 = "8" And La9 = "1")) And ((Lab7 = "9" And La7 = "1") Or (Lab8 = "9" And La8 = "1") Or (Lab9 = "9" And La9 = "1")) And (Lab4 = "7" Or Lab5 = "7" Or Lab6 = "7")) Or (((Lab7 = "3" And La7 = "1") Or (Lab8 = "3" And La8 = "1") Or (Lab9 = "3" And La9 = "1")) And ((Lab7 = "6" And La7 = "1") Or (Lab8 = "6" And La8 = "1") Or (Lab9 = "6" And La9 = "1")) And (Lab4 = "9" Or Lab5 = "9" Or Lab6 = "9")) Or (((Lab7 = "3" And La7 = "1") Or (Lab8 = "3" And La8 = "1") Or (Lab9 = "3" And La9 = "1")) And ((Lab7 = "9" And La7 = "1") Or (Lab8 = "9" And La8 = "1") Or (Lab9 = "9" And La9 = "1")) And (Lab4 = "6" Or Lab5 = "6" Or Lab6 = "6")) Or (((Lab7 = "6" And La7 = "1") Or (Lab8 = "6" And La8 = "1") Or (Lab9 = "6" And La9 = "1")) And ((Lab7 = "9" And La7 = "1") Or (Lab8 = "9" And La8 = "1") Or (Lab9 = "9" And La9 = "1")) And (Lab4 = "3" Or Lab5 = "3" Or Lab6 = "3")) Or (((Lab7 = "2" And La7 = "1") Or (Lab8 = "2" And La8 = "1") Or (Lab9 = "2" And La9 = "1")) And ((Lab7 = "5" And La7 = "1") Or (Lab8 = "5" And La8 = "1") Or (Lab9 = "5" And La9 = "1")) And (Lab4 = "8" Or Lab5 = "8" Or Lab6 = "8")) Or (((Lab7 = "2" And La7 = "1") Or (Lab8 = "2" And La8 = "1") Or (Lab9 = "2" And La9 = "1")) And ((Lab7 = "8" And La7 = "1") Or (Lab8 = "8" And La8 = "1") Or (Lab9 = "8" And La9 = "1")) And (Lab4 = "5" Or Lab5 = "5" Or Lab6 = "5")) Or (((Lab7 = "5" And La7 = "1") Or (Lab8 = "5" And La8 = "1") Or (Lab9 = "5" And La9 = "1")) And ((Lab7 = "8" And La7 = "1") Or (Lab8 = "8" And La8 = "1") Or (Lab9 = "8" And La9 = "1")) And (Lab4 = "2" Or Lab5 = "2" Or Lab6 = "2")) Or (((Lab7 = "1" And La7 = "1") Or (Lab8 = "1" And La8 = "1") Or (Lab9 = "1" And La9 = "1")) And ((Lab7 = "4" And La7 = "1") Or (Lab8 = "4" And La8 = "1") Or (Lab9 = "4" And La9 = "1")) And (Lab4 = "7" Or Lab5 = "7" Or Lab6 = "7")) Or (((Lab7 = "1" And La7 = "1") Or (Lab8 = "1" And La8 = "1") Or (Lab9 = "1" And La9 = "1")) And ((Lab7 = "7" And La7 = "1") Or (Lab8 = "7" And La8 = "1") Or (Lab9 = "7" And La9 = "1")) And (Lab4 = "4" Or Lab5 = "4" Or Lab6 = "4")) Or (((Lab7 = "4" And La7 = "1") Or (Lab8 = "4" And La8 = "1") Or (Lab9 = "4" And La9 = "1")) And ((Lab7 = "7" And La7 = "1") Or (Lab8 = "7" And La8 = "1") Or (Lab9 = "7" And La9 = "1")) And (Lab4 = "1" Or Lab5 = "1" Or Lab6 = "1")) Or (VaH.Checked = False And ((((Lab7 = "1" And La7 = "1") Or (Lab8 = "1" And La8 = "1") Or (Lab9 = "1" And La9 = "1")) And ((Lab7 = "5" And La7 = "1") Or (Lab8 = "5" And La8 = "1") Or (Lab9 = "5" And La9 = "1")) And (Lab4 = "9" Or Lab5 = "9" Or Lab6 = "9")) Or (((Lab7 = "1" And La7 = "1") Or (Lab8 = "1" And La8 = "1") Or (Lab9 = "1" And La9 = "1")) And ((Lab7 = "9" And La7 = "1") Or (Lab8 = "9" And La8 = "1") Or (Lab9 = "9" And La9 = "1")) And (Lab4 = "5" Or Lab5 = "5" Or Lab6 = "5")) Or (((Lab7 = "5" And La7 = "1") Or (Lab8 = "5" And La8 = "1") Or (Lab9 = "5" And La9 = "1")) And ((Lab7 = "9" And La7 = "1") Or (Lab8 = "9" And La8 = "1") Or (Lab9 = "9" And La9 = "1")) And (Lab4 = "1" Or Lab5 = "1" Or Lab6 = "1")) Or (((Lab7 = "3" And La7 = "1") Or (Lab8 = "3" And La8 = "1") Or (Lab9 = "3" And La9 = "1")) And ((Lab7 = "5" And La7 = "1") Or (Lab8 = "5" And La8 = "1") Or (Lab9 = "5" And La9 = "1")) And (Lab4 = "7" Or Lab5 = "7" Or Lab6 = "7")) Or (((Lab7 = "3" And La7 = "1") Or (Lab8 = "3" And La8 = "1") Or (Lab9 = "3" And La9 = "1")) And ((Lab7 = "7" And La7 = "1") Or (Lab8 = "7" And La8 = "1") Or (Lab9 = "7" And La9 = "1")) And (Lab4 = "5" Or Lab5 = "5" Or Lab6 = "5")) Or (((Lab7 = "5" And La7 = "1") Or (Lab8 = "5" And La8 = "1") Or (Lab9 = "5" And La9 = "1")) And ((Lab7 = "7" And La7 = "1") Or (Lab8 = "7" And La8 = "1") Or (Lab9 = "7" And La9 = "1")) And (Lab4 = "3" Or Lab5 = "3" Or Lab6 = "3")))) Then
        Else
            If (La1 = "1" And La2 = "1" And La3 = "1") And (((Lab1 = "1" Or Lab2 = "1" Or Lab3 = "1") And (Lab1 = "2" Or Lab2 = "2" Or Lab3 = "2") And (Lab4 = "3" Or Lab5 = "3" Or Lab6 = "3")) Or ((Lab1 = "1" Or Lab2 = "1" Or Lab3 = "1") And (Lab1 = "3" Or Lab2 = "3" Or Lab3 = "3") And (Lab4 = "2" Or Lab5 = "2" Or Lab6 = "2")) Or ((Lab1 = "2" Or Lab2 = "2" Or Lab3 = "2") And (Lab1 = "3" Or Lab2 = "3" Or Lab3 = "3") And (Lab4 = "1" Or Lab5 = "1" Or Lab6 = "1")) Or ((Lab1 = "4" Or Lab2 = "4" Or Lab3 = "4") And (Lab1 = "5" Or Lab2 = "5" Or Lab3 = "5") And (Lab4 = "6" Or Lab5 = "6" Or Lab6 = "6")) Or ((Lab1 = "4" Or Lab2 = "4" Or Lab3 = "4") And (Lab1 = "6" Or Lab2 = "6" Or Lab3 = "6") And (Lab4 = "5" Or Lab5 = "5" Or Lab6 = "5")) Or ((Lab1 = "5" Or Lab2 = "5" Or Lab3 = "5") And (Lab1 = "6" Or Lab2 = "6" Or Lab3 = "6") And (Lab4 = "4" Or Lab5 = "4" Or Lab6 = "4")) Or ((Lab1 = "7" Or Lab2 = "7" Or Lab3 = "7") And (Lab1 = "8" Or Lab2 = "8" Or Lab3 = "8") And (Lab4 = "9" Or Lab5 = "9" Or Lab6 = "9")) Or ((Lab1 = "7" Or Lab2 = "7" Or Lab3 = "7") And (Lab1 = "9" Or Lab2 = "9" Or Lab3 = "9") And (Lab4 = "8" Or Lab5 = "8" Or Lab6 = "8")) Or ((Lab1 = "8" Or Lab2 = "8" Or Lab3 = "8") And (Lab1 = "9" Or Lab2 = "9" Or Lab3 = "9") And (Lab4 = "7" Or Lab5 = "7" Or Lab6 = "7"))) Then
                wn3 += 1
            End If
            If (La1 = "1" And La2 = "1" And La3 = "1") And (((Lab1 = "3" Or Lab2 = "3" Or Lab3 = "3") And (Lab1 = "6" Or Lab2 = "6" Or Lab3 = "6") And (Lab4 = "9" Or Lab5 = "9" Or Lab6 = "9")) Or ((Lab1 = "3" Or Lab2 = "3" Or Lab3 = "3") And (Lab1 = "9" Or Lab2 = "9" Or Lab3 = "9") And (Lab4 = "6" Or Lab5 = "6" Or Lab6 = "6")) Or ((Lab1 = "6" Or Lab2 = "6" Or Lab3 = "6") And (Lab1 = "9" Or Lab2 = "9" Or Lab3 = "9") And (Lab4 = "3" Or Lab5 = "3" Or Lab6 = "3")) Or ((Lab1 = "2" Or Lab2 = "2" Or Lab3 = "2") And (Lab1 = "5" Or Lab2 = "5" Or Lab3 = "5") And (Lab4 = "8" Or Lab5 = "8" Or Lab6 = "8")) Or ((Lab1 = "2" Or Lab2 = "2" Or Lab3 = "2") And (Lab1 = "8" Or Lab2 = "8" Or Lab3 = "8") And (Lab4 = "5" Or Lab5 = "5" Or Lab6 = "5")) Or ((Lab1 = "5" Or Lab2 = "5" Or Lab3 = "5") And (Lab1 = "8" Or Lab2 = "8" Or Lab3 = "8") And (Lab4 = "2" Or Lab5 = "2" Or Lab6 = "2")) Or ((Lab1 = "1" Or Lab2 = "1" Or Lab3 = "1") And (Lab1 = "4" Or Lab2 = "4" Or Lab3 = "4") And (Lab4 = "7" Or Lab5 = "7" Or Lab6 = "7")) Or ((Lab1 = "1" Or Lab2 = "1" Or Lab3 = "1") And (Lab1 = "7" Or Lab2 = "7" Or Lab3 = "7") And (Lab4 = "4" Or Lab5 = "4" Or Lab6 = "4")) Or ((Lab1 = "4" Or Lab2 = "4" Or Lab3 = "4") And (Lab1 = "7" Or Lab2 = "7" Or Lab3 = "7") And (Lab4 = "1" Or Lab5 = "1" Or Lab6 = "1"))) Then
                wn3 += 1
            End If
            If VaH.Checked = False Then
                If (La1 = "1" And La2 = "1" And La3 = "1") And (((Lab1 = "1" Or Lab2 = "1" Or Lab3 = "1") And (Lab1 = "5" Or Lab2 = "5" Or Lab3 = "5") And (Lab4 = "9" Or Lab5 = "9" Or Lab6 = "9")) Or ((Lab1 = "1" Or Lab2 = "1" Or Lab3 = "1") And (Lab1 = "9" Or Lab2 = "9" Or Lab3 = "9") And (Lab4 = "5" Or Lab5 = "5" Or Lab6 = "5")) Or ((Lab1 = "5" Or Lab2 = "5" Or Lab3 = "5") And (Lab1 = "9" Or Lab2 = "9" Or Lab3 = "9") And (Lab4 = "1" Or Lab5 = "1" Or Lab6 = "1"))) Then
                    wn3 += 1
                End If
                If (La1 = "1" And La2 = "1" And La3 = "1") And (((Lab1 = "3" Or Lab2 = "3" Or Lab3 = "3") And (Lab1 = "5" Or Lab2 = "5" Or Lab3 = "5") And (Lab4 = "7" Or Lab5 = "7" Or Lab6 = "7")) Or ((Lab1 = "3" Or Lab2 = "3" Or Lab3 = "3") And (Lab1 = "7" Or Lab2 = "7" Or Lab3 = "7") And (Lab4 = "5" Or Lab5 = "5" Or Lab6 = "5")) Or ((Lab1 = "5" Or Lab2 = "5" Or Lab3 = "5") And (Lab1 = "7" Or Lab2 = "7" Or Lab3 = "7") And (Lab4 = "3" Or Lab5 = "3" Or Lab6 = "3"))) Then
                    wn3 += 1
                End If
                If (La1 = "1" And La2 = "1" And La3 = "1") And (La7 = "0" Or La8 = "0" Or La9 = "0") Then
                    If ((Lab1 = "1" Or Lab2 = "1" Or Lab3 = "1") And (Lab1 = "2" Or Lab2 = "2" Or Lab3 = "2") And (Lab7 = "3" Or Lab8 = "3" Or Lab9 = "3")) Or ((Lab1 = "1" Or Lab2 = "1" Or Lab3 = "1") And (Lab1 = "3" Or Lab2 = "3" Or Lab3 = "3") And (Lab7 = "2" Or Lab8 = "2" Or Lab9 = "2")) Or ((Lab1 = "2" Or Lab2 = "2" Or Lab3 = "2") And (Lab1 = "3" Or Lab2 = "3" Or Lab3 = "3") And (Lab7 = "1" Or Lab8 = "1" Or Lab9 = "1")) Or ((Lab1 = "4" Or Lab2 = "4" Or Lab3 = "4") And (Lab1 = "5" Or Lab2 = "5" Or Lab3 = "5") And (Lab7 = "6" Or Lab8 = "6" Or Lab9 = "6")) Or ((Lab1 = "4" Or Lab2 = "4" Or Lab3 = "4") And (Lab1 = "6" Or Lab2 = "6" Or Lab3 = "6") And (Lab7 = "5" Or Lab8 = "5" Or Lab9 = "5")) Or ((Lab1 = "5" Or Lab2 = "5" Or Lab3 = "5") And (Lab1 = "6" Or Lab2 = "6" Or Lab3 = "6") And (Lab7 = "4" Or Lab8 = "4" Or Lab9 = "4")) Or ((Lab1 = "7" Or Lab2 = "7" Or Lab3 = "7") And (Lab1 = "8" Or Lab2 = "8" Or Lab3 = "8") And (Lab7 = "9" Or Lab8 = "9" Or Lab9 = "9")) Or ((Lab1 = "7" Or Lab2 = "7" Or Lab3 = "7") And (Lab1 = "9" Or Lab2 = "9" Or Lab3 = "9") And (Lab7 = "8" Or Lab8 = "8" Or Lab9 = "8")) Or ((Lab1 = "8" Or Lab2 = "8" Or Lab3 = "8") And (Lab1 = "9" Or Lab2 = "9" Or Lab3 = "9") And (Lab7 = "7" Or Lab8 = "7" Or Lab9 = "7")) Then
                        w39 += 1
                    End If
                    If ((Lab1 = "3" Or Lab2 = "3" Or Lab3 = "3") And (Lab1 = "6" Or Lab2 = "6" Or Lab3 = "6") And (Lab7 = "9" Or Lab8 = "9" Or Lab9 = "9")) Or ((Lab1 = "3" Or Lab2 = "3" Or Lab3 = "3") And (Lab1 = "9" Or Lab2 = "9" Or Lab3 = "9") And (Lab7 = "6" Or Lab8 = "6" Or Lab9 = "6")) Or ((Lab1 = "6" Or Lab2 = "6" Or Lab3 = "6") And (Lab1 = "9" Or Lab2 = "9" Or Lab3 = "9") And (Lab7 = "3" Or Lab8 = "3" Or Lab9 = "3")) Or ((Lab1 = "2" Or Lab2 = "2" Or Lab3 = "2") And (Lab1 = "5" Or Lab2 = "5" Or Lab3 = "5") And (Lab7 = "8" Or Lab8 = "8" Or Lab9 = "8")) Or ((Lab1 = "2" Or Lab2 = "2" Or Lab3 = "2") And (Lab1 = "8" Or Lab2 = "8" Or Lab3 = "8") And (Lab7 = "5" Or Lab8 = "5" Or Lab9 = "5")) Or ((Lab1 = "5" Or Lab2 = "5" Or Lab3 = "5") And (Lab1 = "8" Or Lab2 = "8" Or Lab3 = "8") And (Lab7 = "2" Or Lab8 = "2" Or Lab9 = "2")) Or ((Lab1 = "1" Or Lab2 = "1" Or Lab3 = "1") And (Lab1 = "4" Or Lab2 = "4" Or Lab3 = "4") And (Lab7 = "7" Or Lab8 = "7" Or Lab9 = "7")) Or ((Lab1 = "1" Or Lab2 = "1" Or Lab3 = "1") And (Lab1 = "7" Or Lab2 = "7" Or Lab3 = "7") And (Lab7 = "4" Or Lab8 = "4" Or Lab9 = "4")) Or ((Lab1 = "4" Or Lab2 = "4" Or Lab3 = "4") And (Lab1 = "7" Or Lab2 = "7" Or Lab3 = "7") And (Lab7 = "1" Or Lab8 = "1" Or Lab9 = "1")) Then
                        w39 += 1
                    End If
                    If ((Lab1 = "1" Or Lab2 = "1" Or Lab3 = "1") And (Lab1 = "5" Or Lab2 = "5" Or Lab3 = "5") And (Lab7 = "9" Or Lab8 = "9" Or Lab9 = "9")) Or ((Lab1 = "1" Or Lab2 = "1" Or Lab3 = "1") And (Lab1 = "9" Or Lab2 = "9" Or Lab3 = "9") And (Lab7 = "5" Or Lab8 = "5" Or Lab9 = "5")) Or ((Lab1 = "5" Or Lab2 = "5" Or Lab3 = "5") And (Lab1 = "9" Or Lab2 = "9" Or Lab3 = "9") And (Lab7 = "1" Or Lab8 = "1" Or Lab9 = "1")) Then
                        w39 += 1
                    End If
                    If ((Lab1 = "3" Or Lab2 = "3" Or Lab3 = "3") And (Lab1 = "5" Or Lab2 = "5" Or Lab3 = "5") And (Lab7 = "7" Or Lab8 = "7" Or Lab9 = "7")) Or ((Lab1 = "3" Or Lab2 = "3" Or Lab3 = "3") And (Lab1 = "7" Or Lab2 = "7" Or Lab3 = "7") And (Lab7 = "5" Or Lab8 = "5" Or Lab9 = "5")) Or ((Lab1 = "5" Or Lab2 = "5" Or Lab3 = "5") And (Lab1 = "7" Or Lab2 = "7" Or Lab3 = "7") And (Lab7 = "3" Or Lab8 = "3" Or Lab9 = "3")) Then
                        w39 += 1
                    End If
                End If
                If (La7 = "0" Or La8 = "0" Or La9 = "0") Or (La1 = "0" Or La2 = "0" Or La3 = "0") Then
                    xz = "0"
                    xzxz(e)
                End If
            End If
        End If
        '  Dim wwn3 As String = wn3 : Dim ww39 As String = w39
        '  MsgBox("er:" + er + " . " + "see:" + see + " . " + "see2:" + see2 + " . " + "wn3:" + wwn3 + " . " + "w39:" + ww39)
        Lab4 = Lx4 : Lab5 = Lx5 : Lab6 = Lx6 : Lab1 = Lx1 : Lab2 = Lx2 : Lab3 = Lx3
        If (wn3 = "0" Or wn3 = "1") And w39 <= er Then
            ss = "0"
            wn3 = "0"
            w39 = "0"
            If see2 = "10" Then
                If die2 = "3" Then
                    La3 = "0"
                End If
                die2 = "0"
                see2 = "1"
            Else
                If die2 = "1" Then
                    La1 = "0"
                End If
                If die2 = "2" Then
                    La2 = "0"
                End If
                If die2 = "3" Then
                    La3 = "0"
                End If
                die2 = "0"
                zxzx(e)
            End If
        Else
            ss = "1"
            wn3 = "0"
            w39 = "0"
            If see2 = "10" Then
                If die2 = "3" Then
                    La3 = "0"
                End If
                die2 = "0"
            Else
                If die2 = "1" Then
                    La1 = "0"
                End If
                If die2 = "2" Then
                    La2 = "0"
                End If
                If die2 = "3" Then
                    La3 = "0"
                End If
                die2 = "0"
            End If
            see2 = "1"
        End If
    End Sub

    Sub xzxz(ByVal e As EventArgs)
        Dim aaa As String = "0"
        If ((Lab7 = "2" And La7 = "1") Or (Lab8 = "2" And La8 = "1") Or (Lab9 = "2" And La9 = "1")) And (((Lab1 = "1" And La1 = "0") Or (Lab2 = "1" And La2 = "0") Or (Lab3 = "1" And La3 = "0")) Or ((Lab1 = "3" And La1 = "0") Or (Lab2 = "3" And La2 = "0") Or (Lab3 = "3" And La3 = "0"))) And ((Lab1 = "5" And La1 = "1") Or (Lab2 = "5" And La2 = "1") Or (Lab3 = "5" And La3 = "1")) And ((Lab1 = "6" And La1 = "1") Or (Lab2 = "6" And La2 = "1") Or (Lab3 = "6" And La3 = "1")) And ((Lab7 = "7" And La7 = "0") Or (Lab8 = "7" And La8 = "0") Or (Lab9 = "7" And La9 = "0")) And ((Lab7 = "8" And La7 = "0") Or (Lab8 = "8" And La8 = "0") Or (Lab9 = "8" And La9 = "0")) Then
            aaa = "1"
        ElseIf ((Lab1 = "1" And La1 = "0") Or (Lab2 = "1" And La2 = "0") Or (Lab3 = "1" And La3 = "0")) And ((Lab7 = "2" And La7 = "1") Or (Lab8 = "2" And La8 = "1") Or (Lab9 = "2" And La9 = "1")) And ((Lab1 = "4" And La1 = "1") Or (Lab2 = "4" And La2 = "1") Or (Lab3 = "4" And La3 = "1")) And ((Lab1 = "5" And La1 = "1") Or (Lab2 = "5" And La2 = "1") Or (Lab3 = "5" And La3 = "1")) And ((Lab7 = "7" And La7 = "0") Or (Lab8 = "7" And La8 = "0") Or (Lab9 = "7" And La9 = "0")) And ((Lab7 = "9" And La7 = "0") Or (Lab8 = "9" And La8 = "0") Or (Lab9 = "9" And La9 = "0")) Then
            aaa = "1"
        ElseIf ((Lab1 = "1" And La1 = "0") Or (Lab2 = "1" And La2 = "0") Or (Lab3 = "1" And La3 = "0")) And ((Lab1 = "2" And La1 = "1") Or (Lab2 = "2" And La2 = "1") Or (Lab3 = "2" And La3 = "1")) And ((Lab1 = "5" And La1 = "1") Or (Lab2 = "5" And La2 = "1") Or (Lab3 = "5" And La3 = "1")) And ((Lab7 = "6" And La7 = "1") Or (Lab8 = "6" And La8 = "1") Or (Lab9 = "6" And La9 = "1")) And ((Lab7 = "7" And La7 = "0") Or (Lab8 = "7" And La8 = "0") Or (Lab9 = "7" And La9 = "0")) And ((Lab7 = "9" And La7 = "0") Or (Lab8 = "9" And La8 = "0") Or (Lab9 = "9" And La9 = "0")) Then
            aaa = "1"
        ElseIf ((Lab1 = "2" And La1 = "1") Or (Lab2 = "2" And La2 = "1") Or (Lab3 = "2" And La3 = "1")) And ((Lab7 = "3" And La7 = "0") Or (Lab8 = "3" And La8 = "0") Or (Lab9 = "3" And La9 = "0")) And ((Lab7 = "4" And La7 = "1") Or (Lab8 = "4" And La8 = "1") Or (Lab9 = "4" And La9 = "1")) And ((Lab1 = "5" And La1 = "1") Or (Lab2 = "5" And La2 = "1") Or (Lab3 = "5" And La3 = "1")) And ((Lab7 = "6" And La7 = "1") Or (Lab8 = "6" And La8 = "1") Or (Lab9 = "6" And La9 = "1")) And ((Lab1 = "7" And La1 = "0") Or (Lab2 = "7" And La2 = "0") Or (Lab3 = "7" And La3 = "0")) Then
            aaa = "2"
        ElseIf ((Lab1 = "2" And La1 = "0") Or (Lab2 = "2" And La2 = "0") Or (Lab3 = "2" And La3 = "0")) And ((Lab1 = "3" And La1 = "1") Or (Lab2 = "3" And La2 = "1") Or (Lab3 = "3" And La3 = "1")) And ((Lab7 = "4" And La7 = "1") Or (Lab8 = "4" And La8 = "1") Or (Lab9 = "4" And La9 = "1")) And ((Lab1 = "5" And La1 = "1") Or (Lab2 = "5" And La2 = "1") Or (Lab3 = "5" And La3 = "1")) And ((Lab7 = "7" And La7 = "0") Or (Lab8 = "7" And La8 = "0") Or (Lab9 = "7" And La9 = "0")) And ((Lab7 = "8" And La7 = "0") Or (Lab8 = "8" And La8 = "0") Or (Lab9 = "8" And La9 = "0")) Then
            aaa = "1"
        ElseIf ((Lab1 = "2" And La1 = "0") Or (Lab2 = "2" And La2 = "0") Or (Lab3 = "2" And La3 = "0")) And ((Lab7 = "4" And La7 = "1") Or (Lab8 = "4" And La8 = "1") Or (Lab9 = "4" And La9 = "1")) And ((Lab1 = "5" And La1 = "1") Or (Lab2 = "5" And La2 = "1") Or (Lab3 = "5" And La3 = "1")) And ((Lab7 = "6" And La7 = "1") Or (Lab8 = "6" And La8 = "1") Or (Lab9 = "6" And La9 = "1")) And ((Lab1 = "8" And La1 = "1") Or (Lab2 = "8" And La2 = "1") Or (Lab3 = "8" And La3 = "1")) And ((Lab7 = "9" And La7 = "0") Or (Lab8 = "9" And La8 = "0") Or (Lab9 = "9" And La9 = "0")) Then
            aaa = "2"
        ElseIf ((Lab7 = "2" And La7 = "1") Or (Lab8 = "2" And La8 = "1") Or (Lab9 = "2" And La9 = "1")) And ((Lab1 = "3" And La1 = "0") Or (Lab2 = "3" And La2 = "0") Or (Lab3 = "3" And La3 = "0")) And ((Lab1 = "5" And La1 = "1") Or (Lab2 = "5" And La2 = "1") Or (Lab3 = "5" And La3 = "1")) And ((Lab1 = "6" And La1 = "1") Or (Lab2 = "6" And La2 = "1") Or (Lab3 = "6" And La3 = "1")) And ((Lab7 = "8" And La7 = "0") Or (Lab8 = "8" And La8 = "0") Or (Lab9 = "8" And La9 = "0")) And ((Lab7 = "9" And La7 = "0") Or (Lab8 = "9" And La8 = "0") Or (Lab9 = "9" And La9 = "0")) Then
            aaa = "2"
        ElseIf ((Lab1 = "2" And La1 = "0") Or (Lab2 = "2" And La2 = "0") Or (Lab3 = "2" And La3 = "0")) And ((Lab7 = "4" And La7 = "1") Or (Lab8 = "4" And La8 = "1") Or (Lab9 = "4" And La9 = "1")) And ((Lab1 = "5" And La1 = "1") Or (Lab2 = "5" And La2 = "1") Or (Lab3 = "5" And La3 = "1")) And ((Lab7 = "6" And La7 = "1") Or (Lab8 = "6" And La8 = "1") Or (Lab9 = "6" And La9 = "1")) And ((Lab1 = "7" And La1 = "1") Or (Lab2 = "7" And La2 = "1") Or (Lab3 = "7" And La3 = "1")) And ((Lab7 = "9" And La7 = "0") Or (Lab8 = "9" And La8 = "0") Or (Lab9 = "9" And La9 = "0")) Then
            aaa = "2"
        ElseIf ((Lab1 = "2" And La1 = "0") Or (Lab2 = "2" And La2 = "0") Or (Lab3 = "2" And La3 = "0")) And ((Lab1 = "3" And La1 = "1") Or (Lab2 = "3" And La2 = "1") Or (Lab3 = "3" And La3 = "1")) And ((Lab1 = "5" And La1 = "1") Or (Lab2 = "5" And La2 = "1") Or (Lab3 = "5" And La3 = "1")) And ((Lab7 = "6" And La7 = "1") Or (Lab8 = "6" And La8 = "1") Or (Lab9 = "6" And La9 = "1")) And ((Lab7 = "7" And La7 = "0") Or (Lab8 = "7" And La8 = "0") Or (Lab9 = "7" And La9 = "0")) And ((Lab7 = "9" And La7 = "0") Or (Lab8 = "9" And La8 = "0") Or (Lab9 = "9" And La9 = "0")) Then
            aaa = "1"
        ElseIf ((Lab1 = "1" And La1 = "0") Or (Lab2 = "1" And La2 = "0") Or (Lab3 = "1" And La3 = "0")) And ((Lab1 = "3" And La1 = "1") Or (Lab2 = "3" And La2 = "1") Or (Lab3 = "3" And La3 = "1")) And ((Lab7 = "4" And La7 = "1") Or (Lab8 = "4" And La8 = "1") Or (Lab9 = "4" And La9 = "1")) And ((Lab1 = "5" And La1 = "1") Or (Lab2 = "5" And La2 = "1") Or (Lab3 = "5" And La3 = "1")) And ((Lab7 = "7" And La7 = "0") Or (Lab8 = "7" And La8 = "0") Or (Lab9 = "7" And La9 = "0")) And ((Lab7 = "9" And La7 = "0") Or (Lab8 = "9" And La8 = "0") Or (Lab9 = "9" And La9 = "0")) Then
            aaa = "1"
        ElseIf ((Lab1 = "2" And La1 = "0") Or (Lab2 = "2" And La2 = "0") Or (Lab3 = "2" And La3 = "0")) And ((Lab1 = "3" And La1 = "1") Or (Lab2 = "3" And La2 = "1") Or (Lab3 = "3" And La3 = "1")) And ((Lab7 = "4" And La7 = "1") Or (Lab8 = "4" And La8 = "1") Or (Lab9 = "4" And La9 = "1")) And ((Lab1 = "5" And La1 = "1") Or (Lab2 = "5" And La2 = "1") Or (Lab3 = "5" And La3 = "1")) And ((Lab7 = "6" And La7 = "1") Or (Lab8 = "6" And La8 = "1") Or (Lab9 = "6" And La9 = "1")) And ((Lab7 = "8" And La7 = "0") Or (Lab8 = "8" And La8 = "0") Or (Lab9 = "8" And La9 = "0")) Then
            aaa = "1"
        ElseIf ((Lab1 = "8" And La1 = "1") Or (Lab2 = "8" And La2 = "1") Or (Lab3 = "8" And La3 = "1")) And ((Lab7 = "3" And La7 = "1") Or (Lab8 = "3" And La8 = "1") Or (Lab9 = "3" And La9 = "1")) And ((Lab7 = "4" And La7 = "1") Or (Lab8 = "4" And La8 = "1") Or (Lab9 = "4" And La9 = "1")) And ((Lab1 = "5" And La1 = "1") Or (Lab2 = "5" And La2 = "1") Or (Lab3 = "5" And La3 = "1")) And ((Lab1 = "7" And La1 = "1") Or (Lab2 = "7" And La2 = "1") Or (Lab3 = "7" And La3 = "1")) And ((Lab7 = "9" And La7 = "0") Or (Lab8 = "9" And La8 = "0") Or (Lab9 = "9" And La9 = "0")) Then
            aaa = "1"
        ElseIf ((Lab1 = "7" And La1 = "1") Or (Lab2 = "7" And La2 = "1") Or (Lab3 = "7" And La3 = "1")) And ((Lab7 = "4" And La7 = "1") Or (Lab8 = "4" And La8 = "1") Or (Lab9 = "4" And La9 = "1")) And ((Lab7 = "2" And La7 = "1") Or (Lab8 = "2" And La8 = "1") Or (Lab9 = "2" And La9 = "1")) And ((Lab1 = "5" And La1 = "1") Or (Lab2 = "5" And La2 = "1") Or (Lab3 = "5" And La3 = "1")) And ((Lab1 = "8" And La1 = "1") Or (Lab2 = "8" And La2 = "1") Or (Lab3 = "8" And La3 = "1")) And ((Lab7 = "9" And La7 = "0") Or (Lab8 = "9" And La8 = "0") Or (Lab9 = "9" And La9 = "0")) Then
            aaa = "1"
        ElseIf ((Lab1 = "1" And La1 = "1") Or (Lab2 = "1" And La2 = "1") Or (Lab3 = "1" And La3 = "1")) And ((Lab7 = "4" And La7 = "1") Or (Lab8 = "4" And La8 = "1") Or (Lab9 = "4" And La9 = "1")) And ((Lab7 = "6" And La7 = "1") Or (Lab8 = "6" And La8 = "1") Or (Lab9 = "6" And La9 = "1")) And ((Lab1 = "5" And La1 = "1") Or (Lab2 = "5" And La2 = "1") Or (Lab3 = "5" And La3 = "1")) And ((Lab1 = "7" And La1 = "0") Or (Lab2 = "7" And La2 = "0") Or (Lab3 = "7" And La3 = "0")) And ((Lab7 = "3" And La7 = "0") Or (Lab8 = "3" And La8 = "0") Or (Lab9 = "3" And La9 = "0")) Then
            aaa = "1"
        ElseIf ((Lab1 = "9" And La1 = "1") Or (Lab2 = "9" And La2 = "1") Or (Lab3 = "9" And La3 = "1")) And ((Lab7 = "6" And La7 = "1") Or (Lab8 = "6" And La8 = "1") Or (Lab9 = "6" And La9 = "1")) And ((Lab7 = "1" And La7 = "0") Or (Lab8 = "1" And La8 = "0") Or (Lab9 = "1" And La9 = "0")) And ((Lab1 = "5" And La1 = "1") Or (Lab2 = "5" And La2 = "1") Or (Lab3 = "5" And La3 = "1")) And ((Lab1 = "8" And La1 = "0") Or (Lab2 = "8" And La2 = "0") Or (Lab3 = "8" And La3 = "0")) And (((Lab7 = "2" And La7 = "0") Or (Lab8 = "2" And La8 = "0") Or (Lab9 = "2" And La9 = "0")) Or ((Lab7 = "3" And La7 = "0") Or (Lab8 = "3" And La8 = "0") Or (Lab9 = "3" And La9 = "0"))) Then
            aaa = "1"
        ElseIf ((Lab1 = "3" And La1 = "1") Or (Lab2 = "3" And La2 = "1") Or (Lab3 = "3" And La3 = "1")) And ((Lab7 = "4" And La7 = "1") Or (Lab8 = "4" And La8 = "1") Or (Lab9 = "4" And La9 = "1")) And ((Lab7 = "9" And La7 = "0") Or (Lab8 = "9" And La8 = "0") Or (Lab9 = "9" And La9 = "0")) And ((Lab1 = "5" And La1 = "1") Or (Lab2 = "5" And La2 = "1") Or (Lab3 = "5" And La3 = "1")) And ((Lab1 = "6" And La1 = "1") Or (Lab2 = "6" And La2 = "1") Or (Lab3 = "6" And La3 = "1")) And ((Lab7 = "8" And La7 = "1") Or (Lab8 = "8" And La8 = "1") Or (Lab9 = "8" And La9 = "1")) Then
            aaa = "1"
        ElseIf ((Lab1 = "1" And La1 = "1") Or (Lab2 = "1" And La2 = "1") Or (Lab3 = "1" And La3 = "1")) And ((Lab7 = "4" And La7 = "1") Or (Lab8 = "4" And La8 = "1") Or (Lab9 = "4" And La9 = "1")) And ((Lab7 = "9" And La7 = "0") Or (Lab8 = "9" And La8 = "0") Or (Lab9 = "9" And La9 = "0")) And ((Lab1 = "3" And La1 = "1") Or (Lab2 = "3" And La2 = "1") Or (Lab3 = "3" And La3 = "1")) And ((Lab1 = "6" And La1 = "1") Or (Lab2 = "6" And La2 = "1") Or (Lab3 = "6" And La3 = "1")) And ((Lab7 = "7" And La7 = "1") Or (Lab8 = "7" And La8 = "1") Or (Lab9 = "7" And La9 = "1")) Then
            aaa = "1"
        End If
        xz += 1
        If aaa = "1" Or aaa = "2" Then
            wn3 += 2
            If aaa = "1" Then
                wn9 += 2
            End If
            If xz = "2" Then
                rle(e) : rle(e) : rle(e)
            ElseIf xz = "3" Then
                rle(e) : rle(e)
            ElseIf xz = "4" Then
                rle(e)
            ElseIf xz = "5" Then
                rhe(e) : rle(e)
            ElseIf xz = "6" Then
                rhe(e) : rle(e) : rle(e)
            ElseIf xz = "7" Then
                rhe(e) : rle(e) : rle(e) : rle(e)
            ElseIf xz = "8" Then
                rhe(e)
            End If
        Else
            If xz = "8" Then
                rhe(e)
            ElseIf xz = "1" Or xz = "2" Or xz = "3" Or xz = "5" Or xz = "6" Or xz = "7" Then
                rle(e)
                xzxz(e)
            ElseIf xz = "4" Then
                rhe(e)
                xzxz(e)
            End If
        End If
    End Sub

    Sub p2(ByVal e As EventArgs)
        If s0 = "-1" Then
        Else
            Dim rand = New Random
            Dim x As Integer
            x = rand.Next(0, s0 + 1)
            Dim z As String = s1.ToList(x)
            Dim u1 As String = s1.Replace("2", "").Replace("3", "").Replace("4", "").Replace("5", "").Replace("6", "").Replace("7", "").Replace("8", "").Replace("9", "")
            Dim u2 As String = s1.Replace("1", "").Replace("3", "").Replace("4", "").Replace("5", "").Replace("6", "").Replace("7", "").Replace("8", "").Replace("9", "")
            Dim u3 As String = s1.Replace("2", "").Replace("1", "").Replace("4", "").Replace("5", "").Replace("6", "").Replace("7", "").Replace("8", "").Replace("9", "")
            Dim u4 As String = s1.Replace("2", "").Replace("3", "").Replace("1", "").Replace("5", "").Replace("6", "").Replace("7", "").Replace("8", "").Replace("9", "")
            Dim u5 As String = s1.Replace("2", "").Replace("3", "").Replace("4", "").Replace("1", "").Replace("6", "").Replace("7", "").Replace("8", "").Replace("9", "")
            Dim u6 As String = s1.Replace("2", "").Replace("3", "").Replace("4", "").Replace("5", "").Replace("1", "").Replace("7", "").Replace("8", "").Replace("9", "")
            Dim u7 As String = s1.Replace("2", "").Replace("3", "").Replace("4", "").Replace("5", "").Replace("6", "").Replace("1", "").Replace("8", "").Replace("9", "")
            Dim u8 As String = s1.Replace("2", "").Replace("3", "").Replace("4", "").Replace("5", "").Replace("6", "").Replace("7", "").Replace("1", "").Replace("9", "")
            Dim u9 As String = s1.Replace("2", "").Replace("3", "").Replace("4", "").Replace("5", "").Replace("6", "").Replace("7", "").Replace("8", "").Replace("1", "")
            If ((La7 = "1" And (z = "1" Or z = "4" Or z = "7")) Or (La8 = "1" And (z = "2" Or z = "5" Or z = "8")) Or (La9 = "1" And (z = "3" Or z = "6" Or z = "9"))) And ((La7 = "0" And (z = "2" Or z = "3" Or z = "5" Or z = "6" Or z = "8" Or z = "9") And (u1 = "1" Or u4 = "4" Or u7 = "7")) Or (La8 = "0" And (z = "1" Or z = "3" Or z = "4" Or z = "6" Or z = "7" Or z = "9") And (u2 = "2" Or u5 = "5" Or u8 = "8")) Or (La9 = "0" And (z = "1" Or z = "2" Or z = "4" Or z = "5" Or z = "7" Or z = "8") And (u3 = "3" Or u6 = "6" Or u9 = "9"))) Then
                If La7 = "0" And (u1 = "1" Or u4 = "4" Or u7 = "7") Then
                    If u1 = "1" Then
                        l47(e)
                    ElseIf u4 = "4" Then
                        l57(e)
                    ElseIf u7 = "7" Then
                        l67(e)
                    End If
                ElseIf La8 = "0" And (u2 = "2" Or u5 = "5" Or u8 = "8") Then
                    If u2 = "2" Then
                        l48(e)
                    ElseIf u5 = "5" Then
                        l58(e)
                    ElseIf u8 = "8" Then
                        l68(e)
                    End If
                ElseIf La9 = "0" And (u3 = "3" Or u6 = "6" Or u9 = "9") Then
                    If u3 = "3" Then
                        l49(e)
                    ElseIf u6 = "6" Then
                        l59(e)
                    ElseIf u9 = "9" Then
                        l69(e)
                    End If
                End If
            Else
                If z = "1" Then
                    l47(e)
                ElseIf z = "2" Then
                    l48(e)
                ElseIf z = "3" Then
                    l49(e)
                ElseIf z = "4" Then
                    l57(e)
                ElseIf z = "5" Then
                    l58(e)
                ElseIf z = "6" Then
                    l59(e)
                ElseIf z = "7" Then
                    l67(e)
                ElseIf z = "8" Then
                    l68(e)
                ElseIf z = "9" Then
                    l69(e)
                End If
            End If
        End If
        s0 = "-1"
        s1 = ""
    End Sub

    Sub t22(ByVal e As EventArgs)
        T2.Stop()
        tt2(e)
        L2 = "0"
        stp2.Text += 1
        If Lab7 = Lb7 Then
        Else
            La7 = "1"
        End If
        If Lab8 = Lb8 Then
        Else
            La8 = "1"
        End If
        If Lab9 = Lb9 Then
        Else
            La9 = "1"
        End If
        n0 += 2
        If Lab4 = Lb7 Then
            n1 = n1 + "4 "
            Le7 += 1
        ElseIf Lab4 = Lb8 Then
            n1 = n1 + "5 "
            Le8 += 1
        ElseIf Lab4 = Lb9 Then
            n1 = n1 + "6 "
            Le9 += 1
        ElseIf Lab5 = Lb7 Then
            n1 = n1 + "10"
            Le7 += 1
        ElseIf Lab5 = Lb8 Then
            n1 = n1 + "11"
            Le8 += 1
        ElseIf Lab5 = Lb9 Then
            n1 = n1 + "12"
            Le9 += 1
        ElseIf Lab6 = Lb7 Then
            n1 = n1 + "16"
            Le7 += 1
        ElseIf Lab6 = Lb8 Then
            n1 = n1 + "17"
            Le8 += 1
        ElseIf Lab6 = Lb9 Then
            n1 = n1 + "18"
            Le9 += 1
        End If
        r0 = "-1"
        r1 = ""
        Lb7 = Lab7 : Lb8 = Lab8 : Lb9 = Lab9
        L1 = "0"
        rf(e)
        ne(e)
        PB2.Visible = False : wt.Visible = False
        Cmpt.Enabled = True
        loc(e)
        bl = "0"
        Wn(e)
        T3.Start()
    End Sub

    Private Sub T2_Tick(sender As Object, e As EventArgs) Handles T2.Tick
        t22(e)
    End Sub

    Private Sub T3_Tick(sender As Object, e As EventArgs) Handles T3.Tick
        If Cmpt.Checked = True And Bu4.Visible = False And L2 = "1" Then
            If L3 = "2" Then
                wn19(e)
                If lwz = "0" Then
                Else
                    PB2.Visible = True
                    wt.Visible = True
                    T3.Stop()
                    bl = "1"
                    If fst.Text = "" Then
                        fst.Text = 0
                        t22(e)
                    ElseIf fst.Text = 0 Then
                        t22(e)
                    Else
                        T2.Start()
                    End If
                End If
            Else
                If L3 = "0" Then
                    PB2.Visible = True
                    wt.Visible = True
                    T3.Stop()
                    bl = "1"
                    If fst.Text = "" Then
                        fst.Text = 0
                        t22(e)
                    ElseIf fst.Text = 0 Then
                        t22(e)
                    Else
                        T2.Start()
                    End If
                End If
            End If
        Else
            If Cmpt.Checked = False Then
                T3.Stop()
            End If
        End If
    End Sub

    Private Sub Bu6_Click(sender As Object, e As EventArgs) Handles Bu6.Click
        sfh += 1
        B67(e)
    End Sub

    Private Sub Bu7_Click(sender As Object, e As EventArgs) Handles Bu7.Click
        sfh -= 1
        Bu6.TabIndex = 6
        B67(e)
        Bu6.TabIndex = 4
    End Sub

    Sub B67(ByVal e As EventArgs)
        If sfh = "1" Then
            Bu7.Visible = False
            Bu1.Visible = True
            Bu2.Visible = True
            Bu3.Visible = True
        Else
            Bu1.Visible = False
            Bu2.Visible = False
            Bu3.Visible = False
            Bu7.Visible = True
        End If
        If sfh = "2" Then
            Bu8.Visible = True
            sv.Visible = True
            If sv.Enabled = True Then
                sv1.Visible = True
            Else
                sv1.Visible = False
            End If
            ld.Visible = True
            ld1.Visible = True
        Else
            Bu8.Visible = False
            sv.Visible = False
            sv1.Visible = False
            ld.Visible = False
            ld1.Visible = False
        End If
        If sfh = "3" Then
            wlf.Visible = True
        Else : wlf.Visible = False
        End If
        If sfh = "4" Then
            rl.Visible = True
            rr.Visible = True
            rh.Visible = True
            rv.Visible = True
        Else
            rl.Visible = False
            rr.Visible = False
            rh.Visible = False
            rv.Visible = False
        End If
        If sfh = "5" Then
            Lf.Visible = True
            fst.Visible = True
        Else
            Lf.Visible = False
            fst.Visible = False
        End If
        If sfh = "6" Then
            Bu6.Visible = False
            Bu5.Visible = True
        Else
            Bu5.Visible = False
            Bu6.Visible = True
        End If
    End Sub

    Private Sub Bu5_Click(sender As Object, e As EventArgs) Handles Bu5.Click
        B5(e)
    End Sub

    Sub B5(ByVal e As EventArgs)
        If Bu8.Text = "عربي" Then
            MsgBox("- If you want to play with the keyboard, Press the 1, 2, 3, 4, 5, 6, 7, 8, 9, z, x, c, a, s, d, q, w or e buttons.
- Use numbers and letters on the keyboard as if they were game boxes.
- Save: F2 or O    - Load: F4 or L    - Save As: R    - Open: F
- Help: F10 or H    - Undo: U    - Redo: I    - OK: F5    - Arabic: G
- Computer: T     - Change the computer's intelligence level: Y
- Start or Stop: P    - Restart All: B or F1    - Restart: N or F3
- Switch the settings buttons: 1! 2@ 3# 4$ 5% 6^
- V & H only or not: J    - Steps of players be equal or not: K
- Download latest version  and  About the designer: M or F9
- Reduce the lighting: F6 - Raise the lighting: F8 ... Press long.
- Add background: F7    - Enable or disable play to the keyboard: F11
- If you want to continue playing with the keyboard, Do not press the writing boxes.. 
And If you press the writing boxes, press F11 to remove the pressure.", vbInformation, "How to use the keyboard to play ?!")
        Else
            MsgBox("- لو اردت اللعب بلوحة المفاتيح، إضغط على ازرار 1، 2، 3، 4، 5، 6، 7، 8، 9، ئ، ء، ؤ، ش، س، ي، ض، ص أو ث.
- إستخدم الأرقام والحروف التي في لوحة المفاتيح كما لو كانت مربعات اللعبة.
- حفظ: F2 أو خ    - تحميل: F4 أو م    - حفظ كـ: ق     - فتح: ب
- مساعدة: F10 أو أ    - تراجع: ع    - إعادة: هـ    - موافق: F5    - إنجليزي: ل
- الحاسوب: ف     - تغيير مستوى ذكاء الحاسوب: غ
- إبدأ أو توقف: ح    - إعادة بدء الكل: لا أو F1    - إعادة بدء: ى أو F3
- تبديل أزرار الإعدادات: 1! 2@ 3# 4$ 5% 6^
- عمودي أو أفقي فقط أو لا: ت    - خطوات اللاعبين يجب تساويهما أو لا: ن
- تحميل آخر إصدار  و  عن المصمم : ة أو F9
- خفض الإضاءة: F6 - رفع الإضاءة: F8 ... إضغط مطولاً.
- إضافة خلفية: F7    - تمكين أو عدم تمكين اللعب بلوحة المفاتيح: F11
- لو اردت الاستمرار في اللعب بلوحة المفاتيح، لا تضغط على مربعات الكتابة.. 
ولو ضغطت على مربعات الكتابة إضغط على F11 لإزالة الضغط.", vbInformation + vbMsgBoxRight + vbMsgBoxRtlReading, "كيفية إستخدام لوحة المفاتيح للعب ؟!")
        End If
    End Sub

    Sub g(ByVal e As EventArgs)
        If Bu8.Text = "عربي" Then
            Bu1.Text = "حول"
            Bu2.Text = "إعادة بدء"
            Bu3.Text = "إعادة بدء الكل"
            If Bu4.Text = "Start" Then
                Bu4.Text = "إبدأ"
            Else
                Bu4.Text = "توقف"
            End If
            Bu5.Text = "كيفية إستخدام لوحة المفاتيح للعب"
            Bu8.Text = "English"
            VaH.Text = "عمودي وأفقي فقط"
            NoS.Text = "خطوات كلا اللاعبين تكون متساوية"
            Cmpt.Text = "الحاسوب"
            wt.Text = "...إنتظر"
            Sega2.Text = "حول"
            Sega2.ckh.Text = "إضغط هنا  لتحميل آخر إصدار من اللعبة"
            Sega2.ckh.Location = New Point(120, 9)
            bmp.Items.Clear()
            bmp.Items.AddRange(New Object() {"غبي", "مبتدئ", "متوسط", "جيد", "متقدم", "جيد جدا", "ممتاز", "محترف"})
            bmp.RightToLeft = RightToLeft.Yes
            bmpn(e)
            wlf.Items.Clear()
            wlf.Items.AddRange(New Object() {"الفائز يلعب أولا", "الخاسر يلعب أولا", "الذي لعب أولا يلعب آخرا المرة القادمة", "إختيار من سيلعب أولا بالقرعة", "إختيار من سيلعب أولا تلقائيا"})
            wlfn(e)
            ns.Items.Clear()
            ns.Items.AddRange(New Object() {"أولا", "آخرا"})
            nsn(e)
            lns.Location = New Point(111, 482)
            lns.Text = "عندما لا يفز أحد: الذي قام باللعب أولاً، يلعب"
            ns.Location = New Point(34, 479)
            sv.Text = "حفظ"
            ld.Text = "تحميل "
            Lf.Location = New Point(145, 519)
            Lf.Text = "سرعة الحاسوب بالملي ثانية :"
            Lf.RightToLeft = RightToLeft.Yes
            fst.Location = New Point(47, 515)
            fst.Size = New Size(85, 32)
            Bu9.Text = "مساعدة"
            ok1.Text = ok1.Text.Replace("OK", "موافق")
            ok2.Text = ok2.Text.Replace("OK", "موافق")
        Else
            Bu1.Text = "About"
            Bu2.Text = "Restart"
            Bu3.Text = "Restart All"
            If Bu4.Text = "إبدأ" Then
                Bu4.Text = "Start"
            Else
                Bu4.Text = "Stop"
            End If
            Bu5.Text = "How to use the keyboard to play"
            Bu8.Text = "عربي"
            VaH.Text = "Vertical and Horizontal only"
            NoS.Text = "The steps of both players be equal"
            Cmpt.Text = "Computer"
            wt.Text = "Wait..."
            Sega2.Text = "About"
            Sega2.ckh.Text = "Click here  to download the latest version of the game"
            Sega2.ckh.Location = New Point(58, 9)
            bmp.Items.Clear()
            bmp.Items.AddRange(New Object() {"Stupid", "Beginner", "Medium", "Good", "Advanced", "Very Good", "Excellent", "Professional"})
            bmp.RightToLeft = RightToLeft.No
            bmpn(e)
            wlf.Items.Clear()
            wlf.Items.AddRange(New Object() {"The winner plays first", "The loser plays first", "Who played first, plays second next time", "Choose who will play first by lot", "Choose who will play first automatically"})
            wlfn(e)
            ns.Items.Clear()
            ns.Items.AddRange(New Object() {"first", "second"})
            nsn(e)
            lns.Location = New Point(34, 482)
            lns.Text = "When no one wins: who played first, plays"
            ns.Location = New Point(383, 479)
            sv.Text = "Save"
            ld.Text = "Load"
            Lf.Location = New Point(42, 519)
            Lf.Text = "Computer speed in milliseconds:"
            Lf.RightToLeft = RightToLeft.No
            fst.Location = New Point(347, 515)
            fst.Size = New Size(75, 32)
            Bu9.Text = "Help"
            ok1.Text = ok1.Text.Replace("موافق", "OK")
            ok2.Text = ok2.Text.Replace("موافق", "OK")
        End If
    End Sub

    Private Sub Bu8_Click(sender As Object, e As EventArgs) Handles Bu8.Click
        g(e)
    End Sub

    Sub ooo(ByVal e As EventArgs)
        If Bu8.Text = "عربي" Then
            MsgBox(("Both of you should agree to this feature by pressing OK"), vbInformation, "warning...")
        Else
            MsgBox(("على كليكما ان توافقا معا على هذه الخاصية بالضغط على موافق"), vbInformation + vbMsgBoxRight + vbMsgBoxRtlReading, "تحذير...")
        End If
    End Sub

    Sub u(ByVal e As EventArgs)
        If bl = "0" Then
            If ok1.Checked = True And ok2.Checked = True Then
                Dim fgh As String = n1.ToList(n0 - 1)
                Dim ghj As String = n1.ToList(n0)
                gh3 = fgh + ghj
                r1 = r1 + fgh + ghj
                r0 += 2
                n0 -= 2
                n1 = n1.ToCharArray(0, n0 + 1)
                If gh3 = "1 " Then
                    rt = Lab4 : Lab4 = Lab1 : Lab1 = rt
                    Le1 -= 1
                ElseIf gh3 = "2 " Then
                    rt = Lab4 : Lab4 = Lab2 : Lab2 = rt
                    Le2 -= 1
                ElseIf gh3 = "3 " Then
                    rt = Lab4 : Lab4 = Lab3 : Lab3 = rt
                    Le3 -= 1
                ElseIf gh3 = "4 " Then
                    l47(e)
                    Le7 -= 1
                ElseIf gh3 = "5 " Then
                    l48(e)
                    Le8 -= 1
                ElseIf gh3 = "6 " Then
                    l49(e)
                    Le9 -= 1
                ElseIf gh3 = "7 " Then
                    rt = Lab5 : Lab5 = Lab1 : Lab1 = rt
                    Le1 -= 1
                ElseIf gh3 = "8 " Then
                    rt = Lab5 : Lab5 = Lab2 : Lab2 = rt
                    Le2 -= 1
                ElseIf gh3 = "9 " Then
                    rt = Lab5 : Lab5 = Lab3 : Lab3 = rt
                    Le3 -= 1
                ElseIf gh3 = "10" Then
                    l57(e)
                    Le7 -= 1
                ElseIf gh3 = "11" Then
                    l58(e)
                    Le8 -= 1
                ElseIf gh3 = "12" Then
                    l59(e)
                    Le9 -= 1
                ElseIf gh3 = "13" Then
                    rt = Lab6 : Lab6 = Lab1 : Lab1 = rt
                    Le1 -= 1
                ElseIf gh3 = "14" Then
                    rt = Lab6 : Lab6 = Lab2 : Lab2 = rt
                    Le2 -= 1
                ElseIf gh3 = "15" Then
                    rt = Lab6 : Lab6 = Lab3 : Lab3 = rt
                    Le3 -= 1
                ElseIf gh3 = "16" Then
                    l67(e)
                    Le7 -= 1
                ElseIf gh3 = "17" Then
                    l68(e)
                    Le8 -= 1
                ElseIf gh3 = "18" Then
                    l69(e)
                    Le9 -= 1
                End If
                If Le1 = "0" Then
                    La1 = "0"
                End If
                If Le2 = "0" Then
                    La2 = "0"
                End If
                If Le3 = "0" Then
                    La3 = "0"
                End If
                If Le7 = "0" Then
                    La7 = "0"
                End If
                If Le8 = "0" Then
                    La8 = "0"
                End If
                If Le9 = "0" Then
                    La9 = "0"
                End If
                L3 = "2"
                If L2 = "0" Then
                    L2 = "1"
                ElseIf L2 = "1" Then
                    L2 = "0"
                End If
                L1 = "0"
                If gh3 = "1 " Or gh3 = "2 " Or gh3 = "3 " Or gh3 = "7 " Or gh3 = "8 " Or gh3 = "9 " Or gh3 = "13" Or gh3 = "14" Or gh3 = "15" Then
                    stp1.Text = stp1.Text - 1
                Else
                    stp2.Text = stp2.Text - 1
                End If
                If n0 = -1 Then
                    nf(e)
                End If
                re(e)
                loc(e)
                If VaH.Checked = False Then
                    Wn(e)
                End If
            Else
                ooo(e)
            End If
        End If
    End Sub

    Private Sub nd_Click(sender As Object, e As EventArgs) Handles nd.Click
        u(e)
    End Sub

    Sub r(ByVal e As EventArgs)
        If bl = "0" Then
            If ok1.Checked = True And ok2.Checked = True Then
                Dim fgh As String = r1.ToList(r0 - 1)
                Dim ghj As String = r1.ToList(r0)
                gh4 = fgh + ghj
                n1 = n1 + fgh + ghj
                n0 += 2
                r0 -= 2
                r1 = r1.ToCharArray(0, r0 + 1)
                If gh4 = "1 " Then
                    rt = Lab4 : Lab4 = Lab1 : Lab1 = rt
                    Le1 += 1
                ElseIf gh4 = "2 " Then
                    rt = Lab4 : Lab4 = Lab2 : Lab2 = rt
                    Le2 += 1
                ElseIf gh4 = "3 " Then
                    rt = Lab4 : Lab4 = Lab3 : Lab3 = rt
                    Le3 += 1
                ElseIf gh4 = "4 " Then
                    l47(e)
                    Le7 += 1
                ElseIf gh4 = "5 " Then
                    l48(e)
                    Le8 += 1
                ElseIf gh4 = "6 " Then
                    l49(e)
                    Le9 += 1
                ElseIf gh4 = "7 " Then
                    rt = Lab5 : Lab5 = Lab1 : Lab1 = rt
                    Le1 += 1
                ElseIf gh4 = "8 " Then
                    rt = Lab5 : Lab5 = Lab2 : Lab2 = rt
                    Le2 += 1
                ElseIf gh4 = "9 " Then
                    rt = Lab5 : Lab5 = Lab3 : Lab3 = rt
                    Le3 += 1
                ElseIf gh4 = "10" Then
                    l57(e)
                    Le7 += 1
                ElseIf gh4 = "11" Then
                    l58(e)
                    Le8 += 1
                ElseIf gh4 = "12" Then
                    l59(e)
                    Le9 += 1
                ElseIf gh4 = "13" Then
                    rt = Lab6 : Lab6 = Lab1 : Lab1 = rt
                    Le1 += 1
                ElseIf gh4 = "14" Then
                    rt = Lab6 : Lab6 = Lab2 : Lab2 = rt
                    Le2 += 1
                ElseIf gh4 = "15" Then
                    rt = Lab6 : Lab6 = Lab3 : Lab3 = rt
                    Le3 += 1
                ElseIf gh4 = "16" Then
                    l67(e)
                    Le7 += 1
                ElseIf gh4 = "17" Then
                    l68(e)
                    Le8 += 1
                ElseIf gh4 = "18" Then
                    l69(e)
                    Le9 += 1
                End If
                If Le1 > 0 Then
                    La1 = "1"
                End If
                If Le2 > 0 Then
                    La2 = "1"
                End If
                If Le3 > 0 Then
                    La3 = "1"
                End If
                If Le7 > 0 Then
                    La7 = "1"
                End If
                If Le8 > 0 Then
                    La8 = "1"
                End If
                If Le9 > 0 Then
                    La9 = "1"
                End If
                If L2 = "0" Then
                    L2 = "1"
                ElseIf L2 = "1" Then
                    L2 = "0"
                End If
                L1 = "0"
                If gh4 = "1 " Or gh4 = "2 " Or gh4 = "3 " Or gh4 = "7 " Or gh4 = "8 " Or gh4 = "9 " Or gh4 = "13" Or gh4 = "14" Or gh4 = "15" Then
                    stp1.Text = stp1.Text + 1
                Else
                    stp2.Text = stp2.Text + 1
                End If
                If r0 = -1 Then
                    rf(e)
                End If
                ne(e)
                loc(e)
                Wn(e)
            Else
                ooo(e)
            End If
        End If
    End Sub

    Private Sub rd_Click(sender As Object, e As EventArgs) Handles rd.Click
        r(e)
    End Sub

    Sub sve(ByVal e As EventArgs)
        If bl = "0" Then
            My.Computer.FileSystem.CreateDirectory(sg + "NewSave")
            Dim ss As String = sg + "NewSave\"
            My.Computer.FileSystem.WriteAllText(ss + "1.sg", wn1.Text, False) '1
            My.Computer.FileSystem.WriteAllText(ss + "2.sg", wn2.Text, False) '2
            My.Computer.FileSystem.WriteAllText(ss + "3.sg", stp1.Text, False) '3
            My.Computer.FileSystem.WriteAllText(ss + "4.sg", stp2.Text, False) '4
            My.Computer.FileSystem.WriteAllText(ss + "5.sg", L2, False)
            My.Computer.FileSystem.WriteAllText(ss + "6.sg", L22, False)
            My.Computer.FileSystem.WriteAllText(ss + "8.sg", nm1.Text, False) '5
            My.Computer.FileSystem.WriteAllText(ss + "9.sg", nm2.Text, False) '6
            My.Computer.FileSystem.WriteAllText(ss + "10.sg", La1, False)
            My.Computer.FileSystem.WriteAllText(ss + "11.sg", La2, False)
            My.Computer.FileSystem.WriteAllText(ss + "12.sg", La3, False)
            My.Computer.FileSystem.WriteAllText(ss + "13.sg", La7, False)
            My.Computer.FileSystem.WriteAllText(ss + "14.sg", La8, False)
            My.Computer.FileSystem.WriteAllText(ss + "15.sg", La9, False)
            My.Computer.FileSystem.WriteAllText(ss + "16.sg", Lab1, False)
            My.Computer.FileSystem.WriteAllText(ss + "17.sg", Lab2, False)
            My.Computer.FileSystem.WriteAllText(ss + "18.sg", Lab3, False)
            My.Computer.FileSystem.WriteAllText(ss + "19.sg", Lab4, False)
            My.Computer.FileSystem.WriteAllText(ss + "20.sg", Lab5, False)
            My.Computer.FileSystem.WriteAllText(ss + "21.sg", Lab6, False)
            My.Computer.FileSystem.WriteAllText(ss + "22.sg", Lab7, False)
            My.Computer.FileSystem.WriteAllText(ss + "23.sg", Lab8, False)
            My.Computer.FileSystem.WriteAllText(ss + "24.sg", Lab9, False)
            My.Computer.FileSystem.WriteAllText(ss + "32.sg", n0, False) '7
            My.Computer.FileSystem.WriteAllText(ss + "33.sg", n1, False) '9
            My.Computer.FileSystem.WriteAllText(ss + "34.sg", r0, False) '8
            My.Computer.FileSystem.WriteAllText(ss + "35.sg", r1, False) '10
            My.Computer.FileSystem.WriteAllText(ss + "36.sg", Le1, False) '11
            My.Computer.FileSystem.WriteAllText(ss + "37.sg", Le2, False) '12
            My.Computer.FileSystem.WriteAllText(ss + "38.sg", Le3, False) '13
            My.Computer.FileSystem.WriteAllText(ss + "39.sg", Le7, False) '14
            My.Computer.FileSystem.WriteAllText(ss + "40.sg", Le8, False) '15
            My.Computer.FileSystem.WriteAllText(ss + "41.sg", Le9, False) '16
            If VaH.Checked = True Then
                My.Computer.FileSystem.WriteAllText(ss + "25.sg", "1", False)
            Else
                My.Computer.FileSystem.WriteAllText(ss + "25.sg", "0", False)
            End If
            If NoS.Checked = False Then
                My.Computer.FileSystem.WriteAllText(ss + "26.sg", "0", False)
            Else
                My.Computer.FileSystem.WriteAllText(ss + "26.sg", "1", False)
            End If
            My.Computer.FileSystem.WriteAllText(ss + "27.sg", ll, False)
            If Cmpt.Checked = False Then
                My.Computer.FileSystem.WriteAllText(ss + "28.sg", "0", False)
            Else
                My.Computer.FileSystem.WriteAllText(ss + "28.sg", "1", False)
            End If
            If ok1.Checked = True And ok2.Checked = True Then
                My.Computer.FileSystem.WriteAllText(ss + "29.sg", "1", False)
            Else
                My.Computer.FileSystem.WriteAllText(ss + "29.sg", "0", False)
            End If
            My.Computer.FileSystem.WriteAllText(ss + "30.sg", L1, False)
            My.Computer.FileSystem.WriteAllText(ss + "31.sg", L3, False)
            My.Computer.FileSystem.WriteAllText(ss + "42.sg", o1, False) '17
            My.Computer.FileSystem.WriteAllText(ss + "44.sg", flw, False)
            My.Computer.FileSystem.WriteAllText(ss + "45.sg", sn, False)
            My.Computer.FileSystem.WriteAllText(ss + "48.sg", sf, False)
            ld.Enabled = True
        End If
    End Sub

    Private Sub sv_Click(sender As Object, e As EventArgs) Handles sv.Click
        sve(e)
    End Sub

    Sub sve1(ByVal e As EventArgs)
        If bl = "0" Then
            Dim ssf As String
            If My.Computer.FileSystem.FileExists(sg + "num.sg") Then
                ssf = My.Computer.FileSystem.ReadAllText(sg + "num.sg")
            Else
                ssf = "1"
            End If
            SFD.FileName = "SEAGA" + ssf + ".sg"
            If SFD.ShowDialog() = DialogResult.OK Then
                Dim sgs1 As String = Len(Trim$(wn1.Text))
                Dim sgs2 As String = Len(Trim$(wn2.Text))
                Dim sgs3 As String = Len(Trim$(stp1.Text))
                Dim sgs4 As String = Len(Trim$(stp2.Text))
                Dim sss5 As String = nm1.Text.Replace(" ", "!")
                Dim sgs5 As String = Len(Trim$(sss5))
                If Len(Trim$(sgs5)) = "0" Then
                    sgs5 = "000000"
                ElseIf Len(Trim$(sgs5)) = "1" Then
                    sgs5 = "00000" + sgs5
                ElseIf Len(Trim$(sgs5)) = "2" Then
                    sgs5 = "0000" + sgs5
                ElseIf Len(Trim$(sgs5)) = "3" Then
                    sgs5 = "000" + sgs5
                ElseIf Len(Trim$(sgs5)) = "4" Then
                    sgs5 = "00" + sgs5
                ElseIf Len(Trim$(sgs5)) = "5" Then
                    sgs5 = "0" + sgs5
                End If
                Dim sss6 As String = nm2.Text.Replace(" ", "!")
                Dim sgs6 As String = Len(Trim$(sss6))
                If Len(Trim$(sgs6)) = "0" Then
                    sgs6 = "000000"
                ElseIf Len(Trim$(sgs6)) = "1" Then
                    sgs6 = "00000" + sgs6
                ElseIf Len(Trim$(sgs6)) = "2" Then
                    sgs6 = "0000" + sgs6
                ElseIf Len(Trim$(sgs6)) = "3" Then
                    sgs6 = "000" + sgs6
                ElseIf Len(Trim$(sgs6)) = "4" Then
                    sgs6 = "00" + sgs6
                ElseIf Len(Trim$(sgs6)) = "5" Then
                    sgs6 = "0" + sgs6
                End If
                Dim sgs7 As String = Len(Trim$(n0))
                Dim sgs8 As String = Len(Trim$(r0))
                Dim sss9 As String = n1.Replace(" ", "!")
                Dim sgs9 As String = Len(Trim$(sss9))
                If Len(Trim$(sgs9)) = "0" Then
                    sgs9 = "0000000"
                ElseIf Len(Trim$(sgs9)) = "1" Then
                    sgs9 = "000000" + sgs9
                ElseIf Len(Trim$(sgs9)) = "2" Then
                    sgs9 = "00000" + sgs9
                ElseIf Len(Trim$(sgs9)) = "3" Then
                    sgs9 = "0000" + sgs9
                ElseIf Len(Trim$(sgs9)) = "4" Then
                    sgs9 = "000" + sgs9
                ElseIf Len(Trim$(sgs9)) = "5" Then
                    sgs9 = "00" + sgs9
                ElseIf Len(Trim$(sgs9)) = "6" Then
                    sgs9 = "0" + sgs9
                End If
                Dim ss10 As String = r1.Replace(" ", "!")
                Dim sg10 As String = Len(Trim$(ss10))
                If Len(Trim$(sg10)) = "0" Then
                    sg10 = "0000000"
                ElseIf Len(Trim$(sg10)) = "1" Then
                    sg10 = "000000" + sg10
                ElseIf Len(Trim$(sg10)) = "2" Then
                    sg10 = "00000" + sg10
                ElseIf Len(Trim$(sg10)) = "3" Then
                    sg10 = "0000" + sg10
                ElseIf Len(Trim$(sg10)) = "4" Then
                    sg10 = "000" + sg10
                ElseIf Len(Trim$(sg10)) = "5" Then
                    sg10 = "00" + sg10
                ElseIf Len(Trim$(sg10)) = "6" Then
                    sg10 = "0" + sg10
                End If
                Dim sg11 As String = Len(Trim$(Le1))
                Dim sg12 As String = Len(Trim$(Le2))
                Dim sg13 As String = Len(Trim$(Le3))
                Dim sg14 As String = Len(Trim$(Le7))
                Dim sg15 As String = Len(Trim$(Le8))
                Dim sg16 As String = Len(Trim$(Le9))
                Dim sg17 As String = Len(Trim$(o1))
                Dim sg18 As String = Len(Trim$(o1))
                Dim sg19 As String = Len(Trim$(di))
                Dim sg20 As String
                Dim sg21 As String
                Dim sg22 As String
                Dim sg23 As String
                If VaH.Checked = True Then : sg20 = "1"
                Else : sg20 = "0"
                End If
                If NoS.Checked = False Then : sg21 = "0"
                Else : sg21 = "1"
                End If
                If Cmpt.Checked = False Then : sg22 = "0"
                Else : sg22 = "1"
                End If
                If ok1.Checked = True And ok2.Checked = True Then : sg23 = "1"
                Else : sg23 = "0"
                End If
                Dim Lee1 As String = Le1 : Dim Lee2 As String = Le2 : Dim Lee3 As String = Le3 : Dim Lee7 As String = Le7 : Dim Lee8 As String = Le8 : Dim Lee9 As String = Le9
                Dim nn0 As String = n0 : Dim rr0 As String = r0
                Dim llll As String = ll
                oo1 = o1
                Dim wer As String = dh + sgs1 + dh + sgs2 + dh + sgs3 + dh + sgs4 + dh + sgs5 + dh + sgs6 + dh + sgs7 + dh + sgs8 + dh + sgs9 + dh + sg10 + dh + sg11 + dh + sg12 + dh + sg13 + dh + sg14 + dh + sg15 + dh + sg16 + dh + sg17 + dh + sg18 + dh + sg19 + dh + wn1.Text + dh + wn2.Text + dh + stp1.Text + dh + stp2.Text + dh + nm1.Text + dh + nm2.Text + dh + nn0 + dh + rr0 + dh + n1 + dh + r1 + dh + Lee1 + dh + Lee2 + dh + Lee3 + dh + Lee7 + dh + Lee8 + dh + Lee9 + dh + oo1 + dh + oo1 + dh + di + dh + L2 + dh + L22 + dh + La1 + dh + La2 + dh + La3 + dh + La7 + dh + La8 + dh + La9 + dh + Lab1 + dh + Lab2 + dh + Lab3 + dh + Lab4 + dh + Lab5 + dh + Lab6 + dh + Lab7 + dh + Lab8 + dh + Lab9 + dh + sg20 + dh + sg21 + dh + sg22 + dh + sg23 + dh + llll + dh + L1 + dh + L3 + dh + flw + dh + sn + dh + de + dh + sf + dh
                Dim wer1 As String = wer.Replace(dh, "")
                Dim sgs0 As String = Len(Trim$(wer))
                Dim sg00 As String = Len(Trim$(wer1))
                If Len(Trim$(sgs0)) = "0" Then
                    sgs0 = "000000000"
                ElseIf Len(Trim$(sgs0)) = "1" Then
                    sgs0 = "00000000" + sgs0
                ElseIf Len(Trim$(sgs0)) = "2" Then
                    sgs0 = "0000000" + sgs0
                ElseIf Len(Trim$(sgs0)) = "3" Then
                    sgs0 = "000000" + sgs0
                ElseIf Len(Trim$(sgs0)) = "4" Then
                    sgs0 = "00000" + sgs0
                ElseIf Len(Trim$(sgs0)) = "5" Then
                    sgs0 = "0000" + sgs0
                ElseIf Len(Trim$(sgs0)) = "6" Then
                    sgs0 = "000" + sgs0
                ElseIf Len(Trim$(sgs0)) = "7" Then
                    sgs0 = "00" + sgs0
                ElseIf Len(Trim$(sgs0)) = "8" Then
                    sgs0 = "0" + sgs0
                End If
                If Len(Trim$(sg00)) = "0" Then
                    sg00 = "000000000"
                ElseIf Len(Trim$(sg00)) = "1" Then
                    sg00 = "00000000" + sg00
                ElseIf Len(Trim$(sg00)) = "2" Then
                    sg00 = "0000000" + sg00
                ElseIf Len(Trim$(sg00)) = "3" Then
                    sg00 = "000000" + sg00
                ElseIf Len(Trim$(sg00)) = "4" Then
                    sg00 = "00000" + sg00
                ElseIf Len(Trim$(sg00)) = "5" Then
                    sg00 = "0000" + sg00
                ElseIf Len(Trim$(sg00)) = "6" Then
                    sg00 = "000" + sg00
                ElseIf Len(Trim$(sg00)) = "7" Then
                    sg00 = "00" + sg00
                ElseIf Len(Trim$(sg00)) = "8" Then
                    sg00 = "0" + sg00
                End If
                My.Computer.FileSystem.WriteAllText(SFD.FileName, sgs0 + sg00 + wer, False)
                Dim ssd As Integer = ssf
                Dim sd1 As Integer = ssd + 1
                Dim sd2 As String = sd1
                My.Computer.FileSystem.WriteAllText(sg + "num.sg", sd2, False)
            End If
        End If
    End Sub

    Private Sub sv1_Click(sender As Object, e As EventArgs) Handles sv1.Click
        sve1(e)
    End Sub

    Sub lde(ByVal e As EventArgs)
        If bl = "0" Then
            Dim ss As String = sg + "NewSave\"
            If Bu8.Text = "عربي" Then
                Bu4.Text = "Start"
            Else
                Bu4.Text = "إبدأ"
            End If
            T1.Stop()
            If My.Computer.FileSystem.ReadAllText(ss + "26.sg") = "0" Then
                NoS.Checked = False
            Else
                NoS.Checked = True
            End If
            If My.Computer.FileSystem.ReadAllText(ss + "25.sg") = "1" Then
                VaH.Checked = True
            Else
                VaH.Checked = False
            End If
            Bu4.Visible = False
            wn1.Text = My.Computer.FileSystem.ReadAllText(ss + "1.sg")
            wn2.Text = My.Computer.FileSystem.ReadAllText(ss + "2.sg")
            stp1.Text = My.Computer.FileSystem.ReadAllText(ss + "3.sg")
            stp2.Text = My.Computer.FileSystem.ReadAllText(ss + "4.sg")
            L2 = My.Computer.FileSystem.ReadAllText(ss + "5.sg")
            L22 = My.Computer.FileSystem.ReadAllText(ss + "6.sg")
            nm1.Text = My.Computer.FileSystem.ReadAllText(ss + "8.sg")
            nm2.Text = My.Computer.FileSystem.ReadAllText(ss + "9.sg")
            La1 = My.Computer.FileSystem.ReadAllText(ss + "10.sg")
            La2 = My.Computer.FileSystem.ReadAllText(ss + "11.sg")
            La3 = My.Computer.FileSystem.ReadAllText(ss + "12.sg")
            La7 = My.Computer.FileSystem.ReadAllText(ss + "13.sg")
            La8 = My.Computer.FileSystem.ReadAllText(ss + "14.sg")
            La9 = My.Computer.FileSystem.ReadAllText(ss + "15.sg")
            Lab1 = My.Computer.FileSystem.ReadAllText(ss + "16.sg")
            Lab2 = My.Computer.FileSystem.ReadAllText(ss + "17.sg")
            Lab3 = My.Computer.FileSystem.ReadAllText(ss + "18.sg")
            Lab4 = My.Computer.FileSystem.ReadAllText(ss + "19.sg")
            Lab5 = My.Computer.FileSystem.ReadAllText(ss + "20.sg")
            Lab6 = My.Computer.FileSystem.ReadAllText(ss + "21.sg")
            Lab7 = My.Computer.FileSystem.ReadAllText(ss + "22.sg")
            Lab8 = My.Computer.FileSystem.ReadAllText(ss + "23.sg")
            Lab9 = My.Computer.FileSystem.ReadAllText(ss + "24.sg")
            If My.Computer.FileSystem.FileExists(ss + "32.sg") Then
                n0 = My.Computer.FileSystem.ReadAllText(ss + "32.sg")
                n1 = My.Computer.FileSystem.ReadAllText(ss + "33.sg")
                r0 = My.Computer.FileSystem.ReadAllText(ss + "34.sg")
                r1 = My.Computer.FileSystem.ReadAllText(ss + "35.sg")
                Le1 = My.Computer.FileSystem.ReadAllText(ss + "36.sg")
                Le2 = My.Computer.FileSystem.ReadAllText(ss + "37.sg")
                Le3 = My.Computer.FileSystem.ReadAllText(ss + "38.sg")
                Le7 = My.Computer.FileSystem.ReadAllText(ss + "39.sg")
                Le8 = My.Computer.FileSystem.ReadAllText(ss + "40.sg")
                Le9 = My.Computer.FileSystem.ReadAllText(ss + "41.sg")
            Else
                n0 = -1
                r0 = -1
                n1 = ""
                r1 = ""
                Le1 = La1
                Le2 = La2
                Le3 = La3
                Le7 = La7
                Le8 = La8
                Le9 = La9
            End If
            ll = My.Computer.FileSystem.ReadAllText(ss + "27.sg")
            L1 = "0"
            If My.Computer.FileSystem.FileExists(ss + "30.sg") Then
                L1 = My.Computer.FileSystem.ReadAllText(ss + "30.sg")
            End If
            ok1.Visible = True
            ok2.Visible = True
            If My.Computer.FileSystem.ReadAllText(ss + "28.sg") = "0" Then
                If Cmpt.Checked = False Then
                    lcn1(e)
                Else
                    Cmpt.Checked = False
                End If
            Else
                If Cmpt.Checked = True Then
                    lcn2(e)
                Else
                    Cmpt.Checked = True
                End If
            End If
            If My.Computer.FileSystem.ReadAllText(ss + "29.sg") = "1" Then
                ok1.Checked = True
                ok2.Checked = True
            End If
            nf(e)
            rf(e)
            If n0 = -1 Then
            Else
                ne(e)
            End If
            If r0 = -1 Then
            Else
                re(e)
            End If
            bmpn(e)
            L3 = "2"
            If My.Computer.FileSystem.FileExists(ss + "31.sg") Then
                L3 = My.Computer.FileSystem.ReadAllText(ss + "31.sg")
            Else
                Wn(e)
            End If
            Bu9.Visible = True
            CB1.Visible = True
            hp.Visible = True
            If My.Computer.FileSystem.FileExists(ss + "42.sg") Then
                o1 = My.Computer.FileSystem.ReadAllText(ss + "42.sg")
                If o1 > 0 Then
                    oo1 = o1
                    ok1.Text = "OK +" + oo1
                    ok2.Text = "OK +" + oo1
                Else
                    If ok1.Checked = True Then
                        o1 = "1"
                        ok1.Text = "OK +1"
                        ok2.Text = "OK +1"
                    Else
                        o1 = "0"
                        ok1.Text = "OK"
                        ok2.Text = "OK"
                    End If
                End If
                If Bu8.Text = "English" Then
                    ok1.Text = ok1.Text.Replace("OK", "موافق")
                    ok2.Text = ok2.Text.Replace("OK", "موافق")
                End If
            End If
            If My.Computer.FileSystem.FileExists(ss + "44.sg") Then
                flw = My.Computer.FileSystem.ReadAllText(ss + "44.sg")
                sn = My.Computer.FileSystem.ReadAllText(ss + "45.sg")
                wlfn(e)
                nsn(e)
            End If
            sf = "1"
            If My.Computer.FileSystem.FileExists(ss + "48.sg") Then
                sf = My.Computer.FileSystem.ReadAllText(ss + "48.sg")
            End If
            loc(e)
            sv.Enabled = True
            If sfh = "2" Then
                sv1.Visible = True
            End If
        End If
    End Sub

    Private Sub ld_Click(sender As Object, e As EventArgs) Handles ld.Click
        lde(e)
    End Sub

    Sub lde1(ByVal e As EventArgs)
        On Error Resume Next
        If bl = "0" Then
            If OFD.ShowDialog() = DialogResult.OK Then
                Dim ofh0 As String = My.Computer.FileSystem.ReadAllText(OFD.FileName)
                Dim ofg0 As String = My.Computer.FileSystem.ReadAllText(OFD.FileName).Replace(dh, "")
                Dim ofg1 As String = ofg0.Substring(0, 9)
                Dim ofg2 As Integer = ofg1
                Dim ofd0 As String = ofg0
                Dim ofg3 As Integer = Len(Trim$(ofh0)) - 18
                Dim ofg4 As String = ofg0.Substring(9, 9)
                Dim ofg5 As Integer = ofg4
                Dim ofg6 As Integer = Len(Trim$(ofg0)) - 18
                If (ofg2 = ofg3) And (ofg5 = ofg6) Then
                    Dim ofd1 As String = ofd0.ToList(18)
                    Dim off1 As Integer = ofd1
                    Dim ofd2 As String = ofd0.ToList(19)
                    Dim off2 As Integer = ofd2
                    Dim ofd3 As String = ofd0.ToList(20)
                    Dim off3 As Integer = ofd3
                    Dim ofd4 As String = ofd0.ToList(21)
                    Dim off4 As Integer = ofd4
                    Dim ofd5 As String = ofd0.Substring(22, 6)
                    Dim off5 As Integer = ofd5
                    Dim ofd6 As String = ofd0.Substring(28, 6)
                    Dim off6 As Integer = ofd6
                    Dim ofd7 As String = ofd0.ToList(34)
                    Dim off7 As Integer = ofd7
                    Dim ofd8 As String = ofd0.ToList(35)
                    Dim off8 As Integer = ofd8
                    Dim ofd9 As String = ofd0.Substring(36, 7)
                    Dim off9 As Integer = ofd9
                    Dim od10 As String = ofd0.Substring(43, 7)
                    Dim of10 As Integer = od10
                    Dim od11 As String = ofd0.ToList(50)
                    Dim of11 As Integer = od11
                    Dim od12 As String = ofd0.ToList(51)
                    Dim of12 As Integer = od12
                    Dim od13 As String = ofd0.ToList(52)
                    Dim of13 As Integer = od13
                    Dim od14 As String = ofd0.ToList(53)
                    Dim of14 As Integer = od14
                    Dim od15 As String = ofd0.ToList(54)
                    Dim of15 As Integer = od15
                    Dim od16 As String = ofd0.ToList(55)
                    Dim of16 As Integer = od16
                    Dim od17 As String = ofd0.ToList(56)
                    Dim of17 As Integer = od17
                    Dim od18 As String = ofd0.ToList(57)
                    Dim of18 As Integer = od18
                    Dim od19 As String = ofd0.ToList(58)
                    Dim of19 As Integer = od19
                    If Bu8.Text = "عربي" Then
                        Bu4.Text = "Start"
                    Else
                        Bu4.Text = "إبدأ"
                    End If
                    T1.Stop()
                    Dim qaz As Integer = 59 + off1 + off2 + off3 + off4 + off5 + off6 + off7 + off8 + off9 + of10 + of11 + of12 + of13 + of14 + of15 + of16 + of17 + of18 + of19
                    If ofd0.Substring(qaz + 18, 1) = "0" Then
                        NoS.Checked = False
                    Else
                        NoS.Checked = True
                    End If
                    If ofd0.Substring(qaz + 17, 1) = "1" Then
                        VaH.Checked = True
                    Else
                        VaH.Checked = False
                    End If
                    Bu4.Visible = False
                    wn1.Text = ofd0.Substring(59, off1)
                    wn2.Text = ofd0.Substring(59 + off1, off2)
                    stp1.Text = ofd0.Substring(59 + off1 + off2, off3)
                    stp2.Text = ofd0.Substring(59 + off1 + off2 + off3, off4)
                    nm1.Text = ofd0.Substring(59 + off1 + off2 + off3 + off4, off5)
                    nm2.Text = ofd0.Substring(59 + off1 + off2 + off3 + off4 + off5, off6)
                    L2 = ofd0.Substring(qaz, 1)
                    L22 = ofd0.Substring(qaz + 1, 1)
                    La1 = ofd0.Substring(qaz + 2, 1)
                    La2 = ofd0.Substring(qaz + 3, 1)
                    La3 = ofd0.Substring(qaz + 4, 1)
                    La7 = ofd0.Substring(qaz + 5, 1)
                    La8 = ofd0.Substring(qaz + 6, 1)
                    La9 = ofd0.Substring(qaz + 7, 1)
                    Lab1 = ofd0.Substring(qaz + 8, 1)
                    Lab2 = ofd0.Substring(qaz + 9, 1)
                    Lab3 = ofd0.Substring(qaz + 10, 1)
                    Lab4 = ofd0.Substring(qaz + 11, 1)
                    Lab5 = ofd0.Substring(qaz + 12, 1)
                    Lab6 = ofd0.Substring(qaz + 13, 1)
                    Lab7 = ofd0.Substring(qaz + 14, 1)
                    Lab8 = ofd0.Substring(qaz + 15, 1)
                    Lab9 = ofd0.Substring(qaz + 16, 1)
                    n0 = ofd0.Substring(59 + off1 + off2 + off3 + off4 + off5 + off6, off7)
                    r0 = ofd0.Substring(59 + off1 + off2 + off3 + off4 + off5 + off6 + off7, off8)
                    n1 = ofd0.Substring(59 + off1 + off2 + off3 + off4 + off5 + off6 + off7 + off8, off9)
                    r1 = ofd0.Substring(59 + off1 + off2 + off3 + off4 + off5 + off6 + off7 + off8 + off9, of10)
                    Le1 = ofd0.Substring(59 + off1 + off2 + off3 + off4 + off5 + off6 + off7 + off8 + off9 + of10, of11)
                    Le2 = ofd0.Substring(59 + off1 + off2 + off3 + off4 + off5 + off6 + off7 + off8 + off9 + of10 + of11, of12)
                    Le3 = ofd0.Substring(59 + off1 + off2 + off3 + off4 + off5 + off6 + off7 + off8 + off9 + of10 + of11 + of12, of13)
                    Le7 = ofd0.Substring(59 + off1 + off2 + off3 + off4 + off5 + off6 + off7 + off8 + off9 + of10 + of11 + of12 + of13, of14)
                    Le8 = ofd0.Substring(59 + off1 + off2 + off3 + off4 + off5 + off6 + off7 + off8 + off9 + of10 + of11 + of12 + of13 + of14, of15)
                    Le9 = ofd0.Substring(59 + off1 + off2 + off3 + off4 + off5 + off6 + off7 + off8 + off9 + of10 + of11 + of12 + of13 + of14 + of15, of16)
                    ll = ofd0.Substring(qaz + 21, 1)
                    L1 = ofd0.Substring(qaz + 22, 1)
                    ok1.Visible = True
                    ok2.Visible = True
                    If ofd0.Substring(qaz + 19, 1) = "0" Then
                        If Cmpt.Checked = False Then
                            lcn1(e)
                        Else
                            Cmpt.Checked = False
                        End If
                    Else
                        If Cmpt.Checked = True Then
                            lcn2(e)
                        Else
                            Cmpt.Checked = True
                        End If
                    End If
                    If ofd0.Substring(qaz + 20, 1) = "1" Then
                        ok1.Checked = True
                        ok2.Checked = True
                    End If
                    nf(e)
                    rf(e)
                    If n0 = -1 Then
                    Else
                        ne(e)
                    End If
                    If r0 = -1 Then
                    Else
                        re(e)
                    End If
                    bmpn(e)
                    L3 = ofd0.Substring(qaz + 23, 1)
                    Bu9.Visible = True
                    CB1.Visible = True
                    hp.Visible = True
                    o1 = ofd0.Substring(59 + off1 + off2 + off3 + off4 + off5 + off6 + off7 + off8 + off9 + of10 + of11 + of12 + of13 + of14 + of15 + of16, of17)
                    If o1 > 0 Then
                        oo1 = o1
                        ok1.Text = "OK +" + oo1
                        ok2.Text = "OK +" + oo1
                    Else
                        If ok1.Checked = True Then
                            o1 = "1"
                            ok1.Text = "OK +1"
                            ok2.Text = "OK +1"
                        Else
                            o1 = "0"
                            ok1.Text = "OK"
                            ok2.Text = "OK"
                        End If
                    End If
                    If Bu8.Text = "English" Then
                        ok1.Text = ok1.Text.Replace("OK", "موافق")
                        ok2.Text = ok2.Text.Replace("OK", "موافق")
                    End If
                    flw = ofd0.Substring(qaz + 24, 1)
                    sn = ofd0.Substring(qaz + 25, 1)
                    wlfn(e)
                    nsn(e)
                    sf = "1"
                    sf = ofd0.Substring(qaz + 27, 1)
                    loc(e)
                    sv.Enabled = True
                    If sfh = "2" Then
                        sv1.Visible = True
                    End If
                Else
                    If Bu8.Text = "عربي" Then
                        MsgBox(("Unknown error"), vbCritical, ":(")
                    Else
                        MsgBox(("خطأ غير معروف"), vbCritical + vbMsgBoxRight + vbMsgBoxRtlReading, ":(")
                    End If
                End If
            End If
        End If
    End Sub

    Private Sub ld1_Click(sender As Object, e As EventArgs) Handles ld1.Click
        lde1(e)
    End Sub

    Sub rle(ByVal e As EventArgs)
        If Lab1 = "3" Then
            Lab1 = "1"
        ElseIf Lab1 = "6" Then
            Lab1 = "2"
        ElseIf Lab1 = "9" Then
            Lab1 = "3"
        ElseIf Lab1 = "8" Then
            Lab1 = "6"
        ElseIf Lab1 = "7" Then
            Lab1 = "9"
        ElseIf Lab1 = "4" Then
            Lab1 = "8"
        ElseIf Lab1 = "1" Then
            Lab1 = "7"
        ElseIf Lab1 = "2" Then
            Lab1 = "4"
        End If
        If Lab2 = "3" Then
            Lab2 = "1"
        ElseIf Lab2 = "6" Then
            Lab2 = "2"
        ElseIf Lab2 = "9" Then
            Lab2 = "3"
        ElseIf Lab2 = "8" Then
            Lab2 = "6"
        ElseIf Lab2 = "7" Then
            Lab2 = "9"
        ElseIf Lab2 = "4" Then
            Lab2 = "8"
        ElseIf Lab2 = "1" Then
            Lab2 = "7"
        ElseIf Lab2 = "2" Then
            Lab2 = "4"
        End If
        If Lab3 = "3" Then
            Lab3 = "1"
        ElseIf Lab3 = "6" Then
            Lab3 = "2"
        ElseIf Lab3 = "9" Then
            Lab3 = "3"
        ElseIf Lab3 = "8" Then
            Lab3 = "6"
        ElseIf Lab3 = "7" Then
            Lab3 = "9"
        ElseIf Lab3 = "4" Then
            Lab3 = "8"
        ElseIf Lab3 = "1" Then
            Lab3 = "7"
        ElseIf Lab3 = "2" Then
            Lab3 = "4"
        End If
        If Lab4 = "3" Then
            Lab4 = "1"
        ElseIf Lab4 = "6" Then
            Lab4 = "2"
        ElseIf Lab4 = "9" Then
            Lab4 = "3"
        ElseIf Lab4 = "8" Then
            Lab4 = "6"
        ElseIf Lab4 = "7" Then
            Lab4 = "9"
        ElseIf Lab4 = "4" Then
            Lab4 = "8"
        ElseIf Lab4 = "1" Then
            Lab4 = "7"
        ElseIf Lab4 = "2" Then
            Lab4 = "4"
        End If
        If Lab5 = "3" Then
            Lab5 = "1"
        ElseIf Lab5 = "6" Then
            Lab5 = "2"
        ElseIf Lab5 = "9" Then
            Lab5 = "3"
        ElseIf Lab5 = "8" Then
            Lab5 = "6"
        ElseIf Lab5 = "7" Then
            Lab5 = "9"
        ElseIf Lab5 = "4" Then
            Lab5 = "8"
        ElseIf Lab5 = "1" Then
            Lab5 = "7"
        ElseIf Lab5 = "2" Then
            Lab5 = "4"
        End If
        If Lab6 = "3" Then
            Lab6 = "1"
        ElseIf Lab6 = "6" Then
            Lab6 = "2"
        ElseIf Lab6 = "9" Then
            Lab6 = "3"
        ElseIf Lab6 = "8" Then
            Lab6 = "6"
        ElseIf Lab6 = "7" Then
            Lab6 = "9"
        ElseIf Lab6 = "4" Then
            Lab6 = "8"
        ElseIf Lab6 = "1" Then
            Lab6 = "7"
        ElseIf Lab6 = "2" Then
            Lab6 = "4"
        End If
        If Lab7 = "3" Then
            Lab7 = "1"
        ElseIf Lab7 = "6" Then
            Lab7 = "2"
        ElseIf Lab7 = "9" Then
            Lab7 = "3"
        ElseIf Lab7 = "8" Then
            Lab7 = "6"
        ElseIf Lab7 = "7" Then
            Lab7 = "9"
        ElseIf Lab7 = "4" Then
            Lab7 = "8"
        ElseIf Lab7 = "1" Then
            Lab7 = "7"
        ElseIf Lab7 = "2" Then
            Lab7 = "4"
        End If
        If Lab8 = "3" Then
            Lab8 = "1"
        ElseIf Lab8 = "6" Then
            Lab8 = "2"
        ElseIf Lab8 = "9" Then
            Lab8 = "3"
        ElseIf Lab8 = "8" Then
            Lab8 = "6"
        ElseIf Lab8 = "7" Then
            Lab8 = "9"
        ElseIf Lab8 = "4" Then
            Lab8 = "8"
        ElseIf Lab8 = "1" Then
            Lab8 = "7"
        ElseIf Lab8 = "2" Then
            Lab8 = "4"
        End If
        If Lab9 = "3" Then
            Lab9 = "1"
        ElseIf Lab9 = "6" Then
            Lab9 = "2"
        ElseIf Lab9 = "9" Then
            Lab9 = "3"
        ElseIf Lab9 = "8" Then
            Lab9 = "6"
        ElseIf Lab9 = "7" Then
            Lab9 = "9"
        ElseIf Lab9 = "4" Then
            Lab9 = "8"
        ElseIf Lab9 = "1" Then
            Lab9 = "7"
        ElseIf Lab9 = "2" Then
            Lab9 = "4"
        End If
    End Sub

    Private Sub rl_Click(sender As Object, e As EventArgs) Handles rl.Click
        If bl = "0" Then
            rle(e)
            loc(e)
        End If
    End Sub

    Private Sub rr_Click(sender As Object, e As EventArgs) Handles rr.Click
        If bl = "0" Then
            If Lab1 = "1" Then
                Lab1 = "3"
            ElseIf Lab1 = "2" Then
                Lab1 = "6"
            ElseIf Lab1 = "3" Then
                Lab1 = "9"
            ElseIf Lab1 = "6" Then
                Lab1 = "8"
            ElseIf Lab1 = "9" Then
                Lab1 = "7"
            ElseIf Lab1 = "8" Then
                Lab1 = "4"
            ElseIf Lab1 = "7" Then
                Lab1 = "1"
            ElseIf Lab1 = "4" Then
                Lab1 = "2"
            End If
            If Lab2 = "1" Then
                Lab2 = "3"
            ElseIf Lab2 = "2" Then
                Lab2 = "6"
            ElseIf Lab2 = "3" Then
                Lab2 = "9"
            ElseIf Lab2 = "6" Then
                Lab2 = "8"
            ElseIf Lab2 = "9" Then
                Lab2 = "7"
            ElseIf Lab2 = "8" Then
                Lab2 = "4"
            ElseIf Lab2 = "7" Then
                Lab2 = "1"
            ElseIf Lab2 = "4" Then
                Lab2 = "2"
            End If
            If Lab3 = "1" Then
                Lab3 = "3"
            ElseIf Lab3 = "2" Then
                Lab3 = "6"
            ElseIf Lab3 = "3" Then
                Lab3 = "9"
            ElseIf Lab3 = "6" Then
                Lab3 = "8"
            ElseIf Lab3 = "9" Then
                Lab3 = "7"
            ElseIf Lab3 = "8" Then
                Lab3 = "4"
            ElseIf Lab3 = "7" Then
                Lab3 = "1"
            ElseIf Lab3 = "4" Then
                Lab3 = "2"
            End If
            If Lab4 = "1" Then
                Lab4 = "3"
            ElseIf Lab4 = "2" Then
                Lab4 = "6"
            ElseIf Lab4 = "3" Then
                Lab4 = "9"
            ElseIf Lab4 = "6" Then
                Lab4 = "8"
            ElseIf Lab4 = "9" Then
                Lab4 = "7"
            ElseIf Lab4 = "8" Then
                Lab4 = "4"
            ElseIf Lab4 = "7" Then
                Lab4 = "1"
            ElseIf Lab4 = "4" Then
                Lab4 = "2"
            End If
            If Lab5 = "1" Then
                Lab5 = "3"
            ElseIf Lab5 = "2" Then
                Lab5 = "6"
            ElseIf Lab5 = "3" Then
                Lab5 = "9"
            ElseIf Lab5 = "6" Then
                Lab5 = "8"
            ElseIf Lab5 = "9" Then
                Lab5 = "7"
            ElseIf Lab5 = "8" Then
                Lab5 = "4"
            ElseIf Lab5 = "7" Then
                Lab5 = "1"
            ElseIf Lab5 = "4" Then
                Lab5 = "2"
            End If
            If Lab6 = "1" Then
                Lab6 = "3"
            ElseIf Lab6 = "2" Then
                Lab6 = "6"
            ElseIf Lab6 = "3" Then
                Lab6 = "9"
            ElseIf Lab6 = "6" Then
                Lab6 = "8"
            ElseIf Lab6 = "9" Then
                Lab6 = "7"
            ElseIf Lab6 = "8" Then
                Lab6 = "4"
            ElseIf Lab6 = "7" Then
                Lab6 = "1"
            ElseIf Lab6 = "4" Then
                Lab6 = "2"
            End If
            If Lab7 = "1" Then
                Lab7 = "3"
            ElseIf Lab7 = "2" Then
                Lab7 = "6"
            ElseIf Lab7 = "3" Then
                Lab7 = "9"
            ElseIf Lab7 = "6" Then
                Lab7 = "8"
            ElseIf Lab7 = "9" Then
                Lab7 = "7"
            ElseIf Lab7 = "8" Then
                Lab7 = "4"
            ElseIf Lab7 = "7" Then
                Lab7 = "1"
            ElseIf Lab7 = "4" Then
                Lab7 = "2"
            End If
            If Lab8 = "1" Then
                Lab8 = "3"
            ElseIf Lab8 = "2" Then
                Lab8 = "6"
            ElseIf Lab8 = "3" Then
                Lab8 = "9"
            ElseIf Lab8 = "6" Then
                Lab8 = "8"
            ElseIf Lab8 = "9" Then
                Lab8 = "7"
            ElseIf Lab8 = "8" Then
                Lab8 = "4"
            ElseIf Lab8 = "7" Then
                Lab8 = "1"
            ElseIf Lab8 = "4" Then
                Lab8 = "2"
            End If
            If Lab9 = "1" Then
                Lab9 = "3"
            ElseIf Lab9 = "2" Then
                Lab9 = "6"
            ElseIf Lab9 = "3" Then
                Lab9 = "9"
            ElseIf Lab9 = "6" Then
                Lab9 = "8"
            ElseIf Lab9 = "9" Then
                Lab9 = "7"
            ElseIf Lab9 = "8" Then
                Lab9 = "4"
            ElseIf Lab9 = "7" Then
                Lab9 = "1"
            ElseIf Lab9 = "4" Then
                Lab9 = "2"
            End If
            loc(e)
        End If
    End Sub

    Sub rhe(ByVal e As EventArgs)
        If Lab1 = "1" Then
            Lab1 = "3"
        ElseIf Lab1 = "4" Then
            Lab1 = "6"
        ElseIf Lab1 = "7" Then
            Lab1 = "9"
        ElseIf Lab1 = "3" Then
            Lab1 = "1"
        ElseIf Lab1 = "6" Then
            Lab1 = "4"
        ElseIf Lab1 = "9" Then
            Lab1 = "7"
        End If
        If Lab2 = "1" Then
            Lab2 = "3"
        ElseIf Lab2 = "4" Then
            Lab2 = "6"
        ElseIf Lab2 = "7" Then
            Lab2 = "9"
        ElseIf Lab2 = "3" Then
            Lab2 = "1"
        ElseIf Lab2 = "6" Then
            Lab2 = "4"
        ElseIf Lab2 = "9" Then
            Lab2 = "7"
        End If
        If Lab3 = "1" Then
            Lab3 = "3"
        ElseIf Lab3 = "4" Then
            Lab3 = "6"
        ElseIf Lab3 = "7" Then
            Lab3 = "9"
        ElseIf Lab3 = "3" Then
            Lab3 = "1"
        ElseIf Lab3 = "6" Then
            Lab3 = "4"
        ElseIf Lab3 = "9" Then
            Lab3 = "7"
        End If
        If Lab4 = "1" Then
            Lab4 = "3"
        ElseIf Lab4 = "4" Then
            Lab4 = "6"
        ElseIf Lab4 = "7" Then
            Lab4 = "9"
        ElseIf Lab4 = "3" Then
            Lab4 = "1"
        ElseIf Lab4 = "6" Then
            Lab4 = "4"
        ElseIf Lab4 = "9" Then
            Lab4 = "7"
        End If
        If Lab5 = "1" Then
            Lab5 = "3"
        ElseIf Lab5 = "4" Then
            Lab5 = "6"
        ElseIf Lab5 = "7" Then
            Lab5 = "9"
        ElseIf Lab5 = "3" Then
            Lab5 = "1"
        ElseIf Lab5 = "6" Then
            Lab5 = "4"
        ElseIf Lab5 = "9" Then
            Lab5 = "7"
        End If
        If Lab6 = "1" Then
            Lab6 = "3"
        ElseIf Lab6 = "4" Then
            Lab6 = "6"
        ElseIf Lab6 = "7" Then
            Lab6 = "9"
        ElseIf Lab6 = "3" Then
            Lab6 = "1"
        ElseIf Lab6 = "6" Then
            Lab6 = "4"
        ElseIf Lab6 = "9" Then
            Lab6 = "7"
        End If
        If Lab7 = "1" Then
            Lab7 = "3"
        ElseIf Lab7 = "4" Then
            Lab7 = "6"
        ElseIf Lab7 = "7" Then
            Lab7 = "9"
        ElseIf Lab7 = "3" Then
            Lab7 = "1"
        ElseIf Lab7 = "6" Then
            Lab7 = "4"
        ElseIf Lab7 = "9" Then
            Lab7 = "7"
        End If
        If Lab8 = "1" Then
            Lab8 = "3"
        ElseIf Lab8 = "4" Then
            Lab8 = "6"
        ElseIf Lab8 = "7" Then
            Lab8 = "9"
        ElseIf Lab8 = "3" Then
            Lab8 = "1"
        ElseIf Lab8 = "6" Then
            Lab8 = "4"
        ElseIf Lab8 = "9" Then
            Lab8 = "7"
        End If
        If Lab9 = "1" Then
            Lab9 = "3"
        ElseIf Lab9 = "4" Then
            Lab9 = "6"
        ElseIf Lab9 = "7" Then
            Lab9 = "9"
        ElseIf Lab9 = "3" Then
            Lab9 = "1"
        ElseIf Lab9 = "6" Then
            Lab9 = "4"
        ElseIf Lab9 = "9" Then
            Lab9 = "7"
        End If
    End Sub

    Private Sub rh_Click(sender As Object, e As EventArgs) Handles rh.Click
        If bl = "0" Then
            rhe(e)
            loc(e)
        End If
    End Sub

    Private Sub rv_Click(sender As Object, e As EventArgs) Handles rv.Click
        If bl = "0" Then
            If Lab1 = "1" Then
                Lab1 = "7"
            ElseIf Lab1 = "2" Then
                Lab1 = "8"
            ElseIf Lab1 = "3" Then
                Lab1 = "9"
            ElseIf Lab1 = "7" Then
                Lab1 = "1"
            ElseIf Lab1 = "8" Then
                Lab1 = "2"
            ElseIf Lab1 = "9" Then
                Lab1 = "3"
            End If
            If Lab2 = "1" Then
                Lab2 = "7"
            ElseIf Lab2 = "2" Then
                Lab2 = "8"
            ElseIf Lab2 = "3" Then
                Lab2 = "9"
            ElseIf Lab2 = "7" Then
                Lab2 = "1"
            ElseIf Lab2 = "8" Then
                Lab2 = "2"
            ElseIf Lab2 = "9" Then
                Lab2 = "3"
            End If
            If Lab3 = "1" Then
                Lab3 = "7"
            ElseIf Lab3 = "2" Then
                Lab3 = "8"
            ElseIf Lab3 = "3" Then
                Lab3 = "9"
            ElseIf Lab3 = "7" Then
                Lab3 = "1"
            ElseIf Lab3 = "8" Then
                Lab3 = "2"
            ElseIf Lab3 = "9" Then
                Lab3 = "3"
            End If
            If Lab4 = "1" Then
                Lab4 = "7"
            ElseIf Lab4 = "2" Then
                Lab4 = "8"
            ElseIf Lab4 = "3" Then
                Lab4 = "9"
            ElseIf Lab4 = "7" Then
                Lab4 = "1"
            ElseIf Lab4 = "8" Then
                Lab4 = "2"
            ElseIf Lab4 = "9" Then
                Lab4 = "3"
            End If
            If Lab5 = "1" Then
                Lab5 = "7"
            ElseIf Lab5 = "2" Then
                Lab5 = "8"
            ElseIf Lab5 = "3" Then
                Lab5 = "9"
            ElseIf Lab5 = "7" Then
                Lab5 = "1"
            ElseIf Lab5 = "8" Then
                Lab5 = "2"
            ElseIf Lab5 = "9" Then
                Lab5 = "3"
            End If
            If Lab6 = "1" Then
                Lab6 = "7"
            ElseIf Lab6 = "2" Then
                Lab6 = "8"
            ElseIf Lab6 = "3" Then
                Lab6 = "9"
            ElseIf Lab6 = "7" Then
                Lab6 = "1"
            ElseIf Lab6 = "8" Then
                Lab6 = "2"
            ElseIf Lab6 = "9" Then
                Lab6 = "3"
            End If
            If Lab7 = "1" Then
                Lab7 = "7"
            ElseIf Lab7 = "2" Then
                Lab7 = "8"
            ElseIf Lab7 = "3" Then
                Lab7 = "9"
            ElseIf Lab7 = "7" Then
                Lab7 = "1"
            ElseIf Lab7 = "8" Then
                Lab7 = "2"
            ElseIf Lab7 = "9" Then
                Lab7 = "3"
            End If
            If Lab8 = "1" Then
                Lab8 = "7"
            ElseIf Lab8 = "2" Then
                Lab8 = "8"
            ElseIf Lab8 = "3" Then
                Lab8 = "9"
            ElseIf Lab8 = "7" Then
                Lab8 = "1"
            ElseIf Lab8 = "8" Then
                Lab8 = "2"
            ElseIf Lab8 = "9" Then
                Lab8 = "3"
            End If
            If Lab9 = "1" Then
                Lab9 = "7"
            ElseIf Lab9 = "2" Then
                Lab9 = "8"
            ElseIf Lab9 = "3" Then
                Lab9 = "9"
            ElseIf Lab9 = "7" Then
                Lab9 = "1"
            ElseIf Lab9 = "8" Then
                Lab9 = "2"
            ElseIf Lab9 = "9" Then
                Lab9 = "3"
            End If
            loc(e)
        End If
    End Sub

    Sub bdl(ByVal e As EventArgs)
        rt = Lab1 : Lab1 = Lab7 : Lab7 = rt
        rt = Lab2 : Lab2 = Lab8 : Lab8 = rt
        rt = Lab3 : Lab3 = Lab9 : Lab9 = rt
        rt = La1 : La1 = La7 : La7 = rt
        rt = La2 : La2 = La8 : La8 = rt
        rt = La3 : La3 = La9 : La9 = rt
    End Sub

    Sub h(ByVal e As EventArgs)
        If bl = "0" Then
            If ok1.Checked = True And ok2.Checked = True Then
                If L2 = "0" Then
                    bl = "1"
                    T3.Stop()
                    ll1 = "1"
                    bdl(e)
                    tt2(e)
                    If Lab7 = Lb7 Then
                    Else
                        La7 = "1"
                    End If
                    If Lab8 = Lb8 Then
                    Else
                        La8 = "1"
                    End If
                    If Lab9 = Lb9 Then
                    Else
                        La9 = "1"
                    End If
                    bdl(e)
                    L2 = "1"
                    stp1.Text += 1
                    n0 += 2
                    If Lab4 = Lb7 Then
                        n1 = n1 + "1 "
                        Le1 += 1
                    ElseIf Lab4 = Lb8 Then
                        n1 = n1 + "2 "
                        Le2 += 1
                    ElseIf Lab4 = Lb9 Then
                        n1 = n1 + "3 "
                        Le3 += 1
                    ElseIf Lab5 = Lb7 Then
                        n1 = n1 + "7 "
                        Le1 += 1
                    ElseIf Lab5 = Lb8 Then
                        n1 = n1 + "8 "
                        Le2 += 1
                    ElseIf Lab5 = Lb9 Then
                        n1 = n1 + "9 "
                        Le3 += 1
                    ElseIf Lab6 = Lb7 Then
                        n1 = n1 + "13"
                        Le1 += 1
                    ElseIf Lab6 = Lb8 Then
                        n1 = n1 + "14"
                        Le2 += 1
                    ElseIf Lab6 = Lb9 Then
                        n1 = n1 + "15"
                        Le3 += 1
                    End If
                    r0 = "-1"
                    r1 = ""
                    Lb7 = Lab7 : Lb8 = Lab8 : Lb9 = Lab9
                    L1 = "0"
                    rf(e)
                    ne(e)
                    loc(e)
                    bl = "0"
                    Wn(e)
                    ll1 = "0"
                    If Cmpt.Checked = True Then
                        T3.Start()
                    End If
                ElseIf L2 = "1" And Cmpt.Checked = False Then
                    bl = "1"
                    ll1 = "1"
                    t22(e)
                    ll1 = "0"
                End If
            Else
                ooo(e)
            End If
        End If
    End Sub

    Private Sub Bu9_Click(sender As Object, e As EventArgs) Handles Bu9.Click
        h(e)
    End Sub

    Private Sub fst_Text(sender As Object, e As EventArgs) Handles fst.TextChanged
        On Error Resume Next
        Dim zz As Integer = fst.Text
        If fst.Text = "" Then
        Else
            fst.Text = zz
            If zz < 0 Or zz > 350 Then
                If zz < 0 Then
                    fst.Text = 0
                ElseIf zz > 350 Then
                    fst.Text = 350
                End If
            ElseIf zz >= 1 Or zz <= 350 Then
                T2.Interval = fst.Text
            End If
        End If
    End Sub

    Sub ok3(ByVal e As EventArgs)
        If ok1.Checked = True And ok2.Checked = True Then
            o1 += 1
            oo1 = o1
            ok1.Text = "OK +" + oo1
            ok2.Text = "OK +" + oo1
        End If
        If Bu8.Text = "English" Then
            ok1.Text = ok1.Text.Replace("OK", "موافق")
            ok2.Text = ok2.Text.Replace("OK", "موافق")
        End If
    End Sub

    Private Sub ok1_CheCha(sender As Object, e As EventArgs) Handles ok1.CheckedChanged
        ok3(e)
    End Sub

    Private Sub ok2_CheCha(sender As Object, e As EventArgs) Handles ok2.CheckedChanged
        ok3(e)
    End Sub

    Private Sub B10_Click(sender As Object, e As EventArgs) Handles B10.Click
        B11.Visible = True
        B10.Visible = False
        NoS.Visible = False
        ns.Visible = True
        lns.Visible = True
    End Sub

    Private Sub B11_Click(sender As Object, e As EventArgs) Handles B11.Click
        B10.TabIndex = 22
        B10.Visible = True
        B11.Visible = False
        ns.Visible = False
        lns.Visible = False
        B10.TabIndex = 20
        NoS.Visible = True
    End Sub

    Sub nsn(ByVal e As EventArgs)
        If sn = "1" Then
            If Bu8.Text = "عربي" Then
                ns.Text = "first"
            Else
                ns.Text = "أولا"
            End If
        ElseIf sn = "2" Then
            If Bu8.Text = "عربي" Then
                ns.Text = "second"
            Else
                ns.Text = "آخرا"
            End If
        End If
    End Sub

    Private Sub ns_TextChanged(sender As Object, e As EventArgs) Handles ns.TextChanged
        nsn(e)
    End Sub

    Private Sub ns_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ns.SelectedIndexChanged
        If ns.Text = "first" Or ns.Text = "أولا" Then
            sn = "1"
        ElseIf ns.Text = "second" Or ns.Text = "آخرا" Then
            sn = "2"
        End If
        nsn(e)
    End Sub

    Private Sub RB1_CheckedChanged(sender As Object, e As EventArgs) Handles RB1.Click
        If sf = "2" Or sf = "3" Then
            La1 = "0" : La2 = "0" : La3 = "0" : La7 = "0" : La8 = "0" : La9 = "0"
            Lab1 = "1" : Lab2 = "2" : Lab3 = "3" : Lab4 = "4" : Lab5 = "5" : Lab6 = "6" : Lab7 = "7" : Lab8 = "8" : Lab9 = "9"
            Le1 = "0" : Le2 = "0" : Le3 = "0" : Le7 = "0" : Le8 = "0" : Le9 = "0"
            sf = "1"
            loc(e)
        End If
    End Sub

    Private Sub RB2_CheckedChanged(sender As Object, e As EventArgs) Handles RB2.Click
        If sf = "1" Or sf = "3" Then
            La1 = "1" : La2 = "1" : La3 = "1" : La7 = "1" : La8 = "1" : La9 = "1"
            Lab1 = "1" : Lab2 = "8" : Lab3 = "3" : Lab4 = "4" : Lab5 = "5" : Lab6 = "6" : Lab7 = "7" : Lab8 = "2" : Lab9 = "9"
            Le1 = "1" : Le2 = "1" : Le3 = "1" : Le7 = "1" : Le8 = "1" : Le9 = "1"
            sf = "2"
            loc(e)
        End If
    End Sub

    Private Sub RB3_CheckedChanged(sender As Object, e As EventArgs) Handles RB3.Click
        If sf = "1" Or sf = "2" Then
            La1 = "1" : La2 = "1" : La3 = "1" : La7 = "1" : La8 = "1" : La9 = "1"
            Lab1 = "2" : Lab2 = "4" : Lab3 = "9" : Lab4 = "3" : Lab5 = "5" : Lab6 = "7" : Lab7 = "1" : Lab8 = "6" : Lab9 = "8"
            Le1 = "1" : Le2 = "1" : Le3 = "1" : Le7 = "1" : Le8 = "1" : Le9 = "1"
            sf = "3"
            loc(e)
            If My.Computer.FileSystem.FileExists(sg + "ABC.sg") Then
            Else
                My.Computer.FileSystem.WriteAllText(sg + "ABC.sg", "", False)
                sfh = "4"
                B67(e)
            End If
        End If
    End Sub

    Private Sub XO_Click(sender As Object, e As EventArgs) Handles XO.Click
        If bl = "0" Then
            If ok1.Checked = True And ok2.Checked = True Then
                bl = "1"
                bdl(e)
                rt = Le1 : Le1 = Le7 : Le7 = rt
                rt = Le2 : Le2 = Le8 : Le8 = rt
                rt = Le3 : Le3 = Le9 : Le9 = rt
                rt = stp1.Text : stp1.Text = stp2.Text : stp2.Text = rt
                If L2 = "0" Then
                    L2 = "1"
                ElseIf L2 = "1" Then
                    L2 = "0"
                End If
                If L22 = "0" Then
                    L22 = "1"
                ElseIf L2 = "1" Then
                    L22 = "0"
                End If
                If L3 = "0" Then
                    L3 = "1"
                ElseIf L3 = "1" Then
                    L3 = "0"
                End If
                If L1 = "1" Then
                    L1 = "7"
                ElseIf L1 = "2" Then
                    L1 = "8"
                ElseIf L1 = "3" Then
                    L1 = "9"
                ElseIf L1 = "7" Then
                    L1 = "1"
                ElseIf L1 = "8" Then
                    L1 = "2"
                ElseIf L1 = "9" Then
                    L1 = "3"
                End If
                n1 = n1.Replace("1 ", "a").Replace("2 ", "b").Replace("3 ", "c").Replace("4 ", "d").Replace("5 ", "e").Replace("6 ", "f").Replace("7 ", "g").Replace("8 ", "h").Replace("9 ", "i").Replace("10", "j").Replace("12", "l").Replace("13", "m").Replace("14", "n").Replace("15", "o").Replace("16", "p").Replace("17", "q").Replace("18", "r")
                n1 = n1.Replace("11", "k")
                n1 = n1.Replace("a", "4 ").Replace("b", "5 ").Replace("c", "6 ").Replace("d", "1 ").Replace("e", "2 ").Replace("f", "3 ").Replace("g", "10").Replace("h", "11").Replace("i", "12").Replace("j", "7 ").Replace("k", "8 ").Replace("l", "9 ").Replace("m", "16").Replace("n", "17").Replace("o", "18").Replace("p", "13").Replace("q", "14").Replace("r", "15")
                r1 = r1.Replace("1 ", "a").Replace("2 ", "b").Replace("3 ", "c").Replace("4 ", "d").Replace("5 ", "e").Replace("6 ", "f").Replace("7 ", "g").Replace("8 ", "h").Replace("9 ", "i").Replace("10", "j").Replace("12", "l").Replace("13", "m").Replace("14", "n").Replace("15", "o").Replace("16", "p").Replace("17", "q").Replace("18", "r")
                r1 = r1.Replace("11", "k")
                r1 = r1.Replace("a", "4 ").Replace("b", "5 ").Replace("c", "6 ").Replace("d", "1 ").Replace("e", "2 ").Replace("f", "3 ").Replace("g", "10").Replace("h", "11").Replace("i", "12").Replace("j", "7 ").Replace("k", "8 ").Replace("l", "9 ").Replace("m", "16").Replace("n", "17").Replace("o", "18").Replace("p", "13").Replace("q", "14").Replace("r", "15")
                loc(e)
                bl = "0"
            Else
                ooo(e)
            End If
        End If
    End Sub

    Private Sub OX_Click(sender As Object, e As EventArgs) Handles OX.Click
        If bl = "0" Then
            If ok1.Checked = True And ok2.Checked = True Then
                bl = "1"
                If L2 = "0" Then
                    L2 = "1"
                ElseIf L2 = "1" Then
                    L2 = "0"
                End If
                L1 = "0"
                loc(e)
                bl = "0"
            Else
                ooo(e)
            End If
        End If
    End Sub

    Private Sub hp_Click(sender As Object, e As EventArgs) Handles hp.Click
        If Bu8.Text = "عربي" Then
            MsgBox(("These tools help you to break free from the limitations of the game for the purpose of experimenting or to know the possibilities of different steps or training and learning or cheating and both players must agree to these features together by clicking on (OK)"), vbInformation, "؟!?")
        Else
            MsgBox(("هذه الأدوات تساعدك على التحرر من قيود اللعبة بغرض التجربة أو معرفة إحتمالات الخطوات المختلفة أو التدريب والتعلم أو الغش وعلى كلا اللاعبين أن يوافقا معا على هذه الخواص بالضغط على موافق"), vbInformation + vbMsgBoxRight + vbMsgBoxRtlReading, "؟!?")
        End If
    End Sub

    Private Sub CB1_C(sender As Object, e As EventArgs) Handles CB1.Click
        If qu = "0" Then
            XO.Visible = True
            CB1.Appearance = Appearance.Normal
            CB1.CheckState = CheckState.Indeterminate
            qu = "1"
        ElseIf qu = "1" Then
            XO.Visible = False
            OX.Visible = True
            CB1.CheckState = CheckState.Indeterminate
            qu = "2"
        ElseIf qu = "2" Then
            XO.Visible = True
            CB1.CheckState = CheckState.Checked
            qu = "3"
        ElseIf qu = "3" Then
            CB1.Appearance = Appearance.Button
            XO.Visible = False
            OX.Visible = False
            qu = "0"
        End If
    End Sub
End Class
