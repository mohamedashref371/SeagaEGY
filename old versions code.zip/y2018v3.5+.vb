﻿Public Class Sega

    Sub mv(ByVal e As KeyEventArgs)
        If e.KeyCode = Keys.NumPad7 Or e.KeyCode = Keys.Q Then
            If Lab1.Text = 1 Then
                zx1(e)
            ElseIf Lab2.Text = 1 Then
                zx2(e)
            ElseIf Lab3.Text = 1 Then
                zx3(e)
            ElseIf Lab4.Text = 1 Then
                as1(e)
            ElseIf Lab5.Text = 1 Then
                as2(e)
            ElseIf Lab6.Text = 1 Then
                as3(e)
            ElseIf Lab7.Text = 1 Then
                cv1(e)
            ElseIf Lab8.Text = 1 Then
                cv2(e)
            ElseIf Lab9.Text = 1 Then
                cv3(e)
            End If
        ElseIf e.KeyCode = Keys.NumPad8 Or e.KeyCode = Keys.W Then
            If Lab1.Text = 2 Then
                zx1(e)
            ElseIf Lab2.Text = 2 Then
                zx2(e)
            ElseIf Lab3.Text = 2 Then
                zx3(e)
            ElseIf Lab4.Text = 2 Then
                as1(e)
            ElseIf Lab5.Text = 2 Then
                as2(e)
            ElseIf Lab6.Text = 2 Then
                as3(e)
            ElseIf Lab7.Text = 2 Then
                cv1(e)
            ElseIf Lab8.Text = 2 Then
                cv2(e)
            ElseIf Lab9.Text = 2 Then
                cv3(e)
            End If
        ElseIf e.KeyCode = Keys.NumPad9 Or e.KeyCode = Keys.E Then
            If Lab1.Text = 3 Then
                zx1(e)
            ElseIf Lab2.Text = 3 Then
                zx2(e)
            ElseIf Lab3.Text = 3 Then
                zx3(e)
            ElseIf Lab4.Text = 3 Then
                as1(e)
            ElseIf Lab5.Text = 3 Then
                as2(e)
            ElseIf Lab6.Text = 3 Then
                as3(e)
            ElseIf Lab7.Text = 3 Then
                cv1(e)
            ElseIf Lab8.Text = 3 Then
                cv2(e)
            ElseIf Lab9.Text = 3 Then
                cv3(e)
            End If
        ElseIf e.KeyCode = Keys.NumPad4 Or e.KeyCode = Keys.A Then
            If Lab1.Text = 4 Then
                zx1(e)
            ElseIf Lab2.Text = 4 Then
                zx2(e)
            ElseIf Lab3.Text = 4 Then
                zx3(e)
            ElseIf Lab4.Text = 4 Then
                as1(e)
            ElseIf Lab5.Text = 4 Then
                as2(e)
            ElseIf Lab6.Text = 4 Then
                as3(e)
            ElseIf Lab7.Text = 4 Then
                cv1(e)
            ElseIf Lab8.Text = 4 Then
                cv2(e)
            ElseIf Lab9.Text = 4 Then
                cv3(e)
            End If
        ElseIf e.KeyCode = Keys.NumPad5 Or e.KeyCode = Keys.S Then
            If Lab1.Text = 5 Then
                zx1(e)
            ElseIf Lab2.Text = 5 Then
                zx2(e)
            ElseIf Lab3.Text = 5 Then
                zx3(e)
            ElseIf Lab4.Text = 5 Then
                as1(e)
            ElseIf Lab5.Text = 5 Then
                as2(e)
            ElseIf Lab6.Text = 5 Then
                as3(e)
            ElseIf Lab7.Text = 5 Then
                cv1(e)
            ElseIf Lab8.Text = 5 Then
                cv2(e)
            ElseIf Lab9.Text = 5 Then
                cv3(e)
            End If
        ElseIf e.KeyCode = Keys.NumPad6 Or e.KeyCode = Keys.D Then
            If Lab1.Text = 6 Then
                zx1(e)
            ElseIf Lab2.Text = 6 Then
                zx2(e)
            ElseIf Lab3.Text = 6 Then
                zx3(e)
            ElseIf Lab4.Text = 6 Then
                as1(e)
            ElseIf Lab5.Text = 6 Then
                as2(e)
            ElseIf Lab6.Text = 6 Then
                as3(e)
            ElseIf Lab7.Text = 6 Then
                cv1(e)
            ElseIf Lab8.Text = 6 Then
                cv2(e)
            ElseIf Lab9.Text = 6 Then
                cv3(e)
            End If
        ElseIf e.KeyCode = Keys.NumPad1 Or e.KeyCode = Keys.Z Then
            If Lab1.Text = 7 Then
                zx1(e)
            ElseIf Lab2.Text = 7 Then
                zx2(e)
            ElseIf Lab3.Text = 7 Then
                zx3(e)
            ElseIf Lab4.Text = 7 Then
                as1(e)
            ElseIf Lab5.Text = 7 Then
                as2(e)
            ElseIf Lab6.Text = 7 Then
                as3(e)
            ElseIf Lab7.Text = 7 Then
                cv1(e)
            ElseIf Lab8.Text = 7 Then
                cv2(e)
            ElseIf Lab9.Text = 7 Then
                cv3(e)
            End If
        ElseIf e.KeyCode = Keys.NumPad2 Or e.KeyCode = Keys.X Then
            If Lab1.Text = 8 Then
                zx1(e)
            ElseIf Lab2.Text = 8 Then
                zx2(e)
            ElseIf Lab3.Text = 8 Then
                zx3(e)
            ElseIf Lab4.Text = 8 Then
                as1(e)
            ElseIf Lab5.Text = 8 Then
                as2(e)
            ElseIf Lab6.Text = 8 Then
                as3(e)
            ElseIf Lab7.Text = 8 Then
                cv1(e)
            ElseIf Lab8.Text = 8 Then
                cv2(e)
            ElseIf Lab9.Text = 8 Then
                cv3(e)
            End If
        ElseIf e.KeyCode = Keys.NumPad3 Or e.KeyCode = Keys.C Then
            If Lab1.Text = 9 Then
                zx1(e)
            ElseIf Lab2.Text = 9 Then
                zx2(e)
            ElseIf Lab3.Text = 9 Then
                zx3(e)
            ElseIf Lab4.Text = 9 Then
                as1(e)
            ElseIf Lab5.Text = 9 Then
                as2(e)
            ElseIf Lab6.Text = 9 Then
                as3(e)
            ElseIf Lab7.Text = 9 Then
                cv1(e)
            ElseIf Lab8.Text = 9 Then
                cv2(e)
            ElseIf Lab9.Text = 9 Then
                cv3(e)
            End If
        End If
    End Sub

    Private Sub Sega_Key(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        mv(e)
    End Sub

    Private Sub Bu1_Key(sender As Object, e As KeyEventArgs) Handles Bu1.KeyDown
        mv(e)
    End Sub

    Private Sub Bu2_Key(sender As Object, e As KeyEventArgs) Handles Bu2.KeyDown
        mv(e)
    End Sub

    Private Sub Bu3_Key(sender As Object, e As KeyEventArgs) Handles Bu3.KeyDown
        mv(e)
    End Sub

    Private Sub Bu4_Key(sender As Object, e As KeyEventArgs) Handles Bu4.KeyDown
        mv(e)
    End Sub

    Private Sub Bu5_Key(sender As Object, e As KeyEventArgs) Handles Bu5.KeyDown
        mv(e)
    End Sub

    Private Sub Bu6_Key(sender As Object, e As KeyEventArgs) Handles Bu6.KeyDown
        mv(e)
    End Sub

    Private Sub Bu7_Key(sender As Object, e As KeyEventArgs) Handles Bu7.KeyDown
        mv(e)
    End Sub

    Private Sub Bu8_Key(sender As Object, e As KeyEventArgs) Handles Bu8.KeyDown
        mv(e)
    End Sub

    Private Sub Cmpt_Key(sender As Object, e As KeyEventArgs) Handles Cmpt.KeyDown
        mv(e)
    End Sub

    Private Sub Cmpt2_Key(sender As Object, e As KeyEventArgs) Handles Cmpt2.KeyDown
        mv(e)
    End Sub

    Private Sub VaH_Key(sender As Object, e As KeyEventArgs) Handles VaH.KeyDown
        mv(e)
    End Sub

    Private Sub NoS_Key(sender As Object, e As KeyEventArgs) Handles NoS.KeyDown
        mv(e)
    End Sub

    Sub zx1(ByVal e As EventArgs)
        On Error Resume Next
        If L2.Text = 0 Then
            If La1.Text = 0 Then
                z1.BackgroundImage = My.Resources.zx23
            Else
                z1.BackgroundImage = My.Resources.zx2
            End If
            If La2.Text = 0 Then
                z2.BackgroundImage = My.Resources.zx3
            Else
                z2.BackgroundImage = My.Resources.zx
            End If
            If La3.Text = 0 Then
                z3.BackgroundImage = My.Resources.zx3
            Else
                z3.BackgroundImage = My.Resources.zx
            End If
            a1.Visible = True
            a2.Visible = True
            a3.Visible = True
            l1.Text = 1
        End If
    End Sub

    Sub zx2(ByVal e As EventArgs)
        On Error Resume Next
        If L2.Text = 0 Then
            If La1.Text = 0 Then
                z1.BackgroundImage = My.Resources.zx3
            Else
                z1.BackgroundImage = My.Resources.zx
            End If
            If La2.Text = 0 Then
                z2.BackgroundImage = My.Resources.zx23
            Else
                z2.BackgroundImage = My.Resources.zx2
            End If
            If La3.Text = 0 Then
                z3.BackgroundImage = My.Resources.zx3
            Else
                z3.BackgroundImage = My.Resources.zx
            End If
            a1.Visible = True
            a2.Visible = True
            a3.Visible = True
            l1.Text = 2
        End If
    End Sub

    Sub zx3(ByVal e As EventArgs)
        On Error Resume Next
        If L2.Text = 0 Then
            If La1.Text = 0 Then
                z1.BackgroundImage = My.Resources.zx3
            Else
                z1.BackgroundImage = My.Resources.zx
            End If
            If La2.Text = 0 Then
                z2.BackgroundImage = My.Resources.zx3
            Else
                z2.BackgroundImage = My.Resources.zx
            End If
            If La3.Text = 0 Then
                z3.BackgroundImage = My.Resources.zx23
            Else
                z3.BackgroundImage = My.Resources.zx2
            End If
            a1.Visible = True
            a2.Visible = True
            a3.Visible = True
            l1.Text = 3
        End If
    End Sub

    Sub cv1(ByVal e As EventArgs)
        On Error Resume Next
        If Cmpt.Checked = False Then
            If L2.Text = 1 Then
                If La4.Text = 0 Then
                    c1.BackgroundImage = My.Resources.cv23
                Else
                    c1.BackgroundImage = My.Resources.cv2
                End If
                If La5.Text = 0 Then
                    c2.BackgroundImage = My.Resources.cv3
                Else
                    c2.BackgroundImage = My.Resources.cv
                End If
                If La6.Text = 0 Then
                    c3.BackgroundImage = My.Resources.cv3
                Else
                    c3.BackgroundImage = My.Resources.cv
                End If
                a1.Visible = True
                a2.Visible = True
                a3.Visible = True
                l1.Text = 4
            End If
        End If
    End Sub

    Sub cv2(ByVal e As EventArgs)
        On Error Resume Next
        If Cmpt.Checked = False Then
            If L2.Text = 1 Then
                If La4.Text = 0 Then
                    c1.BackgroundImage = My.Resources.cv3
                Else
                    c1.BackgroundImage = My.Resources.cv
                End If
                If La5.Text = 0 Then
                    c2.BackgroundImage = My.Resources.cv23
                Else
                    c2.BackgroundImage = My.Resources.cv2
                End If
                If La6.Text = 0 Then
                    c3.BackgroundImage = My.Resources.cv3
                Else
                    c3.BackgroundImage = My.Resources.cv
                End If
                a1.Visible = True
                a2.Visible = True
                a3.Visible = True
                l1.Text = 5
            End If
        End If
    End Sub

    Sub cv3(ByVal e As EventArgs)
        On Error Resume Next
        If Cmpt.Checked = False Then
            If L2.Text = 1 Then
                If La4.Text = 0 Then
                    c1.BackgroundImage = My.Resources.cv3
                Else
                    c1.BackgroundImage = My.Resources.cv
                End If
                If La5.Text = 0 Then
                    c2.BackgroundImage = My.Resources.cv3
                Else
                    c2.BackgroundImage = My.Resources.cv
                End If
                If La6.Text = 0 Then
                    c3.BackgroundImage = My.Resources.cv23
                Else
                    c3.BackgroundImage = My.Resources.cv2
                End If
                a1.Visible = True
                a2.Visible = True
                a3.Visible = True
                l1.Text = 6
            End If
        End If
    End Sub

    Sub as1(ByVal e As EventArgs)
        On Error Resume Next
        If a1.Visible = True Then
            If l1.Text = 1 Then
                ll.Location = z1.Location
                z1.Location = a1.Location
                a1.Location = ll.Location
                a1.Visible = False
                a2.Visible = False
                a3.Visible = False
                z1.BackgroundImage = My.Resources.zx
                La1.Text = 1
                rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
                stp1.Text = stp1.Text + 1
                L2.Text = 1
                l1.Text = 0
            ElseIf l1.Text = 2 Then
                ll.Location = z2.Location
                z2.Location = a1.Location
                a1.Location = ll.Location
                a1.Visible = False
                a2.Visible = False
                a3.Visible = False
                z2.BackgroundImage = My.Resources.zx
                La2.Text = 1
                rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
                stp1.Text = stp1.Text + 1
                L2.Text = 1
                l1.Text = 0
            ElseIf l1.Text = 3 Then
                ll.Location = z3.Location
                z3.Location = a1.Location
                a1.Location = ll.Location
                a1.Visible = False
                a2.Visible = False
                a3.Visible = False
                z3.BackgroundImage = My.Resources.zx
                La3.Text = 1
                rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
                stp1.Text = stp1.Text + 1
                L2.Text = 1
                l1.Text = 0
            ElseIf l1.Text = 4 Then
                ll.Location = c1.Location
                c1.Location = a1.Location
                a1.Location = ll.Location
                a1.Visible = False
                a2.Visible = False
                a3.Visible = False
                c1.BackgroundImage = My.Resources.cv
                La4.Text = 1
                rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
                stp2.Text = stp2.Text + 1
                L2.Text = 0
                l1.Text = 0
            ElseIf l1.Text = 5 Then
                ll.Location = c2.Location
                c2.Location = a1.Location
                a1.Location = ll.Location
                a1.Visible = False
                a2.Visible = False
                a3.Visible = False
                c2.BackgroundImage = My.Resources.cv
                La5.Text = 1
                rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
                stp2.Text = stp2.Text + 1
                L2.Text = 0
                l1.Text = 0
            ElseIf l1.Text = 6 Then
                ll.Location = c3.Location
                c3.Location = a1.Location
                a1.Location = ll.Location
                a1.Visible = False
                a2.Visible = False
                a3.Visible = False
                c3.BackgroundImage = My.Resources.cv
                La6.Text = 1
                rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
                stp2.Text = stp2.Text + 1
                L2.Text = 0
                l1.Text = 0
            End If
            Wn(e)
            If L2.Text = 0 Then
                PB1.BackgroundImage = My.Resources.zx
            ElseIf L2.Text = 1 Then
                PB1.BackgroundImage = My.Resources.cv
            End If
        End If
    End Sub

    Sub as2(ByVal e As EventArgs)
        On Error Resume Next
        If a2.Visible = True Then
            If l1.Text = 1 Then
                ll.Location = z1.Location
                z1.Location = a2.Location
                a2.Location = ll.Location
                a1.Visible = False
                a2.Visible = False
                a3.Visible = False
                z1.BackgroundImage = My.Resources.zx
                La1.Text = 1
                rt.Text = Lab5.Text : Lab5.Text = Lab1.Text : Lab1.Text = rt.Text
                stp1.Text = stp1.Text + 1
                L2.Text = 1
                l1.Text = 0
            ElseIf l1.Text = 2 Then
                ll.Location = z2.Location
                z2.Location = a2.Location
                a2.Location = ll.Location
                a1.Visible = False
                a2.Visible = False
                a3.Visible = False
                z2.BackgroundImage = My.Resources.zx
                La2.Text = 1
                rt.Text = Lab5.Text : Lab5.Text = Lab2.Text : Lab2.Text = rt.Text
                stp1.Text = stp1.Text + 1
                L2.Text = 1
                l1.Text = 0
            ElseIf l1.Text = 3 Then
                ll.Location = z3.Location
                z3.Location = a2.Location
                a2.Location = ll.Location
                a1.Visible = False
                a2.Visible = False
                a3.Visible = False
                z3.BackgroundImage = My.Resources.zx
                La3.Text = 1
                rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
                stp1.Text = stp1.Text + 1
                L2.Text = 1
                l1.Text = 0
            ElseIf l1.Text = 4 Then
                ll.Location = c1.Location
                c1.Location = a2.Location
                a2.Location = ll.Location
                a1.Visible = False
                a2.Visible = False
                a3.Visible = False
                c1.BackgroundImage = My.Resources.cv
                La4.Text = 1
                rt.Text = Lab5.Text : Lab5.Text = Lab7.Text : Lab7.Text = rt.Text
                stp2.Text = stp2.Text + 1
                L2.Text = 0
                l1.Text = 0
            ElseIf l1.Text = 5 Then
                ll.Location = c2.Location
                c2.Location = a2.Location
                a2.Location = ll.Location
                a1.Visible = False
                a2.Visible = False
                a3.Visible = False
                c2.BackgroundImage = My.Resources.cv
                La5.Text = 1
                rt.Text = Lab5.Text : Lab5.Text = Lab8.Text : Lab8.Text = rt.Text
                stp2.Text = stp2.Text + 1
                L2.Text = 0
                l1.Text = 0
            ElseIf l1.Text = 6 Then
                ll.Location = c3.Location
                c3.Location = a2.Location
                a2.Location = ll.Location
                a1.Visible = False
                a2.Visible = False
                a3.Visible = False
                c3.BackgroundImage = My.Resources.cv
                La6.Text = 1
                rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
                stp2.Text = stp2.Text + 1
                L2.Text = 0
                l1.Text = 0
            End If
            Wn(e)
            If L2.Text = 0 Then
                PB1.BackgroundImage = My.Resources.zx
            ElseIf L2.Text = 1 Then
                PB1.BackgroundImage = My.Resources.cv
            End If
        End If
    End Sub

    Sub as3(ByVal e As EventArgs)
        On Error Resume Next
        If a3.Visible = True Then
            If l1.Text = 1 Then
                ll.Location = z1.Location
                z1.Location = a3.Location
                a3.Location = ll.Location
                a1.Visible = False
                a2.Visible = False
                a3.Visible = False
                z1.BackgroundImage = My.Resources.zx
                La1.Text = 1
                rt.Text = Lab6.Text : Lab6.Text = Lab1.Text : Lab1.Text = rt.Text
                stp1.Text = stp1.Text + 1
                L2.Text = 1
                l1.Text = 0
            ElseIf l1.Text = 2 Then
                ll.Location = z2.Location
                z2.Location = a3.Location
                a3.Location = ll.Location
                a1.Visible = False
                a2.Visible = False
                a3.Visible = False
                z2.BackgroundImage = My.Resources.zx
                La2.Text = 1
                rt.Text = Lab6.Text : Lab6.Text = Lab2.Text : Lab2.Text = rt.Text
                stp1.Text = stp1.Text + 1
                L2.Text = 1
                l1.Text = 0
            ElseIf l1.Text = 3 Then
                ll.Location = z3.Location
                z3.Location = a3.Location
                a3.Location = ll.Location
                a1.Visible = False
                a2.Visible = False
                a3.Visible = False
                z3.BackgroundImage = My.Resources.zx
                La3.Text = 1
                rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
                stp1.Text = stp1.Text + 1
                L2.Text = 1
                l1.Text = 0
            ElseIf l1.Text = 4 Then
                ll.Location = c1.Location
                c1.Location = a3.Location
                a3.Location = ll.Location
                a1.Visible = False
                a2.Visible = False
                a3.Visible = False
                c1.BackgroundImage = My.Resources.cv
                La4.Text = 1
                rt.Text = Lab6.Text : Lab6.Text = Lab7.Text : Lab7.Text = rt.Text
                stp2.Text = stp2.Text + 1
                L2.Text = 0
                l1.Text = 0
            ElseIf l1.Text = 5 Then
                ll.Location = c2.Location
                c2.Location = a3.Location
                a3.Location = ll.Location
                a1.Visible = False
                a2.Visible = False
                a3.Visible = False
                c2.BackgroundImage = My.Resources.cv
                La5.Text = 1
                rt.Text = Lab6.Text : Lab6.Text = Lab8.Text : Lab8.Text = rt.Text
                stp2.Text = stp2.Text + 1
                L2.Text = 0
                l1.Text = 0
            ElseIf l1.Text = 6 Then
                ll.Location = c3.Location
                c3.Location = a3.Location
                a3.Location = ll.Location
                a1.Visible = False
                a2.Visible = False
                a3.Visible = False
                c3.BackgroundImage = My.Resources.cv
                La6.Text = 1
                rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
                stp2.Text = stp2.Text + 1
                L2.Text = 0
                l1.Text = 0
            End If
            Wn(e)
            If L2.Text = 0 Then
                PB1.BackgroundImage = My.Resources.zx
            ElseIf L2.Text = 1 Then
                PB1.BackgroundImage = My.Resources.cv
            End If
        End If
    End Sub

    Private Sub z1_Click(sender As Object, e As EventArgs) Handles z1.Click
        zx1(e)
    End Sub

    Private Sub z2_Click(sender As Object, e As EventArgs) Handles z2.Click
        zx2(e)
    End Sub

    Private Sub z3_Click(sender As Object, e As EventArgs) Handles z3.Click
        zx3(e)
    End Sub

    Private Sub c1_Click(sender As Object, e As EventArgs) Handles c1.Click
        cv1(e)
    End Sub

    Private Sub c2_Click(sender As Object, e As EventArgs) Handles c2.Click
        cv2(e)
    End Sub

    Private Sub c3_Click(sender As Object, e As EventArgs) Handles c3.Click
        cv3(e)
    End Sub

    Private Sub a1_Click(sender As Object, e As EventArgs) Handles a1.Click
        as1(e)
    End Sub

    Private Sub a2_Click(sender As Object, e As EventArgs) Handles a2.Click
        as2(e)
    End Sub

    Private Sub a3_Click(sender As Object, e As EventArgs) Handles a3.Click
        as3(e)
    End Sub

    Private Sub Bu2_Click(sender As Object, e As EventArgs) Handles Bu2.Click
        Res(e)
    End Sub

    Private Sub Bu1_Click(sender As Object, e As EventArgs) Handles Bu1.Click
        Sega2.ShowDialog()
    End Sub

    Private Sub NoS_CheckedChanged(sender As Object, e As EventArgs) Handles NoS.CheckedChanged
        If NoS.Checked = True Then
            If Bu8.Text = "عربي" Then
                If MsgBox(("- If you activate this feature, the number of steps of both players must be equal to win one of you.
- No one likes this feature because it is difficult and boring ...
- Are you sure you want to enable this feature ?!"), vbYesNo + vbQuestion, "Warning...") = MsgBoxResult.Yes Then
                Else
                    NoS.Checked = False
                End If
            Else
                If MsgBox(("- لو قمت بتفعيل هذه الخاصية،  يجب ان تكون عدد خطوات كلا اللاعبين متساوية ليفوز واحد منكما.
- لا احد يحب هذه الخاصية لأنها صعبة ومملة ...
- هل انت متأكد من انك تريد تفعيل هذه الخاصية ?!"), vbYesNo + vbQuestion + vbMsgBoxRight + vbMsgBoxRtlReading, "تحذير...") = MsgBoxResult.Yes Then
                Else
                    NoS.Checked = False
                End If
            End If
        End If
        If NoS.Checked = True Then
            stp1.Visible = True
            stp2.Visible = True
        Else
            stp1.Visible = False
            stp2.Visible = False
        End If
        If (L3.Text = 0) Or (L3.Text = 1) Then
            Wn(e)
        End If
    End Sub

    Sub Res(ByVal e As EventArgs)
        On Error Resume Next
        z1.Location = New Point(78, 82)
        z2.Location = New Point(202, 82)
        z3.Location = New Point(323, 82)
        c1.Location = New Point(78, 312)
        c2.Location = New Point(202, 312)
        c3.Location = New Point(323, 312)
        a1.Location = New Point(78, 200)
        a2.Location = New Point(202, 200)
        a3.Location = New Point(323, 200)
        a1.Visible = False
        a2.Visible = False
        a3.Visible = False
        z1.BackgroundImage = My.Resources.zx3
        z2.BackgroundImage = My.Resources.zx3
        z3.BackgroundImage = My.Resources.zx3
        c1.BackgroundImage = My.Resources.cv3
        c2.BackgroundImage = My.Resources.cv3
        c3.BackgroundImage = My.Resources.cv3
        La1.Text = 0
        La2.Text = 0
        La3.Text = 0
        La4.Text = 0
        La5.Text = 0
        La6.Text = 0
        Lab1.Text = 1
        Lab2.Text = 2
        Lab3.Text = 3
        Lab4.Text = 4
        Lab5.Text = 5
        Lab6.Text = 6
        Lab7.Text = 7
        Lab8.Text = 8
        Lab9.Text = 9
        Lb1.Text = 1
        Lb2.Text = 2
        Lb3.Text = 3
        Lb7.Text = 7
        Lb8.Text = 8
        Lb9.Text = 9
        stp1.Text = 0
        stp2.Text = 0
        l1.Text = 0
        If Bu8.Text = "عربي" Then
            Bu4.Text = "Start"
        Else
            Bu4.Text = "إبدأ"
        End If
        T1.Stop()
        ll.Location = New Point(0, 0)
        L2.Text = L22.Text
        If L22.Text = 3 Then
            Bu4.Visible = True
            PB1.BackgroundImage = Nothing
        Else
            Bu4.Visible = False
            If L2.Text = 0 Then
                PB1.BackgroundImage = My.Resources.zx
            ElseIf L2.Text = 1 Then
                PB1.BackgroundImage = My.Resources.cv
            End If
        End If
        L3.Text = 2
    End Sub

    Sub Wn(ByVal e As EventArgs)
        On Error Resume Next
        If (NoS.Checked = False) Or ((NoS.Checked = True) And (stp1.Text = stp2.Text) And (L3.Text = 2)) Then
            If (La1.Text = 1 And La2.Text = 1 And La3.Text = 1) And (((Lab1.Text = 1 And Lab2.Text = 2 And Lab3.Text = 3) Or (Lab1.Text = 1 And Lab2.Text = 3 And Lab3.Text = 2) Or (Lab1.Text = 2 And Lab2.Text = 1 And Lab3.Text = 3) Or (Lab1.Text = 2 And Lab2.Text = 3 And Lab3.Text = 1) Or (Lab1.Text = 3 And Lab2.Text = 1 And Lab3.Text = 2) Or (Lab1.Text = 3 And Lab2.Text = 2 And Lab3.Text = 1) Or (Lab1.Text = 4 And Lab2.Text = 5 And Lab3.Text = 6) Or (Lab1.Text = 4 And Lab2.Text = 6 And Lab3.Text = 5) Or (Lab1.Text = 5 And Lab2.Text = 4 And Lab3.Text = 6) Or (Lab1.Text = 5 And Lab2.Text = 6 And Lab3.Text = 4) Or (Lab1.Text = 6 And Lab2.Text = 4 And Lab3.Text = 5) Or (Lab1.Text = 6 And Lab2.Text = 5 And Lab3.Text = 4) Or (Lab1.Text = 7 And Lab2.Text = 8 And Lab3.Text = 9) Or (Lab1.Text = 7 And Lab2.Text = 9 And Lab3.Text = 8) Or (Lab1.Text = 8 And Lab2.Text = 7 And Lab3.Text = 9) Or (Lab1.Text = 8 And Lab2.Text = 9 And Lab3.Text = 7) Or (Lab1.Text = 9 And Lab2.Text = 7 And Lab3.Text = 8) Or (Lab1.Text = 9 And Lab2.Text = 8 And Lab3.Text = 7) Or (Lab1.Text = 1 And Lab2.Text = 4 And Lab3.Text = 7) Or (Lab1.Text = 1 And Lab2.Text = 7 And Lab3.Text = 4) Or (Lab1.Text = 4 And Lab2.Text = 1 And Lab3.Text = 7) Or (Lab1.Text = 4 And Lab2.Text = 7 And Lab3.Text = 1) Or (Lab1.Text = 7 And Lab2.Text = 1 And Lab3.Text = 4) Or (Lab1.Text = 7 And Lab2.Text = 4 And Lab3.Text = 1) Or (Lab1.Text = 2 And Lab2.Text = 5 And Lab3.Text = 8) Or (Lab1.Text = 2 And Lab2.Text = 8 And Lab3.Text = 5) Or (Lab1.Text = 5 And Lab2.Text = 2 And Lab3.Text = 8) Or (Lab1.Text = 5 And Lab2.Text = 8 And Lab3.Text = 2) Or (Lab1.Text = 8 And Lab2.Text = 2 And Lab3.Text = 5) Or (Lab1.Text = 8 And Lab2.Text = 5 And Lab3.Text = 2) Or (Lab1.Text = 3 And Lab2.Text = 6 And Lab3.Text = 9) Or (Lab1.Text = 3 And Lab2.Text = 9 And Lab3.Text = 6) Or (Lab1.Text = 6 And Lab2.Text = 3 And Lab3.Text = 9) Or (Lab1.Text = 6 And Lab2.Text = 9 And Lab3.Text = 3) Or (Lab1.Text = 9 And Lab2.Text = 3 And Lab3.Text = 6) Or (Lab1.Text = 9 And Lab2.Text = 6 And Lab3.Text = 3)) Or ((VaH.Checked = False) And ((Lab1.Text = 1 And Lab2.Text = 5 And Lab3.Text = 9) Or (Lab1.Text = 1 And Lab2.Text = 9 And Lab3.Text = 5) Or (Lab1.Text = 5 And Lab2.Text = 1 And Lab3.Text = 9) Or (Lab1.Text = 5 And Lab2.Text = 9 And Lab3.Text = 1) Or (Lab1.Text = 9 And Lab2.Text = 1 And Lab3.Text = 5) Or (Lab1.Text = 9 And Lab2.Text = 5 And Lab3.Text = 1) Or (Lab1.Text = 3 And Lab2.Text = 5 And Lab3.Text = 7) Or (Lab1.Text = 3 And Lab2.Text = 7 And Lab3.Text = 5) Or (Lab1.Text = 5 And Lab2.Text = 3 And Lab3.Text = 7) Or (Lab1.Text = 5 And Lab2.Text = 7 And Lab3.Text = 3) Or (Lab1.Text = 7 And Lab2.Text = 3 And Lab3.Text = 5) Or (Lab1.Text = 7 And Lab2.Text = 5 And Lab3.Text = 3)))) Then
                wn1.Text = wn1.Text + 1
                z1.BackgroundImage = My.Resources.zx4
                z2.BackgroundImage = My.Resources.zx4
                z3.BackgroundImage = My.Resources.zx4
                If nm1.Text = "" Then
                    If Cmpt.Checked = True Then
                        If Bu8.Text = "عربي" Then
                            MsgBox(("You won, Player"), vbInformation, "Excellent")
                        Else
                            MsgBox(("انت فزت يا Player"), vbInformation + vbMsgBoxRight + vbMsgBoxRtlReading, "ممتاز")
                        End If
                    Else
                        If Bu8.Text = "عربي" Then
                            MsgBox(("You won, Player1"), vbInformation, "Excellent")
                        Else
                            MsgBox(("انت فزت يا Player1"), vbInformation + vbMsgBoxRight + vbMsgBoxRtlReading, "ممتاز")
                        End If
                    End If
                    L2.Text = 0
                    L22.Text = 0
                Else
                    If Bu8.Text = "عربي" Then
                        MsgBox(("You won, " + nm1.Text), vbInformation, "Excellent")
                    Else
                        MsgBox(("انت فزت يا " + nm1.Text), vbInformation + vbMsgBoxRight + vbMsgBoxRtlReading, "ممتاز")
                    End If
                    L2.Text = 0
                    L22.Text = 0
                End If
                Res(e)
            End If
            If (La4.Text = 1 And La5.Text = 1 And La6.Text = 1) And (((Lab7.Text = 1 And Lab8.Text = 2 And Lab9.Text = 3) Or (Lab7.Text = 1 And Lab8.Text = 3 And Lab9.Text = 2) Or (Lab7.Text = 2 And Lab8.Text = 1 And Lab9.Text = 3) Or (Lab7.Text = 2 And Lab8.Text = 3 And Lab9.Text = 1) Or (Lab7.Text = 3 And Lab8.Text = 1 And Lab9.Text = 2) Or (Lab7.Text = 3 And Lab8.Text = 2 And Lab9.Text = 1) Or (Lab7.Text = 4 And Lab8.Text = 5 And Lab9.Text = 6) Or (Lab7.Text = 4 And Lab8.Text = 6 And Lab9.Text = 5) Or (Lab7.Text = 5 And Lab8.Text = 4 And Lab9.Text = 6) Or (Lab7.Text = 5 And Lab8.Text = 6 And Lab9.Text = 4) Or (Lab7.Text = 6 And Lab8.Text = 4 And Lab9.Text = 5) Or (Lab7.Text = 6 And Lab8.Text = 5 And Lab9.Text = 4) Or (Lab7.Text = 7 And Lab8.Text = 8 And Lab9.Text = 9) Or (Lab7.Text = 7 And Lab8.Text = 9 And Lab9.Text = 8) Or (Lab7.Text = 8 And Lab8.Text = 7 And Lab9.Text = 9) Or (Lab7.Text = 8 And Lab8.Text = 9 And Lab9.Text = 7) Or (Lab7.Text = 9 And Lab8.Text = 7 And Lab9.Text = 8) Or (Lab7.Text = 9 And Lab8.Text = 8 And Lab9.Text = 7) Or (Lab7.Text = 1 And Lab8.Text = 4 And Lab9.Text = 7) Or (Lab7.Text = 1 And Lab8.Text = 7 And Lab9.Text = 4) Or (Lab7.Text = 4 And Lab8.Text = 1 And Lab9.Text = 7) Or (Lab7.Text = 4 And Lab8.Text = 7 And Lab9.Text = 1) Or (Lab7.Text = 7 And Lab8.Text = 1 And Lab9.Text = 4) Or (Lab7.Text = 7 And Lab8.Text = 4 And Lab9.Text = 1) Or (Lab7.Text = 2 And Lab8.Text = 5 And Lab9.Text = 8) Or (Lab7.Text = 2 And Lab8.Text = 8 And Lab9.Text = 5) Or (Lab7.Text = 5 And Lab8.Text = 2 And Lab9.Text = 8) Or (Lab7.Text = 5 And Lab8.Text = 8 And Lab9.Text = 2) Or (Lab7.Text = 8 And Lab8.Text = 2 And Lab9.Text = 5) Or (Lab7.Text = 8 And Lab8.Text = 5 And Lab9.Text = 2) Or (Lab7.Text = 3 And Lab8.Text = 6 And Lab9.Text = 9) Or (Lab7.Text = 3 And Lab8.Text = 9 And Lab9.Text = 6) Or (Lab7.Text = 6 And Lab8.Text = 3 And Lab9.Text = 9) Or (Lab7.Text = 6 And Lab8.Text = 9 And Lab9.Text = 3) Or (Lab7.Text = 9 And Lab8.Text = 3 And Lab9.Text = 6) Or (Lab7.Text = 9 And Lab8.Text = 6 And Lab9.Text = 3)) Or ((VaH.Checked = False) And ((Lab7.Text = 1 And Lab8.Text = 5 And Lab9.Text = 9) Or (Lab7.Text = 1 And Lab8.Text = 9 And Lab9.Text = 5) Or (Lab7.Text = 5 And Lab8.Text = 1 And Lab9.Text = 9) Or (Lab7.Text = 5 And Lab8.Text = 9 And Lab9.Text = 1) Or (Lab7.Text = 9 And Lab8.Text = 1 And Lab9.Text = 5) Or (Lab7.Text = 9 And Lab8.Text = 5 And Lab9.Text = 1) Or (Lab7.Text = 3 And Lab8.Text = 5 And Lab9.Text = 7) Or (Lab7.Text = 3 And Lab8.Text = 7 And Lab9.Text = 5) Or (Lab7.Text = 5 And Lab8.Text = 3 And Lab9.Text = 7) Or (Lab7.Text = 5 And Lab8.Text = 7 And Lab9.Text = 3) Or (Lab7.Text = 7 And Lab8.Text = 3 And Lab9.Text = 5) Or (Lab7.Text = 7 And Lab8.Text = 5 And Lab9.Text = 3)))) Then
                wn2.Text = wn2.Text + 1
                c1.BackgroundImage = My.Resources.cv4
                c2.BackgroundImage = My.Resources.cv4
                c3.BackgroundImage = My.Resources.cv4
                If nm2.Text = "" Then
                    If Cmpt.Checked = True Then
                        If Bu8.Text = "عربي" Then
                            MsgBox(("You won, Computer"), vbInformation, "Excellent")
                        Else
                            MsgBox(("انت فزت يا Computer"), vbInformation + vbMsgBoxRight + vbMsgBoxRtlReading, "ممتاز")
                        End If
                    Else
                        If Bu8.Text = "عربي" Then
                            MsgBox(("You won, Player2"), vbInformation, "Excellent")
                        Else
                            MsgBox(("انت فزت يا Player2"), vbInformation + vbMsgBoxRight + vbMsgBoxRtlReading, "ممتاز")
                        End If
                    End If
                    L2.Text = 1
                    L22.Text = 1
                Else
                    If Bu8.Text = "عربي" Then
                        MsgBox(("You won, " + nm2.Text), vbInformation, "Excellent")
                    Else
                        MsgBox(("انت فزت يا " + nm2.Text), vbInformation + vbMsgBoxRight + vbMsgBoxRtlReading, "ممتاز")
                    End If
                    L2.Text = 1
                    L22.Text = 1
                End If
                Res(e)
            End If
        ElseIf (stp1.Text IsNot stp2.Text) And (NoS.Checked = True) And (L3.Text = 2) Then
            If (La1.Text = 1 And La2.Text = 1 And La3.Text = 1) And (((Lab1.Text = 1 And Lab2.Text = 2 And Lab3.Text = 3) Or (Lab1.Text = 1 And Lab2.Text = 3 And Lab3.Text = 2) Or (Lab1.Text = 2 And Lab2.Text = 1 And Lab3.Text = 3) Or (Lab1.Text = 2 And Lab2.Text = 3 And Lab3.Text = 1) Or (Lab1.Text = 3 And Lab2.Text = 1 And Lab3.Text = 2) Or (Lab1.Text = 3 And Lab2.Text = 2 And Lab3.Text = 1) Or (Lab1.Text = 4 And Lab2.Text = 5 And Lab3.Text = 6) Or (Lab1.Text = 4 And Lab2.Text = 6 And Lab3.Text = 5) Or (Lab1.Text = 5 And Lab2.Text = 4 And Lab3.Text = 6) Or (Lab1.Text = 5 And Lab2.Text = 6 And Lab3.Text = 4) Or (Lab1.Text = 6 And Lab2.Text = 4 And Lab3.Text = 5) Or (Lab1.Text = 6 And Lab2.Text = 5 And Lab3.Text = 4) Or (Lab1.Text = 7 And Lab2.Text = 8 And Lab3.Text = 9) Or (Lab1.Text = 7 And Lab2.Text = 9 And Lab3.Text = 8) Or (Lab1.Text = 8 And Lab2.Text = 7 And Lab3.Text = 9) Or (Lab1.Text = 8 And Lab2.Text = 9 And Lab3.Text = 7) Or (Lab1.Text = 9 And Lab2.Text = 7 And Lab3.Text = 8) Or (Lab1.Text = 9 And Lab2.Text = 8 And Lab3.Text = 7) Or (Lab1.Text = 1 And Lab2.Text = 4 And Lab3.Text = 7) Or (Lab1.Text = 1 And Lab2.Text = 7 And Lab3.Text = 4) Or (Lab1.Text = 4 And Lab2.Text = 1 And Lab3.Text = 7) Or (Lab1.Text = 4 And Lab2.Text = 7 And Lab3.Text = 1) Or (Lab1.Text = 7 And Lab2.Text = 1 And Lab3.Text = 4) Or (Lab1.Text = 7 And Lab2.Text = 4 And Lab3.Text = 1) Or (Lab1.Text = 2 And Lab2.Text = 5 And Lab3.Text = 8) Or (Lab1.Text = 2 And Lab2.Text = 8 And Lab3.Text = 5) Or (Lab1.Text = 5 And Lab2.Text = 2 And Lab3.Text = 8) Or (Lab1.Text = 5 And Lab2.Text = 8 And Lab3.Text = 2) Or (Lab1.Text = 8 And Lab2.Text = 2 And Lab3.Text = 5) Or (Lab1.Text = 8 And Lab2.Text = 5 And Lab3.Text = 2) Or (Lab1.Text = 3 And Lab2.Text = 6 And Lab3.Text = 9) Or (Lab1.Text = 3 And Lab2.Text = 9 And Lab3.Text = 6) Or (Lab1.Text = 6 And Lab2.Text = 3 And Lab3.Text = 9) Or (Lab1.Text = 6 And Lab2.Text = 9 And Lab3.Text = 3) Or (Lab1.Text = 9 And Lab2.Text = 3 And Lab3.Text = 6) Or (Lab1.Text = 9 And Lab2.Text = 6 And Lab3.Text = 3)) Or ((VaH.Checked = False) And ((Lab1.Text = 1 And Lab2.Text = 5 And Lab3.Text = 9) Or (Lab1.Text = 1 And Lab2.Text = 9 And Lab3.Text = 5) Or (Lab1.Text = 5 And Lab2.Text = 1 And Lab3.Text = 9) Or (Lab1.Text = 5 And Lab2.Text = 9 And Lab3.Text = 1) Or (Lab1.Text = 9 And Lab2.Text = 1 And Lab3.Text = 5) Or (Lab1.Text = 9 And Lab2.Text = 5 And Lab3.Text = 1) Or (Lab1.Text = 3 And Lab2.Text = 5 And Lab3.Text = 7) Or (Lab1.Text = 3 And Lab2.Text = 7 And Lab3.Text = 5) Or (Lab1.Text = 5 And Lab2.Text = 3 And Lab3.Text = 7) Or (Lab1.Text = 5 And Lab2.Text = 7 And Lab3.Text = 3) Or (Lab1.Text = 7 And Lab2.Text = 3 And Lab3.Text = 5) Or (Lab1.Text = 7 And Lab2.Text = 5 And Lab3.Text = 3)))) Then
                L3.Text = 0
                z1.BackgroundImage = My.Resources.zx4
                z2.BackgroundImage = My.Resources.zx4
                z3.BackgroundImage = My.Resources.zx4
            End If
            If (La4.Text = 1 And La5.Text = 1 And La6.Text = 1) And (((Lab7.Text = 1 And Lab8.Text = 2 And Lab9.Text = 3) Or (Lab7.Text = 1 And Lab8.Text = 3 And Lab9.Text = 2) Or (Lab7.Text = 2 And Lab8.Text = 1 And Lab9.Text = 3) Or (Lab7.Text = 2 And Lab8.Text = 3 And Lab9.Text = 1) Or (Lab7.Text = 3 And Lab8.Text = 1 And Lab9.Text = 2) Or (Lab7.Text = 3 And Lab8.Text = 2 And Lab9.Text = 1) Or (Lab7.Text = 4 And Lab8.Text = 5 And Lab9.Text = 6) Or (Lab7.Text = 4 And Lab8.Text = 6 And Lab9.Text = 5) Or (Lab7.Text = 5 And Lab8.Text = 4 And Lab9.Text = 6) Or (Lab7.Text = 5 And Lab8.Text = 6 And Lab9.Text = 4) Or (Lab7.Text = 6 And Lab8.Text = 4 And Lab9.Text = 5) Or (Lab7.Text = 6 And Lab8.Text = 5 And Lab9.Text = 4) Or (Lab7.Text = 7 And Lab8.Text = 8 And Lab9.Text = 9) Or (Lab7.Text = 7 And Lab8.Text = 9 And Lab9.Text = 8) Or (Lab7.Text = 8 And Lab8.Text = 7 And Lab9.Text = 9) Or (Lab7.Text = 8 And Lab8.Text = 9 And Lab9.Text = 7) Or (Lab7.Text = 9 And Lab8.Text = 7 And Lab9.Text = 8) Or (Lab7.Text = 9 And Lab8.Text = 8 And Lab9.Text = 7) Or (Lab7.Text = 1 And Lab8.Text = 4 And Lab9.Text = 7) Or (Lab7.Text = 1 And Lab8.Text = 7 And Lab9.Text = 4) Or (Lab7.Text = 4 And Lab8.Text = 1 And Lab9.Text = 7) Or (Lab7.Text = 4 And Lab8.Text = 7 And Lab9.Text = 1) Or (Lab7.Text = 7 And Lab8.Text = 1 And Lab9.Text = 4) Or (Lab7.Text = 7 And Lab8.Text = 4 And Lab9.Text = 1) Or (Lab7.Text = 2 And Lab8.Text = 5 And Lab9.Text = 8) Or (Lab7.Text = 2 And Lab8.Text = 8 And Lab9.Text = 5) Or (Lab7.Text = 5 And Lab8.Text = 2 And Lab9.Text = 8) Or (Lab7.Text = 5 And Lab8.Text = 8 And Lab9.Text = 2) Or (Lab7.Text = 8 And Lab8.Text = 2 And Lab9.Text = 5) Or (Lab7.Text = 8 And Lab8.Text = 5 And Lab9.Text = 2) Or (Lab7.Text = 3 And Lab8.Text = 6 And Lab9.Text = 9) Or (Lab7.Text = 3 And Lab8.Text = 9 And Lab9.Text = 6) Or (Lab7.Text = 6 And Lab8.Text = 3 And Lab9.Text = 9) Or (Lab7.Text = 6 And Lab8.Text = 9 And Lab9.Text = 3) Or (Lab7.Text = 9 And Lab8.Text = 3 And Lab9.Text = 6) Or (Lab7.Text = 9 And Lab8.Text = 6 And Lab9.Text = 3)) Or ((VaH.Checked = False) And ((Lab7.Text = 1 And Lab8.Text = 5 And Lab9.Text = 9) Or (Lab7.Text = 1 And Lab8.Text = 9 And Lab9.Text = 5) Or (Lab7.Text = 5 And Lab8.Text = 1 And Lab9.Text = 9) Or (Lab7.Text = 5 And Lab8.Text = 9 And Lab9.Text = 1) Or (Lab7.Text = 9 And Lab8.Text = 1 And Lab9.Text = 5) Or (Lab7.Text = 9 And Lab8.Text = 5 And Lab9.Text = 1) Or (Lab7.Text = 3 And Lab8.Text = 5 And Lab9.Text = 7) Or (Lab7.Text = 3 And Lab8.Text = 7 And Lab9.Text = 5) Or (Lab7.Text = 5 And Lab8.Text = 3 And Lab9.Text = 7) Or (Lab7.Text = 5 And Lab8.Text = 7 And Lab9.Text = 3) Or (Lab7.Text = 7 And Lab8.Text = 3 And Lab9.Text = 5) Or (Lab7.Text = 7 And Lab8.Text = 5 And Lab9.Text = 3)))) Then
                L3.Text = 1
                c1.BackgroundImage = My.Resources.cv4
                c2.BackgroundImage = My.Resources.cv4
                c3.BackgroundImage = My.Resources.cv4
            End If
        ElseIf (L3.Text = 0) Or (L3.Text = 1) Then
            If L3.Text = 0 Then
                If (La4.Text = 1 And La5.Text = 1 And La6.Text = 1) And (((Lab7.Text = 1 And Lab8.Text = 2 And Lab9.Text = 3) Or (Lab7.Text = 1 And Lab8.Text = 3 And Lab9.Text = 2) Or (Lab7.Text = 2 And Lab8.Text = 1 And Lab9.Text = 3) Or (Lab7.Text = 2 And Lab8.Text = 3 And Lab9.Text = 1) Or (Lab7.Text = 3 And Lab8.Text = 1 And Lab9.Text = 2) Or (Lab7.Text = 3 And Lab8.Text = 2 And Lab9.Text = 1) Or (Lab7.Text = 4 And Lab8.Text = 5 And Lab9.Text = 6) Or (Lab7.Text = 4 And Lab8.Text = 6 And Lab9.Text = 5) Or (Lab7.Text = 5 And Lab8.Text = 4 And Lab9.Text = 6) Or (Lab7.Text = 5 And Lab8.Text = 6 And Lab9.Text = 4) Or (Lab7.Text = 6 And Lab8.Text = 4 And Lab9.Text = 5) Or (Lab7.Text = 6 And Lab8.Text = 5 And Lab9.Text = 4) Or (Lab7.Text = 7 And Lab8.Text = 8 And Lab9.Text = 9) Or (Lab7.Text = 7 And Lab8.Text = 9 And Lab9.Text = 8) Or (Lab7.Text = 8 And Lab8.Text = 7 And Lab9.Text = 9) Or (Lab7.Text = 8 And Lab8.Text = 9 And Lab9.Text = 7) Or (Lab7.Text = 9 And Lab8.Text = 7 And Lab9.Text = 8) Or (Lab7.Text = 9 And Lab8.Text = 8 And Lab9.Text = 7) Or (Lab7.Text = 1 And Lab8.Text = 4 And Lab9.Text = 7) Or (Lab7.Text = 1 And Lab8.Text = 7 And Lab9.Text = 4) Or (Lab7.Text = 4 And Lab8.Text = 1 And Lab9.Text = 7) Or (Lab7.Text = 4 And Lab8.Text = 7 And Lab9.Text = 1) Or (Lab7.Text = 7 And Lab8.Text = 1 And Lab9.Text = 4) Or (Lab7.Text = 7 And Lab8.Text = 4 And Lab9.Text = 1) Or (Lab7.Text = 2 And Lab8.Text = 5 And Lab9.Text = 8) Or (Lab7.Text = 2 And Lab8.Text = 8 And Lab9.Text = 5) Or (Lab7.Text = 5 And Lab8.Text = 2 And Lab9.Text = 8) Or (Lab7.Text = 5 And Lab8.Text = 8 And Lab9.Text = 2) Or (Lab7.Text = 8 And Lab8.Text = 2 And Lab9.Text = 5) Or (Lab7.Text = 8 And Lab8.Text = 5 And Lab9.Text = 2) Or (Lab7.Text = 3 And Lab8.Text = 6 And Lab9.Text = 9) Or (Lab7.Text = 3 And Lab8.Text = 9 And Lab9.Text = 6) Or (Lab7.Text = 6 And Lab8.Text = 3 And Lab9.Text = 9) Or (Lab7.Text = 6 And Lab8.Text = 9 And Lab9.Text = 3) Or (Lab7.Text = 9 And Lab8.Text = 3 And Lab9.Text = 6) Or (Lab7.Text = 9 And Lab8.Text = 6 And Lab9.Text = 3)) Or ((VaH.Checked = False) And ((Lab7.Text = 1 And Lab8.Text = 5 And Lab9.Text = 9) Or (Lab7.Text = 1 And Lab8.Text = 9 And Lab9.Text = 5) Or (Lab7.Text = 5 And Lab8.Text = 1 And Lab9.Text = 9) Or (Lab7.Text = 5 And Lab8.Text = 9 And Lab9.Text = 1) Or (Lab7.Text = 9 And Lab8.Text = 1 And Lab9.Text = 5) Or (Lab7.Text = 9 And Lab8.Text = 5 And Lab9.Text = 1) Or (Lab7.Text = 3 And Lab8.Text = 5 And Lab9.Text = 7) Or (Lab7.Text = 3 And Lab8.Text = 7 And Lab9.Text = 5) Or (Lab7.Text = 5 And Lab8.Text = 3 And Lab9.Text = 7) Or (Lab7.Text = 5 And Lab8.Text = 7 And Lab9.Text = 3) Or (Lab7.Text = 7 And Lab8.Text = 3 And Lab9.Text = 5) Or (Lab7.Text = 7 And Lab8.Text = 5 And Lab9.Text = 3)))) Then
                    La1.Text = 0
                    La2.Text = 0
                    La3.Text = 0
                    La4.Text = 0
                    La5.Text = 0
                    La6.Text = 0
                    Lb1.Text = Lab1.Text : Lb2.Text = Lab2.Text : Lb3.Text = Lab3.Text
                    Lb7.Text = Lab7.Text : Lb8.Text = Lab8.Text : Lb9.Text = Lab9.Text
                    L3.Text = 2
                    z1.BackgroundImage = My.Resources.zx3
                    z2.BackgroundImage = My.Resources.zx3
                    z3.BackgroundImage = My.Resources.zx3
                    c1.BackgroundImage = My.Resources.cv3
                    c2.BackgroundImage = My.Resources.cv3
                    c3.BackgroundImage = My.Resources.cv3
                    L2.Text = L22.Text
                    PB1.BackgroundImage = My.Resources.zx
                Else
                    wn1.Text = wn1.Text + 1
                    If nm1.Text = "" Then
                        If Cmpt.Checked = True Then
                            If Bu8.Text = "عربي" Then
                                MsgBox(("You won, Player"), vbInformation, "Excellent")
                            Else
                                MsgBox(("انت فزت يا Player"), vbInformation + vbMsgBoxRight + vbMsgBoxRtlReading, "ممتاز")
                            End If
                        Else
                            If Bu8.Text = "عربي" Then
                                MsgBox(("You won, Player1"), vbInformation, "Excellent")
                            Else
                                MsgBox(("انت فزت يا Player1"), vbInformation + vbMsgBoxRight + vbMsgBoxRtlReading, "ممتاز")
                            End If
                        End If
                        L2.Text = 0
                        L22.Text = 0
                    Else
                        If Bu8.Text = "عربي" Then
                            MsgBox(("You won, " + nm1.Text), vbInformation, "Excellent")
                        Else
                            MsgBox(("انت فزت يا " + nm1.Text), vbInformation + vbMsgBoxRight + vbMsgBoxRtlReading, "ممتاز")
                        End If
                        L2.Text = 0
                        L22.Text = 0
                    End If
                    Res(e)
                End If
            ElseIf L3.Text = 1 Then
                If (La1.Text = 1 And La2.Text = 1 And La3.Text = 1) And (((Lab1.Text = 1 And Lab2.Text = 2 And Lab3.Text = 3) Or (Lab1.Text = 1 And Lab2.Text = 3 And Lab3.Text = 2) Or (Lab1.Text = 2 And Lab2.Text = 1 And Lab3.Text = 3) Or (Lab1.Text = 2 And Lab2.Text = 3 And Lab3.Text = 1) Or (Lab1.Text = 3 And Lab2.Text = 1 And Lab3.Text = 2) Or (Lab1.Text = 3 And Lab2.Text = 2 And Lab3.Text = 1) Or (Lab1.Text = 4 And Lab2.Text = 5 And Lab3.Text = 6) Or (Lab1.Text = 4 And Lab2.Text = 6 And Lab3.Text = 5) Or (Lab1.Text = 5 And Lab2.Text = 4 And Lab3.Text = 6) Or (Lab1.Text = 5 And Lab2.Text = 6 And Lab3.Text = 4) Or (Lab1.Text = 6 And Lab2.Text = 4 And Lab3.Text = 5) Or (Lab1.Text = 6 And Lab2.Text = 5 And Lab3.Text = 4) Or (Lab1.Text = 7 And Lab2.Text = 8 And Lab3.Text = 9) Or (Lab1.Text = 7 And Lab2.Text = 9 And Lab3.Text = 8) Or (Lab1.Text = 8 And Lab2.Text = 7 And Lab3.Text = 9) Or (Lab1.Text = 8 And Lab2.Text = 9 And Lab3.Text = 7) Or (Lab1.Text = 9 And Lab2.Text = 7 And Lab3.Text = 8) Or (Lab1.Text = 9 And Lab2.Text = 8 And Lab3.Text = 7) Or (Lab1.Text = 1 And Lab2.Text = 4 And Lab3.Text = 7) Or (Lab1.Text = 1 And Lab2.Text = 7 And Lab3.Text = 4) Or (Lab1.Text = 4 And Lab2.Text = 1 And Lab3.Text = 7) Or (Lab1.Text = 4 And Lab2.Text = 7 And Lab3.Text = 1) Or (Lab1.Text = 7 And Lab2.Text = 1 And Lab3.Text = 4) Or (Lab1.Text = 7 And Lab2.Text = 4 And Lab3.Text = 1) Or (Lab1.Text = 2 And Lab2.Text = 5 And Lab3.Text = 8) Or (Lab1.Text = 2 And Lab2.Text = 8 And Lab3.Text = 5) Or (Lab1.Text = 5 And Lab2.Text = 2 And Lab3.Text = 8) Or (Lab1.Text = 5 And Lab2.Text = 8 And Lab3.Text = 2) Or (Lab1.Text = 8 And Lab2.Text = 2 And Lab3.Text = 5) Or (Lab1.Text = 8 And Lab2.Text = 5 And Lab3.Text = 2) Or (Lab1.Text = 3 And Lab2.Text = 6 And Lab3.Text = 9) Or (Lab1.Text = 3 And Lab2.Text = 9 And Lab3.Text = 6) Or (Lab1.Text = 6 And Lab2.Text = 3 And Lab3.Text = 9) Or (Lab1.Text = 6 And Lab2.Text = 9 And Lab3.Text = 3) Or (Lab1.Text = 9 And Lab2.Text = 3 And Lab3.Text = 6) Or (Lab1.Text = 9 And Lab2.Text = 6 And Lab3.Text = 3)) Or ((VaH.Checked = False) And ((Lab1.Text = 1 And Lab2.Text = 5 And Lab3.Text = 9) Or (Lab1.Text = 1 And Lab2.Text = 9 And Lab3.Text = 5) Or (Lab1.Text = 5 And Lab2.Text = 1 And Lab3.Text = 9) Or (Lab1.Text = 5 And Lab2.Text = 9 And Lab3.Text = 1) Or (Lab1.Text = 9 And Lab2.Text = 1 And Lab3.Text = 5) Or (Lab1.Text = 9 And Lab2.Text = 5 And Lab3.Text = 1) Or (Lab1.Text = 3 And Lab2.Text = 5 And Lab3.Text = 7) Or (Lab1.Text = 3 And Lab2.Text = 7 And Lab3.Text = 5) Or (Lab1.Text = 5 And Lab2.Text = 3 And Lab3.Text = 7) Or (Lab1.Text = 5 And Lab2.Text = 7 And Lab3.Text = 3) Or (Lab1.Text = 7 And Lab2.Text = 3 And Lab3.Text = 5) Or (Lab1.Text = 7 And Lab2.Text = 5 And Lab3.Text = 3)))) Then
                    La1.Text = 0
                    La2.Text = 0
                    La3.Text = 0
                    La4.Text = 0
                    La5.Text = 0
                    La6.Text = 0
                    Lb1.Text = Lab1.Text : Lb2.Text = Lab2.Text : Lb3.Text = Lab3.Text
                    Lb7.Text = Lab7.Text : Lb8.Text = Lab8.Text : Lb9.Text = Lab9.Text
                    L3.Text = 2
                    z1.BackgroundImage = My.Resources.zx3
                    z2.BackgroundImage = My.Resources.zx3
                    z3.BackgroundImage = My.Resources.zx3
                    c1.BackgroundImage = My.Resources.cv3
                    c2.BackgroundImage = My.Resources.cv3
                    c3.BackgroundImage = My.Resources.cv3
                    L2.Text = L22.Text
                    PB1.BackgroundImage = My.Resources.cv
                Else
                    wn2.Text = wn2.Text + 1
                    If nm2.Text = "" Then
                        If Cmpt.Checked = True Then
                            If Bu8.Text = "عربي" Then
                                MsgBox(("You won, Computer"), vbInformation, "Excellent")
                            Else
                                MsgBox(("انت فزت يا Computer"), vbInformation + vbMsgBoxRight + vbMsgBoxRtlReading, "ممتاز")
                            End If
                        Else
                            If Bu8.Text = "عربي" Then
                                MsgBox(("You won, Player2"), vbInformation, "Excellent")
                            Else
                                MsgBox(("انت فزت يا Player2"), vbInformation + vbMsgBoxRight + vbMsgBoxRtlReading, "ممتاز")
                            End If
                        End If
                        L2.Text = 1
                        L22.Text = 1
                    Else
                        If Bu8.Text = "عربي" Then
                            MsgBox(("You won, " + nm2.Text), vbInformation, "Excellent")
                        Else
                            MsgBox(("انت فزت يا " + nm2.Text), vbInformation + vbMsgBoxRight + vbMsgBoxRtlReading, "ممتاز")
                        End If
                        L2.Text = 1
                        L22.Text = 1
                    End If
                    Res(e)
                End If
            End If
        End If
    End Sub

    Private Sub VaH_CheckedChanged(sender As Object, e As EventArgs) Handles VaH.CheckedChanged
        If VaH.Checked = False Then
            Wn(e)
        End If
    End Sub

    Private Sub Bu3_Click(sender As Object, e As EventArgs) Handles Bu3.Click
        Res(e)
        wn1.Text = 0
        wn2.Text = 0
        L2.Text = 3
        L22.Text = 3
        PB1.BackgroundImage = Nothing
        nm1.Text = "Player1"
        nm2.Text = "Player2"
        Bu4.Visible = True
        VaH.Checked = True
        NoS.Checked = False
        Cmpt.Checked = False
    End Sub

    Private Sub Bu4_Click(sender As Object, e As EventArgs) Handles Bu4.Click
        If Bu4.Text = "Start" Or Bu4.Text = "إبدأ" Then
            If Bu8.Text = "عربي" Then
                Bu4.Text = "Stop"
            Else
                Bu4.Text = "توقف"
            End If
            L222.Text = 0
            PB1.BackgroundImage = My.Resources.zx
            T1.Start()
        Else
            T1.Stop()
            Bu4.Visible = False
            If Bu8.Text = "عربي" Then
                Bu4.Text = "Start"
            Else
                Bu4.Text = "إبدأ"
            End If
            L2.Text = L222.Text
            L22.Text = L222.Text
            L222.Text = 3
        End If
    End Sub

    Private Sub T1_Tick(sender As Object, e As EventArgs) Handles T1.Tick
        If L222.Text = 0 Then
            L222.Text = 1
            PB1.BackgroundImage = My.Resources.cv
        ElseIf L222.Text = 1 Then
            L222.Text = 0
            PB1.BackgroundImage = My.Resources.zx
        End If
    End Sub

    Private Sub Cmpt_CheckedChanged(sender As Object, e As EventArgs) Handles Cmpt.CheckedChanged
        If Cmpt.Checked = True Then
            If nm2.Text = "Player2" Or nm2.Text = "Player" Or nm2.Text = "" Then
                If Cmpt2.Checked = False Then
                    nm2.Text = "Computer"
                Else
                    nm2.Text = "Computer2"
                End If
            End If
            If Cmpt2.Checked = False Then
                If nm1.Text = "Player1" Or nm1.Text = "" Then
                    nm1.Text = "Player"
                End If
            End If
            T3.Start()
        Else
            If nm2.Text = "Computer" Or nm2.Text = "Computer2" Or nm2.Text = "" Then
                nm2.Text = "Player2"
            End If
            If nm1.Text = "Player" Or nm1.Text = "" Then
                nm1.Text = "Player1"
            End If
            T2.Stop()
            If Cmpt2.Checked = False Then
                T3.Stop()
            End If
        End If
    End Sub

    Private Sub T2_Tick(sender As Object, e As EventArgs) Handles T2.Tick
        T2.Stop()
        If (((Lab7.Text = 1) And (Lab8.Text = 2)) Or ((Lab8.Text = 1) And (Lab7.Text = 2))) And ((Lab4.Text = 3) Or (Lab5.Text = 3) Or (Lab6.Text = 3)) And ((La4.Text = 1) And (La5.Text = 1)) Then
            If Lab4.Text = 3 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab5.Text = 3 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab6.Text = 3 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
            End If
        ElseIf (((Lab7.Text = 1) And (Lab9.Text = 2)) Or ((Lab9.Text = 1) And (Lab7.Text = 2))) And ((Lab4.Text = 3) Or (Lab5.Text = 3) Or (Lab6.Text = 3)) And ((La4.Text = 1) And (La6.Text = 1)) Then
            If Lab4.Text = 3 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab5.Text = 3 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab6.Text = 3 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab8.Text : Lab8.Text = rt.Text
            End If
        ElseIf (((Lab8.Text = 1) And (Lab9.Text = 2)) Or ((Lab9.Text = 1) And (Lab8.Text = 2))) And ((Lab4.Text = 3) Or (Lab5.Text = 3) Or (Lab6.Text = 3)) And ((La5.Text = 1) And (La6.Text = 1)) Then
            If Lab4.Text = 3 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
            ElseIf Lab5.Text = 3 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab7.Text : Lab7.Text = rt.Text
            ElseIf Lab6.Text = 3 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab7.Text : Lab7.Text = rt.Text
            End If
        ElseIf (((Lab7.Text = 1) And (Lab8.Text = 3)) Or ((Lab8.Text = 1) And (Lab7.Text = 3))) And ((Lab4.Text = 2) Or (Lab5.Text = 2) Or (Lab6.Text = 2)) And ((La4.Text = 1) And (La5.Text = 1)) Then
            If Lab4.Text = 2 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab5.Text = 2 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab6.Text = 2 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
            End If
        ElseIf (((Lab7.Text = 1) And (Lab9.Text = 3)) Or ((Lab9.Text = 1) And (Lab7.Text = 3))) And ((Lab4.Text = 2) Or (Lab5.Text = 2) Or (Lab6.Text = 2)) And ((La4.Text = 1) And (La6.Text = 1)) Then
            If Lab4.Text = 2 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab5.Text = 2 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab6.Text = 2 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab8.Text : Lab8.Text = rt.Text
            End If
        ElseIf (((Lab8.Text = 1) And (Lab9.Text = 3)) Or ((Lab9.Text = 1) And (Lab8.Text = 3))) And ((Lab4.Text = 2) Or (Lab5.Text = 2) Or (Lab6.Text = 2)) And ((La5.Text = 1) And (La6.Text = 1)) Then
            If Lab4.Text = 2 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
            ElseIf Lab5.Text = 2 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab7.Text : Lab7.Text = rt.Text
            ElseIf Lab6.Text = 2 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab7.Text : Lab7.Text = rt.Text
            End If
        ElseIf (((Lab7.Text = 2) And (Lab8.Text = 3)) Or ((Lab8.Text = 2) And (Lab7.Text = 3))) And ((Lab4.Text = 1) Or (Lab5.Text = 1) Or (Lab6.Text = 1)) And ((La4.Text = 1) And (La5.Text = 1)) Then
            If Lab4.Text = 1 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab5.Text = 1 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab6.Text = 1 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
            End If
        ElseIf (((Lab7.Text = 2) And (Lab9.Text = 3)) Or ((Lab9.Text = 2) And (Lab7.Text = 3))) And ((Lab4.Text = 1) Or (Lab5.Text = 1) Or (Lab6.Text = 1)) And ((La4.Text = 1) And (La6.Text = 1)) Then
            If Lab4.Text = 1 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab5.Text = 1 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab6.Text = 1 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab8.Text : Lab8.Text = rt.Text
            End If
        ElseIf (((Lab8.Text = 2) And (Lab9.Text = 3)) Or ((Lab9.Text = 2) And (Lab8.Text = 3))) And ((Lab4.Text = 1) Or (Lab5.Text = 1) Or (Lab6.Text = 1)) And ((La5.Text = 1) And (La6.Text = 1)) Then
            If Lab4.Text = 1 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
            ElseIf Lab5.Text = 1 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab7.Text : Lab7.Text = rt.Text
            ElseIf Lab6.Text = 1 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab7.Text : Lab7.Text = rt.Text
            End If
        ElseIf (((Lab7.Text = 4) And (Lab8.Text = 5)) Or ((Lab8.Text = 4) And (Lab7.Text = 5))) And ((Lab4.Text = 6) Or (Lab5.Text = 6) Or (Lab6.Text = 6)) And ((La4.Text = 1) And (La5.Text = 1)) Then
            If Lab4.Text = 6 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab5.Text = 6 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab6.Text = 6 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
            End If
        ElseIf (((Lab7.Text = 4) And (Lab9.Text = 5)) Or ((Lab9.Text = 4) And (Lab7.Text = 5))) And ((Lab4.Text = 6) Or (Lab5.Text = 6) Or (Lab6.Text = 6)) And ((La4.Text = 1) And (La6.Text = 1)) Then
            If Lab4.Text = 6 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab5.Text = 6 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab6.Text = 6 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab8.Text : Lab8.Text = rt.Text
            End If
        ElseIf (((Lab8.Text = 4) And (Lab9.Text = 5)) Or ((Lab9.Text = 4) And (Lab8.Text = 5))) And ((Lab4.Text = 6) Or (Lab5.Text = 6) Or (Lab6.Text = 6)) And ((La5.Text = 1) And (La6.Text = 1)) Then
            If Lab4.Text = 6 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
            ElseIf Lab5.Text = 6 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab7.Text : Lab7.Text = rt.Text
            ElseIf Lab6.Text = 6 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab7.Text : Lab7.Text = rt.Text
            End If
        ElseIf (((Lab7.Text = 4) And (Lab8.Text = 6)) Or ((Lab8.Text = 4) And (Lab7.Text = 6))) And ((Lab4.Text = 5) Or (Lab5.Text = 5) Or (Lab6.Text = 5)) And ((La4.Text = 1) And (La5.Text = 1)) Then
            If Lab4.Text = 5 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab5.Text = 5 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab6.Text = 5 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
            End If
        ElseIf (((Lab7.Text = 4) And (Lab9.Text = 6)) Or ((Lab9.Text = 4) And (Lab7.Text = 6))) And ((Lab4.Text = 5) Or (Lab5.Text = 5) Or (Lab6.Text = 5)) And ((La4.Text = 1) And (La6.Text = 1)) Then
            If Lab4.Text = 5 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab5.Text = 5 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab6.Text = 5 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab8.Text : Lab8.Text = rt.Text
            End If
        ElseIf (((Lab8.Text = 4) And (Lab9.Text = 6)) Or ((Lab9.Text = 4) And (Lab8.Text = 6))) And ((Lab4.Text = 5) Or (Lab5.Text = 5) Or (Lab6.Text = 5)) And ((La5.Text = 1) And (La6.Text = 1)) Then
            If Lab4.Text = 5 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
            ElseIf Lab5.Text = 5 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab7.Text : Lab7.Text = rt.Text
            ElseIf Lab6.Text = 5 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab7.Text : Lab7.Text = rt.Text
            End If
        ElseIf (((Lab7.Text = 5) And (Lab8.Text = 6)) Or ((Lab8.Text = 5) And (Lab7.Text = 6))) And ((Lab4.Text = 4) Or (Lab5.Text = 4) Or (Lab6.Text = 4)) And ((La4.Text = 1) And (La5.Text = 1)) Then
            If Lab4.Text = 4 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab5.Text = 4 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab6.Text = 4 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
            End If
        ElseIf (((Lab7.Text = 5) And (Lab9.Text = 6)) Or ((Lab9.Text = 5) And (Lab7.Text = 6))) And ((Lab4.Text = 4) Or (Lab5.Text = 4) Or (Lab6.Text = 4)) And ((La4.Text = 1) And (La6.Text = 1)) Then
            If Lab4.Text = 4 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab5.Text = 4 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab6.Text = 4 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab8.Text : Lab8.Text = rt.Text
            End If
        ElseIf (((Lab8.Text = 5) And (Lab9.Text = 6)) Or ((Lab9.Text = 5) And (Lab8.Text = 6))) And ((Lab4.Text = 4) Or (Lab5.Text = 4) Or (Lab6.Text = 4)) And ((La5.Text = 1) And (La6.Text = 1)) Then
            If Lab4.Text = 4 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
            ElseIf Lab5.Text = 4 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab7.Text : Lab7.Text = rt.Text
            ElseIf Lab6.Text = 4 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab7.Text : Lab7.Text = rt.Text
            End If
        ElseIf (((Lab7.Text = 7) And (Lab8.Text = 8)) Or ((Lab8.Text = 7) And (Lab7.Text = 8))) And ((Lab4.Text = 9) Or (Lab5.Text = 9) Or (Lab6.Text = 9)) And ((La4.Text = 1) And (La5.Text = 1)) Then
            If Lab4.Text = 9 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab5.Text = 9 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab6.Text = 9 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
            End If
        ElseIf (((Lab7.Text = 7) And (Lab9.Text = 8)) Or ((Lab9.Text = 7) And (Lab7.Text = 8))) And ((Lab4.Text = 9) Or (Lab5.Text = 9) Or (Lab6.Text = 9)) And ((La4.Text = 1) And (La6.Text = 1)) Then
            If Lab4.Text = 9 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab5.Text = 9 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab6.Text = 9 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab8.Text : Lab8.Text = rt.Text
            End If
        ElseIf (((Lab8.Text = 7) And (Lab9.Text = 8)) Or ((Lab9.Text = 7) And (Lab8.Text = 8))) And ((Lab4.Text = 9) Or (Lab5.Text = 9) Or (Lab6.Text = 9)) And ((La5.Text = 1) And (La6.Text = 1)) Then
            If Lab4.Text = 9 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
            ElseIf Lab5.Text = 9 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab7.Text : Lab7.Text = rt.Text
            ElseIf Lab6.Text = 9 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab7.Text : Lab7.Text = rt.Text
            End If
        ElseIf (((Lab7.Text = 7) And (Lab8.Text = 9)) Or ((Lab8.Text = 7) And (Lab7.Text = 9))) And ((Lab4.Text = 8) Or (Lab5.Text = 8) Or (Lab6.Text = 8)) And ((La4.Text = 1) And (La5.Text = 1)) Then
            If Lab4.Text = 8 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab5.Text = 8 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab6.Text = 8 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
            End If
        ElseIf (((Lab7.Text = 7) And (Lab9.Text = 9)) Or ((Lab9.Text = 7) And (Lab7.Text = 9))) And ((Lab4.Text = 8) Or (Lab5.Text = 8) Or (Lab6.Text = 8)) And ((La4.Text = 1) And (La6.Text = 1)) Then
            If Lab4.Text = 8 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab5.Text = 8 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab6.Text = 8 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab8.Text : Lab8.Text = rt.Text
            End If
        ElseIf (((Lab8.Text = 7) And (Lab9.Text = 9)) Or ((Lab9.Text = 7) And (Lab8.Text = 9))) And ((Lab4.Text = 8) Or (Lab5.Text = 8) Or (Lab6.Text = 8)) And ((La5.Text = 1) And (La6.Text = 1)) Then
            If Lab4.Text = 8 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
            ElseIf Lab5.Text = 8 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab7.Text : Lab7.Text = rt.Text
            ElseIf Lab6.Text = 8 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab7.Text : Lab7.Text = rt.Text
            End If
        ElseIf (((Lab7.Text = 8) And (Lab8.Text = 9)) Or ((Lab8.Text = 8) And (Lab7.Text = 9))) And ((Lab4.Text = 7) Or (Lab5.Text = 7) Or (Lab6.Text = 7)) And ((La4.Text = 1) And (La5.Text = 1)) Then
            If Lab4.Text = 7 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab5.Text = 7 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab6.Text = 7 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
            End If
        ElseIf (((Lab7.Text = 8) And (Lab9.Text = 9)) Or ((Lab9.Text = 8) And (Lab7.Text = 9))) And ((Lab4.Text = 7) Or (Lab5.Text = 7) Or (Lab6.Text = 7)) And ((La4.Text = 1) And (La6.Text = 1)) Then
            If Lab4.Text = 7 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab5.Text = 7 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab6.Text = 7 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab8.Text : Lab8.Text = rt.Text
            End If
        ElseIf (((Lab8.Text = 8) And (Lab9.Text = 9)) Or ((Lab9.Text = 8) And (Lab8.Text = 9))) And ((Lab4.Text = 7) Or (Lab5.Text = 7) Or (Lab6.Text = 7)) And ((La5.Text = 1) And (La6.Text = 1)) Then
            If Lab4.Text = 7 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
            ElseIf Lab5.Text = 7 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab7.Text : Lab7.Text = rt.Text
            ElseIf Lab6.Text = 7 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab7.Text : Lab7.Text = rt.Text
            End If
        ElseIf (((Lab7.Text = 1) And (Lab8.Text = 4)) Or ((Lab8.Text = 1) And (Lab7.Text = 4))) And ((Lab4.Text = 7) Or (Lab5.Text = 7) Or (Lab6.Text = 7)) And ((La4.Text = 1) And (La5.Text = 1)) Then
            If Lab4.Text = 7 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab5.Text = 7 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab6.Text = 7 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
            End If
        ElseIf (((Lab7.Text = 1) And (Lab9.Text = 4)) Or ((Lab9.Text = 1) And (Lab7.Text = 4))) And ((Lab4.Text = 7) Or (Lab5.Text = 7) Or (Lab6.Text = 7)) And ((La4.Text = 1) And (La6.Text = 1)) Then
            If Lab4.Text = 7 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab5.Text = 7 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab6.Text = 7 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab8.Text : Lab8.Text = rt.Text
            End If
        ElseIf (((Lab8.Text = 1) And (Lab9.Text = 4)) Or ((Lab9.Text = 1) And (Lab8.Text = 4))) And ((Lab4.Text = 7) Or (Lab5.Text = 7) Or (Lab6.Text = 7)) And ((La5.Text = 1) And (La6.Text = 1)) Then
            If Lab4.Text = 7 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
            ElseIf Lab5.Text = 7 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab7.Text : Lab7.Text = rt.Text
            ElseIf Lab6.Text = 7 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab7.Text : Lab7.Text = rt.Text
            End If
        ElseIf (((Lab7.Text = 1) And (Lab8.Text = 7)) Or ((Lab8.Text = 1) And (Lab7.Text = 7))) And ((Lab4.Text = 4) Or (Lab5.Text = 4) Or (Lab6.Text = 4)) And ((La4.Text = 1) And (La5.Text = 1)) Then
            If Lab4.Text = 4 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab5.Text = 4 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab6.Text = 4 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
            End If
        ElseIf (((Lab7.Text = 1) And (Lab9.Text = 7)) Or ((Lab9.Text = 1) And (Lab7.Text = 7))) And ((Lab4.Text = 4) Or (Lab5.Text = 4) Or (Lab6.Text = 4)) And ((La4.Text = 1) And (La6.Text = 1)) Then
            If Lab4.Text = 4 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab5.Text = 4 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab6.Text = 4 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab8.Text : Lab8.Text = rt.Text
            End If
        ElseIf (((Lab8.Text = 1) And (Lab9.Text = 7)) Or ((Lab9.Text = 1) And (Lab8.Text = 7))) And ((Lab4.Text = 4) Or (Lab5.Text = 4) Or (Lab6.Text = 4)) And ((La5.Text = 1) And (La6.Text = 1)) Then
            If Lab4.Text = 4 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
            ElseIf Lab5.Text = 4 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab7.Text : Lab7.Text = rt.Text
            ElseIf Lab6.Text = 4 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab7.Text : Lab7.Text = rt.Text
            End If
        ElseIf (((Lab7.Text = 4) And (Lab8.Text = 7)) Or ((Lab8.Text = 4) And (Lab7.Text = 7))) And ((Lab4.Text = 1) Or (Lab5.Text = 1) Or (Lab6.Text = 1)) And ((La4.Text = 1) And (La5.Text = 1)) Then
            If Lab4.Text = 1 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab5.Text = 1 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab6.Text = 1 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
            End If
        ElseIf (((Lab7.Text = 4) And (Lab9.Text = 7)) Or ((Lab9.Text = 4) And (Lab7.Text = 7))) And ((Lab4.Text = 1) Or (Lab5.Text = 1) Or (Lab6.Text = 1)) And ((La4.Text = 1) And (La6.Text = 1)) Then
            If Lab4.Text = 1 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab5.Text = 1 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab6.Text = 1 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab8.Text : Lab8.Text = rt.Text
            End If
        ElseIf (((Lab8.Text = 4) And (Lab9.Text = 7)) Or ((Lab9.Text = 4) And (Lab8.Text = 7))) And ((Lab4.Text = 1) Or (Lab5.Text = 1) Or (Lab6.Text = 1)) And ((La5.Text = 1) And (La6.Text = 1)) Then
            If Lab4.Text = 1 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
            ElseIf Lab5.Text = 1 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab7.Text : Lab7.Text = rt.Text
            ElseIf Lab6.Text = 1 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab7.Text : Lab7.Text = rt.Text
            End If
        ElseIf (((Lab7.Text = 2) And (Lab8.Text = 5)) Or ((Lab8.Text = 2) And (Lab7.Text = 5))) And ((Lab4.Text = 8) Or (Lab5.Text = 8) Or (Lab6.Text = 8)) And ((La4.Text = 1) And (La5.Text = 1)) Then
            If Lab4.Text = 8 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab5.Text = 8 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab6.Text = 8 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
            End If
        ElseIf (((Lab7.Text = 2) And (Lab9.Text = 5)) Or ((Lab9.Text = 2) And (Lab7.Text = 5))) And ((Lab4.Text = 8) Or (Lab5.Text = 8) Or (Lab6.Text = 8)) And ((La4.Text = 1) And (La6.Text = 1)) Then
            If Lab4.Text = 8 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab5.Text = 8 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab6.Text = 8 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab8.Text : Lab8.Text = rt.Text
            End If
        ElseIf (((Lab8.Text = 2) And (Lab9.Text = 5)) Or ((Lab9.Text = 2) And (Lab8.Text = 5))) And ((Lab4.Text = 8) Or (Lab5.Text = 8) Or (Lab6.Text = 8)) And ((La5.Text = 1) And (La6.Text = 1)) Then
            If Lab4.Text = 8 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
            ElseIf Lab5.Text = 8 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab7.Text : Lab7.Text = rt.Text
            ElseIf Lab6.Text = 8 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab7.Text : Lab7.Text = rt.Text
            End If
        ElseIf (((Lab7.Text = 2) And (Lab8.Text = 8)) Or ((Lab8.Text = 2) And (Lab7.Text = 8))) And ((Lab4.Text = 5) Or (Lab5.Text = 5) Or (Lab6.Text = 5)) And ((La4.Text = 1) And (La5.Text = 1)) Then
            If Lab4.Text = 5 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab5.Text = 5 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab6.Text = 5 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
            End If
        ElseIf (((Lab7.Text = 2) And (Lab9.Text = 8)) Or ((Lab9.Text = 2) And (Lab7.Text = 8))) And ((Lab4.Text = 5) Or (Lab5.Text = 5) Or (Lab6.Text = 5)) And ((La4.Text = 1) And (La6.Text = 1)) Then
            If Lab4.Text = 5 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab5.Text = 5 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab6.Text = 5 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab8.Text : Lab8.Text = rt.Text
            End If
        ElseIf (((Lab8.Text = 2) And (Lab9.Text = 8)) Or ((Lab9.Text = 2) And (Lab8.Text = 8))) And ((Lab4.Text = 5) Or (Lab5.Text = 5) Or (Lab6.Text = 5)) And ((La5.Text = 1) And (La6.Text = 1)) Then
            If Lab4.Text = 5 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
            ElseIf Lab5.Text = 5 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab7.Text : Lab7.Text = rt.Text
            ElseIf Lab6.Text = 5 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab7.Text : Lab7.Text = rt.Text
            End If
        ElseIf (((Lab7.Text = 5) And (Lab8.Text = 8)) Or ((Lab8.Text = 5) And (Lab7.Text = 8))) And ((Lab4.Text = 2) Or (Lab5.Text = 2) Or (Lab6.Text = 2)) And ((La4.Text = 1) And (La5.Text = 1)) Then
            If Lab4.Text = 2 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab5.Text = 2 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab6.Text = 2 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
            End If
        ElseIf (((Lab7.Text = 5) And (Lab9.Text = 8)) Or ((Lab9.Text = 5) And (Lab7.Text = 8))) And ((Lab4.Text = 2) Or (Lab5.Text = 2) Or (Lab6.Text = 2)) And ((La4.Text = 1) And (La6.Text = 1)) Then
            If Lab4.Text = 2 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab5.Text = 2 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab6.Text = 2 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab8.Text : Lab8.Text = rt.Text
            End If
        ElseIf (((Lab8.Text = 5) And (Lab9.Text = 8)) Or ((Lab9.Text = 5) And (Lab8.Text = 8))) And ((Lab4.Text = 2) Or (Lab5.Text = 2) Or (Lab6.Text = 2)) And ((La5.Text = 1) And (La6.Text = 1)) Then
            If Lab4.Text = 2 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
            ElseIf Lab5.Text = 2 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab7.Text : Lab7.Text = rt.Text
            ElseIf Lab6.Text = 2 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab7.Text : Lab7.Text = rt.Text
            End If
        ElseIf (((Lab7.Text = 3) And (Lab8.Text = 6)) Or ((Lab8.Text = 3) And (Lab7.Text = 6))) And ((Lab4.Text = 9) Or (Lab5.Text = 9) Or (Lab6.Text = 9)) And ((La4.Text = 1) And (La5.Text = 1)) Then
            If Lab4.Text = 9 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab5.Text = 9 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab6.Text = 9 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
            End If
        ElseIf (((Lab7.Text = 3) And (Lab9.Text = 6)) Or ((Lab9.Text = 3) And (Lab7.Text = 6))) And ((Lab4.Text = 9) Or (Lab5.Text = 9) Or (Lab6.Text = 9)) And ((La4.Text = 1) And (La6.Text = 1)) Then
            If Lab4.Text = 9 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab5.Text = 9 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab6.Text = 9 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab8.Text : Lab8.Text = rt.Text
            End If
        ElseIf (((Lab8.Text = 3) And (Lab9.Text = 6)) Or ((Lab9.Text = 3) And (Lab8.Text = 6))) And ((Lab4.Text = 9) Or (Lab5.Text = 9) Or (Lab6.Text = 9)) And ((La5.Text = 1) And (La6.Text = 1)) Then
            If Lab4.Text = 9 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
            ElseIf Lab5.Text = 9 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab7.Text : Lab7.Text = rt.Text
            ElseIf Lab6.Text = 9 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab7.Text : Lab7.Text = rt.Text
            End If
        ElseIf (((Lab7.Text = 3) And (Lab8.Text = 9)) Or ((Lab8.Text = 3) And (Lab7.Text = 9))) And ((Lab4.Text = 6) Or (Lab5.Text = 6) Or (Lab6.Text = 6)) And ((La4.Text = 1) And (La5.Text = 1)) Then
            If Lab4.Text = 6 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab5.Text = 6 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab6.Text = 6 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
            End If
        ElseIf (((Lab7.Text = 3) And (Lab9.Text = 9)) Or ((Lab9.Text = 3) And (Lab7.Text = 9))) And ((Lab4.Text = 6) Or (Lab5.Text = 6) Or (Lab6.Text = 6)) And ((La4.Text = 1) And (La6.Text = 1)) Then
            If Lab4.Text = 6 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab5.Text = 6 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab6.Text = 6 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab8.Text : Lab8.Text = rt.Text
            End If
        ElseIf (((Lab8.Text = 3) And (Lab9.Text = 9)) Or ((Lab9.Text = 3) And (Lab8.Text = 9))) And ((Lab4.Text = 6) Or (Lab5.Text = 6) Or (Lab6.Text = 6)) And ((La5.Text = 1) And (La6.Text = 1)) Then
            If Lab4.Text = 6 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
            ElseIf Lab5.Text = 6 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab7.Text : Lab7.Text = rt.Text
            ElseIf Lab6.Text = 6 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab7.Text : Lab7.Text = rt.Text
            End If
        ElseIf (((Lab7.Text = 6) And (Lab8.Text = 9)) Or ((Lab8.Text = 6) And (Lab7.Text = 9))) And ((Lab4.Text = 3) Or (Lab5.Text = 3) Or (Lab6.Text = 3)) And ((La4.Text = 1) And (La5.Text = 1)) Then
            If Lab4.Text = 3 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab5.Text = 3 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab6.Text = 3 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
            End If
        ElseIf (((Lab7.Text = 6) And (Lab9.Text = 9)) Or ((Lab9.Text = 6) And (Lab7.Text = 9))) And ((Lab4.Text = 3) Or (Lab5.Text = 3) Or (Lab6.Text = 3)) And ((La4.Text = 1) And (La6.Text = 1)) Then
            If Lab4.Text = 3 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab5.Text = 3 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab6.Text = 3 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab8.Text : Lab8.Text = rt.Text
            End If
        ElseIf (((Lab8.Text = 6) And (Lab9.Text = 9)) Or ((Lab9.Text = 6) And (Lab8.Text = 9))) And ((Lab4.Text = 3) Or (Lab5.Text = 3) Or (Lab6.Text = 3)) And ((La5.Text = 1) And (La6.Text = 1)) Then
            If Lab4.Text = 3 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
            ElseIf Lab5.Text = 3 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab7.Text : Lab7.Text = rt.Text
            ElseIf Lab6.Text = 3 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab7.Text : Lab7.Text = rt.Text
            End If
        ElseIf (((Lab7.Text = 1) And (Lab8.Text = 5)) Or ((Lab8.Text = 1) And (Lab7.Text = 5))) And ((Lab4.Text = 9) Or (Lab5.Text = 9) Or (Lab6.Text = 9)) And ((La4.Text = 1) And (La5.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 9 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab5.Text = 9 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab6.Text = 9 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
            End If
        ElseIf (((Lab7.Text = 1) And (Lab9.Text = 5)) Or ((Lab9.Text = 1) And (Lab7.Text = 5))) And ((Lab4.Text = 9) Or (Lab5.Text = 9) Or (Lab6.Text = 9)) And ((La4.Text = 1) And (La6.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 9 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab5.Text = 9 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab6.Text = 9 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab8.Text : Lab8.Text = rt.Text
            End If
        ElseIf (((Lab8.Text = 1) And (Lab9.Text = 5)) Or ((Lab9.Text = 1) And (Lab8.Text = 5))) And ((Lab4.Text = 9) Or (Lab5.Text = 9) Or (Lab6.Text = 9)) And ((La5.Text = 1) And (La6.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 9 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
            ElseIf Lab5.Text = 9 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab7.Text : Lab7.Text = rt.Text
            ElseIf Lab6.Text = 9 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab7.Text : Lab7.Text = rt.Text
            End If
        ElseIf (((Lab7.Text = 1) And (Lab8.Text = 9)) Or ((Lab8.Text = 1) And (Lab7.Text = 9))) And ((Lab4.Text = 5) Or (Lab5.Text = 5) Or (Lab6.Text = 5)) And ((La4.Text = 1) And (La5.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 5 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab5.Text = 5 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab6.Text = 5 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
            End If
        ElseIf (((Lab7.Text = 1) And (Lab9.Text = 9)) Or ((Lab9.Text = 1) And (Lab7.Text = 9))) And ((Lab4.Text = 5) Or (Lab5.Text = 5) Or (Lab6.Text = 5)) And ((La4.Text = 1) And (La6.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 5 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab5.Text = 5 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab6.Text = 5 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab8.Text : Lab8.Text = rt.Text
            End If
        ElseIf (((Lab8.Text = 1) And (Lab9.Text = 9)) Or ((Lab9.Text = 1) And (Lab8.Text = 9))) And ((Lab4.Text = 5) Or (Lab5.Text = 5) Or (Lab6.Text = 5)) And ((La5.Text = 1) And (La6.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 5 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
            ElseIf Lab5.Text = 5 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab7.Text : Lab7.Text = rt.Text
            ElseIf Lab6.Text = 5 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab7.Text : Lab7.Text = rt.Text
            End If
        ElseIf (((Lab7.Text = 5) And (Lab8.Text = 9)) Or ((Lab8.Text = 5) And (Lab7.Text = 9))) And ((Lab4.Text = 1) Or (Lab5.Text = 1) Or (Lab6.Text = 1)) And ((La4.Text = 1) And (La5.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 1 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab5.Text = 1 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab6.Text = 1 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
            End If
        ElseIf (((Lab7.Text = 5) And (Lab9.Text = 9)) Or ((Lab9.Text = 5) And (Lab7.Text = 9))) And ((Lab4.Text = 1) Or (Lab5.Text = 1) Or (Lab6.Text = 1)) And ((La4.Text = 1) And (La6.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 1 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab5.Text = 1 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab6.Text = 1 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab8.Text : Lab8.Text = rt.Text
            End If
        ElseIf (((Lab8.Text = 5) And (Lab9.Text = 9)) Or ((Lab9.Text = 5) And (Lab8.Text = 9))) And ((Lab4.Text = 1) Or (Lab5.Text = 1) Or (Lab6.Text = 1)) And ((La5.Text = 1) And (La6.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 1 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
            ElseIf Lab5.Text = 1 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab7.Text : Lab7.Text = rt.Text
            ElseIf Lab6.Text = 1 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab7.Text : Lab7.Text = rt.Text
            End If
        ElseIf (((Lab7.Text = 3) And (Lab8.Text = 5)) Or ((Lab8.Text = 3) And (Lab7.Text = 5))) And ((Lab4.Text = 7) Or (Lab5.Text = 7) Or (Lab6.Text = 7)) And ((La4.Text = 1) And (La5.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 7 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab5.Text = 7 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab6.Text = 7 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
            End If
        ElseIf (((Lab7.Text = 3) And (Lab9.Text = 5)) Or ((Lab9.Text = 3) And (Lab7.Text = 5))) And ((Lab4.Text = 7) Or (Lab5.Text = 7) Or (Lab6.Text = 7)) And ((La4.Text = 1) And (La6.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 7 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab5.Text = 7 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab6.Text = 7 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab8.Text : Lab8.Text = rt.Text
            End If
        ElseIf (((Lab8.Text = 3) And (Lab9.Text = 5)) Or ((Lab9.Text = 3) And (Lab8.Text = 5))) And ((Lab4.Text = 7) Or (Lab5.Text = 7) Or (Lab6.Text = 7)) And ((La5.Text = 1) And (La6.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 7 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
            ElseIf Lab5.Text = 7 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab7.Text : Lab7.Text = rt.Text
            ElseIf Lab6.Text = 7 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab7.Text : Lab7.Text = rt.Text
            End If
        ElseIf (((Lab7.Text = 3) And (Lab8.Text = 7)) Or ((Lab8.Text = 3) And (Lab7.Text = 7))) And ((Lab4.Text = 5) Or (Lab5.Text = 5) Or (Lab6.Text = 5)) And ((La4.Text = 1) And (La5.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 5 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab5.Text = 5 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab6.Text = 5 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
            End If
        ElseIf (((Lab7.Text = 3) And (Lab9.Text = 7)) Or ((Lab9.Text = 3) And (Lab7.Text = 7))) And ((Lab4.Text = 5) Or (Lab5.Text = 5) Or (Lab6.Text = 5)) And ((La4.Text = 1) And (La6.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 5 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab5.Text = 5 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab6.Text = 5 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab8.Text : Lab8.Text = rt.Text
            End If
        ElseIf (((Lab8.Text = 3) And (Lab9.Text = 7)) Or ((Lab9.Text = 3) And (Lab8.Text = 7))) And ((Lab4.Text = 5) Or (Lab5.Text = 5) Or (Lab6.Text = 5)) And ((La5.Text = 1) And (La6.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 5 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
            ElseIf Lab5.Text = 5 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab7.Text : Lab7.Text = rt.Text
            ElseIf Lab6.Text = 5 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab7.Text : Lab7.Text = rt.Text
            End If
        ElseIf (((Lab7.Text = 5) And (Lab8.Text = 7)) Or ((Lab8.Text = 5) And (Lab7.Text = 7))) And ((Lab4.Text = 3) Or (Lab5.Text = 3) Or (Lab6.Text = 3)) And ((La4.Text = 1) And (La5.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 3 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab5.Text = 3 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab6.Text = 3 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
            End If
        ElseIf (((Lab7.Text = 5) And (Lab9.Text = 7)) Or ((Lab9.Text = 5) And (Lab7.Text = 7))) And ((Lab4.Text = 3) Or (Lab5.Text = 3) Or (Lab6.Text = 3)) And ((La4.Text = 1) And (La6.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 3 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab5.Text = 3 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab6.Text = 3 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab8.Text : Lab8.Text = rt.Text
            End If
        ElseIf (((Lab8.Text = 5) And (Lab9.Text = 7)) Or ((Lab9.Text = 5) And (Lab8.Text = 7))) And ((Lab4.Text = 3) Or (Lab5.Text = 3) Or (Lab6.Text = 3)) And ((La5.Text = 1) And (La6.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 3 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
            ElseIf Lab5.Text = 3 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab7.Text : Lab7.Text = rt.Text
            ElseIf Lab6.Text = 3 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab7.Text : Lab7.Text = rt.Text
            End If

        ElseIf (((((Lab1.Text = 1) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 1))) And ((La1.Text = 1) And (La2.Text = 1))) Or ((((Lab1.Text = 1) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 1))) And ((La1.Text = 1) And (La3.Text = 1))) Or ((((Lab2.Text = 1) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 1))) And ((La2.Text = 1) And (La3.Text = 1)))) And ((Lab4.Text = 3) Or (Lab5.Text = 3) Or (Lab6.Text = 3)) Then
            If Lab4.Text = 3 Then
                If ((((Lab1.Text = 2) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 2))) And ((Lab7.Text = 8) Or (Lab7.Text = 5))) Or ((((Lab1.Text = 1) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 1)) Or ((Lab1.Text = 1) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 1))) And ((Lab7.Text = 7) Or (Lab7.Text = 4))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
                ElseIf ((((Lab1.Text = 2) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 2))) And ((Lab8.Text = 8) Or (Lab8.Text = 5))) Or ((((Lab1.Text = 1) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 1)) Or ((Lab1.Text = 1) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 1))) And ((Lab8.Text = 7) Or (Lab8.Text = 4))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
                ElseIf ((((Lab1.Text = 2) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 2))) And ((Lab9.Text = 8) Or (Lab9.Text = 5))) Or ((((Lab1.Text = 1) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 1)) Or ((Lab1.Text = 1) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 1))) And ((Lab9.Text = 7) Or (Lab9.Text = 4))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
                End If
            ElseIf Lab5.Text = 3 Then
                If ((((Lab1.Text = 2) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 2))) And ((Lab7.Text = 8) Or (Lab7.Text = 5))) Or ((((Lab1.Text = 1) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 1)) Or ((Lab1.Text = 1) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 1))) And ((Lab7.Text = 7) Or (Lab7.Text = 4))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab8.Text : Lab8.Text = rt.Text
                ElseIf ((((Lab1.Text = 2) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 2))) And ((Lab8.Text = 8) Or (Lab8.Text = 5))) Or ((((Lab1.Text = 1) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 1)) Or ((Lab1.Text = 1) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 1))) And ((Lab8.Text = 7) Or (Lab8.Text = 4))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
                ElseIf ((((Lab1.Text = 2) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 2))) And ((Lab9.Text = 8) Or (Lab9.Text = 5))) Or ((((Lab1.Text = 1) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 1)) Or ((Lab1.Text = 1) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 1))) And ((Lab9.Text = 7) Or (Lab9.Text = 4))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab7.Text : Lab7.Text = rt.Text
                Else
                    rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
                End If
            ElseIf Lab6.Text = 3 Then
                If ((((Lab1.Text = 2) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 2))) And ((Lab7.Text = 8) Or (Lab7.Text = 5))) Or ((((Lab1.Text = 1) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 1)) Or ((Lab1.Text = 1) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 1))) And ((Lab7.Text = 7) Or (Lab7.Text = 4))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab8.Text : Lab8.Text = rt.Text
                ElseIf ((((Lab1.Text = 2) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 2))) And ((Lab8.Text = 8) Or (Lab8.Text = 5))) Or ((((Lab1.Text = 1) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 1)) Or ((Lab1.Text = 1) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 1))) And ((Lab8.Text = 7) Or (Lab8.Text = 4))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
                ElseIf ((((Lab1.Text = 2) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 2))) And ((Lab9.Text = 8) Or (Lab9.Text = 5))) Or ((((Lab1.Text = 1) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 1)) Or ((Lab1.Text = 1) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 1))) And ((Lab9.Text = 7) Or (Lab9.Text = 4))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab7.Text : Lab7.Text = rt.Text
                Else
                    rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
                End If
            End If
        ElseIf (((((Lab1.Text = 1) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 1))) And ((La1.Text = 1) And (La2.Text = 1))) Or ((((Lab1.Text = 1) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 1))) And ((La1.Text = 1) And (La3.Text = 1))) Or ((((Lab2.Text = 1) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 1))) And ((La2.Text = 1) And (La3.Text = 1)))) And ((Lab4.Text = 2) Or (Lab5.Text = 2) Or (Lab6.Text = 2)) Then
            If Lab4.Text = 2 Then
                If ((((Lab1.Text = 3) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 3))) And ((Lab7.Text = 9) Or (Lab7.Text = 6))) Or ((((Lab1.Text = 1) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 1)) Or ((Lab1.Text = 1) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 1))) And ((Lab7.Text = 7) Or (Lab7.Text = 4))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
                ElseIf ((((Lab1.Text = 3) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 3))) And ((Lab8.Text = 9) Or (Lab8.Text = 6))) Or ((((Lab1.Text = 1) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 1)) Or ((Lab1.Text = 1) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 1))) And ((Lab8.Text = 7) Or (Lab8.Text = 4))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
                ElseIf ((((Lab1.Text = 3) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 3))) And ((Lab9.Text = 9) Or (Lab9.Text = 6))) Or ((((Lab1.Text = 1) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 1)) Or ((Lab1.Text = 1) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 1))) And ((Lab9.Text = 7) Or (Lab9.Text = 4))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
                End If
            ElseIf Lab5.Text = 2 Then
                If ((((Lab1.Text = 3) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 3))) And ((Lab7.Text = 9) Or (Lab7.Text = 6))) Or ((((Lab1.Text = 1) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 1)) Or ((Lab1.Text = 1) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 1))) And ((Lab7.Text = 7) Or (Lab7.Text = 4))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab8.Text : Lab8.Text = rt.Text
                ElseIf ((((Lab1.Text = 3) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 3))) And ((Lab8.Text = 9) Or (Lab8.Text = 6))) Or ((((Lab1.Text = 1) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 1)) Or ((Lab1.Text = 1) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 1))) And ((Lab8.Text = 7) Or (Lab8.Text = 4))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
                ElseIf ((((Lab1.Text = 3) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 3))) And ((Lab9.Text = 9) Or (Lab9.Text = 6))) Or ((((Lab1.Text = 1) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 1)) Or ((Lab1.Text = 1) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 1))) And ((Lab9.Text = 7) Or (Lab9.Text = 4))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab7.Text : Lab7.Text = rt.Text
                Else
                    rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
                End If
            ElseIf Lab6.Text = 2 Then
                If ((((Lab1.Text = 3) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 3))) And ((Lab7.Text = 9) Or (Lab7.Text = 6))) Or ((((Lab1.Text = 1) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 1)) Or ((Lab1.Text = 1) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 1))) And ((Lab7.Text = 7) Or (Lab7.Text = 4))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab8.Text : Lab8.Text = rt.Text
                ElseIf ((((Lab1.Text = 3) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 3))) And ((Lab8.Text = 9) Or (Lab8.Text = 6))) Or ((((Lab1.Text = 1) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 1)) Or ((Lab1.Text = 1) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 1))) And ((Lab8.Text = 7) Or (Lab8.Text = 4))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
                ElseIf ((((Lab1.Text = 3) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 3))) And ((Lab9.Text = 9) Or (Lab9.Text = 6))) Or ((((Lab1.Text = 1) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 1)) Or ((Lab1.Text = 1) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 1))) And ((Lab9.Text = 7) Or (Lab9.Text = 4))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab7.Text : Lab7.Text = rt.Text
                Else
                    rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
                End If
            End If
        ElseIf (((((Lab1.Text = 2) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 2))) And ((La1.Text = 1) And (La2.Text = 1))) Or ((((Lab1.Text = 2) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 2))) And ((La1.Text = 1) And (La3.Text = 1))) Or ((((Lab2.Text = 2) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 2))) And ((La2.Text = 1) And (La3.Text = 1)))) And ((Lab4.Text = 1) Or (Lab5.Text = 1) Or (Lab6.Text = 1)) Then
            If Lab4.Text = 1 Then
                If ((((Lab1.Text = 3) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 3))) And ((Lab7.Text = 9) Or (Lab7.Text = 6))) Or ((((Lab1.Text = 2) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 2))) And ((Lab7.Text = 8) Or (Lab7.Text = 5))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
                ElseIf ((((Lab1.Text = 3) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 3))) And ((Lab8.Text = 9) Or (Lab8.Text = 6))) Or ((((Lab1.Text = 2) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 2))) And ((Lab8.Text = 8) Or (Lab8.Text = 5))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
                ElseIf ((((Lab1.Text = 3) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 3))) And ((Lab9.Text = 9) Or (Lab9.Text = 6))) Or ((((Lab1.Text = 2) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 2))) And ((Lab9.Text = 8) Or (Lab9.Text = 5))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
                End If
            ElseIf Lab5.Text = 1 Then
                If ((((Lab1.Text = 3) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 3))) And ((Lab7.Text = 9) Or (Lab7.Text = 6))) Or ((((Lab1.Text = 2) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 2))) And ((Lab7.Text = 8) Or (Lab7.Text = 5))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab8.Text : Lab8.Text = rt.Text
                ElseIf ((((Lab1.Text = 3) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 3))) And ((Lab8.Text = 9) Or (Lab8.Text = 6))) Or ((((Lab1.Text = 2) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 2))) And ((Lab8.Text = 8) Or (Lab8.Text = 5))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
                ElseIf ((((Lab1.Text = 3) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 3))) And ((Lab9.Text = 9) Or (Lab9.Text = 6))) Or ((((Lab1.Text = 2) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 2))) And ((Lab9.Text = 8) Or (Lab9.Text = 5))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab7.Text : Lab7.Text = rt.Text
                Else
                    rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
                End If
            ElseIf Lab6.Text = 1 Then
                If ((((Lab1.Text = 3) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 3))) And ((Lab7.Text = 9) Or (Lab7.Text = 6))) Or ((((Lab1.Text = 2) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 2))) And ((Lab7.Text = 8) Or (Lab7.Text = 5))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab8.Text : Lab8.Text = rt.Text
                ElseIf ((((Lab1.Text = 3) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 3))) And ((Lab8.Text = 9) Or (Lab8.Text = 6))) Or ((((Lab1.Text = 2) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 2))) And ((Lab8.Text = 8) Or (Lab8.Text = 5))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
                ElseIf ((((Lab1.Text = 3) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 3))) And ((Lab9.Text = 9) Or (Lab9.Text = 6))) Or ((((Lab1.Text = 2) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 2))) And ((Lab9.Text = 8) Or (Lab9.Text = 5))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab7.Text : Lab7.Text = rt.Text
                Else
                    rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
                End If
            End If
        ElseIf (((((Lab1.Text = 4) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 4))) And ((La1.Text = 1) And (La2.Text = 1))) Or ((((Lab1.Text = 4) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 4))) And ((La1.Text = 1) And (La3.Text = 1))) Or ((((Lab2.Text = 4) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 4))) And ((La2.Text = 1) And (La3.Text = 1)))) And ((Lab4.Text = 6) Or (Lab5.Text = 6) Or (Lab6.Text = 6)) Then
            If Lab4.Text = 6 Then
                If ((((Lab1.Text = 2) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 2)) Or ((Lab1.Text = 5) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 5))) And ((Lab7.Text = 8) Or (Lab7.Text = 2))) Or ((((Lab1.Text = 1) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 1)) Or ((Lab1.Text = 4) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 4))) And ((Lab7.Text = 7) Or (Lab7.Text = 1))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
                ElseIf ((((Lab1.Text = 2) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 2)) Or ((Lab1.Text = 5) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 5))) And ((Lab8.Text = 8) Or (Lab8.Text = 2))) Or ((((Lab1.Text = 1) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 1)) Or ((Lab1.Text = 4) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 4))) And ((Lab8.Text = 7) Or (Lab8.Text = 1))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
                ElseIf ((((Lab1.Text = 2) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 2)) Or ((Lab1.Text = 5) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 5))) And ((Lab9.Text = 8) Or (Lab9.Text = 2))) Or ((((Lab1.Text = 1) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 1)) Or ((Lab1.Text = 4) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 4))) And ((Lab9.Text = 7) Or (Lab9.Text = 1))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
                End If
            ElseIf Lab5.Text = 6 Then
                If ((((Lab1.Text = 2) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 2)) Or ((Lab1.Text = 5) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 5))) And ((Lab7.Text = 8) Or (Lab7.Text = 2))) Or ((((Lab1.Text = 1) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 1)) Or ((Lab1.Text = 4) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 4))) And ((Lab7.Text = 7) Or (Lab7.Text = 1))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab8.Text : Lab8.Text = rt.Text
                ElseIf ((((Lab1.Text = 2) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 2)) Or ((Lab1.Text = 5) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 5))) And ((Lab8.Text = 8) Or (Lab8.Text = 2))) Or ((((Lab1.Text = 1) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 1)) Or ((Lab1.Text = 4) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 4))) And ((Lab8.Text = 7) Or (Lab8.Text = 1))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
                ElseIf ((((Lab1.Text = 2) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 2)) Or ((Lab1.Text = 5) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 5))) And ((Lab9.Text = 8) Or (Lab9.Text = 2))) Or ((((Lab1.Text = 1) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 1)) Or ((Lab1.Text = 4) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 4))) And ((Lab9.Text = 7) Or (Lab9.Text = 1))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab7.Text : Lab7.Text = rt.Text
                Else
                    rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
                End If
            ElseIf Lab6.Text = 6 Then
                If ((((Lab1.Text = 2) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 2)) Or ((Lab1.Text = 5) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 5))) And ((Lab7.Text = 8) Or (Lab7.Text = 2))) Or ((((Lab1.Text = 1) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 1)) Or ((Lab1.Text = 4) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 4))) And ((Lab7.Text = 7) Or (Lab7.Text = 1))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab8.Text : Lab8.Text = rt.Text
                ElseIf ((((Lab1.Text = 2) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 2)) Or ((Lab1.Text = 5) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 5))) And ((Lab8.Text = 8) Or (Lab8.Text = 2))) Or ((((Lab1.Text = 1) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 1)) Or ((Lab1.Text = 4) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 4))) And ((Lab8.Text = 7) Or (Lab8.Text = 1))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
                ElseIf ((((Lab1.Text = 2) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 2)) Or ((Lab1.Text = 5) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 5))) And ((Lab9.Text = 8) Or (Lab9.Text = 2))) Or ((((Lab1.Text = 1) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 1)) Or ((Lab1.Text = 4) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 4))) And ((Lab9.Text = 7) Or (Lab9.Text = 1))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab7.Text : Lab7.Text = rt.Text
                Else
                    rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
                End If
            End If
        ElseIf (((((Lab1.Text = 4) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 4))) And ((La1.Text = 1) And (La2.Text = 1))) Or ((((Lab1.Text = 4) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 4))) And ((La1.Text = 1) And (La3.Text = 1))) Or ((((Lab2.Text = 4) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 4))) And ((La2.Text = 1) And (La3.Text = 1)))) And ((Lab4.Text = 5) Or (Lab5.Text = 5) Or (Lab6.Text = 5)) Then
            If Lab4.Text = 5 Then
                If ((((Lab1.Text = 1) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 1)) Or ((Lab1.Text = 4) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 4))) And ((Lab7.Text = 7) Or (Lab7.Text = 1))) Or ((((Lab1.Text = 3) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 3)) Or ((Lab1.Text = 6) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 6))) And ((Lab7.Text = 9) Or (Lab7.Text = 3))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
                ElseIf ((((Lab1.Text = 1) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 1)) Or ((Lab1.Text = 4) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 4))) And ((Lab8.Text = 7) Or (Lab8.Text = 1))) Or ((((Lab1.Text = 3) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 3)) Or ((Lab1.Text = 6) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 6))) And ((Lab8.Text = 9) Or (Lab8.Text = 3))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
                ElseIf ((((Lab1.Text = 1) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 1)) Or ((Lab1.Text = 4) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 4))) And ((Lab9.Text = 7) Or (Lab9.Text = 1))) Or ((((Lab1.Text = 3) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 3)) Or ((Lab1.Text = 6) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 6))) And ((Lab9.Text = 9) Or (Lab9.Text = 3))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
                End If
            ElseIf Lab5.Text = 5 Then
                If ((((Lab1.Text = 1) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 1)) Or ((Lab1.Text = 4) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 4))) And ((Lab7.Text = 7) Or (Lab7.Text = 1))) Or ((((Lab1.Text = 3) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 3)) Or ((Lab1.Text = 6) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 6))) And ((Lab7.Text = 9) Or (Lab7.Text = 3))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab8.Text : Lab8.Text = rt.Text
                ElseIf ((((Lab1.Text = 1) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 1)) Or ((Lab1.Text = 4) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 4))) And ((Lab8.Text = 7) Or (Lab8.Text = 1))) Or ((((Lab1.Text = 3) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 3)) Or ((Lab1.Text = 6) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 6))) And ((Lab8.Text = 9) Or (Lab8.Text = 3))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
                ElseIf ((((Lab1.Text = 1) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 1)) Or ((Lab1.Text = 4) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 4))) And ((Lab9.Text = 7) Or (Lab9.Text = 1))) Or ((((Lab1.Text = 3) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 3)) Or ((Lab1.Text = 6) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 6))) And ((Lab9.Text = 9) Or (Lab9.Text = 3))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab7.Text : Lab7.Text = rt.Text
                Else
                    rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
                End If
            ElseIf Lab6.Text = 5 Then
                If ((((Lab1.Text = 1) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 1)) Or ((Lab1.Text = 4) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 4))) And ((Lab7.Text = 7) Or (Lab7.Text = 1))) Or ((((Lab1.Text = 3) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 3)) Or ((Lab1.Text = 6) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 6))) And ((Lab7.Text = 9) Or (Lab7.Text = 3))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab8.Text : Lab8.Text = rt.Text
                ElseIf ((((Lab1.Text = 1) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 1)) Or ((Lab1.Text = 4) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 4))) And ((Lab8.Text = 7) Or (Lab8.Text = 1))) Or ((((Lab1.Text = 3) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 3)) Or ((Lab1.Text = 6) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 6))) And ((Lab8.Text = 9) Or (Lab8.Text = 3))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
                ElseIf ((((Lab1.Text = 1) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 1)) Or ((Lab1.Text = 4) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 4))) And ((Lab9.Text = 7) Or (Lab9.Text = 1))) Or ((((Lab1.Text = 3) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 3)) Or ((Lab1.Text = 6) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 6))) And ((Lab9.Text = 9) Or (Lab9.Text = 3))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab7.Text : Lab7.Text = rt.Text
                Else
                    rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
                End If
            End If
        ElseIf (((((Lab1.Text = 5) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 5))) And ((La1.Text = 1) And (La2.Text = 1))) Or ((((Lab1.Text = 5) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 5))) And ((La1.Text = 1) And (La3.Text = 1))) Or ((((Lab2.Text = 5) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 5))) And ((La2.Text = 1) And (La3.Text = 1)))) And ((Lab4.Text = 4) Or (Lab5.Text = 4) Or (Lab6.Text = 4)) Then
            If Lab4.Text = 4 Then
                If ((((Lab1.Text = 2) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 2)) Or ((Lab1.Text = 5) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 5))) And ((Lab7.Text = 8) Or (Lab7.Text = 2))) Or ((((Lab1.Text = 3) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 3)) Or ((Lab1.Text = 6) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 6))) And ((Lab7.Text = 9) Or (Lab7.Text = 3))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
                ElseIf ((((Lab1.Text = 2) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 2)) Or ((Lab1.Text = 5) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 5))) And ((Lab8.Text = 8) Or (Lab8.Text = 2))) Or ((((Lab1.Text = 3) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 3)) Or ((Lab1.Text = 6) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 6))) And ((Lab8.Text = 9) Or (Lab8.Text = 3))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
                ElseIf ((((Lab1.Text = 2) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 2)) Or ((Lab1.Text = 5) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 5))) And ((Lab9.Text = 8) Or (Lab9.Text = 2))) Or ((((Lab1.Text = 3) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 3)) Or ((Lab1.Text = 6) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 6))) And ((Lab9.Text = 9) Or (Lab9.Text = 3))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
                End If
            ElseIf Lab5.Text = 4 Then
                If ((((Lab1.Text = 2) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 2)) Or ((Lab1.Text = 5) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 5))) And ((Lab7.Text = 8) Or (Lab7.Text = 2))) Or ((((Lab1.Text = 3) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 3)) Or ((Lab1.Text = 6) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 6))) And ((Lab7.Text = 9) Or (Lab7.Text = 3))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab8.Text : Lab8.Text = rt.Text
                ElseIf ((((Lab1.Text = 2) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 2)) Or ((Lab1.Text = 5) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 5))) And ((Lab8.Text = 8) Or (Lab8.Text = 2))) Or ((((Lab1.Text = 3) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 3)) Or ((Lab1.Text = 6) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 6))) And ((Lab8.Text = 9) Or (Lab8.Text = 3))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
                ElseIf ((((Lab1.Text = 2) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 2)) Or ((Lab1.Text = 5) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 5))) And ((Lab9.Text = 8) Or (Lab9.Text = 2))) Or ((((Lab1.Text = 3) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 3)) Or ((Lab1.Text = 6) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 6))) And ((Lab9.Text = 9) Or (Lab9.Text = 3))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab7.Text : Lab7.Text = rt.Text
                Else
                    rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
                End If
            ElseIf Lab6.Text = 4 Then
                If ((((Lab1.Text = 2) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 2)) Or ((Lab1.Text = 5) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 5))) And ((Lab7.Text = 8) Or (Lab7.Text = 2))) Or ((((Lab1.Text = 3) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 3)) Or ((Lab1.Text = 6) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 6))) And ((Lab7.Text = 9) Or (Lab7.Text = 3))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab8.Text : Lab8.Text = rt.Text
                ElseIf ((((Lab1.Text = 2) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 2)) Or ((Lab1.Text = 5) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 5))) And ((Lab8.Text = 8) Or (Lab8.Text = 2))) Or ((((Lab1.Text = 3) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 3)) Or ((Lab1.Text = 6) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 6))) And ((Lab8.Text = 9) Or (Lab8.Text = 3))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
                ElseIf ((((Lab1.Text = 2) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 2)) Or ((Lab1.Text = 5) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 5))) And ((Lab9.Text = 8) Or (Lab9.Text = 2))) Or ((((Lab1.Text = 3) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 3)) Or ((Lab1.Text = 6) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 6))) And ((Lab9.Text = 9) Or (Lab9.Text = 3))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab7.Text : Lab7.Text = rt.Text
                Else
                    rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
                End If
            End If
        ElseIf (((((Lab1.Text = 7) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 7))) And ((La1.Text = 1) And (La2.Text = 1))) Or ((((Lab1.Text = 7) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 7))) And ((La1.Text = 1) And (La3.Text = 1))) Or ((((Lab2.Text = 7) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 7))) And ((La2.Text = 1) And (La3.Text = 1)))) And ((Lab4.Text = 9) Or (Lab5.Text = 9) Or (Lab6.Text = 9)) Then
            If Lab4.Text = 9 Then
                If ((((Lab1.Text = 2) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 2)) Or ((Lab1.Text = 5) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 5))) And ((Lab7.Text = 5) Or (Lab7.Text = 2))) Or ((((Lab1.Text = 1) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 1)) Or ((Lab1.Text = 4) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 4))) And ((Lab7.Text = 4) Or (Lab7.Text = 1))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
                ElseIf ((((Lab1.Text = 2) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 2)) Or ((Lab1.Text = 5) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 5))) And ((Lab8.Text = 5) Or (Lab8.Text = 2))) Or ((((Lab1.Text = 1) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 1)) Or ((Lab1.Text = 4) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 4))) And ((Lab8.Text = 4) Or (Lab8.Text = 1))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
                ElseIf ((((Lab1.Text = 2) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 2)) Or ((Lab1.Text = 5) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 5))) And ((Lab9.Text = 5) Or (Lab9.Text = 2))) Or ((((Lab1.Text = 1) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 1)) Or ((Lab1.Text = 4) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 4))) And ((Lab9.Text = 4) Or (Lab9.Text = 1))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
                End If
            ElseIf Lab5.Text = 9 Then
                If ((((Lab1.Text = 2) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 2)) Or ((Lab1.Text = 5) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 5))) And ((Lab7.Text = 5) Or (Lab7.Text = 2))) Or ((((Lab1.Text = 1) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 1)) Or ((Lab1.Text = 4) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 4))) And ((Lab7.Text = 4) Or (Lab7.Text = 1))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab8.Text : Lab8.Text = rt.Text
                ElseIf ((((Lab1.Text = 2) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 2)) Or ((Lab1.Text = 5) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 5))) And ((Lab8.Text = 5) Or (Lab8.Text = 2))) Or ((((Lab1.Text = 1) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 1)) Or ((Lab1.Text = 4) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 4))) And ((Lab8.Text = 4) Or (Lab8.Text = 1))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
                ElseIf ((((Lab1.Text = 2) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 2)) Or ((Lab1.Text = 5) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 5))) And ((Lab9.Text = 5) Or (Lab9.Text = 2))) Or ((((Lab1.Text = 1) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 1)) Or ((Lab1.Text = 4) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 4))) And ((Lab9.Text = 4) Or (Lab9.Text = 1))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab7.Text : Lab7.Text = rt.Text
                Else
                    rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
                End If
            ElseIf Lab6.Text = 9 Then
                If ((((Lab1.Text = 2) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 2)) Or ((Lab1.Text = 5) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 5))) And ((Lab7.Text = 5) Or (Lab7.Text = 2))) Or ((((Lab1.Text = 1) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 1)) Or ((Lab1.Text = 4) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 4))) And ((Lab7.Text = 4) Or (Lab7.Text = 1))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab8.Text : Lab8.Text = rt.Text
                ElseIf ((((Lab1.Text = 2) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 2)) Or ((Lab1.Text = 5) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 5))) And ((Lab8.Text = 5) Or (Lab8.Text = 2))) Or ((((Lab1.Text = 1) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 1)) Or ((Lab1.Text = 4) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 4))) And ((Lab8.Text = 4) Or (Lab8.Text = 1))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
                ElseIf ((((Lab1.Text = 2) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 2)) Or ((Lab1.Text = 5) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 5))) And ((Lab9.Text = 5) Or (Lab9.Text = 2))) Or ((((Lab1.Text = 1) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 1)) Or ((Lab1.Text = 4) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 4))) And ((Lab9.Text = 4) Or (Lab9.Text = 1))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab7.Text : Lab7.Text = rt.Text
                Else
                    rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
                End If
            End If
        ElseIf (((((Lab1.Text = 7) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 7))) And ((La1.Text = 1) And (La2.Text = 1))) Or ((((Lab1.Text = 7) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 7))) And ((La1.Text = 1) And (La3.Text = 1))) Or ((((Lab2.Text = 7) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 7))) And ((La2.Text = 1) And (La3.Text = 1)))) And ((Lab4.Text = 8) Or (Lab5.Text = 8) Or (Lab6.Text = 8)) Then
            If Lab4.Text = 8 Then
                If ((((Lab1.Text = 3) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 3)) Or ((Lab1.Text = 6) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 6))) And ((Lab7.Text = 6) Or (Lab7.Text = 3))) Or ((((Lab1.Text = 1) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 1)) Or ((Lab1.Text = 4) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 4))) And ((Lab7.Text = 4) Or (Lab7.Text = 1))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
                ElseIf ((((Lab1.Text = 3) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 3)) Or ((Lab1.Text = 6) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 6))) And ((Lab8.Text = 6) Or (Lab8.Text = 3))) Or ((((Lab1.Text = 1) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 1)) Or ((Lab1.Text = 4) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 4))) And ((Lab8.Text = 4) Or (Lab8.Text = 1))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
                ElseIf ((((Lab1.Text = 3) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 3)) Or ((Lab1.Text = 6) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 6))) And ((Lab9.Text = 6) Or (Lab9.Text = 3))) Or ((((Lab1.Text = 1) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 1)) Or ((Lab1.Text = 4) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 4))) And ((Lab9.Text = 4) Or (Lab9.Text = 1))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
                End If
            ElseIf Lab5.Text = 8 Then
                If ((((Lab1.Text = 3) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 3)) Or ((Lab1.Text = 6) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 6))) And ((Lab7.Text = 6) Or (Lab7.Text = 3))) Or ((((Lab1.Text = 1) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 1)) Or ((Lab1.Text = 4) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 4))) And ((Lab7.Text = 4) Or (Lab7.Text = 1))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab8.Text : Lab8.Text = rt.Text
                ElseIf ((((Lab1.Text = 3) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 3)) Or ((Lab1.Text = 6) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 6))) And ((Lab8.Text = 6) Or (Lab8.Text = 3))) Or ((((Lab1.Text = 1) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 1)) Or ((Lab1.Text = 4) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 4))) And ((Lab8.Text = 4) Or (Lab8.Text = 1))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
                ElseIf ((((Lab1.Text = 3) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 3)) Or ((Lab1.Text = 6) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 6))) And ((Lab9.Text = 6) Or (Lab9.Text = 3))) Or ((((Lab1.Text = 1) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 1)) Or ((Lab1.Text = 4) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 4))) And ((Lab9.Text = 4) Or (Lab9.Text = 1))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab7.Text : Lab7.Text = rt.Text
                Else
                    rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
                End If
            ElseIf Lab6.Text = 8 Then
                If ((((Lab1.Text = 3) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 3)) Or ((Lab1.Text = 6) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 6))) And ((Lab7.Text = 6) Or (Lab7.Text = 3))) Or ((((Lab1.Text = 1) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 1)) Or ((Lab1.Text = 4) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 4))) And ((Lab7.Text = 4) Or (Lab7.Text = 1))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab8.Text : Lab8.Text = rt.Text
                ElseIf ((((Lab1.Text = 3) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 3)) Or ((Lab1.Text = 6) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 6))) And ((Lab8.Text = 6) Or (Lab8.Text = 3))) Or ((((Lab1.Text = 1) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 1)) Or ((Lab1.Text = 4) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 4))) And ((Lab8.Text = 4) Or (Lab8.Text = 1))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
                ElseIf ((((Lab1.Text = 3) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 3)) Or ((Lab1.Text = 6) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 6))) And ((Lab9.Text = 6) Or (Lab9.Text = 3))) Or ((((Lab1.Text = 1) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 1)) Or ((Lab1.Text = 4) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 4))) And ((Lab9.Text = 4) Or (Lab9.Text = 1))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab7.Text : Lab7.Text = rt.Text
                Else
                    rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
                End If
            End If
        ElseIf (((((Lab1.Text = 8) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 8))) And ((La1.Text = 1) And (La2.Text = 1))) Or ((((Lab1.Text = 8) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 8))) And ((La1.Text = 1) And (La3.Text = 1))) Or ((((Lab2.Text = 8) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 8))) And ((La2.Text = 1) And (La3.Text = 1)))) And ((Lab4.Text = 7) Or (Lab5.Text = 7) Or (Lab6.Text = 7)) Then
            If Lab4.Text = 7 Then
                If ((((Lab1.Text = 3) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 3)) Or ((Lab1.Text = 6) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 6))) And ((Lab7.Text = 6) Or (Lab7.Text = 3))) Or ((((Lab1.Text = 2) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 2)) Or ((Lab1.Text = 5) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 5))) And ((Lab7.Text = 5) Or (Lab7.Text = 2))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
                ElseIf ((((Lab1.Text = 3) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 3)) Or ((Lab1.Text = 6) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 6))) And ((Lab8.Text = 6) Or (Lab8.Text = 3))) Or ((((Lab1.Text = 2) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 2)) Or ((Lab1.Text = 5) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 5))) And ((Lab8.Text = 5) Or (Lab8.Text = 2))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
                ElseIf ((((Lab1.Text = 3) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 3)) Or ((Lab1.Text = 6) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 6))) And ((Lab9.Text = 6) Or (Lab9.Text = 3))) Or ((((Lab1.Text = 2) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 2)) Or ((Lab1.Text = 5) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 5))) And ((Lab9.Text = 5) Or (Lab9.Text = 2))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
                End If
            ElseIf Lab5.Text = 7 Then
                If ((((Lab1.Text = 3) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 3)) Or ((Lab1.Text = 6) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 6))) And ((Lab7.Text = 6) Or (Lab7.Text = 3))) Or ((((Lab1.Text = 2) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 2)) Or ((Lab1.Text = 5) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 5))) And ((Lab7.Text = 5) Or (Lab7.Text = 2))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab8.Text : Lab8.Text = rt.Text
                ElseIf ((((Lab1.Text = 3) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 3)) Or ((Lab1.Text = 6) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 6))) And ((Lab8.Text = 6) Or (Lab8.Text = 3))) Or ((((Lab1.Text = 2) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 2)) Or ((Lab1.Text = 5) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 5))) And ((Lab8.Text = 5) Or (Lab8.Text = 2))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
                ElseIf ((((Lab1.Text = 3) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 3)) Or ((Lab1.Text = 6) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 6))) And ((Lab9.Text = 6) Or (Lab9.Text = 3))) Or ((((Lab1.Text = 2) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 2)) Or ((Lab1.Text = 5) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 5))) And ((Lab9.Text = 5) Or (Lab9.Text = 2))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab7.Text : Lab7.Text = rt.Text
                Else
                    rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
                End If
            ElseIf Lab6.Text = 7 Then
                If ((((Lab1.Text = 3) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 3)) Or ((Lab1.Text = 6) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 6))) And ((Lab7.Text = 6) Or (Lab7.Text = 3))) Or ((((Lab1.Text = 2) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 2)) Or ((Lab1.Text = 5) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 5))) And ((Lab7.Text = 5) Or (Lab7.Text = 2))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab8.Text : Lab8.Text = rt.Text
                ElseIf ((((Lab1.Text = 3) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 3)) Or ((Lab1.Text = 6) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 6))) And ((Lab8.Text = 6) Or (Lab8.Text = 3))) Or ((((Lab1.Text = 2) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 2)) Or ((Lab1.Text = 5) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 5))) And ((Lab8.Text = 5) Or (Lab8.Text = 2))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
                ElseIf ((((Lab1.Text = 3) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 3)) Or ((Lab1.Text = 6) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 6))) And ((Lab9.Text = 6) Or (Lab9.Text = 3))) Or ((((Lab1.Text = 2) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 2)) Or ((Lab1.Text = 5) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 5))) And ((Lab9.Text = 5) Or (Lab9.Text = 2))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab7.Text : Lab7.Text = rt.Text
                Else
                    rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
                End If
            End If
        ElseIf (((((Lab1.Text = 1) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 1))) And ((La1.Text = 1) And (La2.Text = 1))) Or ((((Lab1.Text = 1) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 1))) And ((La1.Text = 1) And (La3.Text = 1))) Or ((((Lab2.Text = 1) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 1))) And ((La2.Text = 1) And (La3.Text = 1)))) And ((Lab4.Text = 7) Or (Lab5.Text = 7) Or (Lab6.Text = 7)) Then
            If Lab4.Text = 7 Then
                If ((((Lab1.Text = 1) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 1)) Or ((Lab1.Text = 1) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 1))) And ((Lab7.Text = 2) Or (Lab7.Text = 3))) Or ((((Lab1.Text = 4) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 4))) And ((Lab7.Text = 5) Or (Lab7.Text = 6))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
                ElseIf ((((Lab1.Text = 1) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 1)) Or ((Lab1.Text = 1) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 1))) And ((Lab8.Text = 2) Or (Lab8.Text = 3))) Or ((((Lab1.Text = 4) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 4))) And ((Lab8.Text = 5) Or (Lab8.Text = 6))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
                ElseIf ((((Lab1.Text = 1) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 1)) Or ((Lab1.Text = 1) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 1))) And ((Lab9.Text = 2) Or (Lab9.Text = 3))) Or ((((Lab1.Text = 4) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 4))) And ((Lab9.Text = 5) Or (Lab9.Text = 6))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
                End If
            ElseIf Lab5.Text = 7 Then
                If ((((Lab1.Text = 1) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 1)) Or ((Lab1.Text = 1) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 1))) And ((Lab7.Text = 2) Or (Lab7.Text = 3))) Or ((((Lab1.Text = 4) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 4))) And ((Lab7.Text = 5) Or (Lab7.Text = 6))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab8.Text : Lab8.Text = rt.Text
                ElseIf ((((Lab1.Text = 1) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 1)) Or ((Lab1.Text = 1) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 1))) And ((Lab8.Text = 2) Or (Lab8.Text = 3))) Or ((((Lab1.Text = 4) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 4))) And ((Lab8.Text = 5) Or (Lab8.Text = 6))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
                ElseIf ((((Lab1.Text = 1) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 1)) Or ((Lab1.Text = 1) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 1))) And ((Lab9.Text = 2) Or (Lab9.Text = 3))) Or ((((Lab1.Text = 4) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 4))) And ((Lab9.Text = 5) Or (Lab9.Text = 6))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab7.Text : Lab7.Text = rt.Text
                Else
                    rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
                End If
            ElseIf Lab6.Text = 7 Then
                If ((((Lab1.Text = 1) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 1)) Or ((Lab1.Text = 1) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 1))) And ((Lab7.Text = 2) Or (Lab7.Text = 3))) Or ((((Lab1.Text = 4) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 4))) And ((Lab7.Text = 5) Or (Lab7.Text = 6))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab8.Text : Lab8.Text = rt.Text
                ElseIf ((((Lab1.Text = 1) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 1)) Or ((Lab1.Text = 1) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 1))) And ((Lab8.Text = 2) Or (Lab8.Text = 3))) Or ((((Lab1.Text = 4) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 4))) And ((Lab8.Text = 5) Or (Lab8.Text = 6))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
                ElseIf ((((Lab1.Text = 1) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 1)) Or ((Lab1.Text = 1) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 1))) And ((Lab9.Text = 2) Or (Lab9.Text = 3))) Or ((((Lab1.Text = 4) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 4))) And ((Lab9.Text = 5) Or (Lab9.Text = 6))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab7.Text : Lab7.Text = rt.Text
                Else
                    rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
                End If
            End If
        ElseIf (((((Lab1.Text = 1) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 1))) And ((La1.Text = 1) And (La2.Text = 1))) Or ((((Lab1.Text = 1) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 1))) And ((La1.Text = 1) And (La3.Text = 1))) Or ((((Lab2.Text = 1) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 1))) And ((La2.Text = 1) And (La3.Text = 1)))) And ((Lab4.Text = 4) Or (Lab5.Text = 4) Or (Lab6.Text = 4)) Then
            If Lab4.Text = 4 Then
                If ((((Lab1.Text = 1) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 1)) Or ((Lab1.Text = 1) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 1))) And ((Lab7.Text = 2) Or (Lab7.Text = 3))) Or ((((Lab1.Text = 7) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 7))) And ((Lab7.Text = 8) Or (Lab7.Text = 9))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
                ElseIf ((((Lab1.Text = 1) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 1)) Or ((Lab1.Text = 1) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 1))) And ((Lab8.Text = 2) Or (Lab8.Text = 3))) Or ((((Lab1.Text = 7) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 7))) And ((Lab8.Text = 8) Or (Lab8.Text = 9))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
                ElseIf ((((Lab1.Text = 1) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 1)) Or ((Lab1.Text = 1) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 1))) And ((Lab9.Text = 2) Or (Lab9.Text = 3))) Or ((((Lab1.Text = 7) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 7))) And ((Lab9.Text = 8) Or (Lab9.Text = 9))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
                End If
            ElseIf Lab5.Text = 4 Then
                If ((((Lab1.Text = 1) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 1)) Or ((Lab1.Text = 1) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 1))) And ((Lab7.Text = 2) Or (Lab7.Text = 3))) Or ((((Lab1.Text = 7) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 7))) And ((Lab7.Text = 8) Or (Lab7.Text = 9))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab8.Text : Lab8.Text = rt.Text
                ElseIf ((((Lab1.Text = 1) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 1)) Or ((Lab1.Text = 1) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 1))) And ((Lab8.Text = 2) Or (Lab8.Text = 3))) Or ((((Lab1.Text = 7) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 7))) And ((Lab8.Text = 8) Or (Lab8.Text = 9))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
                ElseIf ((((Lab1.Text = 1) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 1)) Or ((Lab1.Text = 1) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 1))) And ((Lab9.Text = 2) Or (Lab9.Text = 3))) Or ((((Lab1.Text = 7) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 7))) And ((Lab9.Text = 8) Or (Lab9.Text = 9))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab7.Text : Lab7.Text = rt.Text
                Else
                    rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
                End If
            ElseIf Lab6.Text = 4 Then
                If ((((Lab1.Text = 1) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 1)) Or ((Lab1.Text = 1) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 1))) And ((Lab7.Text = 2) Or (Lab7.Text = 3))) Or ((((Lab1.Text = 7) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 7))) And ((Lab7.Text = 8) Or (Lab7.Text = 9))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab8.Text : Lab8.Text = rt.Text
                ElseIf ((((Lab1.Text = 1) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 1)) Or ((Lab1.Text = 1) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 1))) And ((Lab8.Text = 2) Or (Lab8.Text = 3))) Or ((((Lab1.Text = 7) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 7))) And ((Lab8.Text = 8) Or (Lab8.Text = 9))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
                ElseIf ((((Lab1.Text = 1) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 1)) Or ((Lab1.Text = 1) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 1))) And ((Lab9.Text = 2) Or (Lab9.Text = 3))) Or ((((Lab1.Text = 7) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 7))) And ((Lab9.Text = 8) Or (Lab9.Text = 9))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab7.Text : Lab7.Text = rt.Text
                Else
                    rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
                End If
            End If
        ElseIf (((((Lab1.Text = 4) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 4))) And ((La1.Text = 1) And (La2.Text = 1))) Or ((((Lab1.Text = 4) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 4))) And ((La1.Text = 1) And (La3.Text = 1))) Or ((((Lab2.Text = 4) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 4))) And ((La2.Text = 1) And (La3.Text = 1)))) And ((Lab4.Text = 1) Or (Lab5.Text = 1) Or (Lab6.Text = 1)) Then
            If Lab4.Text = 1 Then
                If ((((Lab1.Text = 4) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 4))) And ((Lab7.Text = 5) Or (Lab7.Text = 6))) Or ((((Lab1.Text = 7) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 7))) And ((Lab7.Text = 8) Or (Lab7.Text = 9))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
                ElseIf ((((Lab1.Text = 4) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 4))) And ((Lab8.Text = 5) Or (Lab8.Text = 6))) Or ((((Lab1.Text = 7) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 7))) And ((Lab8.Text = 8) Or (Lab8.Text = 9))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
                ElseIf ((((Lab1.Text = 4) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 4))) And ((Lab9.Text = 5) Or (Lab9.Text = 6))) Or ((((Lab1.Text = 7) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 7))) And ((Lab9.Text = 8) Or (Lab9.Text = 9))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
                End If
            ElseIf Lab5.Text = 1 Then
                If ((((Lab1.Text = 4) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 4))) And ((Lab7.Text = 5) Or (Lab7.Text = 6))) Or ((((Lab1.Text = 7) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 7))) And ((Lab7.Text = 8) Or (Lab7.Text = 9))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab8.Text : Lab8.Text = rt.Text
                ElseIf ((((Lab1.Text = 4) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 4))) And ((Lab8.Text = 5) Or (Lab8.Text = 6))) Or ((((Lab1.Text = 7) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 7))) And ((Lab8.Text = 8) Or (Lab8.Text = 9))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
                ElseIf ((((Lab1.Text = 4) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 4))) And ((Lab9.Text = 5) Or (Lab9.Text = 6))) Or ((((Lab1.Text = 7) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 7))) And ((Lab9.Text = 8) Or (Lab9.Text = 9))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab7.Text : Lab7.Text = rt.Text
                Else
                    rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
                End If
            ElseIf Lab6.Text = 1 Then
                If ((((Lab1.Text = 4) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 4))) And ((Lab7.Text = 5) Or (Lab7.Text = 6))) Or ((((Lab1.Text = 7) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 7))) And ((Lab7.Text = 8) Or (Lab7.Text = 9))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab8.Text : Lab8.Text = rt.Text
                ElseIf ((((Lab1.Text = 4) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 4))) And ((Lab8.Text = 5) Or (Lab8.Text = 6))) Or ((((Lab1.Text = 7) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 7))) And ((Lab8.Text = 8) Or (Lab8.Text = 9))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
                ElseIf ((((Lab1.Text = 4) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 4))) And ((Lab9.Text = 5) Or (Lab9.Text = 6))) Or ((((Lab1.Text = 7) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 7))) And ((Lab9.Text = 8) Or (Lab9.Text = 9))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab7.Text : Lab7.Text = rt.Text
                Else
                    rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
                End If
            End If
        ElseIf (((((Lab1.Text = 2) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 2))) And ((La1.Text = 1) And (La2.Text = 1))) Or ((((Lab1.Text = 2) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 2))) And ((La1.Text = 1) And (La3.Text = 1))) Or ((((Lab2.Text = 2) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 2))) And ((La2.Text = 1) And (La3.Text = 1)))) And ((Lab4.Text = 8) Or (Lab5.Text = 8) Or (Lab6.Text = 8)) Then
            If Lab4.Text = 8 Then
                If ((((Lab1.Text = 4) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 4)) Or ((Lab1.Text = 5) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 5))) And ((Lab7.Text = 4) Or (Lab7.Text = 6))) Or ((((Lab1.Text = 1) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 1)) Or ((Lab1.Text = 2) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 2))) And ((Lab7.Text = 1) Or (Lab7.Text = 3))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
                ElseIf ((((Lab1.Text = 4) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 4)) Or ((Lab1.Text = 5) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 5))) And ((Lab8.Text = 4) Or (Lab8.Text = 6))) Or ((((Lab1.Text = 1) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 1)) Or ((Lab1.Text = 2) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 2))) And ((Lab8.Text = 1) Or (Lab8.Text = 3))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
                ElseIf ((((Lab1.Text = 4) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 4)) Or ((Lab1.Text = 5) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 5))) And ((Lab9.Text = 4) Or (Lab9.Text = 6))) Or ((((Lab1.Text = 1) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 1)) Or ((Lab1.Text = 2) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 2))) And ((Lab9.Text = 1) Or (Lab9.Text = 3))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
                End If
            ElseIf Lab5.Text = 8 Then
                If ((((Lab1.Text = 4) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 4)) Or ((Lab1.Text = 5) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 5))) And ((Lab7.Text = 4) Or (Lab7.Text = 6))) Or ((((Lab1.Text = 1) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 1)) Or ((Lab1.Text = 2) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 2))) And ((Lab7.Text = 1) Or (Lab7.Text = 3))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab8.Text : Lab8.Text = rt.Text
                ElseIf ((((Lab1.Text = 4) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 4)) Or ((Lab1.Text = 5) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 5))) And ((Lab8.Text = 4) Or (Lab8.Text = 6))) Or ((((Lab1.Text = 1) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 1)) Or ((Lab1.Text = 2) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 2))) And ((Lab8.Text = 1) Or (Lab8.Text = 3))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
                ElseIf ((((Lab1.Text = 4) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 4)) Or ((Lab1.Text = 5) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 5))) And ((Lab9.Text = 4) Or (Lab9.Text = 6))) Or ((((Lab1.Text = 1) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 1)) Or ((Lab1.Text = 2) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 2))) And ((Lab9.Text = 1) Or (Lab9.Text = 3))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab7.Text : Lab7.Text = rt.Text
                Else
                    rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
                End If
            ElseIf Lab6.Text = 8 Then
                If ((((Lab1.Text = 4) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 4)) Or ((Lab1.Text = 5) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 5))) And ((Lab7.Text = 4) Or (Lab7.Text = 6))) Or ((((Lab1.Text = 1) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 1)) Or ((Lab1.Text = 2) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 2))) And ((Lab7.Text = 1) Or (Lab7.Text = 3))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab8.Text : Lab8.Text = rt.Text
                ElseIf ((((Lab1.Text = 4) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 4)) Or ((Lab1.Text = 5) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 5))) And ((Lab8.Text = 4) Or (Lab8.Text = 6))) Or ((((Lab1.Text = 1) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 1)) Or ((Lab1.Text = 2) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 2))) And ((Lab8.Text = 1) Or (Lab8.Text = 3))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
                ElseIf ((((Lab1.Text = 4) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 4)) Or ((Lab1.Text = 5) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 5))) And ((Lab9.Text = 4) Or (Lab9.Text = 6))) Or ((((Lab1.Text = 1) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 1)) Or ((Lab1.Text = 2) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 2))) And ((Lab9.Text = 1) Or (Lab9.Text = 3))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab7.Text : Lab7.Text = rt.Text
                Else
                    rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
                End If
            End If
        ElseIf (((((Lab1.Text = 2) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 2))) And ((La1.Text = 1) And (La2.Text = 1))) Or ((((Lab1.Text = 2) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 2))) And ((La1.Text = 1) And (La3.Text = 1))) Or ((((Lab2.Text = 2) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 2))) And ((La2.Text = 1) And (La3.Text = 1)))) And ((Lab4.Text = 5) Or (Lab5.Text = 5) Or (Lab6.Text = 5)) Then
            If Lab4.Text = 5 Then
                If ((((Lab1.Text = 7) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 7)) Or ((Lab1.Text = 8) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 8))) And ((Lab7.Text = 7) Or (Lab7.Text = 9))) Or ((((Lab1.Text = 1) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 1)) Or ((Lab1.Text = 2) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 2))) And ((Lab7.Text = 1) Or (Lab7.Text = 3))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
                ElseIf ((((Lab1.Text = 7) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 7)) Or ((Lab1.Text = 8) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 8))) And ((Lab8.Text = 7) Or (Lab8.Text = 9))) Or ((((Lab1.Text = 1) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 1)) Or ((Lab1.Text = 2) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 2))) And ((Lab8.Text = 1) Or (Lab8.Text = 3))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
                ElseIf ((((Lab1.Text = 7) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 7)) Or ((Lab1.Text = 8) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 8))) And ((Lab9.Text = 7) Or (Lab9.Text = 9))) Or ((((Lab1.Text = 1) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 1)) Or ((Lab1.Text = 2) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 2))) And ((Lab9.Text = 1) Or (Lab9.Text = 3))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
                End If
            ElseIf Lab5.Text = 5 Then
                If ((((Lab1.Text = 7) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 7)) Or ((Lab1.Text = 8) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 8))) And ((Lab7.Text = 7) Or (Lab7.Text = 9))) Or ((((Lab1.Text = 1) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 1)) Or ((Lab1.Text = 2) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 2))) And ((Lab7.Text = 1) Or (Lab7.Text = 3))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab8.Text : Lab8.Text = rt.Text
                ElseIf ((((Lab1.Text = 7) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 7)) Or ((Lab1.Text = 8) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 8))) And ((Lab8.Text = 7) Or (Lab8.Text = 9))) Or ((((Lab1.Text = 1) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 1)) Or ((Lab1.Text = 2) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 2))) And ((Lab8.Text = 1) Or (Lab8.Text = 3))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
                ElseIf ((((Lab1.Text = 7) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 7)) Or ((Lab1.Text = 8) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 8))) And ((Lab9.Text = 7) Or (Lab9.Text = 9))) Or ((((Lab1.Text = 1) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 1)) Or ((Lab1.Text = 2) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 2))) And ((Lab9.Text = 1) Or (Lab9.Text = 3))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab7.Text : Lab7.Text = rt.Text
                Else
                    rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
                End If
            ElseIf Lab6.Text = 5 Then
                If ((((Lab1.Text = 7) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 7)) Or ((Lab1.Text = 8) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 8))) And ((Lab7.Text = 7) Or (Lab7.Text = 9))) Or ((((Lab1.Text = 1) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 1)) Or ((Lab1.Text = 2) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 2))) And ((Lab7.Text = 1) Or (Lab7.Text = 3))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab8.Text : Lab8.Text = rt.Text
                ElseIf ((((Lab1.Text = 7) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 7)) Or ((Lab1.Text = 8) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 8))) And ((Lab8.Text = 7) Or (Lab8.Text = 9))) Or ((((Lab1.Text = 1) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 1)) Or ((Lab1.Text = 2) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 2))) And ((Lab8.Text = 1) Or (Lab8.Text = 3))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
                ElseIf ((((Lab1.Text = 7) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 7)) Or ((Lab1.Text = 8) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 8))) And ((Lab9.Text = 7) Or (Lab9.Text = 9))) Or ((((Lab1.Text = 1) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 1)) Or ((Lab1.Text = 2) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 2))) And ((Lab9.Text = 1) Or (Lab9.Text = 3))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab7.Text : Lab7.Text = rt.Text
                Else
                    rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
                End If
            End If
        ElseIf (((((Lab1.Text = 5) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 5))) And ((La1.Text = 1) And (La2.Text = 1))) Or ((((Lab1.Text = 5) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 5))) And ((La1.Text = 1) And (La3.Text = 1))) Or ((((Lab2.Text = 5) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 5))) And ((La2.Text = 1) And (La3.Text = 1)))) And ((Lab4.Text = 2) Or (Lab5.Text = 2) Or (Lab6.Text = 2)) Then
            If Lab4.Text = 2 Then
                If ((((Lab1.Text = 7) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 7)) Or ((Lab1.Text = 8) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 8))) And ((Lab7.Text = 7) Or (Lab7.Text = 9))) Or ((((Lab1.Text = 4) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 4)) Or ((Lab1.Text = 5) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 5))) And ((Lab7.Text = 4) Or (Lab7.Text = 6))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
                ElseIf ((((Lab1.Text = 7) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 7)) Or ((Lab1.Text = 8) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 8))) And ((Lab8.Text = 7) Or (Lab8.Text = 9))) Or ((((Lab1.Text = 4) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 4)) Or ((Lab1.Text = 5) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 5))) And ((Lab8.Text = 4) Or (Lab8.Text = 6))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
                ElseIf ((((Lab1.Text = 7) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 7)) Or ((Lab1.Text = 8) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 8))) And ((Lab9.Text = 7) Or (Lab9.Text = 9))) Or ((((Lab1.Text = 4) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 4)) Or ((Lab1.Text = 5) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 5))) And ((Lab9.Text = 4) Or (Lab9.Text = 6))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
                End If
            ElseIf Lab5.Text = 2 Then
                If ((((Lab1.Text = 7) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 7)) Or ((Lab1.Text = 8) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 8))) And ((Lab7.Text = 7) Or (Lab7.Text = 9))) Or ((((Lab1.Text = 4) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 4)) Or ((Lab1.Text = 5) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 5))) And ((Lab7.Text = 4) Or (Lab7.Text = 6))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab8.Text : Lab8.Text = rt.Text
                ElseIf ((((Lab1.Text = 7) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 7)) Or ((Lab1.Text = 8) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 8))) And ((Lab8.Text = 7) Or (Lab8.Text = 9))) Or ((((Lab1.Text = 4) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 4)) Or ((Lab1.Text = 5) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 5))) And ((Lab8.Text = 4) Or (Lab8.Text = 6))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
                ElseIf ((((Lab1.Text = 7) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 7)) Or ((Lab1.Text = 8) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 8))) And ((Lab9.Text = 7) Or (Lab9.Text = 9))) Or ((((Lab1.Text = 4) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 4)) Or ((Lab1.Text = 5) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 5))) And ((Lab9.Text = 4) Or (Lab9.Text = 6))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab7.Text : Lab7.Text = rt.Text
                Else
                    rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
                End If
            ElseIf Lab6.Text = 2 Then
                If ((((Lab1.Text = 7) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 7)) Or ((Lab1.Text = 8) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 8))) And ((Lab7.Text = 7) Or (Lab7.Text = 9))) Or ((((Lab1.Text = 4) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 4)) Or ((Lab1.Text = 5) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 5))) And ((Lab7.Text = 4) Or (Lab7.Text = 6))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab8.Text : Lab8.Text = rt.Text
                ElseIf ((((Lab1.Text = 7) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 7)) Or ((Lab1.Text = 8) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 8))) And ((Lab8.Text = 7) Or (Lab8.Text = 9))) Or ((((Lab1.Text = 4) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 4)) Or ((Lab1.Text = 5) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 5))) And ((Lab8.Text = 4) Or (Lab8.Text = 6))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
                ElseIf ((((Lab1.Text = 7) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 7)) Or ((Lab1.Text = 8) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 8))) And ((Lab9.Text = 7) Or (Lab9.Text = 9))) Or ((((Lab1.Text = 4) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 4)) Or ((Lab1.Text = 5) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 5))) And ((Lab9.Text = 4) Or (Lab9.Text = 6))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab7.Text : Lab7.Text = rt.Text
                Else
                    rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
                End If
            End If
        ElseIf (((((Lab1.Text = 3) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 3))) And ((La1.Text = 1) And (La2.Text = 1))) Or ((((Lab1.Text = 3) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 3))) And ((La1.Text = 1) And (La3.Text = 1))) Or ((((Lab2.Text = 3) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 3))) And ((La2.Text = 1) And (La3.Text = 1)))) And ((Lab4.Text = 9) Or (Lab5.Text = 9) Or (Lab6.Text = 9)) Then
            If Lab4.Text = 9 Then
                If ((((Lab1.Text = 3) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 3))) And ((Lab7.Text = 2) Or (Lab7.Text = 1))) Or ((((Lab1.Text = 6) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 6))) And ((Lab7.Text = 5) Or (Lab7.Text = 4))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
                ElseIf ((((Lab1.Text = 3) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 3))) And ((Lab8.Text = 2) Or (Lab8.Text = 1))) Or ((((Lab1.Text = 6) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 6))) And ((Lab8.Text = 5) Or (Lab8.Text = 4))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
                ElseIf ((((Lab1.Text = 3) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 3))) And ((Lab9.Text = 2) Or (Lab9.Text = 1))) Or ((((Lab1.Text = 6) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 6))) And ((Lab9.Text = 5) Or (Lab9.Text = 4))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
                End If
            ElseIf Lab5.Text = 9 Then
                If ((((Lab1.Text = 3) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 3))) And ((Lab7.Text = 2) Or (Lab7.Text = 1))) Or ((((Lab1.Text = 6) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 6))) And ((Lab7.Text = 5) Or (Lab7.Text = 4))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab8.Text : Lab8.Text = rt.Text
                ElseIf ((((Lab1.Text = 3) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 3))) And ((Lab8.Text = 2) Or (Lab8.Text = 1))) Or ((((Lab1.Text = 6) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 6))) And ((Lab8.Text = 5) Or (Lab8.Text = 4))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
                ElseIf ((((Lab1.Text = 3) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 3))) And ((Lab9.Text = 2) Or (Lab9.Text = 1))) Or ((((Lab1.Text = 6) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 6))) And ((Lab9.Text = 5) Or (Lab9.Text = 4))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab7.Text : Lab7.Text = rt.Text
                Else
                    rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
                End If
            ElseIf Lab6.Text = 9 Then
                If ((((Lab1.Text = 3) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 3))) And ((Lab7.Text = 2) Or (Lab7.Text = 1))) Or ((((Lab1.Text = 6) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 6))) And ((Lab7.Text = 5) Or (Lab7.Text = 4))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab8.Text : Lab8.Text = rt.Text
                ElseIf ((((Lab1.Text = 3) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 3))) And ((Lab8.Text = 2) Or (Lab8.Text = 1))) Or ((((Lab1.Text = 6) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 6))) And ((Lab8.Text = 5) Or (Lab8.Text = 4))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
                ElseIf ((((Lab1.Text = 3) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 3))) And ((Lab9.Text = 2) Or (Lab9.Text = 1))) Or ((((Lab1.Text = 6) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 6))) And ((Lab9.Text = 5) Or (Lab9.Text = 4))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab7.Text : Lab7.Text = rt.Text
                Else
                    rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
                End If
            End If
        ElseIf (((((Lab1.Text = 3) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 3))) And ((La1.Text = 1) And (La2.Text = 1))) Or ((((Lab1.Text = 3) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 3))) And ((La1.Text = 1) And (La3.Text = 1))) Or ((((Lab2.Text = 3) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 3))) And ((La2.Text = 1) And (La3.Text = 1)))) And ((Lab4.Text = 6) Or (Lab5.Text = 6) Or (Lab6.Text = 6)) Then
            If Lab4.Text = 6 Then
                If ((((Lab1.Text = 3) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 3))) And ((Lab7.Text = 2) Or (Lab7.Text = 1))) Or ((((Lab1.Text = 9) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 9))) And ((Lab7.Text = 8) Or (Lab7.Text = 7))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
                ElseIf ((((Lab1.Text = 3) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 3))) And ((Lab8.Text = 2) Or (Lab8.Text = 1))) Or ((((Lab1.Text = 9) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 9))) And ((Lab8.Text = 8) Or (Lab8.Text = 7))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
                ElseIf ((((Lab1.Text = 3) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 3))) And ((Lab9.Text = 2) Or (Lab9.Text = 1))) Or ((((Lab1.Text = 9) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 9))) And ((Lab9.Text = 8) Or (Lab9.Text = 7))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
                End If
            ElseIf Lab5.Text = 6 Then
                If ((((Lab1.Text = 3) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 3))) And ((Lab7.Text = 2) Or (Lab7.Text = 1))) Or ((((Lab1.Text = 9) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 9))) And ((Lab7.Text = 8) Or (Lab7.Text = 7))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab8.Text : Lab8.Text = rt.Text
                ElseIf ((((Lab1.Text = 3) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 3))) And ((Lab8.Text = 2) Or (Lab8.Text = 1))) Or ((((Lab1.Text = 9) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 9))) And ((Lab8.Text = 8) Or (Lab8.Text = 7))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
                ElseIf ((((Lab1.Text = 3) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 3))) And ((Lab9.Text = 2) Or (Lab9.Text = 1))) Or ((((Lab1.Text = 9) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 9))) And ((Lab9.Text = 8) Or (Lab9.Text = 7))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab7.Text : Lab7.Text = rt.Text
                Else
                    rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
                End If
            ElseIf Lab6.Text = 6 Then
                If ((((Lab1.Text = 3) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 3))) And ((Lab7.Text = 2) Or (Lab7.Text = 1))) Or ((((Lab1.Text = 9) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 9))) And ((Lab7.Text = 8) Or (Lab7.Text = 7))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab8.Text : Lab8.Text = rt.Text
                ElseIf ((((Lab1.Text = 3) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 3))) And ((Lab8.Text = 2) Or (Lab8.Text = 1))) Or ((((Lab1.Text = 9) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 9))) And ((Lab8.Text = 8) Or (Lab8.Text = 7))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
                ElseIf ((((Lab1.Text = 3) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 3))) And ((Lab9.Text = 2) Or (Lab9.Text = 1))) Or ((((Lab1.Text = 9) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 9))) And ((Lab9.Text = 8) Or (Lab9.Text = 7))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab7.Text : Lab7.Text = rt.Text
                Else
                    rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
                End If
            End If
        ElseIf (((((Lab1.Text = 6) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 6))) And ((La1.Text = 1) And (La2.Text = 1))) Or ((((Lab1.Text = 6) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 6))) And ((La1.Text = 1) And (La3.Text = 1))) Or ((((Lab2.Text = 6) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 6))) And ((La2.Text = 1) And (La3.Text = 1)))) And ((Lab4.Text = 3) Or (Lab5.Text = 3) Or (Lab6.Text = 3)) Then
            If Lab4.Text = 3 Then
                If ((((Lab1.Text = 6) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 6))) And ((Lab7.Text = 5) Or (Lab7.Text = 4))) Or ((((Lab1.Text = 9) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 9))) And ((Lab7.Text = 8) Or (Lab7.Text = 7))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
                ElseIf ((((Lab1.Text = 6) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 6))) And ((Lab8.Text = 5) Or (Lab8.Text = 4))) Or ((((Lab1.Text = 9) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 9))) And ((Lab8.Text = 8) Or (Lab8.Text = 7))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
                ElseIf ((((Lab1.Text = 6) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 6))) And ((Lab9.Text = 5) Or (Lab9.Text = 4))) Or ((((Lab1.Text = 9) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 9))) And ((Lab9.Text = 8) Or (Lab9.Text = 7))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
                End If
            ElseIf Lab5.Text = 3 Then
                If ((((Lab1.Text = 6) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 6))) And ((Lab7.Text = 5) Or (Lab7.Text = 4))) Or ((((Lab1.Text = 9) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 9))) And ((Lab7.Text = 8) Or (Lab7.Text = 7))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab8.Text : Lab8.Text = rt.Text
                ElseIf ((((Lab1.Text = 6) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 6))) And ((Lab8.Text = 5) Or (Lab8.Text = 4))) Or ((((Lab1.Text = 9) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 9))) And ((Lab8.Text = 8) Or (Lab8.Text = 7))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
                ElseIf ((((Lab1.Text = 6) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 6))) And ((Lab9.Text = 5) Or (Lab9.Text = 4))) Or ((((Lab1.Text = 9) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 9))) And ((Lab9.Text = 8) Or (Lab9.Text = 7))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab7.Text : Lab7.Text = rt.Text
                Else
                    rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
                End If
            ElseIf Lab6.Text = 3 Then
                If ((((Lab1.Text = 6) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 6))) And ((Lab7.Text = 5) Or (Lab7.Text = 4))) Or ((((Lab1.Text = 9) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 9))) And ((Lab7.Text = 8) Or (Lab7.Text = 7))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab8.Text : Lab8.Text = rt.Text
                ElseIf ((((Lab1.Text = 6) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 6))) And ((Lab8.Text = 5) Or (Lab8.Text = 4))) Or ((((Lab1.Text = 9) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 9))) And ((Lab8.Text = 8) Or (Lab8.Text = 7))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
                ElseIf ((((Lab1.Text = 6) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 6))) And ((Lab9.Text = 5) Or (Lab9.Text = 4))) Or ((((Lab1.Text = 9) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 9))) And ((Lab9.Text = 8) Or (Lab9.Text = 7))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab7.Text : Lab7.Text = rt.Text
                Else
                    rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
                End If
            End If
        ElseIf (((Lab1.Text = 1) And (Lab2.Text = 5)) Or ((Lab2.Text = 1) And (Lab1.Text = 5))) And ((Lab4.Text = 9) Or (Lab5.Text = 9) Or (Lab6.Text = 9)) And ((La1.Text = 1) And (La2.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 9 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab5.Text = 9 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab6.Text = 9 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
            End If
        ElseIf (((Lab1.Text = 1) And (Lab3.Text = 5)) Or ((Lab3.Text = 1) And (Lab1.Text = 5))) And ((Lab4.Text = 9) Or (Lab5.Text = 9) Or (Lab6.Text = 9)) And ((La1.Text = 1) And (La3.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 9 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab5.Text = 9 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab6.Text = 9 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab8.Text : Lab8.Text = rt.Text
            End If
        ElseIf (((Lab2.Text = 1) And (Lab3.Text = 5)) Or ((Lab3.Text = 1) And (Lab2.Text = 5))) And ((Lab4.Text = 9) Or (Lab5.Text = 9) Or (Lab6.Text = 9)) And ((La2.Text = 1) And (La3.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 9 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
            ElseIf Lab5.Text = 9 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab7.Text : Lab7.Text = rt.Text
            ElseIf Lab6.Text = 9 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab7.Text : Lab7.Text = rt.Text
            End If
        ElseIf (((Lab1.Text = 1) And (Lab2.Text = 9)) Or ((Lab2.Text = 1) And (Lab1.Text = 9))) And ((Lab4.Text = 5) Or (Lab5.Text = 5) Or (Lab6.Text = 5)) And ((La1.Text = 1) And (La2.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 5 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab5.Text = 5 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab6.Text = 5 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
            End If
        ElseIf (((Lab1.Text = 1) And (Lab3.Text = 9)) Or ((Lab3.Text = 1) And (Lab1.Text = 9))) And ((Lab4.Text = 5) Or (Lab5.Text = 5) Or (Lab6.Text = 5)) And ((La1.Text = 1) And (La3.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 5 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab5.Text = 5 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab6.Text = 5 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab8.Text : Lab8.Text = rt.Text
            End If
        ElseIf (((Lab2.Text = 1) And (Lab3.Text = 9)) Or ((Lab3.Text = 1) And (Lab2.Text = 9))) And ((Lab4.Text = 5) Or (Lab5.Text = 5) Or (Lab6.Text = 5)) And ((La2.Text = 1) And (La3.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 5 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
            ElseIf Lab5.Text = 5 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab7.Text : Lab7.Text = rt.Text
            ElseIf Lab6.Text = 5 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab7.Text : Lab7.Text = rt.Text
            End If
        ElseIf (((Lab1.Text = 5) And (Lab2.Text = 9)) Or ((Lab2.Text = 5) And (Lab1.Text = 9))) And ((Lab4.Text = 1) Or (Lab5.Text = 1) Or (Lab6.Text = 1)) And ((La1.Text = 1) And (La2.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 1 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab5.Text = 1 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab6.Text = 1 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
            End If
        ElseIf (((Lab1.Text = 5) And (Lab3.Text = 9)) Or ((Lab3.Text = 5) And (Lab1.Text = 9))) And ((Lab4.Text = 1) Or (Lab5.Text = 1) Or (Lab6.Text = 1)) And ((La1.Text = 1) And (La3.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 1 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab5.Text = 1 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab6.Text = 1 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab8.Text : Lab8.Text = rt.Text
            End If
        ElseIf (((Lab2.Text = 5) And (Lab3.Text = 9)) Or ((Lab3.Text = 5) And (Lab2.Text = 9))) And ((Lab4.Text = 1) Or (Lab5.Text = 1) Or (Lab6.Text = 1)) And ((La2.Text = 1) And (La3.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 1 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
            ElseIf Lab5.Text = 1 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab7.Text : Lab7.Text = rt.Text
            ElseIf Lab6.Text = 1 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab7.Text : Lab7.Text = rt.Text
            End If
        ElseIf (((Lab1.Text = 3) And (Lab2.Text = 5)) Or ((Lab2.Text = 3) And (Lab1.Text = 5))) And ((Lab4.Text = 7) Or (Lab5.Text = 7) Or (Lab6.Text = 7)) And ((La1.Text = 1) And (La2.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 7 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab5.Text = 7 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab6.Text = 7 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
            End If
        ElseIf (((Lab1.Text = 3) And (Lab3.Text = 5)) Or ((Lab3.Text = 3) And (Lab1.Text = 5))) And ((Lab4.Text = 7) Or (Lab5.Text = 7) Or (Lab6.Text = 7)) And ((La1.Text = 1) And (La3.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 7 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab5.Text = 7 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab6.Text = 7 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab8.Text : Lab8.Text = rt.Text
            End If
        ElseIf (((Lab2.Text = 3) And (Lab3.Text = 5)) Or ((Lab3.Text = 3) And (Lab2.Text = 5))) And ((Lab4.Text = 7) Or (Lab5.Text = 7) Or (Lab6.Text = 7)) And ((La2.Text = 1) And (La3.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 7 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
            ElseIf Lab5.Text = 7 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab7.Text : Lab7.Text = rt.Text
            ElseIf Lab6.Text = 7 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab7.Text : Lab7.Text = rt.Text
            End If
        ElseIf (((Lab1.Text = 3) And (Lab2.Text = 7)) Or ((Lab2.Text = 3) And (Lab1.Text = 7))) And ((Lab4.Text = 5) Or (Lab5.Text = 5) Or (Lab6.Text = 5)) And ((La1.Text = 1) And (La2.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 5 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab5.Text = 5 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab6.Text = 5 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
            End If
        ElseIf (((Lab1.Text = 3) And (Lab3.Text = 7)) Or ((Lab3.Text = 3) And (Lab1.Text = 7))) And ((Lab4.Text = 5) Or (Lab5.Text = 5) Or (Lab6.Text = 5)) And ((La1.Text = 1) And (La3.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 5 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab5.Text = 5 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab6.Text = 5 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab8.Text : Lab8.Text = rt.Text
            End If
        ElseIf (((Lab2.Text = 3) And (Lab3.Text = 7)) Or ((Lab3.Text = 3) And (Lab2.Text = 7))) And ((Lab4.Text = 5) Or (Lab5.Text = 5) Or (Lab6.Text = 5)) And ((La2.Text = 1) And (La3.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 5 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
            ElseIf Lab5.Text = 5 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab7.Text : Lab7.Text = rt.Text
            ElseIf Lab6.Text = 5 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab7.Text : Lab7.Text = rt.Text
            End If
        ElseIf (((Lab1.Text = 5) And (Lab2.Text = 7)) Or ((Lab2.Text = 5) And (Lab1.Text = 7))) And ((Lab4.Text = 3) Or (Lab5.Text = 3) Or (Lab6.Text = 3)) And ((La1.Text = 1) And (La2.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 3 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab5.Text = 3 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab6.Text = 3 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
            End If
        ElseIf (((Lab1.Text = 5) And (Lab3.Text = 7)) Or ((Lab3.Text = 5) And (Lab1.Text = 7))) And ((Lab4.Text = 3) Or (Lab5.Text = 3) Or (Lab6.Text = 3)) And ((La1.Text = 1) And (La3.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 3 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab5.Text = 3 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab6.Text = 3 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab8.Text : Lab8.Text = rt.Text
            End If
        ElseIf (((Lab2.Text = 5) And (Lab3.Text = 7)) Or ((Lab3.Text = 5) And (Lab2.Text = 7))) And ((Lab4.Text = 3) Or (Lab5.Text = 3) Or (Lab6.Text = 3)) And ((La2.Text = 1) And (La3.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 3 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
            ElseIf Lab5.Text = 3 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab7.Text : Lab7.Text = rt.Text
            ElseIf Lab6.Text = 3 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab7.Text : Lab7.Text = rt.Text
            End If

        ElseIf (((((Lab1.Text = 1) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 1))) And ((La1.Text = 1) And (La2.Text = 1))) Or ((((Lab1.Text = 1) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 1))) And ((La1.Text = 1) And (La3.Text = 1))) Or ((((Lab2.Text = 1) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 1))) And ((La2.Text = 1) And (La3.Text = 1)))) And ((Lab7.Text = 3) Or (Lab8.Text = 3) Or (Lab9.Text = 3)) Then
            If Lab7.Text = 3 Then
                If ((((Lab1.Text = 2) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 2))) And ((Lab8.Text = 8) Or (Lab8.Text = 5))) Or ((((Lab1.Text = 1) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 1)) Or ((Lab1.Text = 1) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 1))) And ((Lab8.Text = 7) Or (Lab8.Text = 4))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
                End If
            ElseIf Lab8.Text = 3 Then
                If ((((Lab1.Text = 2) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 2))) And ((Lab9.Text = 8) Or (Lab9.Text = 5))) Or ((((Lab1.Text = 1) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 1)) Or ((Lab1.Text = 1) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 1))) And ((Lab9.Text = 7) Or (Lab9.Text = 4))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
                End If
            ElseIf Lab9.Text = 3 Then
                If ((((Lab1.Text = 2) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 2))) And ((Lab7.Text = 8) Or (Lab7.Text = 5))) Or ((((Lab1.Text = 1) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 1)) Or ((Lab1.Text = 1) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 1))) And ((Lab7.Text = 7) Or (Lab7.Text = 4))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
                End If
            End If
        ElseIf (((((Lab1.Text = 1) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 1))) And ((La1.Text = 1) And (La2.Text = 1))) Or ((((Lab1.Text = 1) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 1))) And ((La1.Text = 1) And (La3.Text = 1))) Or ((((Lab2.Text = 1) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 1))) And ((La2.Text = 1) And (La3.Text = 1)))) And ((Lab7.Text = 2) Or (Lab8.Text = 2) Or (Lab9.Text = 2)) Then
            If Lab7.Text = 2 Then
                If ((((Lab1.Text = 3) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 3))) And ((Lab8.Text = 9) Or (Lab8.Text = 6))) Or ((((Lab1.Text = 1) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 1)) Or ((Lab1.Text = 1) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 1))) And ((Lab8.Text = 7) Or (Lab8.Text = 4))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
                End If
            ElseIf Lab8.Text = 2 Then
                If ((((Lab1.Text = 3) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 3))) And ((Lab9.Text = 9) Or (Lab9.Text = 6))) Or ((((Lab1.Text = 1) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 1)) Or ((Lab1.Text = 1) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 1))) And ((Lab9.Text = 7) Or (Lab9.Text = 4))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
                End If
            ElseIf Lab9.Text = 2 Then
                If ((((Lab1.Text = 3) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 3))) And ((Lab7.Text = 9) Or (Lab7.Text = 6))) Or ((((Lab1.Text = 1) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 1)) Or ((Lab1.Text = 1) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 1))) And ((Lab7.Text = 7) Or (Lab7.Text = 4))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
                End If
            End If
        ElseIf (((((Lab1.Text = 2) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 2))) And ((La1.Text = 1) And (La2.Text = 1))) Or ((((Lab1.Text = 2) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 2))) And ((La1.Text = 1) And (La3.Text = 1))) Or ((((Lab2.Text = 2) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 2))) And ((La2.Text = 1) And (La3.Text = 1)))) And ((Lab7.Text = 1) Or (Lab8.Text = 1) Or (Lab9.Text = 1)) Then
            If Lab7.Text = 1 Then
                If ((((Lab1.Text = 3) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 3))) And ((Lab8.Text = 9) Or (Lab8.Text = 6))) Or ((((Lab1.Text = 2) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 2))) And ((Lab8.Text = 8) Or (Lab8.Text = 5))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
                End If
            ElseIf Lab8.Text = 1 Then
                If ((((Lab1.Text = 3) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 3))) And ((Lab9.Text = 9) Or (Lab9.Text = 6))) Or ((((Lab1.Text = 2) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 2))) And ((Lab9.Text = 8) Or (Lab9.Text = 5))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
                End If
            ElseIf Lab9.Text = 1 Then
                If ((((Lab1.Text = 3) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 3)) Or ((Lab1.Text = 3) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 3))) And ((Lab7.Text = 9) Or (Lab7.Text = 6))) Or ((((Lab1.Text = 2) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 2)) Or ((Lab1.Text = 2) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 2))) And ((Lab7.Text = 8) Or (Lab7.Text = 5))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
                End If
            End If
        ElseIf (((((Lab1.Text = 4) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 4))) And ((La1.Text = 1) And (La2.Text = 1))) Or ((((Lab1.Text = 4) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 4))) And ((La1.Text = 1) And (La3.Text = 1))) Or ((((Lab2.Text = 4) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 4))) And ((La2.Text = 1) And (La3.Text = 1)))) And ((Lab7.Text = 6) Or (Lab8.Text = 6) Or (Lab9.Text = 6)) Then
            If Lab7.Text = 6 Then
                If ((((Lab1.Text = 2) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 2)) Or ((Lab1.Text = 5) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 5))) And ((Lab8.Text = 8) Or (Lab8.Text = 2))) Or ((((Lab1.Text = 1) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 1)) Or ((Lab1.Text = 4) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 4))) And ((Lab8.Text = 7) Or (Lab8.Text = 1))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
                End If
            ElseIf Lab8.Text = 6 Then
                If ((((Lab1.Text = 2) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 2)) Or ((Lab1.Text = 5) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 5))) And ((Lab9.Text = 8) Or (Lab9.Text = 2))) Or ((((Lab1.Text = 1) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 1)) Or ((Lab1.Text = 4) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 4))) And ((Lab9.Text = 7) Or (Lab9.Text = 1))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
                End If
            ElseIf Lab9.Text = 6 Then
                If ((((Lab1.Text = 2) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 2)) Or ((Lab1.Text = 5) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 5))) And ((Lab7.Text = 8) Or (Lab7.Text = 2))) Or ((((Lab1.Text = 1) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 1)) Or ((Lab1.Text = 4) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 4))) And ((Lab7.Text = 7) Or (Lab7.Text = 1))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
                End If
            End If
        ElseIf (((((Lab1.Text = 4) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 4))) And ((La1.Text = 1) And (La2.Text = 1))) Or ((((Lab1.Text = 4) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 4))) And ((La1.Text = 1) And (La3.Text = 1))) Or ((((Lab2.Text = 4) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 4))) And ((La2.Text = 1) And (La3.Text = 1)))) And ((Lab7.Text = 5) Or (Lab8.Text = 5) Or (Lab9.Text = 5)) Then
            If Lab7.Text = 5 Then
                If ((((Lab1.Text = 1) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 1)) Or ((Lab1.Text = 4) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 4))) And ((Lab8.Text = 7) Or (Lab8.Text = 1))) Or ((((Lab1.Text = 3) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 3)) Or ((Lab1.Text = 6) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 6))) And ((Lab8.Text = 9) Or (Lab8.Text = 3))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
                End If
            ElseIf Lab8.Text = 5 Then
                If ((((Lab1.Text = 1) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 1)) Or ((Lab1.Text = 4) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 4))) And ((Lab9.Text = 7) Or (Lab9.Text = 1))) Or ((((Lab1.Text = 3) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 3)) Or ((Lab1.Text = 6) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 6))) And ((Lab9.Text = 9) Or (Lab9.Text = 3))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
                End If
            ElseIf Lab9.Text = 5 Then
                If ((((Lab1.Text = 1) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 1)) Or ((Lab1.Text = 4) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 4))) And ((Lab7.Text = 7) Or (Lab7.Text = 1))) Or ((((Lab1.Text = 3) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 3)) Or ((Lab1.Text = 6) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 6))) And ((Lab7.Text = 9) Or (Lab7.Text = 3))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
                End If
            End If
        ElseIf (((((Lab1.Text = 5) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 5))) And ((La1.Text = 1) And (La2.Text = 1))) Or ((((Lab1.Text = 5) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 5))) And ((La1.Text = 1) And (La3.Text = 1))) Or ((((Lab2.Text = 5) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 5))) And ((La2.Text = 1) And (La3.Text = 1)))) And ((Lab7.Text = 4) Or (Lab8.Text = 4) Or (Lab9.Text = 4)) Then
            If Lab7.Text = 4 Then
                If ((((Lab1.Text = 2) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 2)) Or ((Lab1.Text = 5) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 5))) And ((Lab8.Text = 8) Or (Lab8.Text = 2))) Or ((((Lab1.Text = 3) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 3)) Or ((Lab1.Text = 6) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 6))) And ((Lab8.Text = 9) Or (Lab8.Text = 3))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
                End If
            ElseIf Lab8.Text = 4 Then
                If ((((Lab1.Text = 2) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 2)) Or ((Lab1.Text = 5) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 5))) And ((Lab9.Text = 8) Or (Lab9.Text = 2))) Or ((((Lab1.Text = 3) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 3)) Or ((Lab1.Text = 6) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 6))) And ((Lab9.Text = 9) Or (Lab9.Text = 3))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
                End If
            ElseIf Lab9.Text = 4 Then
                If ((((Lab1.Text = 2) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 2)) Or ((Lab1.Text = 5) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 5))) And ((Lab7.Text = 8) Or (Lab7.Text = 2))) Or ((((Lab1.Text = 3) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 3)) Or ((Lab1.Text = 6) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 6))) And ((Lab7.Text = 9) Or (Lab7.Text = 3))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
                End If
            End If
        ElseIf (((((Lab1.Text = 7) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 7))) And ((La1.Text = 1) And (La2.Text = 1))) Or ((((Lab1.Text = 7) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 7))) And ((La1.Text = 1) And (La3.Text = 1))) Or ((((Lab2.Text = 7) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 7))) And ((La2.Text = 1) And (La3.Text = 1)))) And ((Lab7.Text = 9) Or (Lab8.Text = 9) Or (Lab9.Text = 9)) Then
            If Lab7.Text = 9 Then
                If ((((Lab1.Text = 2) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 2)) Or ((Lab1.Text = 5) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 5))) And ((Lab8.Text = 5) Or (Lab8.Text = 2))) Or ((((Lab1.Text = 1) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 1)) Or ((Lab1.Text = 4) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 4))) And ((Lab8.Text = 4) Or (Lab8.Text = 1))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
                End If
            ElseIf Lab8.Text = 9 Then
                If ((((Lab1.Text = 2) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 2)) Or ((Lab1.Text = 5) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 5))) And ((Lab9.Text = 5) Or (Lab9.Text = 2))) Or ((((Lab1.Text = 1) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 1)) Or ((Lab1.Text = 4) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 4))) And ((Lab9.Text = 4) Or (Lab9.Text = 1))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
                End If
            ElseIf Lab9.Text = 9 Then
                If ((((Lab1.Text = 2) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 2)) Or ((Lab1.Text = 5) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 5))) And ((Lab7.Text = 5) Or (Lab7.Text = 2))) Or ((((Lab1.Text = 1) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 1)) Or ((Lab1.Text = 4) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 4))) And ((Lab7.Text = 4) Or (Lab7.Text = 1))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
                End If
            End If
        ElseIf (((((Lab1.Text = 7) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 7))) And ((La1.Text = 1) And (La2.Text = 1))) Or ((((Lab1.Text = 7) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 7))) And ((La1.Text = 1) And (La3.Text = 1))) Or ((((Lab2.Text = 7) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 7))) And ((La2.Text = 1) And (La3.Text = 1)))) And ((Lab7.Text = 8) Or (Lab8.Text = 8) Or (Lab9.Text = 8)) Then
            If Lab7.Text = 8 Then
                If ((((Lab1.Text = 3) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 3)) Or ((Lab1.Text = 6) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 6))) And ((Lab8.Text = 6) Or (Lab8.Text = 3))) Or ((((Lab1.Text = 1) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 1)) Or ((Lab1.Text = 4) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 4))) And ((Lab8.Text = 4) Or (Lab8.Text = 1))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
                End If
            ElseIf Lab8.Text = 8 Then
                If ((((Lab1.Text = 3) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 3)) Or ((Lab1.Text = 6) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 6))) And ((Lab9.Text = 6) Or (Lab9.Text = 3))) Or ((((Lab1.Text = 1) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 1)) Or ((Lab1.Text = 4) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 4))) And ((Lab9.Text = 4) Or (Lab9.Text = 1))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
                End If
            ElseIf Lab9.Text = 8 Then
                If ((((Lab1.Text = 3) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 3)) Or ((Lab1.Text = 6) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 6))) And ((Lab7.Text = 6) Or (Lab7.Text = 3))) Or ((((Lab1.Text = 1) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 1)) Or ((Lab1.Text = 1) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 1)) Or ((Lab2.Text = 1) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 1)) Or ((Lab1.Text = 4) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 4))) And ((Lab7.Text = 4) Or (Lab7.Text = 1))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
                End If
            End If
        ElseIf (((((Lab1.Text = 8) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 8))) And ((La1.Text = 1) And (La2.Text = 1))) Or ((((Lab1.Text = 8) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 8))) And ((La1.Text = 1) And (La3.Text = 1))) Or ((((Lab2.Text = 8) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 8))) And ((La2.Text = 1) And (La3.Text = 1)))) And ((Lab7.Text = 7) Or (Lab8.Text = 7) Or (Lab9.Text = 7)) Then
            If Lab7.Text = 7 Then
                If ((((Lab1.Text = 3) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 3)) Or ((Lab1.Text = 6) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 6))) And ((Lab8.Text = 6) Or (Lab8.Text = 3))) Or ((((Lab1.Text = 2) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 2)) Or ((Lab1.Text = 5) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 5))) And ((Lab8.Text = 5) Or (Lab8.Text = 2))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
                End If
            ElseIf Lab8.Text = 7 Then
                If ((((Lab1.Text = 3) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 3)) Or ((Lab1.Text = 6) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 6))) And ((Lab9.Text = 6) Or (Lab9.Text = 3))) Or ((((Lab1.Text = 2) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 2)) Or ((Lab1.Text = 5) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 5))) And ((Lab9.Text = 5) Or (Lab9.Text = 2))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
                End If
            ElseIf Lab9.Text = 7 Then
                If ((((Lab1.Text = 3) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 3)) Or ((Lab1.Text = 3) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 3)) Or ((Lab2.Text = 3) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 3)) Or ((Lab1.Text = 6) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 6))) And ((Lab7.Text = 6) Or (Lab7.Text = 3))) Or ((((Lab1.Text = 2) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 2)) Or ((Lab1.Text = 2) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 2)) Or ((Lab2.Text = 2) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 2)) Or ((Lab1.Text = 5) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 5))) And ((Lab7.Text = 5) Or (Lab7.Text = 2))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
                End If
            End If
        ElseIf (((((Lab1.Text = 1) And (Lab2.Text = 4)) Or ((Lab1.Text = 4) And (Lab2.Text = 1))) And ((La1.Text = 1) And (La2.Text = 1))) Or ((((Lab1.Text = 1) And (Lab3.Text = 4)) Or ((Lab1.Text = 4) And (Lab3.Text = 1))) And ((La1.Text = 1) And (La3.Text = 1))) Or ((((Lab2.Text = 1) And (Lab3.Text = 4)) Or ((Lab2.Text = 4) And (Lab3.Text = 1))) And ((La2.Text = 1) And (La3.Text = 1)))) And ((Lab7.Text = 7) Or (Lab8.Text = 7) Or (Lab9.Text = 7)) Then
            If Lab7.Text = 7 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab8.Text = 7 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab9.Text = 7 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
            End If
        ElseIf (((((Lab1.Text = 1) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 1))) And ((La1.Text = 1) And (La2.Text = 1))) Or ((((Lab1.Text = 1) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 1))) And ((La1.Text = 1) And (La3.Text = 1))) Or ((((Lab2.Text = 1) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 1))) And ((La2.Text = 1) And (La3.Text = 1)))) And ((Lab7.Text = 4) Or (Lab8.Text = 4) Or (Lab9.Text = 4)) Then
            If Lab7.Text = 4 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab8.Text = 4 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab9.Text = 4 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
            End If
        ElseIf (((((Lab1.Text = 4) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 4))) And ((La1.Text = 1) And (La2.Text = 1))) Or ((((Lab1.Text = 4) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 4))) And ((La1.Text = 1) And (La3.Text = 1))) Or ((((Lab2.Text = 4) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 4))) And ((La2.Text = 1) And (La3.Text = 1)))) And ((Lab7.Text = 1) Or (Lab8.Text = 1) Or (Lab9.Text = 1)) Then
            If Lab7.Text = 1 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab8.Text = 1 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab9.Text = 1 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
            End If
        ElseIf (((((Lab1.Text = 2) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 2))) And ((La1.Text = 1) And (La2.Text = 1))) Or ((((Lab1.Text = 2) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 2))) And ((La1.Text = 1) And (La3.Text = 1))) Or ((((Lab2.Text = 2) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 2))) And ((La2.Text = 1) And (La3.Text = 1)))) And ((Lab7.Text = 8) Or (Lab8.Text = 8) Or (Lab9.Text = 8)) Then
            If Lab7.Text = 8 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab8.Text = 8 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab9.Text = 8 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
            End If
        ElseIf (((((Lab1.Text = 2) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 2))) And ((La1.Text = 1) And (La2.Text = 1))) Or ((((Lab1.Text = 2) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 2))) And ((La1.Text = 1) And (La3.Text = 1))) Or ((((Lab2.Text = 2) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 2))) And ((La2.Text = 1) And (La3.Text = 1)))) And ((Lab7.Text = 5) Or (Lab8.Text = 5) Or (Lab9.Text = 5)) Then
            If Lab7.Text = 5 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab8.Text = 5 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab9.Text = 5 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
            End If
        ElseIf (((((Lab1.Text = 5) And (Lab2.Text = 8)) Or ((Lab1.Text = 8) And (Lab2.Text = 5))) And ((La1.Text = 1) And (La2.Text = 1))) Or ((((Lab1.Text = 5) And (Lab3.Text = 8)) Or ((Lab1.Text = 8) And (Lab3.Text = 5))) And ((La1.Text = 1) And (La3.Text = 1))) Or ((((Lab2.Text = 5) And (Lab3.Text = 8)) Or ((Lab2.Text = 8) And (Lab3.Text = 5))) And ((La2.Text = 1) And (La3.Text = 1)))) And ((Lab7.Text = 2) Or (Lab8.Text = 2) Or (Lab9.Text = 2)) Then
            If Lab7.Text = 2 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab8.Text = 2 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab9.Text = 2 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
            End If
        ElseIf (((((Lab1.Text = 3) And (Lab2.Text = 6)) Or ((Lab1.Text = 6) And (Lab2.Text = 3))) And ((La1.Text = 1) And (La2.Text = 1))) Or ((((Lab1.Text = 3) And (Lab3.Text = 6)) Or ((Lab1.Text = 6) And (Lab3.Text = 3))) And ((La1.Text = 1) And (La3.Text = 1))) Or ((((Lab2.Text = 3) And (Lab3.Text = 6)) Or ((Lab2.Text = 6) And (Lab3.Text = 3))) And ((La2.Text = 1) And (La3.Text = 1)))) And ((Lab7.Text = 9) Or (Lab8.Text = 9) Or (Lab9.Text = 9)) Then
            If Lab7.Text = 9 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab8.Text = 9 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab9.Text = 9 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
            End If
        ElseIf (((((Lab1.Text = 3) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 3))) And ((La1.Text = 1) And (La2.Text = 1))) Or ((((Lab1.Text = 3) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 3))) And ((La1.Text = 1) And (La3.Text = 1))) Or ((((Lab2.Text = 3) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 3))) And ((La2.Text = 1) And (La3.Text = 1)))) And ((Lab7.Text = 6) Or (Lab8.Text = 6) Or (Lab9.Text = 6)) Then
            If Lab7.Text = 6 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab8.Text = 6 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab9.Text = 6 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
            End If
        ElseIf (((((Lab1.Text = 6) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 6))) And ((La1.Text = 1) And (La2.Text = 1))) Or ((((Lab1.Text = 6) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 6))) And ((La1.Text = 1) And (La3.Text = 1))) Or ((((Lab2.Text = 6) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 6))) And ((La2.Text = 1) And (La3.Text = 1)))) And ((Lab7.Text = 3) Or (Lab8.Text = 3) Or (Lab9.Text = 3)) Then
            If Lab7.Text = 3 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab8.Text = 3 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab9.Text = 3 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
            End If
        ElseIf (((((Lab1.Text = 1) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 1))) And ((La1.Text = 1) And (La2.Text = 1))) Or ((((Lab1.Text = 1) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 1))) And ((La1.Text = 1) And (La3.Text = 1))) Or ((((Lab2.Text = 1) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 1))) And ((La2.Text = 1) And (La3.Text = 1)))) And ((Lab7.Text = 9) Or (Lab8.Text = 9) Or (Lab9.Text = 9)) And (VaH.Checked = False) Then
            If Lab7.Text = 9 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab8.Text = 9 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab9.Text = 9 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
            End If
        ElseIf (((((Lab1.Text = 1) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 1))) And ((La1.Text = 1) And (La2.Text = 1))) Or ((((Lab1.Text = 1) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 1))) And ((La1.Text = 1) And (La3.Text = 1))) Or ((((Lab2.Text = 1) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 1))) And ((La2.Text = 1) And (La3.Text = 1)))) And ((Lab7.Text = 5) Or (Lab8.Text = 5) Or (Lab9.Text = 5)) And (VaH.Checked = False) Then
            If Lab7.Text = 5 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab8.Text = 5 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab9.Text = 5 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
            End If
        ElseIf (((((Lab1.Text = 5) And (Lab2.Text = 9)) Or ((Lab1.Text = 9) And (Lab2.Text = 5))) And ((La1.Text = 1) And (La2.Text = 1))) Or ((((Lab1.Text = 5) And (Lab3.Text = 9)) Or ((Lab1.Text = 9) And (Lab3.Text = 5))) And ((La1.Text = 1) And (La3.Text = 1))) Or ((((Lab2.Text = 5) And (Lab3.Text = 9)) Or ((Lab2.Text = 9) And (Lab3.Text = 5))) And ((La2.Text = 1) And (La3.Text = 1)))) And ((Lab7.Text = 1) Or (Lab8.Text = 1) Or (Lab9.Text = 1)) And (VaH.Checked = False) Then
            If Lab7.Text = 1 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab8.Text = 1 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab9.Text = 1 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
            End If
        ElseIf (((((Lab1.Text = 3) And (Lab2.Text = 5)) Or ((Lab1.Text = 5) And (Lab2.Text = 3))) And ((La1.Text = 1) And (La2.Text = 1))) Or ((((Lab1.Text = 3) And (Lab3.Text = 5)) Or ((Lab1.Text = 5) And (Lab3.Text = 3))) And ((La1.Text = 1) And (La3.Text = 1))) Or ((((Lab2.Text = 3) And (Lab3.Text = 5)) Or ((Lab2.Text = 5) And (Lab3.Text = 3))) And ((La2.Text = 1) And (La3.Text = 1)))) And ((Lab7.Text = 7) Or (Lab8.Text = 7) Or (Lab9.Text = 7)) And (VaH.Checked = False) Then
            If Lab7.Text = 7 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab8.Text = 7 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab9.Text = 7 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
            End If
        ElseIf (((((Lab1.Text = 3) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 3))) And ((La1.Text = 1) And (La2.Text = 1))) Or ((((Lab1.Text = 3) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 3))) And ((La1.Text = 1) And (La3.Text = 1))) Or ((((Lab2.Text = 3) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 3))) And ((La2.Text = 1) And (La3.Text = 1)))) And ((Lab7.Text = 5) Or (Lab8.Text = 5) Or (Lab9.Text = 5)) And (VaH.Checked = False) Then
            If Lab7.Text = 5 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab8.Text = 5 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab9.Text = 5 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
            End If
        ElseIf (((((Lab1.Text = 5) And (Lab2.Text = 7)) Or ((Lab1.Text = 7) And (Lab2.Text = 5))) And ((La1.Text = 1) And (La2.Text = 1))) Or ((((Lab1.Text = 5) And (Lab3.Text = 7)) Or ((Lab1.Text = 7) And (Lab3.Text = 5))) And ((La1.Text = 1) And (La3.Text = 1))) Or ((((Lab2.Text = 5) And (Lab3.Text = 7)) Or ((Lab2.Text = 7) And (Lab3.Text = 5))) And ((La2.Text = 1) And (La3.Text = 1)))) And ((Lab7.Text = 3) Or (Lab8.Text = 3) Or (Lab9.Text = 3)) And (VaH.Checked = False) Then
            If Lab7.Text = 3 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
            ElseIf Lab8.Text = 3 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
            ElseIf Lab9.Text = 3 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
            End If

        Else
            If ((La4.Text = 0) And (La5.Text = 0) And (La6.Text = 0)) Or ((La4.Text = 1) And (La5.Text = 1) And (La6.Text = 1)) Then
                If L4.Text = 1 Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
                ElseIf L4.Text = 2 Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab7.Text : Lab7.Text = rt.Text
                ElseIf L4.Text = 3 Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab7.Text : Lab7.Text = rt.Text
                ElseIf L4.Text = 4 Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
                ElseIf L4.Text = 5 Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab8.Text : Lab8.Text = rt.Text
                ElseIf L4.Text = 6 Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab8.Text : Lab8.Text = rt.Text
                ElseIf L4.Text = 7 Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
                ElseIf L4.Text = 8 Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
                ElseIf L4.Text = 9 Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
                End If
            Else
                If La4.Text = 0 Then
                    If (L4.Text = 1) Or (L4.Text = 2) Or (L4.Text = 3) Then
                        rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
                    ElseIf (L4.Text = 4) Or (L4.Text = 5) Or (L4.Text = 6) Then
                        rt.Text = Lab5.Text : Lab5.Text = Lab7.Text : Lab7.Text = rt.Text
                    ElseIf (L4.Text = 7) Or (L4.Text = 8) Or (L4.Text = 9) Then
                        rt.Text = Lab6.Text : Lab6.Text = Lab7.Text : Lab7.Text = rt.Text
                    End If
                ElseIf La5.Text = 0 Then
                    If (L4.Text = 1) Or (L4.Text = 2) Or (L4.Text = 3) Then
                        rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
                    ElseIf (L4.Text = 4) Or (L4.Text = 5) Or (L4.Text = 6) Then
                        rt.Text = Lab5.Text : Lab5.Text = Lab8.Text : Lab8.Text = rt.Text
                    ElseIf (L4.Text = 7) Or (L4.Text = 8) Or (L4.Text = 9) Then
                        rt.Text = Lab6.Text : Lab6.Text = Lab8.Text : Lab8.Text = rt.Text
                    End If
                ElseIf La6.Text = 0 Then
                    If (L4.Text = 1) Or (L4.Text = 2) Or (L4.Text = 3) Then
                        rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
                    ElseIf (L4.Text = 4) Or (L4.Text = 5) Or (L4.Text = 6) Then
                        rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
                    ElseIf (L4.Text = 7) Or (L4.Text = 8) Or (L4.Text = 9) Then
                        rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
                    End If
                End If
            End If
        End If
        L2.Text = 0
        stp2.Text = stp2.Text + 1
        If Lab7.Text = 1 Then
            c1.Location = New Point(78, 82)
        End If
        If Lab7.Text = 2 Then
            c1.Location = New Point(202, 82)
        End If
        If Lab7.Text = 3 Then
            c1.Location = New Point(323, 82)
        End If
        If Lab7.Text = 4 Then
            c1.Location = New Point(78, 200)
        End If
        If Lab7.Text = 5 Then
            c1.Location = New Point(202, 200)
        End If
        If Lab7.Text = 6 Then
            c1.Location = New Point(323, 200)
        End If
        If Lab7.Text = 7 Then
            c1.Location = New Point(78, 312)
        End If
        If Lab7.Text = 8 Then
            c1.Location = New Point(202, 312)
        End If
        If Lab7.Text = 9 Then
            c1.Location = New Point(323, 312)
        End If
        If Lab8.Text = 1 Then
            c2.Location = New Point(78, 82)
        End If
        If Lab8.Text = 2 Then
            c2.Location = New Point(202, 82)
        End If
        If Lab8.Text = 3 Then
            c2.Location = New Point(323, 82)
        End If
        If Lab8.Text = 4 Then
            c2.Location = New Point(78, 200)
        End If
        If Lab8.Text = 5 Then
            c2.Location = New Point(202, 200)
        End If
        If Lab8.Text = 6 Then
            c2.Location = New Point(323, 200)
        End If
        If Lab8.Text = 7 Then
            c2.Location = New Point(78, 312)
        End If
        If Lab8.Text = 8 Then
            c2.Location = New Point(202, 312)
        End If
        If Lab8.Text = 9 Then
            c2.Location = New Point(323, 312)
        End If
        If Lab9.Text = 1 Then
            c3.Location = New Point(78, 82)
        End If
        If Lab9.Text = 2 Then
            c3.Location = New Point(202, 82)
        End If
        If Lab9.Text = 3 Then
            c3.Location = New Point(323, 82)
        End If
        If Lab9.Text = 4 Then
            c3.Location = New Point(78, 200)
        End If
        If Lab9.Text = 5 Then
            c3.Location = New Point(202, 200)
        End If
        If Lab9.Text = 6 Then
            c3.Location = New Point(323, 200)
        End If
        If Lab9.Text = 7 Then
            c3.Location = New Point(78, 312)
        End If
        If Lab9.Text = 8 Then
            c3.Location = New Point(202, 312)
        End If
        If Lab9.Text = 9 Then
            c3.Location = New Point(323, 312)
        End If
        If Lab7.Text = Lb7.Text Then
        Else
            La4.Text = 1
            c1.BackgroundImage = My.Resources.cv
        End If
        If Lab8.Text = Lb8.Text Then
        Else
            La5.Text = 1
            c2.BackgroundImage = My.Resources.cv
        End If
        If Lab9.Text = Lb9.Text Then
        Else
            La6.Text = 1
            c3.BackgroundImage = My.Resources.cv
        End If
        If Lab4.Text = 1 Then
            a1.Location = New Point(78, 82)
        End If
        If Lab4.Text = 2 Then
            a1.Location = New Point(202, 82)
        End If
        If Lab4.Text = 3 Then
            a1.Location = New Point(323, 82)
        End If
        If Lab4.Text = 4 Then
            a1.Location = New Point(78, 200)
        End If
        If Lab4.Text = 5 Then
            a1.Location = New Point(202, 200)
        End If
        If Lab4.Text = 6 Then
            a1.Location = New Point(323, 200)
        End If
        If Lab4.Text = 7 Then
            a1.Location = New Point(78, 312)
        End If
        If Lab4.Text = 8 Then
            a1.Location = New Point(202, 312)
        End If
        If Lab4.Text = 9 Then
            a1.Location = New Point(323, 312)
        End If
        If Lab5.Text = 1 Then
            a2.Location = New Point(78, 82)
        End If
        If Lab5.Text = 2 Then
            a2.Location = New Point(202, 82)
        End If
        If Lab5.Text = 3 Then
            a2.Location = New Point(323, 82)
        End If
        If Lab5.Text = 4 Then
            a2.Location = New Point(78, 200)
        End If
        If Lab5.Text = 5 Then
            a2.Location = New Point(202, 200)
        End If
        If Lab5.Text = 6 Then
            a2.Location = New Point(323, 200)
        End If
        If Lab5.Text = 7 Then
            a2.Location = New Point(78, 312)
        End If
        If Lab5.Text = 8 Then
            a2.Location = New Point(202, 312)
        End If
        If Lab5.Text = 9 Then
            a2.Location = New Point(323, 312)
        End If
        If Lab6.Text = 1 Then
            a3.Location = New Point(78, 82)
        End If
        If Lab6.Text = 2 Then
            a3.Location = New Point(202, 82)
        End If
        If Lab6.Text = 3 Then
            a3.Location = New Point(323, 82)
        End If
        If Lab6.Text = 4 Then
            a3.Location = New Point(78, 200)
        End If
        If Lab6.Text = 5 Then
            a3.Location = New Point(202, 200)
        End If
        If Lab6.Text = 6 Then
            a3.Location = New Point(323, 200)
        End If
        If Lab6.Text = 7 Then
            a3.Location = New Point(78, 312)
        End If
        If Lab6.Text = 8 Then
            a3.Location = New Point(202, 312)
        End If
        If Lab6.Text = 9 Then
            a3.Location = New Point(323, 312)
        End If
        PB2.Visible = False : wt.Visible = False
        Wn(e)
        PB1.BackgroundImage = My.Resources.zx
        If T2.Interval = 1 Then
            T2.Interval = 250
        End If
        T3.Start()
    End Sub

    Private Sub T3_Tick(sender As Object, e As EventArgs) Handles T3.Tick
        If (Cmpt.Checked = True) And (Bu4.Visible = False) And (L2.Text = 1) Then
            If L3.Text = 2 Then
                If (La1.Text = 1 And La2.Text = 1 And La3.Text = 1) And (((Lab1.Text = 1 And Lab2.Text = 2 And Lab3.Text = 3) Or (Lab1.Text = 1 And Lab2.Text = 3 And Lab3.Text = 2) Or (Lab1.Text = 2 And Lab2.Text = 1 And Lab3.Text = 3) Or (Lab1.Text = 2 And Lab2.Text = 3 And Lab3.Text = 1) Or (Lab1.Text = 3 And Lab2.Text = 1 And Lab3.Text = 2) Or (Lab1.Text = 3 And Lab2.Text = 2 And Lab3.Text = 1) Or (Lab1.Text = 4 And Lab2.Text = 5 And Lab3.Text = 6) Or (Lab1.Text = 4 And Lab2.Text = 6 And Lab3.Text = 5) Or (Lab1.Text = 5 And Lab2.Text = 4 And Lab3.Text = 6) Or (Lab1.Text = 5 And Lab2.Text = 6 And Lab3.Text = 4) Or (Lab1.Text = 6 And Lab2.Text = 4 And Lab3.Text = 5) Or (Lab1.Text = 6 And Lab2.Text = 5 And Lab3.Text = 4) Or (Lab1.Text = 7 And Lab2.Text = 8 And Lab3.Text = 9) Or (Lab1.Text = 7 And Lab2.Text = 9 And Lab3.Text = 8) Or (Lab1.Text = 8 And Lab2.Text = 7 And Lab3.Text = 9) Or (Lab1.Text = 8 And Lab2.Text = 9 And Lab3.Text = 7) Or (Lab1.Text = 9 And Lab2.Text = 7 And Lab3.Text = 8) Or (Lab1.Text = 9 And Lab2.Text = 8 And Lab3.Text = 7) Or (Lab1.Text = 1 And Lab2.Text = 4 And Lab3.Text = 7) Or (Lab1.Text = 1 And Lab2.Text = 7 And Lab3.Text = 4) Or (Lab1.Text = 4 And Lab2.Text = 1 And Lab3.Text = 7) Or (Lab1.Text = 4 And Lab2.Text = 7 And Lab3.Text = 1) Or (Lab1.Text = 7 And Lab2.Text = 1 And Lab3.Text = 4) Or (Lab1.Text = 7 And Lab2.Text = 4 And Lab3.Text = 1) Or (Lab1.Text = 2 And Lab2.Text = 5 And Lab3.Text = 8) Or (Lab1.Text = 2 And Lab2.Text = 8 And Lab3.Text = 5) Or (Lab1.Text = 5 And Lab2.Text = 2 And Lab3.Text = 8) Or (Lab1.Text = 5 And Lab2.Text = 8 And Lab3.Text = 2) Or (Lab1.Text = 8 And Lab2.Text = 2 And Lab3.Text = 5) Or (Lab1.Text = 8 And Lab2.Text = 5 And Lab3.Text = 2) Or (Lab1.Text = 3 And Lab2.Text = 6 And Lab3.Text = 9) Or (Lab1.Text = 3 And Lab2.Text = 9 And Lab3.Text = 6) Or (Lab1.Text = 6 And Lab2.Text = 3 And Lab3.Text = 9) Or (Lab1.Text = 6 And Lab2.Text = 9 And Lab3.Text = 3) Or (Lab1.Text = 9 And Lab2.Text = 3 And Lab3.Text = 6) Or (Lab1.Text = 9 And Lab2.Text = 6 And Lab3.Text = 3)) Or ((VaH.Checked = False) And ((Lab1.Text = 1 And Lab2.Text = 5 And Lab3.Text = 9) Or (Lab1.Text = 1 And Lab2.Text = 9 And Lab3.Text = 5) Or (Lab1.Text = 5 And Lab2.Text = 1 And Lab3.Text = 9) Or (Lab1.Text = 5 And Lab2.Text = 9 And Lab3.Text = 1) Or (Lab1.Text = 9 And Lab2.Text = 1 And Lab3.Text = 5) Or (Lab1.Text = 9 And Lab2.Text = 5 And Lab3.Text = 1) Or (Lab1.Text = 3 And Lab2.Text = 5 And Lab3.Text = 7) Or (Lab1.Text = 3 And Lab2.Text = 7 And Lab3.Text = 5) Or (Lab1.Text = 5 And Lab2.Text = 3 And Lab3.Text = 7) Or (Lab1.Text = 5 And Lab2.Text = 7 And Lab3.Text = 3) Or (Lab1.Text = 7 And Lab2.Text = 3 And Lab3.Text = 5) Or (Lab1.Text = 7 And Lab2.Text = 5 And Lab3.Text = 3)))) Then
                Else
                    PB2.Visible = True
                    wt.Visible = True
                    T3.Stop()
                    T2.Start()
                End If
            Else
                If L3.Text = 0 Then
                    PB2.Visible = True
                    wt.Visible = True
                    T3.Stop()
                    T2.Start()
                End If
            End If
        End If
        If (Cmpt2.Checked = True) And (Bu4.Visible = False) And (L2.Text = 0) Then
            If L3.Text = 2 Then
                If (La4.Text = 1 And La5.Text = 1 And La6.Text = 1) And (((Lab7.Text = 1 And Lab8.Text = 2 And Lab9.Text = 3) Or (Lab7.Text = 1 And Lab8.Text = 3 And Lab9.Text = 2) Or (Lab7.Text = 2 And Lab8.Text = 1 And Lab9.Text = 3) Or (Lab7.Text = 2 And Lab8.Text = 3 And Lab9.Text = 1) Or (Lab7.Text = 3 And Lab8.Text = 1 And Lab9.Text = 2) Or (Lab7.Text = 3 And Lab8.Text = 2 And Lab9.Text = 1) Or (Lab7.Text = 4 And Lab8.Text = 5 And Lab9.Text = 6) Or (Lab7.Text = 4 And Lab8.Text = 6 And Lab9.Text = 5) Or (Lab7.Text = 5 And Lab8.Text = 4 And Lab9.Text = 6) Or (Lab7.Text = 5 And Lab8.Text = 6 And Lab9.Text = 4) Or (Lab7.Text = 6 And Lab8.Text = 4 And Lab9.Text = 5) Or (Lab7.Text = 6 And Lab8.Text = 5 And Lab9.Text = 4) Or (Lab7.Text = 7 And Lab8.Text = 8 And Lab9.Text = 9) Or (Lab7.Text = 7 And Lab8.Text = 9 And Lab9.Text = 8) Or (Lab7.Text = 8 And Lab8.Text = 7 And Lab9.Text = 9) Or (Lab7.Text = 8 And Lab8.Text = 9 And Lab9.Text = 7) Or (Lab7.Text = 9 And Lab8.Text = 7 And Lab9.Text = 8) Or (Lab7.Text = 9 And Lab8.Text = 8 And Lab9.Text = 7) Or (Lab7.Text = 1 And Lab8.Text = 4 And Lab9.Text = 7) Or (Lab7.Text = 1 And Lab8.Text = 7 And Lab9.Text = 4) Or (Lab7.Text = 4 And Lab8.Text = 1 And Lab9.Text = 7) Or (Lab7.Text = 4 And Lab8.Text = 7 And Lab9.Text = 1) Or (Lab7.Text = 7 And Lab8.Text = 1 And Lab9.Text = 4) Or (Lab7.Text = 7 And Lab8.Text = 4 And Lab9.Text = 1) Or (Lab7.Text = 2 And Lab8.Text = 5 And Lab9.Text = 8) Or (Lab7.Text = 2 And Lab8.Text = 8 And Lab9.Text = 5) Or (Lab7.Text = 5 And Lab8.Text = 2 And Lab9.Text = 8) Or (Lab7.Text = 5 And Lab8.Text = 8 And Lab9.Text = 2) Or (Lab7.Text = 8 And Lab8.Text = 2 And Lab9.Text = 5) Or (Lab7.Text = 8 And Lab8.Text = 5 And Lab9.Text = 2) Or (Lab7.Text = 3 And Lab8.Text = 6 And Lab9.Text = 9) Or (Lab7.Text = 3 And Lab8.Text = 9 And Lab9.Text = 6) Or (Lab7.Text = 6 And Lab8.Text = 3 And Lab9.Text = 9) Or (Lab7.Text = 6 And Lab8.Text = 9 And Lab9.Text = 3) Or (Lab7.Text = 9 And Lab8.Text = 3 And Lab9.Text = 6) Or (Lab7.Text = 9 And Lab8.Text = 6 And Lab9.Text = 3)) Or ((VaH.Checked = False) And ((Lab7.Text = 1 And Lab8.Text = 5 And Lab9.Text = 9) Or (Lab7.Text = 1 And Lab8.Text = 9 And Lab9.Text = 5) Or (Lab7.Text = 5 And Lab8.Text = 1 And Lab9.Text = 9) Or (Lab7.Text = 5 And Lab8.Text = 9 And Lab9.Text = 1) Or (Lab7.Text = 9 And Lab8.Text = 1 And Lab9.Text = 5) Or (Lab7.Text = 9 And Lab8.Text = 5 And Lab9.Text = 1) Or (Lab7.Text = 3 And Lab8.Text = 5 And Lab9.Text = 7) Or (Lab7.Text = 3 And Lab8.Text = 7 And Lab9.Text = 5) Or (Lab7.Text = 5 And Lab8.Text = 3 And Lab9.Text = 7) Or (Lab7.Text = 5 And Lab8.Text = 7 And Lab9.Text = 3) Or (Lab7.Text = 7 And Lab8.Text = 3 And Lab9.Text = 5) Or (Lab7.Text = 7 And Lab8.Text = 5 And Lab9.Text = 3)))) Then
                Else
                    PB3.Visible = True
                    wt2.Visible = True
                    T3.Stop()
                    T4.Start()
                End If
            Else
                If L3.Text = 1 Then
                    PB3.Visible = True
                    wt2.Visible = True
                    T3.Stop()
                    T4.Start()
                End If
            End If
        End If
        If L4.Text = 1 Then
            L4.Text = 2
        ElseIf L4.Text = 2 Then
            L4.Text = 3
        ElseIf L4.Text = 3 Then
            L4.Text = 4
        ElseIf L4.Text = 4 Then
            L4.Text = 5
        ElseIf L4.Text = 5 Then
            L4.Text = 6
        ElseIf L4.Text = 6 Then
            L4.Text = 7
        ElseIf L4.Text = 7 Then
            L4.Text = 8
        ElseIf L4.Text = 8 Then
            L4.Text = 9
        ElseIf L4.Text = 9 Then
            L4.Text = 1
        End If
    End Sub

    Private Sub Bu6_Click(sender As Object, e As EventArgs) Handles Bu6.Click
        If sfh.Text = "1" Then
            Bu1.Visible = False
            Bu2.Visible = False
            Bu3.Visible = False
            Bu7.Visible = True
            Bu8.Visible = True
            sfh.Text = "2"
        ElseIf sfh.Text = "2" Then
            Bu6.Visible = False
            Bu8.Visible = False
            Bu5.Visible = True
            sfh.Text = "3"
        End If
    End Sub

    Private Sub Bu7_Click(sender As Object, e As EventArgs) Handles Bu7.Click
        If sfh.Text = "2" Then
            Bu7.Visible = False
            Bu8.Visible = False
            Bu1.Visible = True
            Bu2.Visible = True
            Bu3.Visible = True
            sfh.Text = "1"
        ElseIf sfh.Text = "3" Then
            Bu5.Visible = False
            Bu6.Visible = True
            Bu8.Visible = True
            sfh.Text = "2"
        End If
    End Sub

    Private Sub Bu5_Click(sender As Object, e As EventArgs) Handles Bu5.Click
        If Bu8.Text = "عربي" Then
            MsgBox("- If you want to play with the keyboard, Press the 1, 2, 3, 4, 5, 6, 7, 8, 9, z, x, c, a, s, d, q, w or e buttons.
- Use numbers and letters on the keyboard as if they were game boxes.
- If you want to continue playing with the keyboard, Do not press the writing boxes.", vbInformation, "How ?!")
        Else
            MsgBox("- لو اردت اللعب بلوحة المفاتيح، إضغط على ازرار 1، 2، 3، 4، 5، 6، 7، 8، 9، ئ، ء، ؤ، ش، س، ي، ض، ص او ث.
- إستخدم الأرقام والحروف التي في لوحة المفاتيح كما لو كانت مربعات اللعبة.
- لو اردت الاستمرار في اللعب بلوحة المفاتيح، لا تضغط على مربعات الكتابة.", vbInformation + vbMsgBoxRight + vbMsgBoxRtlReading, "كيف؟!")
        End If

    End Sub

    Private Sub Bu8_Click(sender As Object, e As EventArgs) Handles Bu8.Click
        If Bu8.Text = "عربي" Then
            Bu1.Text = "حول"
            Bu2.Text = "إعادة بدء"
            Bu3.Text = "إعادة بدء الكل"
            If Bu4.Text = "Start" Then
                Bu4.Text = "إبدأ"
            Else
                Bu4.Text = "توقف"
            End If
            Bu5.Text = "كيفية إستخدام لوحة المفاتيح للعب"
            Bu8.Text = "English"
            VaH.Text = "عمودي وأفقي فقط"
            NoS.Text = "خطوات كلا اللاعبين تكون متساوية"
            Cmpt.Text = "الحاسوب"
            Cmpt2.Text = "الحاسوب"
            wt.Text = "...إنتظر"
            wt2.Text = "...إنتظر"
            Sega2.Text = "حول"
            Sega2.ckh.Text = "إضغط هنا  لتحميل آخر إصدار من اللعبة"
            Sega2.ckh.Location = New Point(120, 9)
        Else
            Bu1.Text = "About"
            Bu2.Text = "Restart"
            Bu3.Text = "Restart All"
            If Bu4.Text = "إبدأ" Then
                Bu4.Text = "Start"
            Else
                Bu4.Text = "Stop"
            End If
            Bu5.Text = "How to use the keyboard to play"
            Bu8.Text = "عربي"
            VaH.Text = "Vertical and Horizontal only"
            NoS.Text = "The steps of both players be equal"
            Cmpt.Text = "Computer"
            Cmpt2.Text = "Computer"
            wt.Text = "Wait..."
            wt2.Text = "Wait..."
            Sega2.Text = "About"
            Sega2.ckh.Text = "Click here  to download the latest version of the game"
            Sega2.ckh.Location = New Point(58, 9)
        End If
    End Sub

    Private Sub T4_Tick(sender As Object, e As EventArgs) Handles T4.Tick
        T4.Stop()
        If (((Lab1.Text = 1) And (Lab2.Text = 2)) Or ((Lab2.Text = 1) And (Lab1.Text = 2))) And ((Lab4.Text = 3) Or (Lab5.Text = 3) Or (Lab6.Text = 3)) And ((La1.Text = 1) And (La2.Text = 1)) Then
            If Lab4.Text = 3 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab5.Text = 3 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab6.Text = 3 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
            End If
        ElseIf (((Lab1.Text = 1) And (Lab3.Text = 2)) Or ((Lab3.Text = 1) And (Lab1.Text = 2))) And ((Lab4.Text = 3) Or (Lab5.Text = 3) Or (Lab6.Text = 3)) And ((La1.Text = 1) And (La3.Text = 1)) Then
            If Lab4.Text = 3 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab5.Text = 3 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab6.Text = 3 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab2.Text : Lab2.Text = rt.Text
            End If
        ElseIf (((Lab2.Text = 1) And (Lab3.Text = 2)) Or ((Lab3.Text = 1) And (Lab2.Text = 2))) And ((Lab4.Text = 3) Or (Lab5.Text = 3) Or (Lab6.Text = 3)) And ((La2.Text = 1) And (La3.Text = 1)) Then
            If Lab4.Text = 3 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
            ElseIf Lab5.Text = 3 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab1.Text : Lab1.Text = rt.Text
            ElseIf Lab6.Text = 3 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab1.Text : Lab1.Text = rt.Text
            End If
        ElseIf (((Lab1.Text = 1) And (Lab2.Text = 3)) Or ((Lab2.Text = 1) And (Lab1.Text = 3))) And ((Lab4.Text = 2) Or (Lab5.Text = 2) Or (Lab6.Text = 2)) And ((La1.Text = 1) And (La2.Text = 1)) Then
            If Lab4.Text = 2 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab5.Text = 2 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab6.Text = 2 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
            End If
        ElseIf (((Lab1.Text = 1) And (Lab3.Text = 3)) Or ((Lab3.Text = 1) And (Lab1.Text = 3))) And ((Lab4.Text = 2) Or (Lab5.Text = 2) Or (Lab6.Text = 2)) And ((La1.Text = 1) And (La3.Text = 1)) Then
            If Lab4.Text = 2 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab5.Text = 2 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab6.Text = 2 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab2.Text : Lab2.Text = rt.Text
            End If
        ElseIf (((Lab2.Text = 1) And (Lab3.Text = 3)) Or ((Lab3.Text = 1) And (Lab2.Text = 3))) And ((Lab4.Text = 2) Or (Lab5.Text = 2) Or (Lab6.Text = 2)) And ((La2.Text = 1) And (La3.Text = 1)) Then
            If Lab4.Text = 2 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
            ElseIf Lab5.Text = 2 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab1.Text : Lab1.Text = rt.Text
            ElseIf Lab6.Text = 2 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab1.Text : Lab1.Text = rt.Text
            End If
        ElseIf (((Lab1.Text = 2) And (Lab2.Text = 3)) Or ((Lab2.Text = 2) And (Lab1.Text = 3))) And ((Lab4.Text = 1) Or (Lab5.Text = 1) Or (Lab6.Text = 1)) And ((La1.Text = 1) And (La2.Text = 1)) Then
            If Lab4.Text = 1 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab5.Text = 1 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab6.Text = 1 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
            End If
        ElseIf (((Lab1.Text = 2) And (Lab3.Text = 3)) Or ((Lab3.Text = 2) And (Lab1.Text = 3))) And ((Lab4.Text = 1) Or (Lab5.Text = 1) Or (Lab6.Text = 1)) And ((La1.Text = 1) And (La3.Text = 1)) Then
            If Lab4.Text = 1 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab5.Text = 1 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab6.Text = 1 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab2.Text : Lab2.Text = rt.Text
            End If
        ElseIf (((Lab2.Text = 2) And (Lab3.Text = 3)) Or ((Lab3.Text = 2) And (Lab2.Text = 3))) And ((Lab4.Text = 1) Or (Lab5.Text = 1) Or (Lab6.Text = 1)) And ((La2.Text = 1) And (La3.Text = 1)) Then
            If Lab4.Text = 1 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
            ElseIf Lab5.Text = 1 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab1.Text : Lab1.Text = rt.Text
            ElseIf Lab6.Text = 1 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab1.Text : Lab1.Text = rt.Text
            End If
        ElseIf (((Lab1.Text = 4) And (Lab2.Text = 5)) Or ((Lab2.Text = 4) And (Lab1.Text = 5))) And ((Lab4.Text = 6) Or (Lab5.Text = 6) Or (Lab6.Text = 6)) And ((La1.Text = 1) And (La2.Text = 1)) Then
            If Lab4.Text = 6 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab5.Text = 6 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab6.Text = 6 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
            End If
        ElseIf (((Lab1.Text = 4) And (Lab3.Text = 5)) Or ((Lab3.Text = 4) And (Lab1.Text = 5))) And ((Lab4.Text = 6) Or (Lab5.Text = 6) Or (Lab6.Text = 6)) And ((La1.Text = 1) And (La3.Text = 1)) Then
            If Lab4.Text = 6 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab5.Text = 6 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab6.Text = 6 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab2.Text : Lab2.Text = rt.Text
            End If
        ElseIf (((Lab2.Text = 4) And (Lab3.Text = 5)) Or ((Lab3.Text = 4) And (Lab2.Text = 5))) And ((Lab4.Text = 6) Or (Lab5.Text = 6) Or (Lab6.Text = 6)) And ((La2.Text = 1) And (La3.Text = 1)) Then
            If Lab4.Text = 6 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
            ElseIf Lab5.Text = 6 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab1.Text : Lab1.Text = rt.Text
            ElseIf Lab6.Text = 6 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab1.Text : Lab1.Text = rt.Text
            End If
        ElseIf (((Lab1.Text = 4) And (Lab2.Text = 6)) Or ((Lab2.Text = 4) And (Lab1.Text = 6))) And ((Lab4.Text = 5) Or (Lab5.Text = 5) Or (Lab6.Text = 5)) And ((La1.Text = 1) And (La2.Text = 1)) Then
            If Lab4.Text = 5 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab5.Text = 5 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab6.Text = 5 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
            End If
        ElseIf (((Lab1.Text = 4) And (Lab3.Text = 6)) Or ((Lab3.Text = 4) And (Lab1.Text = 6))) And ((Lab4.Text = 5) Or (Lab5.Text = 5) Or (Lab6.Text = 5)) And ((La1.Text = 1) And (La3.Text = 1)) Then
            If Lab4.Text = 5 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab5.Text = 5 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab6.Text = 5 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab2.Text : Lab2.Text = rt.Text
            End If
        ElseIf (((Lab2.Text = 4) And (Lab3.Text = 6)) Or ((Lab3.Text = 4) And (Lab2.Text = 6))) And ((Lab4.Text = 5) Or (Lab5.Text = 5) Or (Lab6.Text = 5)) And ((La2.Text = 1) And (La3.Text = 1)) Then
            If Lab4.Text = 5 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
            ElseIf Lab5.Text = 5 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab1.Text : Lab1.Text = rt.Text
            ElseIf Lab6.Text = 5 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab1.Text : Lab1.Text = rt.Text
            End If
        ElseIf (((Lab1.Text = 5) And (Lab2.Text = 6)) Or ((Lab2.Text = 5) And (Lab1.Text = 6))) And ((Lab4.Text = 4) Or (Lab5.Text = 4) Or (Lab6.Text = 4)) And ((La1.Text = 1) And (La2.Text = 1)) Then
            If Lab4.Text = 4 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab5.Text = 4 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab6.Text = 4 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
            End If
        ElseIf (((Lab1.Text = 5) And (Lab3.Text = 6)) Or ((Lab3.Text = 5) And (Lab1.Text = 6))) And ((Lab4.Text = 4) Or (Lab5.Text = 4) Or (Lab6.Text = 4)) And ((La1.Text = 1) And (La3.Text = 1)) Then
            If Lab4.Text = 4 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab5.Text = 4 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab6.Text = 4 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab2.Text : Lab2.Text = rt.Text
            End If
        ElseIf (((Lab2.Text = 5) And (Lab3.Text = 6)) Or ((Lab3.Text = 5) And (Lab2.Text = 6))) And ((Lab4.Text = 4) Or (Lab5.Text = 4) Or (Lab6.Text = 4)) And ((La2.Text = 1) And (La3.Text = 1)) Then
            If Lab4.Text = 4 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
            ElseIf Lab5.Text = 4 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab1.Text : Lab1.Text = rt.Text
            ElseIf Lab6.Text = 4 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab1.Text : Lab1.Text = rt.Text
            End If
        ElseIf (((Lab1.Text = 7) And (Lab2.Text = 8)) Or ((Lab2.Text = 7) And (Lab1.Text = 8))) And ((Lab4.Text = 9) Or (Lab5.Text = 9) Or (Lab6.Text = 9)) And ((La1.Text = 1) And (La2.Text = 1)) Then
            If Lab4.Text = 9 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab5.Text = 9 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab6.Text = 9 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
            End If
        ElseIf (((Lab1.Text = 7) And (Lab3.Text = 8)) Or ((Lab3.Text = 7) And (Lab1.Text = 8))) And ((Lab4.Text = 9) Or (Lab5.Text = 9) Or (Lab6.Text = 9)) And ((La1.Text = 1) And (La3.Text = 1)) Then
            If Lab4.Text = 9 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab5.Text = 9 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab6.Text = 9 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab2.Text : Lab2.Text = rt.Text
            End If
        ElseIf (((Lab2.Text = 7) And (Lab3.Text = 8)) Or ((Lab3.Text = 7) And (Lab2.Text = 8))) And ((Lab4.Text = 9) Or (Lab5.Text = 9) Or (Lab6.Text = 9)) And ((La2.Text = 1) And (La3.Text = 1)) Then
            If Lab4.Text = 9 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
            ElseIf Lab5.Text = 9 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab1.Text : Lab1.Text = rt.Text
            ElseIf Lab6.Text = 9 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab1.Text : Lab1.Text = rt.Text
            End If
        ElseIf (((Lab1.Text = 7) And (Lab2.Text = 9)) Or ((Lab2.Text = 7) And (Lab1.Text = 9))) And ((Lab4.Text = 8) Or (Lab5.Text = 8) Or (Lab6.Text = 8)) And ((La1.Text = 1) And (La2.Text = 1)) Then
            If Lab4.Text = 8 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab5.Text = 8 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab6.Text = 8 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
            End If
        ElseIf (((Lab1.Text = 7) And (Lab3.Text = 9)) Or ((Lab3.Text = 7) And (Lab1.Text = 9))) And ((Lab4.Text = 8) Or (Lab5.Text = 8) Or (Lab6.Text = 8)) And ((La1.Text = 1) And (La3.Text = 1)) Then
            If Lab4.Text = 8 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab5.Text = 8 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab6.Text = 8 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab2.Text : Lab2.Text = rt.Text
            End If
        ElseIf (((Lab2.Text = 7) And (Lab3.Text = 9)) Or ((Lab3.Text = 7) And (Lab2.Text = 9))) And ((Lab4.Text = 8) Or (Lab5.Text = 8) Or (Lab6.Text = 8)) And ((La2.Text = 1) And (La3.Text = 1)) Then
            If Lab4.Text = 8 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
            ElseIf Lab5.Text = 8 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab1.Text : Lab1.Text = rt.Text
            ElseIf Lab6.Text = 8 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab1.Text : Lab1.Text = rt.Text
            End If
        ElseIf (((Lab1.Text = 8) And (Lab2.Text = 9)) Or ((Lab2.Text = 8) And (Lab1.Text = 9))) And ((Lab4.Text = 7) Or (Lab5.Text = 7) Or (Lab6.Text = 7)) And ((La1.Text = 1) And (La2.Text = 1)) Then
            If Lab4.Text = 7 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab5.Text = 7 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab6.Text = 7 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
            End If
        ElseIf (((Lab1.Text = 8) And (Lab3.Text = 9)) Or ((Lab3.Text = 8) And (Lab1.Text = 9))) And ((Lab4.Text = 7) Or (Lab5.Text = 7) Or (Lab6.Text = 7)) And ((La1.Text = 1) And (La3.Text = 1)) Then
            If Lab4.Text = 7 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab5.Text = 7 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab6.Text = 7 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab2.Text : Lab2.Text = rt.Text
            End If
        ElseIf (((Lab2.Text = 8) And (Lab3.Text = 9)) Or ((Lab3.Text = 8) And (Lab2.Text = 9))) And ((Lab4.Text = 7) Or (Lab5.Text = 7) Or (Lab6.Text = 7)) And ((La2.Text = 1) And (La3.Text = 1)) Then
            If Lab4.Text = 7 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
            ElseIf Lab5.Text = 7 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab1.Text : Lab1.Text = rt.Text
            ElseIf Lab6.Text = 7 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab1.Text : Lab1.Text = rt.Text
            End If
        ElseIf (((Lab1.Text = 1) And (Lab2.Text = 4)) Or ((Lab2.Text = 1) And (Lab1.Text = 4))) And ((Lab4.Text = 7) Or (Lab5.Text = 7) Or (Lab6.Text = 7)) And ((La1.Text = 1) And (La2.Text = 1)) Then
            If Lab4.Text = 7 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab5.Text = 7 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab6.Text = 7 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
            End If
        ElseIf (((Lab1.Text = 1) And (Lab3.Text = 4)) Or ((Lab3.Text = 1) And (Lab1.Text = 4))) And ((Lab4.Text = 7) Or (Lab5.Text = 7) Or (Lab6.Text = 7)) And ((La1.Text = 1) And (La3.Text = 1)) Then
            If Lab4.Text = 7 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab5.Text = 7 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab6.Text = 7 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab2.Text : Lab2.Text = rt.Text
            End If
        ElseIf (((Lab2.Text = 1) And (Lab3.Text = 4)) Or ((Lab3.Text = 1) And (Lab2.Text = 4))) And ((Lab4.Text = 7) Or (Lab5.Text = 7) Or (Lab6.Text = 7)) And ((La2.Text = 1) And (La3.Text = 1)) Then
            If Lab4.Text = 7 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
            ElseIf Lab5.Text = 7 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab1.Text : Lab1.Text = rt.Text
            ElseIf Lab6.Text = 7 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab1.Text : Lab1.Text = rt.Text
            End If
        ElseIf (((Lab1.Text = 1) And (Lab2.Text = 7)) Or ((Lab2.Text = 1) And (Lab1.Text = 7))) And ((Lab4.Text = 4) Or (Lab5.Text = 4) Or (Lab6.Text = 4)) And ((La1.Text = 1) And (La2.Text = 1)) Then
            If Lab4.Text = 4 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab5.Text = 4 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab6.Text = 4 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
            End If
        ElseIf (((Lab1.Text = 1) And (Lab3.Text = 7)) Or ((Lab3.Text = 1) And (Lab1.Text = 7))) And ((Lab4.Text = 4) Or (Lab5.Text = 4) Or (Lab6.Text = 4)) And ((La1.Text = 1) And (La3.Text = 1)) Then
            If Lab4.Text = 4 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab5.Text = 4 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab6.Text = 4 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab2.Text : Lab2.Text = rt.Text
            End If
        ElseIf (((Lab2.Text = 1) And (Lab3.Text = 7)) Or ((Lab3.Text = 1) And (Lab2.Text = 7))) And ((Lab4.Text = 4) Or (Lab5.Text = 4) Or (Lab6.Text = 4)) And ((La2.Text = 1) And (La3.Text = 1)) Then
            If Lab4.Text = 4 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
            ElseIf Lab5.Text = 4 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab1.Text : Lab1.Text = rt.Text
            ElseIf Lab6.Text = 4 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab1.Text : Lab1.Text = rt.Text
            End If
        ElseIf (((Lab1.Text = 4) And (Lab2.Text = 7)) Or ((Lab2.Text = 4) And (Lab1.Text = 7))) And ((Lab4.Text = 1) Or (Lab5.Text = 1) Or (Lab6.Text = 1)) And ((La1.Text = 1) And (La2.Text = 1)) Then
            If Lab4.Text = 1 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab5.Text = 1 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab6.Text = 1 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
            End If
        ElseIf (((Lab1.Text = 4) And (Lab3.Text = 7)) Or ((Lab3.Text = 4) And (Lab1.Text = 7))) And ((Lab4.Text = 1) Or (Lab5.Text = 1) Or (Lab6.Text = 1)) And ((La1.Text = 1) And (La3.Text = 1)) Then
            If Lab4.Text = 1 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab5.Text = 1 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab6.Text = 1 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab2.Text : Lab2.Text = rt.Text
            End If
        ElseIf (((Lab2.Text = 4) And (Lab3.Text = 7)) Or ((Lab3.Text = 4) And (Lab2.Text = 7))) And ((Lab4.Text = 1) Or (Lab5.Text = 1) Or (Lab6.Text = 1)) And ((La2.Text = 1) And (La3.Text = 1)) Then
            If Lab4.Text = 1 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
            ElseIf Lab5.Text = 1 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab1.Text : Lab1.Text = rt.Text
            ElseIf Lab6.Text = 1 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab1.Text : Lab1.Text = rt.Text
            End If
        ElseIf (((Lab1.Text = 2) And (Lab2.Text = 5)) Or ((Lab2.Text = 2) And (Lab1.Text = 5))) And ((Lab4.Text = 8) Or (Lab5.Text = 8) Or (Lab6.Text = 8)) And ((La1.Text = 1) And (La2.Text = 1)) Then
            If Lab4.Text = 8 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab5.Text = 8 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab6.Text = 8 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
            End If
        ElseIf (((Lab1.Text = 2) And (Lab3.Text = 5)) Or ((Lab3.Text = 2) And (Lab1.Text = 5))) And ((Lab4.Text = 8) Or (Lab5.Text = 8) Or (Lab6.Text = 8)) And ((La1.Text = 1) And (La3.Text = 1)) Then
            If Lab4.Text = 8 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab5.Text = 8 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab6.Text = 8 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab2.Text : Lab2.Text = rt.Text
            End If
        ElseIf (((Lab2.Text = 2) And (Lab3.Text = 5)) Or ((Lab3.Text = 2) And (Lab2.Text = 5))) And ((Lab4.Text = 8) Or (Lab5.Text = 8) Or (Lab6.Text = 8)) And ((La2.Text = 1) And (La3.Text = 1)) Then
            If Lab4.Text = 8 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
            ElseIf Lab5.Text = 8 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab1.Text : Lab1.Text = rt.Text
            ElseIf Lab6.Text = 8 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab1.Text : Lab1.Text = rt.Text
            End If
        ElseIf (((Lab1.Text = 2) And (Lab2.Text = 8)) Or ((Lab2.Text = 2) And (Lab1.Text = 8))) And ((Lab4.Text = 5) Or (Lab5.Text = 5) Or (Lab6.Text = 5)) And ((La1.Text = 1) And (La2.Text = 1)) Then
            If Lab4.Text = 5 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab5.Text = 5 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab6.Text = 5 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
            End If
        ElseIf (((Lab1.Text = 2) And (Lab3.Text = 8)) Or ((Lab3.Text = 2) And (Lab1.Text = 8))) And ((Lab4.Text = 5) Or (Lab5.Text = 5) Or (Lab6.Text = 5)) And ((La1.Text = 1) And (La3.Text = 1)) Then
            If Lab4.Text = 5 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab5.Text = 5 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab6.Text = 5 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab2.Text : Lab2.Text = rt.Text
            End If
        ElseIf (((Lab2.Text = 2) And (Lab3.Text = 8)) Or ((Lab3.Text = 2) And (Lab2.Text = 8))) And ((Lab4.Text = 5) Or (Lab5.Text = 5) Or (Lab6.Text = 5)) And ((La2.Text = 1) And (La3.Text = 1)) Then
            If Lab4.Text = 5 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
            ElseIf Lab5.Text = 5 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab1.Text : Lab1.Text = rt.Text
            ElseIf Lab6.Text = 5 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab1.Text : Lab1.Text = rt.Text
            End If
        ElseIf (((Lab1.Text = 5) And (Lab2.Text = 8)) Or ((Lab2.Text = 5) And (Lab1.Text = 8))) And ((Lab4.Text = 2) Or (Lab5.Text = 2) Or (Lab6.Text = 2)) And ((La1.Text = 1) And (La2.Text = 1)) Then
            If Lab4.Text = 2 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab5.Text = 2 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab6.Text = 2 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
            End If
        ElseIf (((Lab1.Text = 5) And (Lab3.Text = 8)) Or ((Lab3.Text = 5) And (Lab1.Text = 8))) And ((Lab4.Text = 2) Or (Lab5.Text = 2) Or (Lab6.Text = 2)) And ((La1.Text = 1) And (La3.Text = 1)) Then
            If Lab4.Text = 2 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab5.Text = 2 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab6.Text = 2 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab2.Text : Lab2.Text = rt.Text
            End If
        ElseIf (((Lab2.Text = 5) And (Lab3.Text = 8)) Or ((Lab3.Text = 5) And (Lab2.Text = 8))) And ((Lab4.Text = 2) Or (Lab5.Text = 2) Or (Lab6.Text = 2)) And ((La2.Text = 1) And (La3.Text = 1)) Then
            If Lab4.Text = 2 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
            ElseIf Lab5.Text = 2 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab1.Text : Lab1.Text = rt.Text
            ElseIf Lab6.Text = 2 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab1.Text : Lab1.Text = rt.Text
            End If
        ElseIf (((Lab1.Text = 3) And (Lab2.Text = 6)) Or ((Lab2.Text = 3) And (Lab1.Text = 6))) And ((Lab4.Text = 9) Or (Lab5.Text = 9) Or (Lab6.Text = 9)) And ((La1.Text = 1) And (La2.Text = 1)) Then
            If Lab4.Text = 9 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab5.Text = 9 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab6.Text = 9 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
            End If
        ElseIf (((Lab1.Text = 3) And (Lab3.Text = 6)) Or ((Lab3.Text = 3) And (Lab1.Text = 6))) And ((Lab4.Text = 9) Or (Lab5.Text = 9) Or (Lab6.Text = 9)) And ((La1.Text = 1) And (La3.Text = 1)) Then
            If Lab4.Text = 9 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab5.Text = 9 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab6.Text = 9 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab2.Text : Lab2.Text = rt.Text
            End If
        ElseIf (((Lab2.Text = 3) And (Lab3.Text = 6)) Or ((Lab3.Text = 3) And (Lab2.Text = 6))) And ((Lab4.Text = 9) Or (Lab5.Text = 9) Or (Lab6.Text = 9)) And ((La2.Text = 1) And (La3.Text = 1)) Then
            If Lab4.Text = 9 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
            ElseIf Lab5.Text = 9 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab1.Text : Lab1.Text = rt.Text
            ElseIf Lab6.Text = 9 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab1.Text : Lab1.Text = rt.Text
            End If
        ElseIf (((Lab1.Text = 3) And (Lab2.Text = 9)) Or ((Lab2.Text = 3) And (Lab1.Text = 9))) And ((Lab4.Text = 6) Or (Lab5.Text = 6) Or (Lab6.Text = 6)) And ((La1.Text = 1) And (La2.Text = 1)) Then
            If Lab4.Text = 6 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab5.Text = 6 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab6.Text = 6 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
            End If
        ElseIf (((Lab1.Text = 3) And (Lab3.Text = 9)) Or ((Lab3.Text = 3) And (Lab1.Text = 9))) And ((Lab4.Text = 6) Or (Lab5.Text = 6) Or (Lab6.Text = 6)) And ((La1.Text = 1) And (La3.Text = 1)) Then
            If Lab4.Text = 6 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab5.Text = 6 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab6.Text = 6 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab2.Text : Lab2.Text = rt.Text
            End If
        ElseIf (((Lab2.Text = 3) And (Lab3.Text = 9)) Or ((Lab3.Text = 3) And (Lab2.Text = 9))) And ((Lab4.Text = 6) Or (Lab5.Text = 6) Or (Lab6.Text = 6)) And ((La2.Text = 1) And (La3.Text = 1)) Then
            If Lab4.Text = 6 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
            ElseIf Lab5.Text = 6 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab1.Text : Lab1.Text = rt.Text
            ElseIf Lab6.Text = 6 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab1.Text : Lab1.Text = rt.Text
            End If
        ElseIf (((Lab1.Text = 6) And (Lab2.Text = 9)) Or ((Lab2.Text = 6) And (Lab1.Text = 9))) And ((Lab4.Text = 3) Or (Lab5.Text = 3) Or (Lab6.Text = 3)) And ((La1.Text = 1) And (La2.Text = 1)) Then
            If Lab4.Text = 3 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab5.Text = 3 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab6.Text = 3 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
            End If
        ElseIf (((Lab1.Text = 6) And (Lab3.Text = 9)) Or ((Lab3.Text = 6) And (Lab1.Text = 9))) And ((Lab4.Text = 3) Or (Lab5.Text = 3) Or (Lab6.Text = 3)) And ((La1.Text = 1) And (La3.Text = 1)) Then
            If Lab4.Text = 3 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab5.Text = 3 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab6.Text = 3 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab2.Text : Lab2.Text = rt.Text
            End If
        ElseIf (((Lab2.Text = 6) And (Lab3.Text = 9)) Or ((Lab3.Text = 6) And (Lab2.Text = 9))) And ((Lab4.Text = 3) Or (Lab5.Text = 3) Or (Lab6.Text = 3)) And ((La2.Text = 1) And (La3.Text = 1)) Then
            If Lab4.Text = 3 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
            ElseIf Lab5.Text = 3 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab1.Text : Lab1.Text = rt.Text
            ElseIf Lab6.Text = 3 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab1.Text : Lab1.Text = rt.Text
            End If
        ElseIf (((Lab1.Text = 1) And (Lab2.Text = 5)) Or ((Lab2.Text = 1) And (Lab1.Text = 5))) And ((Lab4.Text = 9) Or (Lab5.Text = 9) Or (Lab6.Text = 9)) And ((La1.Text = 1) And (La2.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 9 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab5.Text = 9 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab6.Text = 9 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
            End If
        ElseIf (((Lab1.Text = 1) And (Lab3.Text = 5)) Or ((Lab3.Text = 1) And (Lab1.Text = 5))) And ((Lab4.Text = 9) Or (Lab5.Text = 9) Or (Lab6.Text = 9)) And ((La1.Text = 1) And (La3.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 9 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab5.Text = 9 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab6.Text = 9 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab2.Text : Lab2.Text = rt.Text
            End If
        ElseIf (((Lab2.Text = 1) And (Lab3.Text = 5)) Or ((Lab3.Text = 1) And (Lab2.Text = 5))) And ((Lab4.Text = 9) Or (Lab5.Text = 9) Or (Lab6.Text = 9)) And ((La2.Text = 1) And (La3.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 9 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
            ElseIf Lab5.Text = 9 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab1.Text : Lab1.Text = rt.Text
            ElseIf Lab6.Text = 9 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab1.Text : Lab1.Text = rt.Text
            End If
        ElseIf (((Lab1.Text = 1) And (Lab2.Text = 9)) Or ((Lab2.Text = 1) And (Lab1.Text = 9))) And ((Lab4.Text = 5) Or (Lab5.Text = 5) Or (Lab6.Text = 5)) And ((La1.Text = 1) And (La2.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 5 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab5.Text = 5 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab6.Text = 5 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
            End If
        ElseIf (((Lab1.Text = 1) And (Lab3.Text = 9)) Or ((Lab3.Text = 1) And (Lab1.Text = 9))) And ((Lab4.Text = 5) Or (Lab5.Text = 5) Or (Lab6.Text = 5)) And ((La1.Text = 1) And (La3.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 5 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab5.Text = 5 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab6.Text = 5 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab2.Text : Lab2.Text = rt.Text
            End If
        ElseIf (((Lab2.Text = 1) And (Lab3.Text = 9)) Or ((Lab3.Text = 1) And (Lab2.Text = 9))) And ((Lab4.Text = 5) Or (Lab5.Text = 5) Or (Lab6.Text = 5)) And ((La2.Text = 1) And (La3.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 5 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
            ElseIf Lab5.Text = 5 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab1.Text : Lab1.Text = rt.Text
            ElseIf Lab6.Text = 5 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab1.Text : Lab1.Text = rt.Text
            End If
        ElseIf (((Lab1.Text = 5) And (Lab2.Text = 9)) Or ((Lab2.Text = 5) And (Lab1.Text = 9))) And ((Lab4.Text = 1) Or (Lab5.Text = 1) Or (Lab6.Text = 1)) And ((La1.Text = 1) And (La2.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 1 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab5.Text = 1 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab6.Text = 1 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
            End If
        ElseIf (((Lab1.Text = 5) And (Lab3.Text = 9)) Or ((Lab3.Text = 5) And (Lab1.Text = 9))) And ((Lab4.Text = 1) Or (Lab5.Text = 1) Or (Lab6.Text = 1)) And ((La1.Text = 1) And (La3.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 1 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab5.Text = 1 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab6.Text = 1 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab2.Text : Lab2.Text = rt.Text
            End If
        ElseIf (((Lab2.Text = 5) And (Lab3.Text = 9)) Or ((Lab3.Text = 5) And (Lab2.Text = 9))) And ((Lab4.Text = 1) Or (Lab5.Text = 1) Or (Lab6.Text = 1)) And ((La2.Text = 1) And (La3.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 1 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
            ElseIf Lab5.Text = 1 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab1.Text : Lab1.Text = rt.Text
            ElseIf Lab6.Text = 1 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab1.Text : Lab1.Text = rt.Text
            End If
        ElseIf (((Lab1.Text = 3) And (Lab2.Text = 5)) Or ((Lab2.Text = 3) And (Lab1.Text = 5))) And ((Lab4.Text = 7) Or (Lab5.Text = 7) Or (Lab6.Text = 7)) And ((La1.Text = 1) And (La2.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 7 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab5.Text = 7 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab6.Text = 7 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
            End If
        ElseIf (((Lab1.Text = 3) And (Lab3.Text = 5)) Or ((Lab3.Text = 3) And (Lab1.Text = 5))) And ((Lab4.Text = 7) Or (Lab5.Text = 7) Or (Lab6.Text = 7)) And ((La1.Text = 1) And (La3.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 7 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab5.Text = 7 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab6.Text = 7 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab2.Text : Lab2.Text = rt.Text
            End If
        ElseIf (((Lab2.Text = 3) And (Lab3.Text = 5)) Or ((Lab3.Text = 3) And (Lab2.Text = 5))) And ((Lab4.Text = 7) Or (Lab5.Text = 7) Or (Lab6.Text = 7)) And ((La2.Text = 1) And (La3.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 7 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
            ElseIf Lab5.Text = 7 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab1.Text : Lab1.Text = rt.Text
            ElseIf Lab6.Text = 7 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab1.Text : Lab1.Text = rt.Text
            End If
        ElseIf (((Lab1.Text = 3) And (Lab2.Text = 7)) Or ((Lab2.Text = 3) And (Lab1.Text = 7))) And ((Lab4.Text = 5) Or (Lab5.Text = 5) Or (Lab6.Text = 5)) And ((La1.Text = 1) And (La2.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 5 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab5.Text = 5 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab6.Text = 5 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
            End If
        ElseIf (((Lab1.Text = 3) And (Lab3.Text = 7)) Or ((Lab3.Text = 3) And (Lab1.Text = 7))) And ((Lab4.Text = 5) Or (Lab5.Text = 5) Or (Lab6.Text = 5)) And ((La1.Text = 1) And (La3.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 5 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab5.Text = 5 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab6.Text = 5 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab2.Text : Lab2.Text = rt.Text
            End If
        ElseIf (((Lab2.Text = 3) And (Lab3.Text = 7)) Or ((Lab3.Text = 3) And (Lab2.Text = 7))) And ((Lab4.Text = 5) Or (Lab5.Text = 5) Or (Lab6.Text = 5)) And ((La2.Text = 1) And (La3.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 5 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
            ElseIf Lab5.Text = 5 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab1.Text : Lab1.Text = rt.Text
            ElseIf Lab6.Text = 5 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab1.Text : Lab1.Text = rt.Text
            End If
        ElseIf (((Lab1.Text = 5) And (Lab2.Text = 7)) Or ((Lab2.Text = 5) And (Lab1.Text = 7))) And ((Lab4.Text = 3) Or (Lab5.Text = 3) Or (Lab6.Text = 3)) And ((La1.Text = 1) And (La2.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 3 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab5.Text = 3 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab6.Text = 3 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
            End If
        ElseIf (((Lab1.Text = 5) And (Lab3.Text = 7)) Or ((Lab3.Text = 5) And (Lab1.Text = 7))) And ((Lab4.Text = 3) Or (Lab5.Text = 3) Or (Lab6.Text = 3)) And ((La1.Text = 1) And (La3.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 3 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab5.Text = 3 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab6.Text = 3 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab2.Text : Lab2.Text = rt.Text
            End If
        ElseIf (((Lab2.Text = 5) And (Lab3.Text = 7)) Or ((Lab3.Text = 5) And (Lab2.Text = 7))) And ((Lab4.Text = 3) Or (Lab5.Text = 3) Or (Lab6.Text = 3)) And ((La2.Text = 1) And (La3.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 3 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
            ElseIf Lab5.Text = 3 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab1.Text : Lab1.Text = rt.Text
            ElseIf Lab6.Text = 3 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab1.Text : Lab1.Text = rt.Text
            End If

        ElseIf (((((Lab7.Text = 1) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 1))) And ((La4.Text = 1) And (La5.Text = 1))) Or ((((Lab7.Text = 1) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 1))) And ((La4.Text = 1) And (La6.Text = 1))) Or ((((Lab8.Text = 1) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 1))) And ((La5.Text = 1) And (La6.Text = 1)))) And ((Lab4.Text = 3) Or (Lab5.Text = 3) Or (Lab6.Text = 3)) Then
            If Lab4.Text = 3 Then
                If ((((Lab7.Text = 2) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 2))) And ((Lab1.Text = 8) Or (Lab1.Text = 5))) Or ((((Lab7.Text = 1) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 1)) Or ((Lab7.Text = 1) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 1))) And ((Lab1.Text = 7) Or (Lab1.Text = 4))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
                ElseIf ((((Lab7.Text = 2) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 2))) And ((Lab2.Text = 8) Or (Lab2.Text = 5))) Or ((((Lab7.Text = 1) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 1)) Or ((Lab7.Text = 1) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 1))) And ((Lab2.Text = 7) Or (Lab2.Text = 4))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
                ElseIf ((((Lab7.Text = 2) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 2))) And ((Lab3.Text = 8) Or (Lab3.Text = 5))) Or ((((Lab7.Text = 1) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 1)) Or ((Lab7.Text = 1) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 1))) And ((Lab3.Text = 7) Or (Lab3.Text = 4))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
                End If
            ElseIf Lab5.Text = 3 Then
                If ((((Lab7.Text = 2) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 2))) And ((Lab1.Text = 8) Or (Lab1.Text = 5))) Or ((((Lab7.Text = 1) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 1)) Or ((Lab7.Text = 1) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 1))) And ((Lab1.Text = 7) Or (Lab1.Text = 4))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab2.Text : Lab2.Text = rt.Text
                ElseIf ((((Lab7.Text = 2) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 2))) And ((Lab2.Text = 8) Or (Lab2.Text = 5))) Or ((((Lab7.Text = 1) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 1)) Or ((Lab7.Text = 1) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 1))) And ((Lab2.Text = 7) Or (Lab2.Text = 4))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
                ElseIf ((((Lab7.Text = 2) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 2))) And ((Lab3.Text = 8) Or (Lab3.Text = 5))) Or ((((Lab7.Text = 1) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 1)) Or ((Lab7.Text = 1) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 1))) And ((Lab3.Text = 7) Or (Lab3.Text = 4))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab1.Text : Lab1.Text = rt.Text
                Else
                    rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
                End If
            ElseIf Lab6.Text = 3 Then
                If ((((Lab7.Text = 2) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 2))) And ((Lab1.Text = 8) Or (Lab1.Text = 5))) Or ((((Lab7.Text = 1) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 1)) Or ((Lab7.Text = 1) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 1))) And ((Lab1.Text = 7) Or (Lab1.Text = 4))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab2.Text : Lab2.Text = rt.Text
                ElseIf ((((Lab7.Text = 2) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 2))) And ((Lab2.Text = 8) Or (Lab2.Text = 5))) Or ((((Lab7.Text = 1) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 1)) Or ((Lab7.Text = 1) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 1))) And ((Lab2.Text = 7) Or (Lab2.Text = 4))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
                ElseIf ((((Lab7.Text = 2) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 2))) And ((Lab3.Text = 8) Or (Lab3.Text = 5))) Or ((((Lab7.Text = 1) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 1)) Or ((Lab7.Text = 1) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 1))) And ((Lab3.Text = 7) Or (Lab3.Text = 4))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab1.Text : Lab1.Text = rt.Text
                Else
                    rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
                End If
            End If
        ElseIf (((((Lab7.Text = 1) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 1))) And ((La4.Text = 1) And (La5.Text = 1))) Or ((((Lab7.Text = 1) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 1))) And ((La4.Text = 1) And (La6.Text = 1))) Or ((((Lab8.Text = 1) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 1))) And ((La5.Text = 1) And (La6.Text = 1)))) And ((Lab4.Text = 2) Or (Lab5.Text = 2) Or (Lab6.Text = 2)) Then
            If Lab4.Text = 2 Then
                If ((((Lab7.Text = 3) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 3))) And ((Lab1.Text = 9) Or (Lab1.Text = 6))) Or ((((Lab7.Text = 1) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 1)) Or ((Lab7.Text = 1) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 1))) And ((Lab1.Text = 7) Or (Lab1.Text = 4))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
                ElseIf ((((Lab7.Text = 3) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 3))) And ((Lab2.Text = 9) Or (Lab2.Text = 6))) Or ((((Lab7.Text = 1) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 1)) Or ((Lab7.Text = 1) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 1))) And ((Lab2.Text = 7) Or (Lab2.Text = 4))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
                ElseIf ((((Lab7.Text = 3) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 3))) And ((Lab3.Text = 9) Or (Lab3.Text = 6))) Or ((((Lab7.Text = 1) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 1)) Or ((Lab7.Text = 1) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 1))) And ((Lab3.Text = 7) Or (Lab3.Text = 4))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
                End If
            ElseIf Lab5.Text = 2 Then
                If ((((Lab7.Text = 3) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 3))) And ((Lab1.Text = 9) Or (Lab1.Text = 6))) Or ((((Lab7.Text = 1) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 1)) Or ((Lab7.Text = 1) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 1))) And ((Lab1.Text = 7) Or (Lab1.Text = 4))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab2.Text : Lab2.Text = rt.Text
                ElseIf ((((Lab7.Text = 3) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 3))) And ((Lab2.Text = 9) Or (Lab2.Text = 6))) Or ((((Lab7.Text = 1) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 1)) Or ((Lab7.Text = 1) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 1))) And ((Lab2.Text = 7) Or (Lab2.Text = 4))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
                ElseIf ((((Lab7.Text = 3) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 3))) And ((Lab3.Text = 9) Or (Lab3.Text = 6))) Or ((((Lab7.Text = 1) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 1)) Or ((Lab7.Text = 1) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 1))) And ((Lab3.Text = 7) Or (Lab3.Text = 4))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab1.Text : Lab1.Text = rt.Text
                Else
                    rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
                End If
            ElseIf Lab6.Text = 2 Then
                If ((((Lab7.Text = 3) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 3))) And ((Lab1.Text = 9) Or (Lab1.Text = 6))) Or ((((Lab7.Text = 1) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 1)) Or ((Lab7.Text = 1) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 1))) And ((Lab1.Text = 7) Or (Lab1.Text = 4))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab2.Text : Lab2.Text = rt.Text
                ElseIf ((((Lab7.Text = 3) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 3))) And ((Lab2.Text = 9) Or (Lab2.Text = 6))) Or ((((Lab7.Text = 1) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 1)) Or ((Lab7.Text = 1) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 1))) And ((Lab2.Text = 7) Or (Lab2.Text = 4))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
                ElseIf ((((Lab7.Text = 3) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 3))) And ((Lab3.Text = 9) Or (Lab3.Text = 6))) Or ((((Lab7.Text = 1) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 1)) Or ((Lab7.Text = 1) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 1))) And ((Lab3.Text = 7) Or (Lab3.Text = 4))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab1.Text : Lab1.Text = rt.Text
                Else
                    rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
                End If
            End If
        ElseIf (((((Lab7.Text = 2) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 2))) And ((La4.Text = 1) And (La5.Text = 1))) Or ((((Lab7.Text = 2) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 2))) And ((La4.Text = 1) And (La6.Text = 1))) Or ((((Lab8.Text = 2) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 2))) And ((La5.Text = 1) And (La6.Text = 1)))) And ((Lab4.Text = 1) Or (Lab5.Text = 1) Or (Lab6.Text = 1)) Then
            If Lab4.Text = 1 Then
                If ((((Lab7.Text = 3) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 3))) And ((Lab1.Text = 9) Or (Lab1.Text = 6))) Or ((((Lab7.Text = 2) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 2))) And ((Lab1.Text = 8) Or (Lab1.Text = 5))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
                ElseIf ((((Lab7.Text = 3) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 3))) And ((Lab2.Text = 9) Or (Lab2.Text = 6))) Or ((((Lab7.Text = 2) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 2))) And ((Lab2.Text = 8) Or (Lab2.Text = 5))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
                ElseIf ((((Lab7.Text = 3) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 3))) And ((Lab3.Text = 9) Or (Lab3.Text = 6))) Or ((((Lab7.Text = 2) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 2))) And ((Lab3.Text = 8) Or (Lab3.Text = 5))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
                End If
            ElseIf Lab5.Text = 1 Then
                If ((((Lab7.Text = 3) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 3))) And ((Lab1.Text = 9) Or (Lab1.Text = 6))) Or ((((Lab7.Text = 2) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 2))) And ((Lab1.Text = 8) Or (Lab1.Text = 5))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab2.Text : Lab2.Text = rt.Text
                ElseIf ((((Lab7.Text = 3) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 3))) And ((Lab2.Text = 9) Or (Lab2.Text = 6))) Or ((((Lab7.Text = 2) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 2))) And ((Lab2.Text = 8) Or (Lab2.Text = 5))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
                ElseIf ((((Lab7.Text = 3) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 3))) And ((Lab3.Text = 9) Or (Lab3.Text = 6))) Or ((((Lab7.Text = 2) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 2))) And ((Lab3.Text = 8) Or (Lab3.Text = 5))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab1.Text : Lab1.Text = rt.Text
                Else
                    rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
                End If
            ElseIf Lab6.Text = 1 Then
                If ((((Lab7.Text = 3) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 3))) And ((Lab1.Text = 9) Or (Lab1.Text = 6))) Or ((((Lab7.Text = 2) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 2))) And ((Lab1.Text = 8) Or (Lab1.Text = 5))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab2.Text : Lab2.Text = rt.Text
                ElseIf ((((Lab7.Text = 3) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 3))) And ((Lab2.Text = 9) Or (Lab2.Text = 6))) Or ((((Lab7.Text = 2) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 2))) And ((Lab2.Text = 8) Or (Lab2.Text = 5))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
                ElseIf ((((Lab7.Text = 3) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 3))) And ((Lab3.Text = 9) Or (Lab3.Text = 6))) Or ((((Lab7.Text = 2) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 2))) And ((Lab3.Text = 8) Or (Lab3.Text = 5))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab1.Text : Lab1.Text = rt.Text
                Else
                    rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
                End If
            End If
        ElseIf (((((Lab7.Text = 4) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 4))) And ((La4.Text = 1) And (La5.Text = 1))) Or ((((Lab7.Text = 4) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 4))) And ((La4.Text = 1) And (La6.Text = 1))) Or ((((Lab8.Text = 4) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 4))) And ((La5.Text = 1) And (La6.Text = 1)))) And ((Lab4.Text = 6) Or (Lab5.Text = 6) Or (Lab6.Text = 6)) Then
            If Lab4.Text = 6 Then
                If ((((Lab7.Text = 2) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 2)) Or ((Lab7.Text = 5) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 5))) And ((Lab1.Text = 8) Or (Lab1.Text = 2))) Or ((((Lab7.Text = 1) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 1)) Or ((Lab7.Text = 4) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 4))) And ((Lab1.Text = 7) Or (Lab1.Text = 1))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
                ElseIf ((((Lab7.Text = 2) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 2)) Or ((Lab7.Text = 5) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 5))) And ((Lab2.Text = 8) Or (Lab2.Text = 2))) Or ((((Lab7.Text = 1) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 1)) Or ((Lab7.Text = 4) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 4))) And ((Lab2.Text = 7) Or (Lab2.Text = 1))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
                ElseIf ((((Lab7.Text = 2) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 2)) Or ((Lab7.Text = 5) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 5))) And ((Lab3.Text = 8) Or (Lab3.Text = 2))) Or ((((Lab7.Text = 1) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 1)) Or ((Lab7.Text = 4) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 4))) And ((Lab3.Text = 7) Or (Lab3.Text = 1))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
                End If
            ElseIf Lab5.Text = 6 Then
                If ((((Lab7.Text = 2) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 2)) Or ((Lab7.Text = 5) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 5))) And ((Lab1.Text = 8) Or (Lab1.Text = 2))) Or ((((Lab7.Text = 1) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 1)) Or ((Lab7.Text = 4) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 4))) And ((Lab1.Text = 7) Or (Lab1.Text = 1))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab2.Text : Lab2.Text = rt.Text
                ElseIf ((((Lab7.Text = 2) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 2)) Or ((Lab7.Text = 5) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 5))) And ((Lab2.Text = 8) Or (Lab2.Text = 2))) Or ((((Lab7.Text = 1) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 1)) Or ((Lab7.Text = 4) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 4))) And ((Lab2.Text = 7) Or (Lab2.Text = 1))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
                ElseIf ((((Lab7.Text = 2) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 2)) Or ((Lab7.Text = 5) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 5))) And ((Lab3.Text = 8) Or (Lab3.Text = 2))) Or ((((Lab7.Text = 1) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 1)) Or ((Lab7.Text = 4) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 4))) And ((Lab3.Text = 7) Or (Lab3.Text = 1))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab1.Text : Lab1.Text = rt.Text
                Else
                    rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
                End If
            ElseIf Lab6.Text = 6 Then
                If ((((Lab7.Text = 2) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 2)) Or ((Lab7.Text = 5) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 5))) And ((Lab1.Text = 8) Or (Lab1.Text = 2))) Or ((((Lab7.Text = 1) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 1)) Or ((Lab7.Text = 4) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 4))) And ((Lab1.Text = 7) Or (Lab1.Text = 1))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab2.Text : Lab2.Text = rt.Text
                ElseIf ((((Lab7.Text = 2) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 2)) Or ((Lab7.Text = 5) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 5))) And ((Lab2.Text = 8) Or (Lab2.Text = 2))) Or ((((Lab7.Text = 1) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 1)) Or ((Lab7.Text = 4) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 4))) And ((Lab2.Text = 7) Or (Lab2.Text = 1))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
                ElseIf ((((Lab7.Text = 2) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 2)) Or ((Lab7.Text = 5) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 5))) And ((Lab3.Text = 8) Or (Lab3.Text = 2))) Or ((((Lab7.Text = 1) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 1)) Or ((Lab7.Text = 4) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 4))) And ((Lab3.Text = 7) Or (Lab3.Text = 1))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab1.Text : Lab1.Text = rt.Text
                Else
                    rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
                End If
            End If
        ElseIf (((((Lab7.Text = 4) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 4))) And ((La4.Text = 1) And (La5.Text = 1))) Or ((((Lab7.Text = 4) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 4))) And ((La4.Text = 1) And (La6.Text = 1))) Or ((((Lab8.Text = 4) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 4))) And ((La5.Text = 1) And (La6.Text = 1)))) And ((Lab4.Text = 5) Or (Lab5.Text = 5) Or (Lab6.Text = 5)) Then
            If Lab4.Text = 5 Then
                If ((((Lab7.Text = 1) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 1)) Or ((Lab7.Text = 4) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 4))) And ((Lab1.Text = 7) Or (Lab1.Text = 1))) Or ((((Lab7.Text = 3) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 3)) Or ((Lab7.Text = 6) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 6))) And ((Lab1.Text = 9) Or (Lab1.Text = 3))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
                ElseIf ((((Lab7.Text = 1) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 1)) Or ((Lab7.Text = 4) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 4))) And ((Lab2.Text = 7) Or (Lab2.Text = 1))) Or ((((Lab7.Text = 3) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 3)) Or ((Lab7.Text = 6) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 6))) And ((Lab2.Text = 9) Or (Lab2.Text = 3))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
                ElseIf ((((Lab7.Text = 1) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 1)) Or ((Lab7.Text = 4) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 4))) And ((Lab3.Text = 7) Or (Lab3.Text = 1))) Or ((((Lab7.Text = 3) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 3)) Or ((Lab7.Text = 6) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 6))) And ((Lab3.Text = 9) Or (Lab3.Text = 3))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
                End If
            ElseIf Lab5.Text = 5 Then
                If ((((Lab7.Text = 1) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 1)) Or ((Lab7.Text = 4) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 4))) And ((Lab1.Text = 7) Or (Lab1.Text = 1))) Or ((((Lab7.Text = 3) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 3)) Or ((Lab7.Text = 6) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 6))) And ((Lab1.Text = 9) Or (Lab1.Text = 3))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab2.Text : Lab2.Text = rt.Text
                ElseIf ((((Lab7.Text = 1) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 1)) Or ((Lab7.Text = 4) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 4))) And ((Lab2.Text = 7) Or (Lab2.Text = 1))) Or ((((Lab7.Text = 3) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 3)) Or ((Lab7.Text = 6) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 6))) And ((Lab2.Text = 9) Or (Lab2.Text = 3))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
                ElseIf ((((Lab7.Text = 1) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 1)) Or ((Lab7.Text = 4) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 4))) And ((Lab3.Text = 7) Or (Lab3.Text = 1))) Or ((((Lab7.Text = 3) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 3)) Or ((Lab7.Text = 6) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 6))) And ((Lab3.Text = 9) Or (Lab3.Text = 3))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab1.Text : Lab1.Text = rt.Text
                Else
                    rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
                End If
            ElseIf Lab6.Text = 5 Then
                If ((((Lab7.Text = 1) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 1)) Or ((Lab7.Text = 4) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 4))) And ((Lab1.Text = 7) Or (Lab1.Text = 1))) Or ((((Lab7.Text = 3) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 3)) Or ((Lab7.Text = 6) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 6))) And ((Lab1.Text = 9) Or (Lab1.Text = 3))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab2.Text : Lab2.Text = rt.Text
                ElseIf ((((Lab7.Text = 1) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 1)) Or ((Lab7.Text = 4) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 4))) And ((Lab2.Text = 7) Or (Lab2.Text = 1))) Or ((((Lab7.Text = 3) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 3)) Or ((Lab7.Text = 6) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 6))) And ((Lab2.Text = 9) Or (Lab2.Text = 3))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
                ElseIf ((((Lab7.Text = 1) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 1)) Or ((Lab7.Text = 4) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 4))) And ((Lab3.Text = 7) Or (Lab3.Text = 1))) Or ((((Lab7.Text = 3) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 3)) Or ((Lab7.Text = 6) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 6))) And ((Lab3.Text = 9) Or (Lab3.Text = 3))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab1.Text : Lab1.Text = rt.Text
                Else
                    rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
                End If
            End If
        ElseIf (((((Lab7.Text = 5) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 5))) And ((La4.Text = 1) And (La5.Text = 1))) Or ((((Lab7.Text = 5) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 5))) And ((La4.Text = 1) And (La6.Text = 1))) Or ((((Lab8.Text = 5) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 5))) And ((La5.Text = 1) And (La6.Text = 1)))) And ((Lab4.Text = 4) Or (Lab5.Text = 4) Or (Lab6.Text = 4)) Then
            If Lab4.Text = 4 Then
                If ((((Lab7.Text = 2) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 2)) Or ((Lab7.Text = 5) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 5))) And ((Lab1.Text = 8) Or (Lab1.Text = 2))) Or ((((Lab7.Text = 3) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 3)) Or ((Lab7.Text = 6) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 6))) And ((Lab1.Text = 9) Or (Lab1.Text = 3))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
                ElseIf ((((Lab7.Text = 2) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 2)) Or ((Lab7.Text = 5) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 5))) And ((Lab2.Text = 8) Or (Lab2.Text = 2))) Or ((((Lab7.Text = 3) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 3)) Or ((Lab7.Text = 6) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 6))) And ((Lab2.Text = 9) Or (Lab2.Text = 3))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
                ElseIf ((((Lab7.Text = 2) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 2)) Or ((Lab7.Text = 5) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 5))) And ((Lab3.Text = 8) Or (Lab3.Text = 2))) Or ((((Lab7.Text = 3) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 3)) Or ((Lab7.Text = 6) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 6))) And ((Lab3.Text = 9) Or (Lab3.Text = 3))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
                End If
            ElseIf Lab5.Text = 4 Then
                If ((((Lab7.Text = 2) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 2)) Or ((Lab7.Text = 5) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 5))) And ((Lab1.Text = 8) Or (Lab1.Text = 2))) Or ((((Lab7.Text = 3) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 3)) Or ((Lab7.Text = 6) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 6))) And ((Lab1.Text = 9) Or (Lab1.Text = 3))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab2.Text : Lab2.Text = rt.Text
                ElseIf ((((Lab7.Text = 2) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 2)) Or ((Lab7.Text = 5) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 5))) And ((Lab2.Text = 8) Or (Lab2.Text = 2))) Or ((((Lab7.Text = 3) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 3)) Or ((Lab7.Text = 6) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 6))) And ((Lab2.Text = 9) Or (Lab2.Text = 3))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
                ElseIf ((((Lab7.Text = 2) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 2)) Or ((Lab7.Text = 5) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 5))) And ((Lab3.Text = 8) Or (Lab3.Text = 2))) Or ((((Lab7.Text = 3) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 3)) Or ((Lab7.Text = 6) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 6))) And ((Lab3.Text = 9) Or (Lab3.Text = 3))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab1.Text : Lab1.Text = rt.Text
                Else
                    rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
                End If
            ElseIf Lab6.Text = 4 Then
                If ((((Lab7.Text = 2) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 2)) Or ((Lab7.Text = 5) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 5))) And ((Lab1.Text = 8) Or (Lab1.Text = 2))) Or ((((Lab7.Text = 3) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 3)) Or ((Lab7.Text = 6) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 6))) And ((Lab1.Text = 9) Or (Lab1.Text = 3))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab2.Text : Lab2.Text = rt.Text
                ElseIf ((((Lab7.Text = 2) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 2)) Or ((Lab7.Text = 5) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 5))) And ((Lab2.Text = 8) Or (Lab2.Text = 2))) Or ((((Lab7.Text = 3) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 3)) Or ((Lab7.Text = 6) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 6))) And ((Lab2.Text = 9) Or (Lab2.Text = 3))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
                ElseIf ((((Lab7.Text = 2) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 2)) Or ((Lab7.Text = 5) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 5))) And ((Lab3.Text = 8) Or (Lab3.Text = 2))) Or ((((Lab7.Text = 3) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 3)) Or ((Lab7.Text = 6) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 6))) And ((Lab3.Text = 9) Or (Lab3.Text = 3))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab1.Text : Lab1.Text = rt.Text
                Else
                    rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
                End If
            End If
        ElseIf (((((Lab7.Text = 7) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 7))) And ((La4.Text = 1) And (La5.Text = 1))) Or ((((Lab7.Text = 7) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 7))) And ((La4.Text = 1) And (La6.Text = 1))) Or ((((Lab8.Text = 7) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 7))) And ((La5.Text = 1) And (La6.Text = 1)))) And ((Lab4.Text = 9) Or (Lab5.Text = 9) Or (Lab6.Text = 9)) Then
            If Lab4.Text = 9 Then
                If ((((Lab7.Text = 2) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 2)) Or ((Lab7.Text = 5) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 5))) And ((Lab1.Text = 5) Or (Lab1.Text = 2))) Or ((((Lab7.Text = 1) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 1)) Or ((Lab7.Text = 4) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 4))) And ((Lab1.Text = 4) Or (Lab1.Text = 1))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
                ElseIf ((((Lab7.Text = 2) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 2)) Or ((Lab7.Text = 5) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 5))) And ((Lab2.Text = 5) Or (Lab2.Text = 2))) Or ((((Lab7.Text = 1) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 1)) Or ((Lab7.Text = 4) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 4))) And ((Lab2.Text = 4) Or (Lab2.Text = 1))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
                ElseIf ((((Lab7.Text = 2) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 2)) Or ((Lab7.Text = 5) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 5))) And ((Lab3.Text = 5) Or (Lab3.Text = 2))) Or ((((Lab7.Text = 1) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 1)) Or ((Lab7.Text = 4) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 4))) And ((Lab3.Text = 4) Or (Lab3.Text = 1))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
                End If
            ElseIf Lab5.Text = 9 Then
                If ((((Lab7.Text = 2) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 2)) Or ((Lab7.Text = 5) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 5))) And ((Lab1.Text = 5) Or (Lab1.Text = 2))) Or ((((Lab7.Text = 1) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 1)) Or ((Lab7.Text = 4) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 4))) And ((Lab1.Text = 4) Or (Lab1.Text = 1))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab2.Text : Lab2.Text = rt.Text
                ElseIf ((((Lab7.Text = 2) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 2)) Or ((Lab7.Text = 5) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 5))) And ((Lab2.Text = 5) Or (Lab2.Text = 2))) Or ((((Lab7.Text = 1) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 1)) Or ((Lab7.Text = 4) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 4))) And ((Lab2.Text = 4) Or (Lab2.Text = 1))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
                ElseIf ((((Lab7.Text = 2) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 2)) Or ((Lab7.Text = 5) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 5))) And ((Lab3.Text = 5) Or (Lab3.Text = 2))) Or ((((Lab7.Text = 1) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 1)) Or ((Lab7.Text = 4) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 4))) And ((Lab3.Text = 4) Or (Lab3.Text = 1))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab1.Text : Lab1.Text = rt.Text
                Else
                    rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
                End If
            ElseIf Lab6.Text = 9 Then
                If ((((Lab7.Text = 2) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 2)) Or ((Lab7.Text = 5) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 5))) And ((Lab1.Text = 5) Or (Lab1.Text = 2))) Or ((((Lab7.Text = 1) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 1)) Or ((Lab7.Text = 4) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 4))) And ((Lab1.Text = 4) Or (Lab1.Text = 1))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab2.Text : Lab2.Text = rt.Text
                ElseIf ((((Lab7.Text = 2) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 2)) Or ((Lab7.Text = 5) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 5))) And ((Lab2.Text = 5) Or (Lab2.Text = 2))) Or ((((Lab7.Text = 1) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 1)) Or ((Lab7.Text = 4) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 4))) And ((Lab2.Text = 4) Or (Lab2.Text = 1))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
                ElseIf ((((Lab7.Text = 2) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 2)) Or ((Lab7.Text = 5) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 5))) And ((Lab3.Text = 5) Or (Lab3.Text = 2))) Or ((((Lab7.Text = 1) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 1)) Or ((Lab7.Text = 4) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 4))) And ((Lab3.Text = 4) Or (Lab3.Text = 1))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab1.Text : Lab1.Text = rt.Text
                Else
                    rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
                End If
            End If
        ElseIf (((((Lab7.Text = 7) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 7))) And ((La4.Text = 1) And (La5.Text = 1))) Or ((((Lab7.Text = 7) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 7))) And ((La4.Text = 1) And (La6.Text = 1))) Or ((((Lab8.Text = 7) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 7))) And ((La5.Text = 1) And (La6.Text = 1)))) And ((Lab4.Text = 8) Or (Lab5.Text = 8) Or (Lab6.Text = 8)) Then
            If Lab4.Text = 8 Then
                If ((((Lab7.Text = 3) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 3)) Or ((Lab7.Text = 6) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 6))) And ((Lab1.Text = 6) Or (Lab1.Text = 3))) Or ((((Lab7.Text = 1) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 1)) Or ((Lab7.Text = 4) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 4))) And ((Lab1.Text = 4) Or (Lab1.Text = 1))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
                ElseIf ((((Lab7.Text = 3) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 3)) Or ((Lab7.Text = 6) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 6))) And ((Lab2.Text = 6) Or (Lab2.Text = 3))) Or ((((Lab7.Text = 1) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 1)) Or ((Lab7.Text = 4) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 4))) And ((Lab2.Text = 4) Or (Lab2.Text = 1))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
                ElseIf ((((Lab7.Text = 3) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 3)) Or ((Lab7.Text = 6) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 6))) And ((Lab3.Text = 6) Or (Lab3.Text = 3))) Or ((((Lab7.Text = 1) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 1)) Or ((Lab7.Text = 4) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 4))) And ((Lab3.Text = 4) Or (Lab3.Text = 1))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
                End If
            ElseIf Lab5.Text = 8 Then
                If ((((Lab7.Text = 3) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 3)) Or ((Lab7.Text = 6) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 6))) And ((Lab1.Text = 6) Or (Lab1.Text = 3))) Or ((((Lab7.Text = 1) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 1)) Or ((Lab7.Text = 4) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 4))) And ((Lab1.Text = 4) Or (Lab1.Text = 1))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab2.Text : Lab2.Text = rt.Text
                ElseIf ((((Lab7.Text = 3) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 3)) Or ((Lab7.Text = 6) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 6))) And ((Lab2.Text = 6) Or (Lab2.Text = 3))) Or ((((Lab7.Text = 1) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 1)) Or ((Lab7.Text = 4) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 4))) And ((Lab2.Text = 4) Or (Lab2.Text = 1))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
                ElseIf ((((Lab7.Text = 3) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 3)) Or ((Lab7.Text = 6) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 6))) And ((Lab3.Text = 6) Or (Lab3.Text = 3))) Or ((((Lab7.Text = 1) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 1)) Or ((Lab7.Text = 4) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 4))) And ((Lab3.Text = 4) Or (Lab3.Text = 1))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab1.Text : Lab1.Text = rt.Text
                Else
                    rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
                End If
            ElseIf Lab6.Text = 8 Then
                If ((((Lab7.Text = 3) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 3)) Or ((Lab7.Text = 6) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 6))) And ((Lab1.Text = 6) Or (Lab1.Text = 3))) Or ((((Lab7.Text = 1) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 1)) Or ((Lab7.Text = 4) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 4))) And ((Lab1.Text = 4) Or (Lab1.Text = 1))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab2.Text : Lab2.Text = rt.Text
                ElseIf ((((Lab7.Text = 3) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 3)) Or ((Lab7.Text = 6) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 6))) And ((Lab2.Text = 6) Or (Lab2.Text = 3))) Or ((((Lab7.Text = 1) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 1)) Or ((Lab7.Text = 4) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 4))) And ((Lab2.Text = 4) Or (Lab2.Text = 1))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
                ElseIf ((((Lab7.Text = 3) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 3)) Or ((Lab7.Text = 6) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 6))) And ((Lab3.Text = 6) Or (Lab3.Text = 3))) Or ((((Lab7.Text = 1) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 1)) Or ((Lab7.Text = 4) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 4))) And ((Lab3.Text = 4) Or (Lab3.Text = 1))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab1.Text : Lab1.Text = rt.Text
                Else
                    rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
                End If
            End If
        ElseIf (((((Lab7.Text = 8) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 8))) And ((La4.Text = 1) And (La5.Text = 1))) Or ((((Lab7.Text = 8) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 8))) And ((La4.Text = 1) And (La6.Text = 1))) Or ((((Lab8.Text = 8) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 8))) And ((La5.Text = 1) And (La6.Text = 1)))) And ((Lab4.Text = 7) Or (Lab5.Text = 7) Or (Lab6.Text = 7)) Then
            If Lab4.Text = 7 Then
                If ((((Lab7.Text = 3) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 3)) Or ((Lab7.Text = 6) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 6))) And ((Lab1.Text = 6) Or (Lab1.Text = 3))) Or ((((Lab7.Text = 2) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 2)) Or ((Lab7.Text = 5) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 5))) And ((Lab1.Text = 5) Or (Lab1.Text = 2))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
                ElseIf ((((Lab7.Text = 3) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 3)) Or ((Lab7.Text = 6) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 6))) And ((Lab2.Text = 6) Or (Lab2.Text = 3))) Or ((((Lab7.Text = 2) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 2)) Or ((Lab7.Text = 5) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 5))) And ((Lab2.Text = 5) Or (Lab2.Text = 2))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
                ElseIf ((((Lab7.Text = 3) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 3)) Or ((Lab7.Text = 6) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 6))) And ((Lab3.Text = 6) Or (Lab3.Text = 3))) Or ((((Lab7.Text = 2) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 2)) Or ((Lab7.Text = 5) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 5))) And ((Lab3.Text = 5) Or (Lab3.Text = 2))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
                End If
            ElseIf Lab5.Text = 7 Then
                If ((((Lab7.Text = 3) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 3)) Or ((Lab7.Text = 6) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 6))) And ((Lab1.Text = 6) Or (Lab1.Text = 3))) Or ((((Lab7.Text = 2) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 2)) Or ((Lab7.Text = 5) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 5))) And ((Lab1.Text = 5) Or (Lab1.Text = 2))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab2.Text : Lab2.Text = rt.Text
                ElseIf ((((Lab7.Text = 3) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 3)) Or ((Lab7.Text = 6) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 6))) And ((Lab2.Text = 6) Or (Lab2.Text = 3))) Or ((((Lab7.Text = 2) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 2)) Or ((Lab7.Text = 5) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 5))) And ((Lab2.Text = 5) Or (Lab2.Text = 2))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
                ElseIf ((((Lab7.Text = 3) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 3)) Or ((Lab7.Text = 6) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 6))) And ((Lab3.Text = 6) Or (Lab3.Text = 3))) Or ((((Lab7.Text = 2) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 2)) Or ((Lab7.Text = 5) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 5))) And ((Lab3.Text = 5) Or (Lab3.Text = 2))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab1.Text : Lab1.Text = rt.Text
                Else
                    rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
                End If
            ElseIf Lab6.Text = 7 Then
                If ((((Lab7.Text = 3) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 3)) Or ((Lab7.Text = 6) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 6))) And ((Lab1.Text = 6) Or (Lab1.Text = 3))) Or ((((Lab7.Text = 2) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 2)) Or ((Lab7.Text = 5) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 5))) And ((Lab1.Text = 5) Or (Lab1.Text = 2))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab2.Text : Lab2.Text = rt.Text
                ElseIf ((((Lab7.Text = 3) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 3)) Or ((Lab7.Text = 6) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 6))) And ((Lab2.Text = 6) Or (Lab2.Text = 3))) Or ((((Lab7.Text = 2) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 2)) Or ((Lab7.Text = 5) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 5))) And ((Lab2.Text = 5) Or (Lab2.Text = 2))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
                ElseIf ((((Lab7.Text = 3) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 3)) Or ((Lab7.Text = 6) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 6))) And ((Lab3.Text = 6) Or (Lab3.Text = 3))) Or ((((Lab7.Text = 2) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 2)) Or ((Lab7.Text = 5) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 5))) And ((Lab3.Text = 5) Or (Lab3.Text = 2))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab1.Text : Lab1.Text = rt.Text
                Else
                    rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
                End If
            End If
        ElseIf (((((Lab7.Text = 1) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 1))) And ((La4.Text = 1) And (La5.Text = 1))) Or ((((Lab7.Text = 1) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 1))) And ((La4.Text = 1) And (La6.Text = 1))) Or ((((Lab8.Text = 1) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 1))) And ((La5.Text = 1) And (La6.Text = 1)))) And ((Lab4.Text = 7) Or (Lab5.Text = 7) Or (Lab6.Text = 7)) Then
            If Lab4.Text = 7 Then
                If ((((Lab7.Text = 1) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 1)) Or ((Lab7.Text = 1) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 1))) And ((Lab1.Text = 2) Or (Lab1.Text = 3))) Or ((((Lab7.Text = 4) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 4))) And ((Lab1.Text = 5) Or (Lab1.Text = 6))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
                ElseIf ((((Lab7.Text = 1) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 1)) Or ((Lab7.Text = 1) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 1))) And ((Lab2.Text = 2) Or (Lab2.Text = 3))) Or ((((Lab7.Text = 4) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 4))) And ((Lab2.Text = 5) Or (Lab2.Text = 6))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
                ElseIf ((((Lab7.Text = 1) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 1)) Or ((Lab7.Text = 1) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 1))) And ((Lab3.Text = 2) Or (Lab3.Text = 3))) Or ((((Lab7.Text = 4) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 4))) And ((Lab3.Text = 5) Or (Lab3.Text = 6))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
                End If
            ElseIf Lab5.Text = 7 Then
                If ((((Lab7.Text = 1) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 1)) Or ((Lab7.Text = 1) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 1))) And ((Lab1.Text = 2) Or (Lab1.Text = 3))) Or ((((Lab7.Text = 4) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 4))) And ((Lab1.Text = 5) Or (Lab1.Text = 6))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab2.Text : Lab2.Text = rt.Text
                ElseIf ((((Lab7.Text = 1) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 1)) Or ((Lab7.Text = 1) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 1))) And ((Lab2.Text = 2) Or (Lab2.Text = 3))) Or ((((Lab7.Text = 4) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 4))) And ((Lab2.Text = 5) Or (Lab2.Text = 6))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
                ElseIf ((((Lab7.Text = 1) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 1)) Or ((Lab7.Text = 1) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 1))) And ((Lab3.Text = 2) Or (Lab3.Text = 3))) Or ((((Lab7.Text = 4) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 4))) And ((Lab3.Text = 5) Or (Lab3.Text = 6))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab1.Text : Lab1.Text = rt.Text
                Else
                    rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
                End If
            ElseIf Lab6.Text = 7 Then
                If ((((Lab7.Text = 1) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 1)) Or ((Lab7.Text = 1) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 1))) And ((Lab1.Text = 2) Or (Lab1.Text = 3))) Or ((((Lab7.Text = 4) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 4))) And ((Lab1.Text = 5) Or (Lab1.Text = 6))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab2.Text : Lab2.Text = rt.Text
                ElseIf ((((Lab7.Text = 1) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 1)) Or ((Lab7.Text = 1) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 1))) And ((Lab2.Text = 2) Or (Lab2.Text = 3))) Or ((((Lab7.Text = 4) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 4))) And ((Lab2.Text = 5) Or (Lab2.Text = 6))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
                ElseIf ((((Lab7.Text = 1) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 1)) Or ((Lab7.Text = 1) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 1))) And ((Lab3.Text = 2) Or (Lab3.Text = 3))) Or ((((Lab7.Text = 4) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 4))) And ((Lab3.Text = 5) Or (Lab3.Text = 6))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab1.Text : Lab1.Text = rt.Text
                Else
                    rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
                End If
            End If
        ElseIf (((((Lab7.Text = 1) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 1))) And ((La4.Text = 1) And (La5.Text = 1))) Or ((((Lab7.Text = 1) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 1))) And ((La4.Text = 1) And (La6.Text = 1))) Or ((((Lab8.Text = 1) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 1))) And ((La5.Text = 1) And (La6.Text = 1)))) And ((Lab4.Text = 4) Or (Lab5.Text = 4) Or (Lab6.Text = 4)) Then
            If Lab4.Text = 4 Then
                If ((((Lab7.Text = 1) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 1)) Or ((Lab7.Text = 1) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 1))) And ((Lab1.Text = 2) Or (Lab1.Text = 3))) Or ((((Lab7.Text = 7) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 7))) And ((Lab1.Text = 8) Or (Lab1.Text = 9))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
                ElseIf ((((Lab7.Text = 1) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 1)) Or ((Lab7.Text = 1) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 1))) And ((Lab2.Text = 2) Or (Lab2.Text = 3))) Or ((((Lab7.Text = 7) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 7))) And ((Lab2.Text = 8) Or (Lab2.Text = 9))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
                ElseIf ((((Lab7.Text = 1) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 1)) Or ((Lab7.Text = 1) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 1))) And ((Lab3.Text = 2) Or (Lab3.Text = 3))) Or ((((Lab7.Text = 7) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 7))) And ((Lab3.Text = 8) Or (Lab3.Text = 9))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
                End If
            ElseIf Lab5.Text = 4 Then
                If ((((Lab7.Text = 1) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 1)) Or ((Lab7.Text = 1) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 1))) And ((Lab1.Text = 2) Or (Lab1.Text = 3))) Or ((((Lab7.Text = 7) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 7))) And ((Lab1.Text = 8) Or (Lab1.Text = 9))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab2.Text : Lab2.Text = rt.Text
                ElseIf ((((Lab7.Text = 1) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 1)) Or ((Lab7.Text = 1) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 1))) And ((Lab2.Text = 2) Or (Lab2.Text = 3))) Or ((((Lab7.Text = 7) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 7))) And ((Lab2.Text = 8) Or (Lab2.Text = 9))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
                ElseIf ((((Lab7.Text = 1) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 1)) Or ((Lab7.Text = 1) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 1))) And ((Lab3.Text = 2) Or (Lab3.Text = 3))) Or ((((Lab7.Text = 7) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 7))) And ((Lab3.Text = 8) Or (Lab3.Text = 9))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab1.Text : Lab1.Text = rt.Text
                Else
                    rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
                End If
            ElseIf Lab6.Text = 4 Then
                If ((((Lab7.Text = 1) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 1)) Or ((Lab7.Text = 1) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 1))) And ((Lab1.Text = 2) Or (Lab1.Text = 3))) Or ((((Lab7.Text = 7) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 7))) And ((Lab1.Text = 8) Or (Lab1.Text = 9))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab2.Text : Lab2.Text = rt.Text
                ElseIf ((((Lab7.Text = 1) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 1)) Or ((Lab7.Text = 1) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 1))) And ((Lab2.Text = 2) Or (Lab2.Text = 3))) Or ((((Lab7.Text = 7) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 7))) And ((Lab2.Text = 8) Or (Lab2.Text = 9))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
                ElseIf ((((Lab7.Text = 1) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 1)) Or ((Lab7.Text = 1) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 1))) And ((Lab3.Text = 2) Or (Lab3.Text = 3))) Or ((((Lab7.Text = 7) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 7))) And ((Lab3.Text = 8) Or (Lab3.Text = 9))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab1.Text : Lab1.Text = rt.Text
                Else
                    rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
                End If
            End If
        ElseIf (((((Lab7.Text = 4) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 4))) And ((La4.Text = 1) And (La5.Text = 1))) Or ((((Lab7.Text = 4) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 4))) And ((La4.Text = 1) And (La6.Text = 1))) Or ((((Lab8.Text = 4) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 4))) And ((La5.Text = 1) And (La6.Text = 1)))) And ((Lab4.Text = 1) Or (Lab5.Text = 1) Or (Lab6.Text = 1)) Then
            If Lab4.Text = 1 Then
                If ((((Lab7.Text = 4) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 4))) And ((Lab1.Text = 5) Or (Lab1.Text = 6))) Or ((((Lab7.Text = 7) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 7))) And ((Lab1.Text = 8) Or (Lab1.Text = 9))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
                ElseIf ((((Lab7.Text = 4) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 4))) And ((Lab2.Text = 5) Or (Lab2.Text = 6))) Or ((((Lab7.Text = 7) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 7))) And ((Lab2.Text = 8) Or (Lab2.Text = 9))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
                ElseIf ((((Lab7.Text = 4) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 4))) And ((Lab3.Text = 5) Or (Lab3.Text = 6))) Or ((((Lab7.Text = 7) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 7))) And ((Lab3.Text = 8) Or (Lab3.Text = 9))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
                End If
            ElseIf Lab5.Text = 1 Then
                If ((((Lab7.Text = 4) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 4))) And ((Lab1.Text = 5) Or (Lab1.Text = 6))) Or ((((Lab7.Text = 7) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 7))) And ((Lab1.Text = 8) Or (Lab1.Text = 9))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab2.Text : Lab2.Text = rt.Text
                ElseIf ((((Lab7.Text = 4) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 4))) And ((Lab2.Text = 5) Or (Lab2.Text = 6))) Or ((((Lab7.Text = 7) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 7))) And ((Lab2.Text = 8) Or (Lab2.Text = 9))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
                ElseIf ((((Lab7.Text = 4) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 4))) And ((Lab3.Text = 5) Or (Lab3.Text = 6))) Or ((((Lab7.Text = 7) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 7))) And ((Lab3.Text = 8) Or (Lab3.Text = 9))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab1.Text : Lab1.Text = rt.Text
                Else
                    rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
                End If
            ElseIf Lab6.Text = 1 Then
                If ((((Lab7.Text = 4) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 4))) And ((Lab1.Text = 5) Or (Lab1.Text = 6))) Or ((((Lab7.Text = 7) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 7))) And ((Lab1.Text = 8) Or (Lab1.Text = 9))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab2.Text : Lab2.Text = rt.Text
                ElseIf ((((Lab7.Text = 4) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 4))) And ((Lab2.Text = 5) Or (Lab2.Text = 6))) Or ((((Lab7.Text = 7) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 7))) And ((Lab2.Text = 8) Or (Lab2.Text = 9))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
                ElseIf ((((Lab7.Text = 4) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 4))) And ((Lab3.Text = 5) Or (Lab3.Text = 6))) Or ((((Lab7.Text = 7) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 7))) And ((Lab3.Text = 8) Or (Lab3.Text = 9))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab1.Text : Lab1.Text = rt.Text
                Else
                    rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
                End If
            End If
        ElseIf (((((Lab7.Text = 2) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 2))) And ((La4.Text = 1) And (La5.Text = 1))) Or ((((Lab7.Text = 2) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 2))) And ((La4.Text = 1) And (La6.Text = 1))) Or ((((Lab8.Text = 2) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 2))) And ((La5.Text = 1) And (La6.Text = 1)))) And ((Lab4.Text = 8) Or (Lab5.Text = 8) Or (Lab6.Text = 8)) Then
            If Lab4.Text = 8 Then
                If ((((Lab7.Text = 4) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 4)) Or ((Lab7.Text = 5) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 5))) And ((Lab1.Text = 4) Or (Lab1.Text = 6))) Or ((((Lab7.Text = 1) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 1)) Or ((Lab7.Text = 2) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 2))) And ((Lab1.Text = 1) Or (Lab1.Text = 3))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
                ElseIf ((((Lab7.Text = 4) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 4)) Or ((Lab7.Text = 5) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 5))) And ((Lab2.Text = 4) Or (Lab2.Text = 6))) Or ((((Lab7.Text = 1) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 1)) Or ((Lab7.Text = 2) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 2))) And ((Lab2.Text = 1) Or (Lab2.Text = 3))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
                ElseIf ((((Lab7.Text = 4) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 4)) Or ((Lab7.Text = 5) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 5))) And ((Lab3.Text = 4) Or (Lab3.Text = 6))) Or ((((Lab7.Text = 1) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 1)) Or ((Lab7.Text = 2) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 2))) And ((Lab3.Text = 1) Or (Lab3.Text = 3))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
                End If
            ElseIf Lab5.Text = 8 Then
                If ((((Lab7.Text = 4) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 4)) Or ((Lab7.Text = 5) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 5))) And ((Lab1.Text = 4) Or (Lab1.Text = 6))) Or ((((Lab7.Text = 1) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 1)) Or ((Lab7.Text = 2) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 2))) And ((Lab1.Text = 1) Or (Lab1.Text = 3))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab2.Text : Lab2.Text = rt.Text
                ElseIf ((((Lab7.Text = 4) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 4)) Or ((Lab7.Text = 5) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 5))) And ((Lab2.Text = 4) Or (Lab2.Text = 6))) Or ((((Lab7.Text = 1) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 1)) Or ((Lab7.Text = 2) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 2))) And ((Lab2.Text = 1) Or (Lab2.Text = 3))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
                ElseIf ((((Lab7.Text = 4) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 4)) Or ((Lab7.Text = 5) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 5))) And ((Lab3.Text = 4) Or (Lab3.Text = 6))) Or ((((Lab7.Text = 1) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 1)) Or ((Lab7.Text = 2) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 2))) And ((Lab3.Text = 1) Or (Lab3.Text = 3))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab1.Text : Lab1.Text = rt.Text
                Else
                    rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
                End If
            ElseIf Lab6.Text = 8 Then
                If ((((Lab7.Text = 4) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 4)) Or ((Lab7.Text = 5) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 5))) And ((Lab1.Text = 4) Or (Lab1.Text = 6))) Or ((((Lab7.Text = 1) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 1)) Or ((Lab7.Text = 2) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 2))) And ((Lab1.Text = 1) Or (Lab1.Text = 3))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab2.Text : Lab2.Text = rt.Text
                ElseIf ((((Lab7.Text = 4) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 4)) Or ((Lab7.Text = 5) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 5))) And ((Lab2.Text = 4) Or (Lab2.Text = 6))) Or ((((Lab7.Text = 1) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 1)) Or ((Lab7.Text = 2) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 2))) And ((Lab2.Text = 1) Or (Lab2.Text = 3))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
                ElseIf ((((Lab7.Text = 4) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 4)) Or ((Lab7.Text = 5) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 5))) And ((Lab3.Text = 4) Or (Lab3.Text = 6))) Or ((((Lab7.Text = 1) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 1)) Or ((Lab7.Text = 2) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 2))) And ((Lab3.Text = 1) Or (Lab3.Text = 3))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab1.Text : Lab1.Text = rt.Text
                Else
                    rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
                End If
            End If
        ElseIf (((((Lab7.Text = 2) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 2))) And ((La4.Text = 1) And (La5.Text = 1))) Or ((((Lab7.Text = 2) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 2))) And ((La4.Text = 1) And (La6.Text = 1))) Or ((((Lab8.Text = 2) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 2))) And ((La5.Text = 1) And (La6.Text = 1)))) And ((Lab4.Text = 5) Or (Lab5.Text = 5) Or (Lab6.Text = 5)) Then
            If Lab4.Text = 5 Then
                If ((((Lab7.Text = 7) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 7)) Or ((Lab7.Text = 8) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 8))) And ((Lab1.Text = 7) Or (Lab1.Text = 9))) Or ((((Lab7.Text = 1) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 1)) Or ((Lab7.Text = 2) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 2))) And ((Lab1.Text = 1) Or (Lab1.Text = 3))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
                ElseIf ((((Lab7.Text = 7) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 7)) Or ((Lab7.Text = 8) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 8))) And ((Lab2.Text = 7) Or (Lab2.Text = 9))) Or ((((Lab7.Text = 1) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 1)) Or ((Lab7.Text = 2) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 2))) And ((Lab2.Text = 1) Or (Lab2.Text = 3))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
                ElseIf ((((Lab7.Text = 7) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 7)) Or ((Lab7.Text = 8) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 8))) And ((Lab3.Text = 7) Or (Lab3.Text = 9))) Or ((((Lab7.Text = 1) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 1)) Or ((Lab7.Text = 2) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 2))) And ((Lab3.Text = 1) Or (Lab3.Text = 3))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
                End If
            ElseIf Lab5.Text = 5 Then
                If ((((Lab7.Text = 7) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 7)) Or ((Lab7.Text = 8) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 8))) And ((Lab1.Text = 7) Or (Lab1.Text = 9))) Or ((((Lab7.Text = 1) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 1)) Or ((Lab7.Text = 2) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 2))) And ((Lab1.Text = 1) Or (Lab1.Text = 3))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab2.Text : Lab2.Text = rt.Text
                ElseIf ((((Lab7.Text = 7) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 7)) Or ((Lab7.Text = 8) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 8))) And ((Lab2.Text = 7) Or (Lab2.Text = 9))) Or ((((Lab7.Text = 1) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 1)) Or ((Lab7.Text = 2) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 2))) And ((Lab2.Text = 1) Or (Lab2.Text = 3))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
                ElseIf ((((Lab7.Text = 7) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 7)) Or ((Lab7.Text = 8) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 8))) And ((Lab3.Text = 7) Or (Lab3.Text = 9))) Or ((((Lab7.Text = 1) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 1)) Or ((Lab7.Text = 2) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 2))) And ((Lab3.Text = 1) Or (Lab3.Text = 3))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab1.Text : Lab1.Text = rt.Text
                Else
                    rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
                End If
            ElseIf Lab6.Text = 5 Then
                If ((((Lab7.Text = 7) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 7)) Or ((Lab7.Text = 8) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 8))) And ((Lab1.Text = 7) Or (Lab1.Text = 9))) Or ((((Lab7.Text = 1) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 1)) Or ((Lab7.Text = 2) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 2))) And ((Lab1.Text = 1) Or (Lab1.Text = 3))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab2.Text : Lab2.Text = rt.Text
                ElseIf ((((Lab7.Text = 7) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 7)) Or ((Lab7.Text = 8) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 8))) And ((Lab2.Text = 7) Or (Lab2.Text = 9))) Or ((((Lab7.Text = 1) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 1)) Or ((Lab7.Text = 2) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 2))) And ((Lab2.Text = 1) Or (Lab2.Text = 3))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
                ElseIf ((((Lab7.Text = 7) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 7)) Or ((Lab7.Text = 8) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 8))) And ((Lab3.Text = 7) Or (Lab3.Text = 9))) Or ((((Lab7.Text = 1) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 1)) Or ((Lab7.Text = 2) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 2))) And ((Lab3.Text = 1) Or (Lab3.Text = 3))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab1.Text : Lab1.Text = rt.Text
                Else
                    rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
                End If
            End If
        ElseIf (((((Lab7.Text = 5) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 5))) And ((La4.Text = 1) And (La5.Text = 1))) Or ((((Lab7.Text = 5) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 5))) And ((La4.Text = 1) And (La6.Text = 1))) Or ((((Lab8.Text = 5) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 5))) And ((La5.Text = 1) And (La6.Text = 1)))) And ((Lab4.Text = 2) Or (Lab5.Text = 2) Or (Lab6.Text = 2)) Then
            If Lab4.Text = 2 Then
                If ((((Lab7.Text = 7) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 7)) Or ((Lab7.Text = 8) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 8))) And ((Lab1.Text = 7) Or (Lab1.Text = 9))) Or ((((Lab7.Text = 4) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 4)) Or ((Lab7.Text = 5) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 5))) And ((Lab1.Text = 4) Or (Lab1.Text = 6))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
                ElseIf ((((Lab7.Text = 7) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 7)) Or ((Lab7.Text = 8) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 8))) And ((Lab2.Text = 7) Or (Lab2.Text = 9))) Or ((((Lab7.Text = 4) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 4)) Or ((Lab7.Text = 5) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 5))) And ((Lab2.Text = 4) Or (Lab2.Text = 6))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
                ElseIf ((((Lab7.Text = 7) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 7)) Or ((Lab7.Text = 8) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 8))) And ((Lab3.Text = 7) Or (Lab3.Text = 9))) Or ((((Lab7.Text = 4) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 4)) Or ((Lab7.Text = 5) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 5))) And ((Lab3.Text = 4) Or (Lab3.Text = 6))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
                End If
            ElseIf Lab5.Text = 2 Then
                If ((((Lab7.Text = 7) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 7)) Or ((Lab7.Text = 8) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 8))) And ((Lab1.Text = 7) Or (Lab1.Text = 9))) Or ((((Lab7.Text = 4) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 4)) Or ((Lab7.Text = 5) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 5))) And ((Lab1.Text = 4) Or (Lab1.Text = 6))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab2.Text : Lab2.Text = rt.Text
                ElseIf ((((Lab7.Text = 7) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 7)) Or ((Lab7.Text = 8) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 8))) And ((Lab2.Text = 7) Or (Lab2.Text = 9))) Or ((((Lab7.Text = 4) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 4)) Or ((Lab7.Text = 5) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 5))) And ((Lab2.Text = 4) Or (Lab2.Text = 6))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
                ElseIf ((((Lab7.Text = 7) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 7)) Or ((Lab7.Text = 8) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 8))) And ((Lab3.Text = 7) Or (Lab3.Text = 9))) Or ((((Lab7.Text = 4) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 4)) Or ((Lab7.Text = 5) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 5))) And ((Lab3.Text = 4) Or (Lab3.Text = 6))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab1.Text : Lab1.Text = rt.Text
                Else
                    rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
                End If
            ElseIf Lab6.Text = 2 Then
                If ((((Lab7.Text = 7) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 7)) Or ((Lab7.Text = 8) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 8))) And ((Lab1.Text = 7) Or (Lab1.Text = 9))) Or ((((Lab7.Text = 4) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 4)) Or ((Lab7.Text = 5) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 5))) And ((Lab1.Text = 4) Or (Lab1.Text = 6))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab2.Text : Lab2.Text = rt.Text
                ElseIf ((((Lab7.Text = 7) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 7)) Or ((Lab7.Text = 8) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 8))) And ((Lab2.Text = 7) Or (Lab2.Text = 9))) Or ((((Lab7.Text = 4) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 4)) Or ((Lab7.Text = 5) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 5))) And ((Lab2.Text = 4) Or (Lab2.Text = 6))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
                ElseIf ((((Lab7.Text = 7) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 7)) Or ((Lab7.Text = 8) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 8))) And ((Lab3.Text = 7) Or (Lab3.Text = 9))) Or ((((Lab7.Text = 4) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 4)) Or ((Lab7.Text = 5) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 5))) And ((Lab3.Text = 4) Or (Lab3.Text = 6))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab1.Text : Lab1.Text = rt.Text
                Else
                    rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
                End If
            End If
        ElseIf (((((Lab7.Text = 3) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 3))) And ((La4.Text = 1) And (La5.Text = 1))) Or ((((Lab7.Text = 3) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 3))) And ((La4.Text = 1) And (La6.Text = 1))) Or ((((Lab8.Text = 3) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 3))) And ((La5.Text = 1) And (La6.Text = 1)))) And ((Lab4.Text = 9) Or (Lab5.Text = 9) Or (Lab6.Text = 9)) Then
            If Lab4.Text = 9 Then
                If ((((Lab7.Text = 3) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 3))) And ((Lab1.Text = 2) Or (Lab1.Text = 1))) Or ((((Lab7.Text = 6) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 6))) And ((Lab1.Text = 5) Or (Lab1.Text = 4))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
                ElseIf ((((Lab7.Text = 3) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 3))) And ((Lab2.Text = 2) Or (Lab2.Text = 1))) Or ((((Lab7.Text = 6) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 6))) And ((Lab2.Text = 5) Or (Lab2.Text = 4))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
                ElseIf ((((Lab7.Text = 3) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 3))) And ((Lab3.Text = 2) Or (Lab3.Text = 1))) Or ((((Lab7.Text = 6) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 6))) And ((Lab3.Text = 5) Or (Lab3.Text = 4))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
                End If
            ElseIf Lab5.Text = 9 Then
                If ((((Lab7.Text = 3) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 3))) And ((Lab1.Text = 2) Or (Lab1.Text = 1))) Or ((((Lab7.Text = 6) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 6))) And ((Lab1.Text = 5) Or (Lab1.Text = 4))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab2.Text : Lab2.Text = rt.Text
                ElseIf ((((Lab7.Text = 3) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 3))) And ((Lab2.Text = 2) Or (Lab2.Text = 1))) Or ((((Lab7.Text = 6) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 6))) And ((Lab2.Text = 5) Or (Lab2.Text = 4))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
                ElseIf ((((Lab7.Text = 3) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 3))) And ((Lab3.Text = 2) Or (Lab3.Text = 1))) Or ((((Lab7.Text = 6) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 6))) And ((Lab3.Text = 5) Or (Lab3.Text = 4))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab1.Text : Lab1.Text = rt.Text
                Else
                    rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
                End If
            ElseIf Lab6.Text = 9 Then
                If ((((Lab7.Text = 3) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 3))) And ((Lab1.Text = 2) Or (Lab1.Text = 1))) Or ((((Lab7.Text = 6) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 6))) And ((Lab1.Text = 5) Or (Lab1.Text = 4))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab2.Text : Lab2.Text = rt.Text
                ElseIf ((((Lab7.Text = 3) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 3))) And ((Lab2.Text = 2) Or (Lab2.Text = 1))) Or ((((Lab7.Text = 6) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 6))) And ((Lab2.Text = 5) Or (Lab2.Text = 4))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
                ElseIf ((((Lab7.Text = 3) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 3))) And ((Lab3.Text = 2) Or (Lab3.Text = 1))) Or ((((Lab7.Text = 6) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 6))) And ((Lab3.Text = 5) Or (Lab3.Text = 4))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab1.Text : Lab1.Text = rt.Text
                Else
                    rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
                End If
            End If
        ElseIf (((((Lab7.Text = 3) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 3))) And ((La4.Text = 1) And (La5.Text = 1))) Or ((((Lab7.Text = 3) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 3))) And ((La4.Text = 1) And (La6.Text = 1))) Or ((((Lab8.Text = 3) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 3))) And ((La5.Text = 1) And (La6.Text = 1)))) And ((Lab4.Text = 6) Or (Lab5.Text = 6) Or (Lab6.Text = 6)) Then
            If Lab4.Text = 6 Then
                If ((((Lab7.Text = 3) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 3))) And ((Lab1.Text = 2) Or (Lab1.Text = 1))) Or ((((Lab7.Text = 9) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 9))) And ((Lab1.Text = 8) Or (Lab1.Text = 7))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
                ElseIf ((((Lab7.Text = 3) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 3))) And ((Lab2.Text = 2) Or (Lab2.Text = 1))) Or ((((Lab7.Text = 9) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 9))) And ((Lab2.Text = 8) Or (Lab2.Text = 7))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
                ElseIf ((((Lab7.Text = 3) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 3))) And ((Lab3.Text = 2) Or (Lab3.Text = 1))) Or ((((Lab7.Text = 9) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 9))) And ((Lab3.Text = 8) Or (Lab3.Text = 7))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
                End If
            ElseIf Lab5.Text = 6 Then
                If ((((Lab7.Text = 3) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 3))) And ((Lab1.Text = 2) Or (Lab1.Text = 1))) Or ((((Lab7.Text = 9) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 9))) And ((Lab1.Text = 8) Or (Lab1.Text = 7))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab2.Text : Lab2.Text = rt.Text
                ElseIf ((((Lab7.Text = 3) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 3))) And ((Lab2.Text = 2) Or (Lab2.Text = 1))) Or ((((Lab7.Text = 9) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 9))) And ((Lab2.Text = 8) Or (Lab2.Text = 7))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
                ElseIf ((((Lab7.Text = 3) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 3))) And ((Lab3.Text = 2) Or (Lab3.Text = 1))) Or ((((Lab7.Text = 9) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 9))) And ((Lab3.Text = 8) Or (Lab3.Text = 7))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab1.Text : Lab1.Text = rt.Text
                Else
                    rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
                End If
            ElseIf Lab6.Text = 6 Then
                If ((((Lab7.Text = 3) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 3))) And ((Lab1.Text = 2) Or (Lab1.Text = 1))) Or ((((Lab7.Text = 9) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 9))) And ((Lab1.Text = 8) Or (Lab1.Text = 7))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab2.Text : Lab2.Text = rt.Text
                ElseIf ((((Lab7.Text = 3) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 3))) And ((Lab2.Text = 2) Or (Lab2.Text = 1))) Or ((((Lab7.Text = 9) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 9))) And ((Lab2.Text = 8) Or (Lab2.Text = 7))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
                ElseIf ((((Lab7.Text = 3) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 3))) And ((Lab3.Text = 2) Or (Lab3.Text = 1))) Or ((((Lab7.Text = 9) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 9))) And ((Lab3.Text = 8) Or (Lab3.Text = 7))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab1.Text : Lab1.Text = rt.Text
                Else
                    rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
                End If
            End If
        ElseIf (((((Lab7.Text = 6) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 6))) And ((La4.Text = 1) And (La5.Text = 1))) Or ((((Lab7.Text = 6) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 6))) And ((La4.Text = 1) And (La6.Text = 1))) Or ((((Lab8.Text = 6) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 6))) And ((La5.Text = 1) And (La6.Text = 1)))) And ((Lab4.Text = 3) Or (Lab5.Text = 3) Or (Lab6.Text = 3)) Then
            If Lab4.Text = 3 Then
                If ((((Lab7.Text = 6) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 6))) And ((Lab1.Text = 5) Or (Lab1.Text = 4))) Or ((((Lab7.Text = 9) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 9))) And ((Lab1.Text = 8) Or (Lab1.Text = 7))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
                ElseIf ((((Lab7.Text = 6) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 6))) And ((Lab2.Text = 5) Or (Lab2.Text = 4))) Or ((((Lab7.Text = 9) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 9))) And ((Lab2.Text = 8) Or (Lab2.Text = 7))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
                ElseIf ((((Lab7.Text = 6) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 6))) And ((Lab3.Text = 5) Or (Lab3.Text = 4))) Or ((((Lab7.Text = 9) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 9))) And ((Lab3.Text = 8) Or (Lab3.Text = 7))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
                End If
            ElseIf Lab5.Text = 3 Then
                If ((((Lab7.Text = 6) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 6))) And ((Lab1.Text = 5) Or (Lab1.Text = 4))) Or ((((Lab7.Text = 9) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 9))) And ((Lab1.Text = 8) Or (Lab1.Text = 7))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab2.Text : Lab2.Text = rt.Text
                ElseIf ((((Lab7.Text = 6) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 6))) And ((Lab2.Text = 5) Or (Lab2.Text = 4))) Or ((((Lab7.Text = 9) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 9))) And ((Lab2.Text = 8) Or (Lab2.Text = 7))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
                ElseIf ((((Lab7.Text = 6) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 6))) And ((Lab3.Text = 5) Or (Lab3.Text = 4))) Or ((((Lab7.Text = 9) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 9))) And ((Lab3.Text = 8) Or (Lab3.Text = 7))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab1.Text : Lab1.Text = rt.Text
                Else
                    rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
                End If
            ElseIf Lab6.Text = 3 Then
                If ((((Lab7.Text = 6) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 6))) And ((Lab1.Text = 5) Or (Lab1.Text = 4))) Or ((((Lab7.Text = 9) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 9))) And ((Lab1.Text = 8) Or (Lab1.Text = 7))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab2.Text : Lab2.Text = rt.Text
                ElseIf ((((Lab7.Text = 6) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 6))) And ((Lab2.Text = 5) Or (Lab2.Text = 4))) Or ((((Lab7.Text = 9) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 9))) And ((Lab2.Text = 8) Or (Lab2.Text = 7))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
                ElseIf ((((Lab7.Text = 6) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 6))) And ((Lab3.Text = 5) Or (Lab3.Text = 4))) Or ((((Lab7.Text = 9) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 9))) And ((Lab3.Text = 8) Or (Lab3.Text = 7))) Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab1.Text : Lab1.Text = rt.Text
                Else
                    rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
                End If
            End If
        ElseIf (((Lab7.Text = 1) And (Lab8.Text = 5)) Or ((Lab8.Text = 1) And (Lab7.Text = 5))) And ((Lab4.Text = 9) Or (Lab5.Text = 9) Or (Lab6.Text = 9)) And ((La4.Text = 1) And (La5.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 9 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab5.Text = 9 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab6.Text = 9 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
            End If
        ElseIf (((Lab7.Text = 1) And (Lab9.Text = 5)) Or ((Lab9.Text = 1) And (Lab7.Text = 5))) And ((Lab4.Text = 9) Or (Lab5.Text = 9) Or (Lab6.Text = 9)) And ((La4.Text = 1) And (La6.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 9 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab5.Text = 9 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab6.Text = 9 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab2.Text : Lab2.Text = rt.Text
            End If
        ElseIf (((Lab8.Text = 1) And (Lab9.Text = 5)) Or ((Lab9.Text = 1) And (Lab8.Text = 5))) And ((Lab4.Text = 9) Or (Lab5.Text = 9) Or (Lab6.Text = 9)) And ((La5.Text = 1) And (La6.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 9 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
            ElseIf Lab5.Text = 9 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab1.Text : Lab1.Text = rt.Text
            ElseIf Lab6.Text = 9 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab1.Text : Lab1.Text = rt.Text
            End If
        ElseIf (((Lab7.Text = 1) And (Lab8.Text = 9)) Or ((Lab8.Text = 1) And (Lab7.Text = 9))) And ((Lab4.Text = 5) Or (Lab5.Text = 5) Or (Lab6.Text = 5)) And ((La4.Text = 1) And (La5.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 5 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab5.Text = 5 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab6.Text = 5 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
            End If
        ElseIf (((Lab7.Text = 1) And (Lab9.Text = 9)) Or ((Lab9.Text = 1) And (Lab7.Text = 9))) And ((Lab4.Text = 5) Or (Lab5.Text = 5) Or (Lab6.Text = 5)) And ((La4.Text = 1) And (La6.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 5 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab5.Text = 5 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab6.Text = 5 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab2.Text : Lab2.Text = rt.Text
            End If
        ElseIf (((Lab8.Text = 1) And (Lab9.Text = 9)) Or ((Lab9.Text = 1) And (Lab8.Text = 9))) And ((Lab4.Text = 5) Or (Lab5.Text = 5) Or (Lab6.Text = 5)) And ((La5.Text = 1) And (La6.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 5 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
            ElseIf Lab5.Text = 5 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab1.Text : Lab1.Text = rt.Text
            ElseIf Lab6.Text = 5 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab1.Text : Lab1.Text = rt.Text
            End If
        ElseIf (((Lab7.Text = 5) And (Lab8.Text = 9)) Or ((Lab8.Text = 5) And (Lab7.Text = 9))) And ((Lab4.Text = 1) Or (Lab5.Text = 1) Or (Lab6.Text = 1)) And ((La4.Text = 1) And (La5.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 1 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab5.Text = 1 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab6.Text = 1 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
            End If
        ElseIf (((Lab7.Text = 5) And (Lab9.Text = 9)) Or ((Lab9.Text = 5) And (Lab7.Text = 9))) And ((Lab4.Text = 1) Or (Lab5.Text = 1) Or (Lab6.Text = 1)) And ((La4.Text = 1) And (La6.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 1 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab5.Text = 1 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab6.Text = 1 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab2.Text : Lab2.Text = rt.Text
            End If
        ElseIf (((Lab8.Text = 5) And (Lab9.Text = 9)) Or ((Lab9.Text = 5) And (Lab8.Text = 9))) And ((Lab4.Text = 1) Or (Lab5.Text = 1) Or (Lab6.Text = 1)) And ((La5.Text = 1) And (La6.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 1 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
            ElseIf Lab5.Text = 1 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab1.Text : Lab1.Text = rt.Text
            ElseIf Lab6.Text = 1 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab1.Text : Lab1.Text = rt.Text
            End If
        ElseIf (((Lab7.Text = 3) And (Lab8.Text = 5)) Or ((Lab8.Text = 3) And (Lab7.Text = 5))) And ((Lab4.Text = 7) Or (Lab5.Text = 7) Or (Lab6.Text = 7)) And ((La4.Text = 1) And (La5.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 7 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab5.Text = 7 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab6.Text = 7 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
            End If
        ElseIf (((Lab7.Text = 3) And (Lab9.Text = 5)) Or ((Lab9.Text = 3) And (Lab7.Text = 5))) And ((Lab4.Text = 7) Or (Lab5.Text = 7) Or (Lab6.Text = 7)) And ((La4.Text = 1) And (La6.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 7 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab5.Text = 7 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab6.Text = 7 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab2.Text : Lab2.Text = rt.Text
            End If
        ElseIf (((Lab8.Text = 3) And (Lab9.Text = 5)) Or ((Lab9.Text = 3) And (Lab8.Text = 5))) And ((Lab4.Text = 7) Or (Lab5.Text = 7) Or (Lab6.Text = 7)) And ((La5.Text = 1) And (La6.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 7 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
            ElseIf Lab5.Text = 7 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab1.Text : Lab1.Text = rt.Text
            ElseIf Lab6.Text = 7 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab1.Text : Lab1.Text = rt.Text
            End If
        ElseIf (((Lab7.Text = 3) And (Lab8.Text = 7)) Or ((Lab8.Text = 3) And (Lab7.Text = 7))) And ((Lab4.Text = 5) Or (Lab5.Text = 5) Or (Lab6.Text = 5)) And ((La4.Text = 1) And (La5.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 5 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab5.Text = 5 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab6.Text = 5 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
            End If
        ElseIf (((Lab7.Text = 3) And (Lab9.Text = 7)) Or ((Lab9.Text = 3) And (Lab7.Text = 7))) And ((Lab4.Text = 5) Or (Lab5.Text = 5) Or (Lab6.Text = 5)) And ((La4.Text = 1) And (La6.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 5 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab5.Text = 5 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab6.Text = 5 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab2.Text : Lab2.Text = rt.Text
            End If
        ElseIf (((Lab8.Text = 3) And (Lab9.Text = 7)) Or ((Lab9.Text = 3) And (Lab8.Text = 7))) And ((Lab4.Text = 5) Or (Lab5.Text = 5) Or (Lab6.Text = 5)) And ((La5.Text = 1) And (La6.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 5 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
            ElseIf Lab5.Text = 5 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab1.Text : Lab1.Text = rt.Text
            ElseIf Lab6.Text = 5 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab1.Text : Lab1.Text = rt.Text
            End If
        ElseIf (((Lab7.Text = 5) And (Lab8.Text = 7)) Or ((Lab8.Text = 5) And (Lab7.Text = 7))) And ((Lab4.Text = 3) Or (Lab5.Text = 3) Or (Lab6.Text = 3)) And ((La4.Text = 1) And (La5.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 3 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab5.Text = 3 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab6.Text = 3 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
            End If
        ElseIf (((Lab7.Text = 5) And (Lab9.Text = 7)) Or ((Lab9.Text = 5) And (Lab7.Text = 7))) And ((Lab4.Text = 3) Or (Lab5.Text = 3) Or (Lab6.Text = 3)) And ((La4.Text = 1) And (La6.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 3 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab5.Text = 3 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab6.Text = 3 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab2.Text : Lab2.Text = rt.Text
            End If
        ElseIf (((Lab8.Text = 5) And (Lab9.Text = 7)) Or ((Lab9.Text = 5) And (Lab8.Text = 7))) And ((Lab4.Text = 3) Or (Lab5.Text = 3) Or (Lab6.Text = 3)) And ((La5.Text = 1) And (La6.Text = 1)) And (VaH.Checked = False) Then
            If Lab4.Text = 3 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
            ElseIf Lab5.Text = 3 Then
                rt.Text = Lab5.Text : Lab5.Text = Lab1.Text : Lab1.Text = rt.Text
            ElseIf Lab6.Text = 3 Then
                rt.Text = Lab6.Text : Lab6.Text = Lab1.Text : Lab1.Text = rt.Text
            End If

        ElseIf (((((Lab7.Text = 1) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 1))) And ((La4.Text = 1) And (La5.Text = 1))) Or ((((Lab7.Text = 1) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 1))) And ((La4.Text = 1) And (La6.Text = 1))) Or ((((Lab8.Text = 1) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 1))) And ((La5.Text = 1) And (La6.Text = 1)))) And ((Lab1.Text = 3) Or (Lab2.Text = 3) Or (Lab3.Text = 3)) Then
            If Lab1.Text = 3 Then
                If ((((Lab7.Text = 2) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 2))) And ((Lab2.Text = 8) Or (Lab2.Text = 5))) Or ((((Lab7.Text = 1) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 1)) Or ((Lab7.Text = 1) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 1))) And ((Lab2.Text = 7) Or (Lab2.Text = 4))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
                End If
            ElseIf Lab2.Text = 3 Then
                If ((((Lab7.Text = 2) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 2))) And ((Lab3.Text = 8) Or (Lab3.Text = 5))) Or ((((Lab7.Text = 1) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 1)) Or ((Lab7.Text = 1) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 1))) And ((Lab3.Text = 7) Or (Lab3.Text = 4))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
                End If
            ElseIf Lab3.Text = 3 Then
                If ((((Lab7.Text = 2) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 2))) And ((Lab1.Text = 8) Or (Lab1.Text = 5))) Or ((((Lab7.Text = 1) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 1)) Or ((Lab7.Text = 1) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 1))) And ((Lab1.Text = 7) Or (Lab1.Text = 4))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
                End If
            End If
        ElseIf (((((Lab7.Text = 1) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 1))) And ((La4.Text = 1) And (La5.Text = 1))) Or ((((Lab7.Text = 1) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 1))) And ((La4.Text = 1) And (La6.Text = 1))) Or ((((Lab8.Text = 1) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 1))) And ((La5.Text = 1) And (La6.Text = 1)))) And ((Lab1.Text = 2) Or (Lab2.Text = 2) Or (Lab3.Text = 2)) Then
            If Lab1.Text = 2 Then
                If ((((Lab7.Text = 3) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 3))) And ((Lab2.Text = 9) Or (Lab2.Text = 6))) Or ((((Lab7.Text = 1) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 1)) Or ((Lab7.Text = 1) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 1))) And ((Lab2.Text = 7) Or (Lab2.Text = 4))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
                End If
            ElseIf Lab2.Text = 2 Then
                If ((((Lab7.Text = 3) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 3))) And ((Lab3.Text = 9) Or (Lab3.Text = 6))) Or ((((Lab7.Text = 1) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 1)) Or ((Lab7.Text = 1) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 1))) And ((Lab3.Text = 7) Or (Lab3.Text = 4))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
                End If
            ElseIf Lab3.Text = 2 Then
                If ((((Lab7.Text = 3) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 3))) And ((Lab1.Text = 9) Or (Lab1.Text = 6))) Or ((((Lab7.Text = 1) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 1)) Or ((Lab7.Text = 1) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 1))) And ((Lab1.Text = 7) Or (Lab1.Text = 4))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
                End If
            End If
        ElseIf (((((Lab7.Text = 2) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 2))) And ((La4.Text = 1) And (La5.Text = 1))) Or ((((Lab7.Text = 2) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 2))) And ((La4.Text = 1) And (La6.Text = 1))) Or ((((Lab8.Text = 2) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 2))) And ((La5.Text = 1) And (La6.Text = 1)))) And ((Lab1.Text = 1) Or (Lab2.Text = 1) Or (Lab3.Text = 1)) Then
            If Lab1.Text = 1 Then
                If ((((Lab7.Text = 3) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 3))) And ((Lab2.Text = 9) Or (Lab2.Text = 6))) Or ((((Lab7.Text = 2) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 2))) And ((Lab2.Text = 8) Or (Lab2.Text = 5))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
                End If
            ElseIf Lab2.Text = 1 Then
                If ((((Lab7.Text = 3) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 3))) And ((Lab3.Text = 9) Or (Lab3.Text = 6))) Or ((((Lab7.Text = 2) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 2))) And ((Lab3.Text = 8) Or (Lab3.Text = 5))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
                End If
            ElseIf Lab3.Text = 1 Then
                If ((((Lab7.Text = 3) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 3)) Or ((Lab7.Text = 3) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 3))) And ((Lab1.Text = 9) Or (Lab1.Text = 6))) Or ((((Lab7.Text = 2) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 2)) Or ((Lab7.Text = 2) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 2))) And ((Lab1.Text = 8) Or (Lab1.Text = 5))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
                End If
            End If
        ElseIf (((((Lab7.Text = 4) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 4))) And ((La4.Text = 1) And (La5.Text = 1))) Or ((((Lab7.Text = 4) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 4))) And ((La4.Text = 1) And (La6.Text = 1))) Or ((((Lab8.Text = 4) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 4))) And ((La5.Text = 1) And (La6.Text = 1)))) And ((Lab1.Text = 6) Or (Lab2.Text = 6) Or (Lab3.Text = 6)) Then
            If Lab1.Text = 6 Then
                If ((((Lab7.Text = 2) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 2)) Or ((Lab7.Text = 5) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 5))) And ((Lab2.Text = 8) Or (Lab2.Text = 2))) Or ((((Lab7.Text = 1) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 1)) Or ((Lab7.Text = 4) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 4))) And ((Lab2.Text = 7) Or (Lab2.Text = 1))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
                End If
            ElseIf Lab2.Text = 6 Then
                If ((((Lab7.Text = 2) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 2)) Or ((Lab7.Text = 5) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 5))) And ((Lab3.Text = 8) Or (Lab3.Text = 2))) Or ((((Lab7.Text = 1) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 1)) Or ((Lab7.Text = 4) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 4))) And ((Lab3.Text = 7) Or (Lab3.Text = 1))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
                End If
            ElseIf Lab3.Text = 6 Then
                If ((((Lab7.Text = 2) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 2)) Or ((Lab7.Text = 5) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 5))) And ((Lab1.Text = 8) Or (Lab1.Text = 2))) Or ((((Lab7.Text = 1) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 1)) Or ((Lab7.Text = 4) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 4))) And ((Lab1.Text = 7) Or (Lab1.Text = 1))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
                End If
            End If
        ElseIf (((((Lab7.Text = 4) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 4))) And ((La4.Text = 1) And (La5.Text = 1))) Or ((((Lab7.Text = 4) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 4))) And ((La4.Text = 1) And (La6.Text = 1))) Or ((((Lab8.Text = 4) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 4))) And ((La5.Text = 1) And (La6.Text = 1)))) And ((Lab1.Text = 5) Or (Lab2.Text = 5) Or (Lab3.Text = 5)) Then
            If Lab1.Text = 5 Then
                If ((((Lab7.Text = 1) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 1)) Or ((Lab7.Text = 4) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 4))) And ((Lab2.Text = 7) Or (Lab2.Text = 1))) Or ((((Lab7.Text = 3) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 3)) Or ((Lab7.Text = 6) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 6))) And ((Lab2.Text = 9) Or (Lab2.Text = 3))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
                End If
            ElseIf Lab2.Text = 5 Then
                If ((((Lab7.Text = 1) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 1)) Or ((Lab7.Text = 4) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 4))) And ((Lab3.Text = 7) Or (Lab3.Text = 1))) Or ((((Lab7.Text = 3) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 3)) Or ((Lab7.Text = 6) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 6))) And ((Lab3.Text = 9) Or (Lab3.Text = 3))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
                End If
            ElseIf Lab3.Text = 5 Then
                If ((((Lab7.Text = 1) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 1)) Or ((Lab7.Text = 4) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 4))) And ((Lab1.Text = 7) Or (Lab1.Text = 1))) Or ((((Lab7.Text = 3) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 3)) Or ((Lab7.Text = 6) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 6))) And ((Lab1.Text = 9) Or (Lab1.Text = 3))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
                End If
            End If
        ElseIf (((((Lab7.Text = 5) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 5))) And ((La4.Text = 1) And (La5.Text = 1))) Or ((((Lab7.Text = 5) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 5))) And ((La4.Text = 1) And (La6.Text = 1))) Or ((((Lab8.Text = 5) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 5))) And ((La5.Text = 1) And (La6.Text = 1)))) And ((Lab1.Text = 4) Or (Lab2.Text = 4) Or (Lab3.Text = 4)) Then
            If Lab1.Text = 4 Then
                If ((((Lab7.Text = 2) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 2)) Or ((Lab7.Text = 5) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 5))) And ((Lab2.Text = 8) Or (Lab2.Text = 2))) Or ((((Lab7.Text = 3) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 3)) Or ((Lab7.Text = 6) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 6))) And ((Lab2.Text = 9) Or (Lab2.Text = 3))) Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
                End If
            ElseIf Lab2.Text = 4 Then
                If ((((Lab7.Text = 2) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 2)) Or ((Lab7.Text = 5) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 5))) And ((Lab3.Text = 8) Or (Lab3.Text = 2))) Or ((((Lab7.Text = 3) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 3)) Or ((Lab7.Text = 6) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 6))) And ((Lab3.Text = 9) Or (Lab3.Text = 3))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
                End If
            ElseIf Lab3.Text = 4 Then
                If ((((Lab7.Text = 2) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 2)) Or ((Lab7.Text = 5) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 5))) And ((Lab1.Text = 8) Or (Lab1.Text = 2))) Or ((((Lab7.Text = 3) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 3)) Or ((Lab7.Text = 6) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 6))) And ((Lab1.Text = 9) Or (Lab1.Text = 3))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
                End If
            End If
        ElseIf (((((Lab7.Text = 7) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 7))) And ((La4.Text = 1) And (La5.Text = 1))) Or ((((Lab7.Text = 7) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 7))) And ((La4.Text = 1) And (La6.Text = 1))) Or ((((Lab8.Text = 7) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 7))) And ((La5.Text = 1) And (La6.Text = 1)))) And ((Lab1.Text = 9) Or (Lab2.Text = 9) Or (Lab3.Text = 9)) Then
            If Lab1.Text = 9 Then
                If ((((Lab7.Text = 2) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 2)) Or ((Lab7.Text = 5) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 5))) And ((Lab2.Text = 5) Or (Lab2.Text = 2))) Or ((((Lab7.Text = 1) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 1)) Or ((Lab7.Text = 4) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 4))) And ((Lab2.Text = 4) Or (Lab2.Text = 1))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
                End If
            ElseIf Lab2.Text = 9 Then
                If ((((Lab7.Text = 2) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 2)) Or ((Lab7.Text = 5) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 5))) And ((Lab3.Text = 5) Or (Lab3.Text = 2))) Or ((((Lab7.Text = 1) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 1)) Or ((Lab7.Text = 4) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 4))) And ((Lab3.Text = 4) Or (Lab3.Text = 1))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
                End If
            ElseIf Lab3.Text = 9 Then
                If ((((Lab7.Text = 2) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 2)) Or ((Lab7.Text = 5) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 5))) And ((Lab1.Text = 5) Or (Lab1.Text = 2))) Or ((((Lab7.Text = 1) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 1)) Or ((Lab7.Text = 4) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 4))) And ((Lab1.Text = 4) Or (Lab1.Text = 1))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
                End If
            End If
        ElseIf (((((Lab7.Text = 7) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 7))) And ((La4.Text = 1) And (La5.Text = 1))) Or ((((Lab7.Text = 7) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 7))) And ((La4.Text = 1) And (La6.Text = 1))) Or ((((Lab8.Text = 7) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 7))) And ((La5.Text = 1) And (La6.Text = 1)))) And ((Lab1.Text = 8) Or (Lab2.Text = 8) Or (Lab3.Text = 8)) Then
            If Lab1.Text = 8 Then
                If ((((Lab7.Text = 3) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 3)) Or ((Lab7.Text = 6) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 6))) And ((Lab2.Text = 6) Or (Lab2.Text = 3))) Or ((((Lab7.Text = 1) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 1)) Or ((Lab7.Text = 4) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 4))) And ((Lab2.Text = 4) Or (Lab2.Text = 1))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
                End If
            ElseIf Lab2.Text = 8 Then
                If ((((Lab7.Text = 3) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 3)) Or ((Lab7.Text = 6) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 6))) And ((Lab3.Text = 6) Or (Lab3.Text = 3))) Or ((((Lab7.Text = 1) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 1)) Or ((Lab7.Text = 4) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 4))) And ((Lab3.Text = 4) Or (Lab3.Text = 1))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
                End If
            ElseIf Lab3.Text = 8 Then
                If ((((Lab7.Text = 3) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 3)) Or ((Lab7.Text = 6) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 6))) And ((Lab1.Text = 6) Or (Lab1.Text = 3))) Or ((((Lab7.Text = 1) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 1)) Or ((Lab7.Text = 1) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 1)) Or ((Lab8.Text = 1) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 1)) Or ((Lab7.Text = 4) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 4))) And ((Lab1.Text = 4) Or (Lab1.Text = 1))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
                End If
            End If
        ElseIf (((((Lab7.Text = 8) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 8))) And ((La4.Text = 1) And (La5.Text = 1))) Or ((((Lab7.Text = 8) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 8))) And ((La4.Text = 1) And (La6.Text = 1))) Or ((((Lab8.Text = 8) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 8))) And ((La5.Text = 1) And (La6.Text = 1)))) And ((Lab1.Text = 7) Or (Lab2.Text = 7) Or (Lab3.Text = 7)) Then
            If Lab1.Text = 7 Then
                If ((((Lab7.Text = 3) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 3)) Or ((Lab7.Text = 6) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 6))) And ((Lab2.Text = 6) Or (Lab2.Text = 3))) Or ((((Lab7.Text = 2) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 2)) Or ((Lab7.Text = 5) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 5))) And ((Lab2.Text = 5) Or (Lab2.Text = 2))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
                End If
            ElseIf Lab2.Text = 7 Then
                If ((((Lab7.Text = 3) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 3)) Or ((Lab7.Text = 6) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 6))) And ((Lab3.Text = 6) Or (Lab3.Text = 3))) Or ((((Lab7.Text = 2) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 2)) Or ((Lab7.Text = 5) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 5))) And ((Lab3.Text = 5) Or (Lab3.Text = 2))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
                End If
            ElseIf Lab3.Text = 7 Then
                If ((((Lab7.Text = 3) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 3)) Or ((Lab7.Text = 3) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 3)) Or ((Lab8.Text = 3) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 3)) Or ((Lab7.Text = 6) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 6))) And ((Lab1.Text = 6) Or (Lab1.Text = 3))) Or ((((Lab7.Text = 2) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 2)) Or ((Lab7.Text = 2) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 2)) Or ((Lab8.Text = 2) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 2)) Or ((Lab7.Text = 5) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 5))) And ((Lab1.Text = 5) Or (Lab1.Text = 2))) Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
                Else
                    rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
                End If
            End If
        ElseIf (((((Lab7.Text = 1) And (Lab8.Text = 4)) Or ((Lab7.Text = 4) And (Lab8.Text = 1))) And ((La4.Text = 1) And (La5.Text = 1))) Or ((((Lab7.Text = 1) And (Lab9.Text = 4)) Or ((Lab7.Text = 4) And (Lab9.Text = 1))) And ((La4.Text = 1) And (La6.Text = 1))) Or ((((Lab8.Text = 1) And (Lab9.Text = 4)) Or ((Lab8.Text = 4) And (Lab9.Text = 1))) And ((La5.Text = 1) And (La6.Text = 1)))) And ((Lab1.Text = 7) Or (Lab2.Text = 7) Or (Lab3.Text = 7)) Then
            If Lab1.Text = 7 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab2.Text = 7 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab3.Text = 7 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
            End If
        ElseIf (((((Lab7.Text = 1) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 1))) And ((La4.Text = 1) And (La5.Text = 1))) Or ((((Lab7.Text = 1) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 1))) And ((La4.Text = 1) And (La6.Text = 1))) Or ((((Lab8.Text = 1) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 1))) And ((La5.Text = 1) And (La6.Text = 1)))) And ((Lab1.Text = 4) Or (Lab2.Text = 4) Or (Lab3.Text = 4)) Then
            If Lab1.Text = 4 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab2.Text = 4 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab3.Text = 4 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
            End If
        ElseIf (((((Lab7.Text = 4) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 4))) And ((La4.Text = 1) And (La5.Text = 1))) Or ((((Lab7.Text = 4) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 4))) And ((La4.Text = 1) And (La6.Text = 1))) Or ((((Lab8.Text = 4) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 4))) And ((La5.Text = 1) And (La6.Text = 1)))) And ((Lab1.Text = 1) Or (Lab2.Text = 1) Or (Lab3.Text = 1)) Then
            If Lab1.Text = 1 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab2.Text = 1 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab3.Text = 1 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
            End If
        ElseIf (((((Lab7.Text = 2) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 2))) And ((La4.Text = 1) And (La5.Text = 1))) Or ((((Lab7.Text = 2) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 2))) And ((La4.Text = 1) And (La6.Text = 1))) Or ((((Lab8.Text = 2) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 2))) And ((La5.Text = 1) And (La6.Text = 1)))) And ((Lab1.Text = 8) Or (Lab2.Text = 8) Or (Lab3.Text = 8)) Then
            If Lab1.Text = 8 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab2.Text = 8 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab3.Text = 8 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
            End If
        ElseIf (((((Lab7.Text = 2) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 2))) And ((La4.Text = 1) And (La5.Text = 1))) Or ((((Lab7.Text = 2) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 2))) And ((La4.Text = 1) And (La6.Text = 1))) Or ((((Lab8.Text = 2) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 2))) And ((La5.Text = 1) And (La6.Text = 1)))) And ((Lab1.Text = 5) Or (Lab2.Text = 5) Or (Lab3.Text = 5)) Then
            If Lab1.Text = 5 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab2.Text = 5 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab3.Text = 5 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
            End If
        ElseIf (((((Lab7.Text = 5) And (Lab8.Text = 8)) Or ((Lab7.Text = 8) And (Lab8.Text = 5))) And ((La4.Text = 1) And (La5.Text = 1))) Or ((((Lab7.Text = 5) And (Lab9.Text = 8)) Or ((Lab7.Text = 8) And (Lab9.Text = 5))) And ((La4.Text = 1) And (La6.Text = 1))) Or ((((Lab8.Text = 5) And (Lab9.Text = 8)) Or ((Lab8.Text = 8) And (Lab9.Text = 5))) And ((La5.Text = 1) And (La6.Text = 1)))) And ((Lab1.Text = 2) Or (Lab2.Text = 2) Or (Lab3.Text = 2)) Then
            If Lab1.Text = 2 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab2.Text = 2 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab3.Text = 2 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
            End If
        ElseIf (((((Lab7.Text = 3) And (Lab8.Text = 6)) Or ((Lab7.Text = 6) And (Lab8.Text = 3))) And ((La4.Text = 1) And (La5.Text = 1))) Or ((((Lab7.Text = 3) And (Lab9.Text = 6)) Or ((Lab7.Text = 6) And (Lab9.Text = 3))) And ((La4.Text = 1) And (La6.Text = 1))) Or ((((Lab8.Text = 3) And (Lab9.Text = 6)) Or ((Lab8.Text = 6) And (Lab9.Text = 3))) And ((La5.Text = 1) And (La6.Text = 1)))) And ((Lab1.Text = 9) Or (Lab2.Text = 9) Or (Lab3.Text = 9)) Then
            If Lab1.Text = 9 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab2.Text = 9 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab3.Text = 9 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
            End If
        ElseIf (((((Lab7.Text = 3) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 3))) And ((La4.Text = 1) And (La5.Text = 1))) Or ((((Lab7.Text = 3) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 3))) And ((La4.Text = 1) And (La6.Text = 1))) Or ((((Lab8.Text = 3) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 3))) And ((La5.Text = 1) And (La6.Text = 1)))) And ((Lab1.Text = 6) Or (Lab2.Text = 6) Or (Lab3.Text = 6)) Then
            If Lab1.Text = 6 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab2.Text = 6 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab3.Text = 6 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
            End If
        ElseIf (((((Lab7.Text = 6) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 6))) And ((La4.Text = 1) And (La5.Text = 1))) Or ((((Lab7.Text = 6) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 6))) And ((La4.Text = 1) And (La6.Text = 1))) Or ((((Lab8.Text = 6) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 6))) And ((La5.Text = 1) And (La6.Text = 1)))) And ((Lab1.Text = 3) Or (Lab2.Text = 3) Or (Lab3.Text = 3)) Then
            If Lab1.Text = 3 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab2.Text = 3 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab3.Text = 3 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
            End If
        ElseIf (((((Lab7.Text = 1) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 1))) And ((La4.Text = 1) And (La5.Text = 1))) Or ((((Lab7.Text = 1) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 1))) And ((La4.Text = 1) And (La6.Text = 1))) Or ((((Lab8.Text = 1) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 1))) And ((La5.Text = 1) And (La6.Text = 1)))) And ((Lab1.Text = 9) Or (Lab2.Text = 9) Or (Lab3.Text = 9)) And (VaH.Checked = False) Then
            If Lab1.Text = 9 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab2.Text = 9 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab3.Text = 9 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
            End If
        ElseIf (((((Lab7.Text = 1) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 1))) And ((La4.Text = 1) And (La5.Text = 1))) Or ((((Lab7.Text = 1) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 1))) And ((La4.Text = 1) And (La6.Text = 1))) Or ((((Lab8.Text = 1) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 1))) And ((La5.Text = 1) And (La6.Text = 1)))) And ((Lab1.Text = 5) Or (Lab2.Text = 5) Or (Lab3.Text = 5)) And (VaH.Checked = False) Then
            If Lab1.Text = 5 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab2.Text = 5 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab3.Text = 5 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
            End If
        ElseIf (((((Lab7.Text = 5) And (Lab8.Text = 9)) Or ((Lab7.Text = 9) And (Lab8.Text = 5))) And ((La4.Text = 1) And (La5.Text = 1))) Or ((((Lab7.Text = 5) And (Lab9.Text = 9)) Or ((Lab7.Text = 9) And (Lab9.Text = 5))) And ((La4.Text = 1) And (La6.Text = 1))) Or ((((Lab8.Text = 5) And (Lab9.Text = 9)) Or ((Lab8.Text = 9) And (Lab9.Text = 5))) And ((La5.Text = 1) And (La6.Text = 1)))) And ((Lab1.Text = 1) Or (Lab2.Text = 1) Or (Lab3.Text = 1)) And (VaH.Checked = False) Then
            If Lab1.Text = 1 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab2.Text = 1 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab3.Text = 1 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
            End If
        ElseIf (((((Lab7.Text = 3) And (Lab8.Text = 5)) Or ((Lab7.Text = 5) And (Lab8.Text = 3))) And ((La4.Text = 1) And (La5.Text = 1))) Or ((((Lab7.Text = 3) And (Lab9.Text = 5)) Or ((Lab7.Text = 5) And (Lab9.Text = 3))) And ((La4.Text = 1) And (La6.Text = 1))) Or ((((Lab8.Text = 3) And (Lab9.Text = 5)) Or ((Lab8.Text = 5) And (Lab9.Text = 3))) And ((La5.Text = 1) And (La6.Text = 1)))) And ((Lab1.Text = 7) Or (Lab2.Text = 7) Or (Lab3.Text = 7)) And (VaH.Checked = False) Then
            If Lab1.Text = 7 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab2.Text = 7 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab3.Text = 7 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
            End If
        ElseIf (((((Lab7.Text = 3) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 3))) And ((La4.Text = 1) And (La5.Text = 1))) Or ((((Lab7.Text = 3) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 3))) And ((La4.Text = 1) And (La6.Text = 1))) Or ((((Lab8.Text = 3) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 3))) And ((La5.Text = 1) And (La6.Text = 1)))) And ((Lab1.Text = 5) Or (Lab2.Text = 5) Or (Lab3.Text = 5)) And (VaH.Checked = False) Then
            If Lab1.Text = 5 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab2.Text = 5 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab3.Text = 5 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
            End If
        ElseIf (((((Lab7.Text = 5) And (Lab8.Text = 7)) Or ((Lab7.Text = 7) And (Lab8.Text = 5))) And ((La4.Text = 1) And (La5.Text = 1))) Or ((((Lab7.Text = 5) And (Lab9.Text = 7)) Or ((Lab7.Text = 7) And (Lab9.Text = 5))) And ((La4.Text = 1) And (La6.Text = 1))) Or ((((Lab8.Text = 5) And (Lab9.Text = 7)) Or ((Lab8.Text = 7) And (Lab9.Text = 5))) And ((La5.Text = 1) And (La6.Text = 1)))) And ((Lab1.Text = 3) Or (Lab2.Text = 3) Or (Lab3.Text = 3)) And (VaH.Checked = False) Then
            If Lab1.Text = 3 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
            ElseIf Lab2.Text = 3 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
            ElseIf Lab3.Text = 3 Then
                rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
            End If

        Else
            If ((La1.Text = 0) And (La2.Text = 0) And (La3.Text = 0)) Or ((La1.Text = 1) And (La2.Text = 1) And (La3.Text = 1)) Then
                If L4.Text = 1 Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
                ElseIf L4.Text = 2 Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab1.Text : Lab1.Text = rt.Text
                ElseIf L4.Text = 3 Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab1.Text : Lab1.Text = rt.Text
                ElseIf L4.Text = 4 Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
                ElseIf L4.Text = 5 Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab2.Text : Lab2.Text = rt.Text
                ElseIf L4.Text = 6 Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab2.Text : Lab2.Text = rt.Text
                ElseIf L4.Text = 7 Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
                ElseIf L4.Text = 8 Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
                ElseIf L4.Text = 9 Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
                End If
            Else
                If La1.Text = 0 Then
                    If (L4.Text = 1) Or (L4.Text = 2) Or (L4.Text = 3) Then
                        rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
                    ElseIf (L4.Text = 4) Or (L4.Text = 5) Or (L4.Text = 6) Then
                        rt.Text = Lab5.Text : Lab5.Text = Lab1.Text : Lab1.Text = rt.Text
                    ElseIf (L4.Text = 7) Or (L4.Text = 8) Or (L4.Text = 9) Then
                        rt.Text = Lab6.Text : Lab6.Text = Lab1.Text : Lab1.Text = rt.Text
                    End If
                ElseIf La2.Text = 0 Then
                    If (L4.Text = 1) Or (L4.Text = 2) Or (L4.Text = 3) Then
                        rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
                    ElseIf (L4.Text = 4) Or (L4.Text = 5) Or (L4.Text = 6) Then
                        rt.Text = Lab5.Text : Lab5.Text = Lab2.Text : Lab2.Text = rt.Text
                    ElseIf (L4.Text = 7) Or (L4.Text = 8) Or (L4.Text = 9) Then
                        rt.Text = Lab6.Text : Lab6.Text = Lab2.Text : Lab2.Text = rt.Text
                    End If
                ElseIf La3.Text = 0 Then
                    If (L4.Text = 1) Or (L4.Text = 2) Or (L4.Text = 3) Then
                        rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
                    ElseIf (L4.Text = 4) Or (L4.Text = 5) Or (L4.Text = 6) Then
                        rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
                    ElseIf (L4.Text = 7) Or (L4.Text = 8) Or (L4.Text = 9) Then
                        rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
                    End If
                End If
            End If
        End If
        L2.Text = 1
        stp1.Text = stp1.Text + 1
        If Lab1.Text = 1 Then
            z1.Location = New Point(78, 82)
        End If
        If Lab1.Text = 2 Then
            z1.Location = New Point(202, 82)
        End If
        If Lab1.Text = 3 Then
            z1.Location = New Point(323, 82)
        End If
        If Lab1.Text = 4 Then
            z1.Location = New Point(78, 200)
        End If
        If Lab1.Text = 5 Then
            z1.Location = New Point(202, 200)
        End If
        If Lab1.Text = 6 Then
            z1.Location = New Point(323, 200)
        End If
        If Lab1.Text = 7 Then
            z1.Location = New Point(78, 312)
        End If
        If Lab1.Text = 8 Then
            z1.Location = New Point(202, 312)
        End If
        If Lab1.Text = 9 Then
            z1.Location = New Point(323, 312)
        End If
        If Lab2.Text = 1 Then
            z2.Location = New Point(78, 82)
        End If
        If Lab2.Text = 2 Then
            z2.Location = New Point(202, 82)
        End If
        If Lab2.Text = 3 Then
            z2.Location = New Point(323, 82)
        End If
        If Lab2.Text = 4 Then
            z2.Location = New Point(78, 200)
        End If
        If Lab2.Text = 5 Then
            z2.Location = New Point(202, 200)
        End If
        If Lab2.Text = 6 Then
            z2.Location = New Point(323, 200)
        End If
        If Lab2.Text = 7 Then
            z2.Location = New Point(78, 312)
        End If
        If Lab2.Text = 8 Then
            z2.Location = New Point(202, 312)
        End If
        If Lab2.Text = 9 Then
            z2.Location = New Point(323, 312)
        End If
        If Lab3.Text = 1 Then
            z3.Location = New Point(78, 82)
        End If
        If Lab3.Text = 2 Then
            z3.Location = New Point(202, 82)
        End If
        If Lab3.Text = 3 Then
            z3.Location = New Point(323, 82)
        End If
        If Lab3.Text = 4 Then
            z3.Location = New Point(78, 200)
        End If
        If Lab3.Text = 5 Then
            z3.Location = New Point(202, 200)
        End If
        If Lab3.Text = 6 Then
            z3.Location = New Point(323, 200)
        End If
        If Lab3.Text = 7 Then
            z3.Location = New Point(78, 312)
        End If
        If Lab3.Text = 8 Then
            z3.Location = New Point(202, 312)
        End If
        If Lab3.Text = 9 Then
            z3.Location = New Point(323, 312)
        End If
        If Lab1.Text = Lb1.Text Then
        Else
            La1.Text = 1
            z1.BackgroundImage = My.Resources.zx
        End If
        If Lab2.Text = Lb2.Text Then
        Else
            La2.Text = 1
            z2.BackgroundImage = My.Resources.zx
        End If
        If Lab3.Text = Lb3.Text Then
        Else
            La3.Text = 1
            z3.BackgroundImage = My.Resources.zx
        End If
        If Lab4.Text = 1 Then
            a1.Location = New Point(78, 82)
        End If
        If Lab4.Text = 2 Then
            a1.Location = New Point(202, 82)
        End If
        If Lab4.Text = 3 Then
            a1.Location = New Point(323, 82)
        End If
        If Lab4.Text = 4 Then
            a1.Location = New Point(78, 200)
        End If
        If Lab4.Text = 5 Then
            a1.Location = New Point(202, 200)
        End If
        If Lab4.Text = 6 Then
            a1.Location = New Point(323, 200)
        End If
        If Lab4.Text = 7 Then
            a1.Location = New Point(78, 312)
        End If
        If Lab4.Text = 8 Then
            a1.Location = New Point(202, 312)
        End If
        If Lab4.Text = 9 Then
            a1.Location = New Point(323, 312)
        End If
        If Lab5.Text = 1 Then
            a2.Location = New Point(78, 82)
        End If
        If Lab5.Text = 2 Then
            a2.Location = New Point(202, 82)
        End If
        If Lab5.Text = 3 Then
            a2.Location = New Point(323, 82)
        End If
        If Lab5.Text = 4 Then
            a2.Location = New Point(78, 200)
        End If
        If Lab5.Text = 5 Then
            a2.Location = New Point(202, 200)
        End If
        If Lab5.Text = 6 Then
            a2.Location = New Point(323, 200)
        End If
        If Lab5.Text = 7 Then
            a2.Location = New Point(78, 312)
        End If
        If Lab5.Text = 8 Then
            a2.Location = New Point(202, 312)
        End If
        If Lab5.Text = 9 Then
            a2.Location = New Point(323, 312)
        End If
        If Lab6.Text = 1 Then
            a3.Location = New Point(78, 82)
        End If
        If Lab6.Text = 2 Then
            a3.Location = New Point(202, 82)
        End If
        If Lab6.Text = 3 Then
            a3.Location = New Point(323, 82)
        End If
        If Lab6.Text = 4 Then
            a3.Location = New Point(78, 200)
        End If
        If Lab6.Text = 5 Then
            a3.Location = New Point(202, 200)
        End If
        If Lab6.Text = 6 Then
            a3.Location = New Point(323, 200)
        End If
        If Lab6.Text = 7 Then
            a3.Location = New Point(78, 312)
        End If
        If Lab6.Text = 8 Then
            a3.Location = New Point(202, 312)
        End If
        If Lab6.Text = 9 Then
            a3.Location = New Point(323, 312)
        End If
        PB3.Visible = False : wt2.Visible = False
        Wn(e)
        PB1.BackgroundImage = My.Resources.cv
        If T4.Interval = 1 Then
            T4.Interval = 250
        End If
        T3.Start()
    End Sub

    Private Sub Cmpt2_CheckedChanged(sender As Object, e As EventArgs) Handles Cmpt2.CheckedChanged
        If Cmpt2.Checked = True Then
            If nm1.Text = "Player1" Or nm1.Text = "Player" Or nm1.Text = "" Then
                If Cmpt.Checked = False Then
                    nm1.Text = "Computer"
                Else
                    nm1.Text = "Computer1"
                End If
            End If
            If Cmpt.Checked = False Then
                If nm2.Text = "Player2" Or nm2.Text = "" Then
                    nm2.Text = "Player"
                End If
            End If
            T3.Start()
        Else
            If nm1.Text = "Computer" Or nm1.Text = "Computer1" Or nm1.Text = "" Then
                nm1.Text = "Player1"
            End If
            If nm2.Text = "Player" Or nm2.Text = "" Then
                nm2.Text = "Player2"
            End If
            T4.Stop()
            If Cmpt.Checked = False Then
                T3.Stop()
            End If
        End If
    End Sub
End Class
