﻿Public Class Sega
    Dim sg As String = My.Computer.FileSystem.SpecialDirectories.AllUsersApplicationData.Replace("5.80.371.3317", "")
    Dim gh1 As String
    Dim gh2 As String
    Dim gh3 As String
    Dim gh4 As String

    Private Sub Sega_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        My.Computer.FileSystem.DeleteDirectory(My.Computer.FileSystem.SpecialDirectories.AllUsersApplicationData, FileIO.DeleteDirectoryOption.DeleteAllContents)
        If My.Computer.FileSystem.DirectoryExists(sg + "Save") Then
            If My.Computer.FileSystem.DirectoryExists(sg + "NewSave") Then
                My.Computer.FileSystem.DeleteDirectory(sg + "NewSave", FileIO.DeleteDirectoryOption.DeleteAllContents)
            End If
            My.Computer.FileSystem.RenameDirectory(sg + "Save", "NewSave")
            ld.Enabled = True
        Else
            If My.Computer.FileSystem.DirectoryExists(sg + "NewSave") Then
                ld.Enabled = True
            End If
        End If
        Text = Text.Replace(" 3713317", "")
    End Sub

    Private Sub Sega_Key(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown, Bu1.KeyDown, Bu2.KeyDown, Bu3.KeyDown, Bu4.KeyDown, Bu5.KeyDown, Bu6.KeyDown, Bu7.KeyDown, Bu8.KeyDown, Bu9.KeyDown, B10.KeyDown, B11.KeyDown, bmp.KeyDown, Cmpt.KeyDown, wlf.KeyDown, nd.KeyDown, rd.KeyDown, ok1.KeyDown, ok2.KeyDown, NoS.KeyDown, VaH.KeyDown, ns.KeyDown, sv.KeyDown, ld.KeyDown, rh.KeyDown, rr.KeyDown, rl.KeyDown, rv.KeyDown
        If e.KeyCode = Keys.NumPad7 Or e.KeyCode = Keys.Q Then
            If Lab1.Text = "1" Then
                zx1(e)
            ElseIf Lab2.Text = "1" Then
                zx2(e)
            ElseIf Lab3.Text = "1" Then
                zx3(e)
            ElseIf Lab4.Text = "1" Then
                as1(e)
            ElseIf Lab5.Text = "1" Then
                as2(e)
            ElseIf Lab6.Text = "1" Then
                as3(e)
            ElseIf Lab7.Text = "1" Then
                cv1(e)
            ElseIf Lab8.Text = "1" Then
                cv2(e)
            ElseIf Lab9.Text = "1" Then
                cv3(e)
            End If
        ElseIf e.KeyCode = Keys.NumPad8 Or e.KeyCode = Keys.W Then
            If Lab1.Text = "2" Then
                zx1(e)
            ElseIf Lab2.Text = "2" Then
                zx2(e)
            ElseIf Lab3.Text = "2" Then
                zx3(e)
            ElseIf Lab4.Text = "2" Then
                as1(e)
            ElseIf Lab5.Text = "2" Then
                as2(e)
            ElseIf Lab6.Text = "2" Then
                as3(e)
            ElseIf Lab7.Text = "2" Then
                cv1(e)
            ElseIf Lab8.Text = "2" Then
                cv2(e)
            ElseIf Lab9.Text = "2" Then
                cv3(e)
            End If
        ElseIf e.KeyCode = Keys.NumPad9 Or e.KeyCode = Keys.E Then
            If Lab1.Text = "3" Then
                zx1(e)
            ElseIf Lab2.Text = "3" Then
                zx2(e)
            ElseIf Lab3.Text = "3" Then
                zx3(e)
            ElseIf Lab4.Text = "3" Then
                as1(e)
            ElseIf Lab5.Text = "3" Then
                as2(e)
            ElseIf Lab6.Text = "3" Then
                as3(e)
            ElseIf Lab7.Text = "3" Then
                cv1(e)
            ElseIf Lab8.Text = "3" Then
                cv2(e)
            ElseIf Lab9.Text = "3" Then
                cv3(e)
            End If
        ElseIf e.KeyCode = Keys.NumPad4 Or e.KeyCode = Keys.A Then
            If Lab1.Text = "4" Then
                zx1(e)
            ElseIf Lab2.Text = "4" Then
                zx2(e)
            ElseIf Lab3.Text = "4" Then
                zx3(e)
            ElseIf Lab4.Text = "4" Then
                as1(e)
            ElseIf Lab5.Text = "4" Then
                as2(e)
            ElseIf Lab6.Text = "4" Then
                as3(e)
            ElseIf Lab7.Text = "4" Then
                cv1(e)
            ElseIf Lab8.Text = "4" Then
                cv2(e)
            ElseIf Lab9.Text = "4" Then
                cv3(e)
            End If
        ElseIf e.KeyCode = Keys.NumPad5 Or e.KeyCode = Keys.S Then
            If Lab1.Text = "5" Then
                zx1(e)
            ElseIf Lab2.Text = "5" Then
                zx2(e)
            ElseIf Lab3.Text = "5" Then
                zx3(e)
            ElseIf Lab4.Text = "5" Then
                as1(e)
            ElseIf Lab5.Text = "5" Then
                as2(e)
            ElseIf Lab6.Text = "5" Then
                as3(e)
            ElseIf Lab7.Text = "5" Then
                cv1(e)
            ElseIf Lab8.Text = "5" Then
                cv2(e)
            ElseIf Lab9.Text = "5" Then
                cv3(e)
            End If
        ElseIf e.KeyCode = Keys.NumPad6 Or e.KeyCode = Keys.D Then
            If Lab1.Text = "6" Then
                zx1(e)
            ElseIf Lab2.Text = "6" Then
                zx2(e)
            ElseIf Lab3.Text = "6" Then
                zx3(e)
            ElseIf Lab4.Text = "6" Then
                as1(e)
            ElseIf Lab5.Text = "6" Then
                as2(e)
            ElseIf Lab6.Text = "6" Then
                as3(e)
            ElseIf Lab7.Text = "6" Then
                cv1(e)
            ElseIf Lab8.Text = "6" Then
                cv2(e)
            ElseIf Lab9.Text = "6" Then
                cv3(e)
            End If
        ElseIf e.KeyCode = Keys.NumPad1 Or e.KeyCode = Keys.Z Then
            If Lab1.Text = "7" Then
                zx1(e)
            ElseIf Lab2.Text = "7" Then
                zx2(e)
            ElseIf Lab3.Text = "7" Then
                zx3(e)
            ElseIf Lab4.Text = "7" Then
                as1(e)
            ElseIf Lab5.Text = "7" Then
                as2(e)
            ElseIf Lab6.Text = "7" Then
                as3(e)
            ElseIf Lab7.Text = "7" Then
                cv1(e)
            ElseIf Lab8.Text = "7" Then
                cv2(e)
            ElseIf Lab9.Text = "7" Then
                cv3(e)
            End If
        ElseIf e.KeyCode = Keys.NumPad2 Or e.KeyCode = Keys.X Then
            If Lab1.Text = "8" Then
                zx1(e)
            ElseIf Lab2.Text = "8" Then
                zx2(e)
            ElseIf Lab3.Text = "8" Then
                zx3(e)
            ElseIf Lab4.Text = "8" Then
                as1(e)
            ElseIf Lab5.Text = "8" Then
                as2(e)
            ElseIf Lab6.Text = "8" Then
                as3(e)
            ElseIf Lab7.Text = "8" Then
                cv1(e)
            ElseIf Lab8.Text = "8" Then
                cv2(e)
            ElseIf Lab9.Text = "8" Then
                cv3(e)
            End If
        ElseIf e.KeyCode = Keys.NumPad3 Or e.KeyCode = Keys.C Then
            If Lab1.Text = "9" Then
                zx1(e)
            ElseIf Lab2.Text = "9" Then
                zx2(e)
            ElseIf Lab3.Text = "9" Then
                zx3(e)
            ElseIf Lab4.Text = "9" Then
                as1(e)
            ElseIf Lab5.Text = "9" Then
                as2(e)
            ElseIf Lab6.Text = "9" Then
                as3(e)
            ElseIf Lab7.Text = "9" Then
                cv1(e)
            ElseIf Lab8.Text = "9" Then
                cv2(e)
            ElseIf Lab9.Text = "9" Then
                cv3(e)
            End If
        ElseIf e.KeyCode = Keys.F2 Or e.KeyCode = Keys.O Then
            If sv.Enabled = True Then
                sve(e)
            End If
        ElseIf e.KeyCode = Keys.F4 Or e.KeyCode = Keys.L Then
            If ld.Enabled = True Then
                lde(e)
            End If
        ElseIf e.KeyCode = Keys.K Or e.KeyCode = Keys.F8 Then
            If clr.Text < 255 Then
                clr.Text += 1
            End If
            clr2(e)
        ElseIf e.KeyCode = Keys.J Or e.KeyCode = Keys.F6 Then
            If clr.Text > 185 Then
                clr.Text -= 1
            End If
            clr2(e)
        ElseIf e.KeyCode = Keys.M Then
            Sega2.Show()
        ElseIf e.KeyCode = Keys.H Or e.KeyCode = Keys.F10 Then
            If Bu9.Visible = True Then
                h(e)
            End If
        ElseIf e.KeyCode = Keys.F5 Then
            If ok1.Checked = True Then
                ok1.Checked = False
            Else
                ok1.Checked = True
            End If
        ElseIf e.KeyCode = Keys.F7 Then
            If ok2.Checked = True Then
                ok2.Checked = False
            Else
                ok2.Checked = True
            End If
        ElseIf e.KeyCode = Keys.G Then
            g(e)
        ElseIf e.KeyCode = Keys.U Then
            If nd.Enabled = True Then
                u(e)
            End If
        ElseIf e.KeyCode = Keys.I Then
            If rd.Enabled = True Then
                r(e)
            End If
        ElseIf e.KeyCode = Keys.T Then
            If Cmpt.Checked = False Then
                Cmpt.Checked = True
            ElseIf Cmpt.Checked = True And bl.Text = "0" Then
                Cmpt.Checked = False
            End If
        ElseIf e.KeyCode = Keys.Y Then
            If ll.Text = "1" Then
                ll.Text = "2"
            ElseIf ll.Text = "2" Then
                ll.Text = "3"
            ElseIf ll.Text = "3" Then
                ll.Text = "4"
            ElseIf ll.Text = "4" Then
                ll.Text = "1"
            End If
            bmpn(e)
        End If
    End Sub

    Sub clr2(ByVal e As EventArgs)
        Dim cl As Color = Color.FromArgb(clr.Text, clr.Text, clr.Text)
        BackColor = cl
        nm1.BackColor = cl
        nm2.BackColor = cl
        bmp.BackColor = cl
        ns.BackColor = cl
        wlf.BackColor = cl
        fst.BackColor = cl
    End Sub

    Sub bmpn(ByVal e As EventArgs)
        If ll.Text = "1" Then
            If Bu8.Text = "عربي" Then
                bmp.Text = "Beginner"
            Else
                bmp.Text = "مبتدئ"
            End If
        ElseIf ll.Text = "2" Then
            If Bu8.Text = "عربي" Then
                bmp.Text = "Medium"
            Else
                bmp.Text = "متوسط"
            End If
        ElseIf ll.Text = "3" Then
            If Bu8.Text = "عربي" Then
                bmp.Text = "Advanced"
            Else
                bmp.Text = "متقدم"
            End If
        ElseIf ll.Text = "4" Then
            If Bu8.Text = "عربي" Then
                bmp.Text = "Professional"
            Else
                bmp.Text = "محترف"
            End If
        End If
    End Sub

    Private Sub bmp_TextChanged(sender As Object, e As EventArgs) Handles bmp.TextChanged
        bmpn(e)
    End Sub

    Private Sub bmp_SelectedIndexChanged(sender As Object, e As EventArgs) Handles bmp.SelectedIndexChanged
        If bmp.Text = "Beginner" Or bmp.Text = "مبتدئ" Then
            ll.Text = "1"
        ElseIf bmp.Text = "Medium" Or bmp.Text = "متوسط" Then
            ll.Text = "2"
        ElseIf bmp.Text = "Advanced" Or bmp.Text = "متقدم" Then
            ll.Text = "3"
        ElseIf bmp.Text = "Professional" Or bmp.Text = "محترف" Then
            ll.Text = "4"
        End If
        bmpn(e)
    End Sub

    Sub zx1(ByVal e As EventArgs)
        If L2.Text = "0" Then
            If La1.Text = "0" Then
                z1.BackgroundImage = My.Resources.zx23
            Else
                z1.BackgroundImage = My.Resources.zx2
            End If
            If La2.Text = "0" Then
                z2.BackgroundImage = My.Resources.zx3
            Else
                z2.BackgroundImage = My.Resources.zx
            End If
            If La3.Text = "0" Then
                z3.BackgroundImage = My.Resources.zx3
            Else
                z3.BackgroundImage = My.Resources.zx
            End If
            a1.Visible = True
            a2.Visible = True
            a3.Visible = True
            l1.Text = "1"
        End If
    End Sub

    Sub zx2(ByVal e As EventArgs)
        If L2.Text = "0" Then
            If La1.Text = "0" Then
                z1.BackgroundImage = My.Resources.zx3
            Else
                z1.BackgroundImage = My.Resources.zx
            End If
            If La2.Text = "0" Then
                z2.BackgroundImage = My.Resources.zx23
            Else
                z2.BackgroundImage = My.Resources.zx2
            End If
            If La3.Text = "0" Then
                z3.BackgroundImage = My.Resources.zx3
            Else
                z3.BackgroundImage = My.Resources.zx
            End If
            a1.Visible = True
            a2.Visible = True
            a3.Visible = True
            l1.Text = "2"
        End If
    End Sub

    Sub zx3(ByVal e As EventArgs)
        If L2.Text = "0" Then
            If La1.Text = "0" Then
                z1.BackgroundImage = My.Resources.zx3
            Else
                z1.BackgroundImage = My.Resources.zx
            End If
            If La2.Text = "0" Then
                z2.BackgroundImage = My.Resources.zx3
            Else
                z2.BackgroundImage = My.Resources.zx
            End If
            If La3.Text = "0" Then
                z3.BackgroundImage = My.Resources.zx23
            Else
                z3.BackgroundImage = My.Resources.zx2
            End If
            a1.Visible = True
            a2.Visible = True
            a3.Visible = True
            l1.Text = "3"
        End If
    End Sub

    Sub cv1(ByVal e As EventArgs)
        If Cmpt.Checked = False Then
            If L2.Text = "1" Then
                If La7.Text = "0" Then
                    c1.BackgroundImage = My.Resources.cv23
                Else
                    c1.BackgroundImage = My.Resources.cv2
                End If
                If La8.Text = "0" Then
                    c2.BackgroundImage = My.Resources.cv3
                Else
                    c2.BackgroundImage = My.Resources.cv
                End If
                If La9.Text = "0" Then
                    c3.BackgroundImage = My.Resources.cv3
                Else
                    c3.BackgroundImage = My.Resources.cv
                End If
                a1.Visible = True
                a2.Visible = True
                a3.Visible = True
                l1.Text = "7"
            End If
        End If
    End Sub

    Sub cv2(ByVal e As EventArgs)
        If Cmpt.Checked = False Then
            If L2.Text = "1" Then
                If La7.Text = "0" Then
                    c1.BackgroundImage = My.Resources.cv3
                Else
                    c1.BackgroundImage = My.Resources.cv
                End If
                If La8.Text = "0" Then
                    c2.BackgroundImage = My.Resources.cv23
                Else
                    c2.BackgroundImage = My.Resources.cv2
                End If
                If La9.Text = "0" Then
                    c3.BackgroundImage = My.Resources.cv3
                Else
                    c3.BackgroundImage = My.Resources.cv
                End If
                a1.Visible = True
                a2.Visible = True
                a3.Visible = True
                l1.Text = "8"
            End If
        End If
    End Sub

    Sub cv3(ByVal e As EventArgs)
        If Cmpt.Checked = False Then
            If L2.Text = "1" Then
                If La7.Text = "0" Then
                    c1.BackgroundImage = My.Resources.cv3
                Else
                    c1.BackgroundImage = My.Resources.cv
                End If
                If La8.Text = "0" Then
                    c2.BackgroundImage = My.Resources.cv3
                Else
                    c2.BackgroundImage = My.Resources.cv
                End If
                If La9.Text = "0" Then
                    c3.BackgroundImage = My.Resources.cv23
                Else
                    c3.BackgroundImage = My.Resources.cv2
                End If
                a1.Visible = True
                a2.Visible = True
                a3.Visible = True
                l1.Text = "9"
            End If
        End If
    End Sub

    Sub as1(ByVal e As EventArgs)
        If a1.Visible = True Then
            n0.Text += 2
            a1.Visible = False
            a2.Visible = False
            a3.Visible = False
            If l1.Text = "1" Then
                z1.BackgroundImage = My.Resources.zx
                ll.Location = z1.Location : z1.Location = a1.Location : a1.Location = ll.Location
                rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
                La1.Text = "1"
                stp1.Text = stp1.Text + 1
                L2.Text = "1"
                n1.Text = n1.Text + "1 "
                Le1.Text += 1
            ElseIf l1.Text = "2" Then
                z2.BackgroundImage = My.Resources.zx
                ll.Location = z2.Location : z2.Location = a1.Location : a1.Location = ll.Location
                rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
                La2.Text = "1"
                stp1.Text = stp1.Text + 1
                L2.Text = "1"
                n1.Text = n1.Text + "2 "
                Le2.Text += 1
            ElseIf l1.Text = "3" Then
                z3.BackgroundImage = My.Resources.zx
                ll.Location = z3.Location : z3.Location = a1.Location : a1.Location = ll.Location
                rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
                La3.Text = "1"
                stp1.Text = stp1.Text + 1
                L2.Text = "1"
                n1.Text = n1.Text + "3 "
                Le3.Text += 1
            ElseIf l1.Text = "7" Then
                c1.BackgroundImage = My.Resources.cv
                ll.Location = c1.Location : c1.Location = a1.Location : a1.Location = ll.Location
                l47(e)
                La7.Text = "1"
                stp2.Text = stp2.Text + 1
                L2.Text = "0"
                n1.Text = n1.Text + "4 "
                Le7.Text += 1
            ElseIf l1.Text = "8" Then
                c2.BackgroundImage = My.Resources.cv
                ll.Location = c2.Location : c2.Location = a1.Location : a1.Location = ll.Location
                l48(e)
                La8.Text = "1"
                stp2.Text = stp2.Text + 1
                L2.Text = "0"
                n1.Text = n1.Text + "5 "
                Le8.Text += 1
            ElseIf l1.Text = "9" Then
                c3.BackgroundImage = My.Resources.cv
                ll.Location = c3.Location : c3.Location = a1.Location : a1.Location = ll.Location
                l49(e)
                La9.Text = "1"
                stp2.Text = stp2.Text + 1
                L2.Text = "0"
                n1.Text = n1.Text + "6 "
                Le9.Text += 1
            End If
            l1.Text = "0"
            r0.Text = -1 : r1.Text = ""
            rf(e) : ne(e) : ws(e) : Wn(e)
            If L2.Text = "0" Then
                PB1.BackgroundImage = My.Resources.zx
            ElseIf L2.Text = "1" Then
                PB1.BackgroundImage = My.Resources.cv
            End If
        End If
    End Sub

    Sub as2(ByVal e As EventArgs)
        If a2.Visible = True Then
            n0.Text += 2
            a1.Visible = False
            a2.Visible = False
            a3.Visible = False
            If l1.Text = "1" Then
                z1.BackgroundImage = My.Resources.zx
                ll.Location = z1.Location : z1.Location = a2.Location : a2.Location = ll.Location
                rt.Text = Lab5.Text : Lab5.Text = Lab1.Text : Lab1.Text = rt.Text
                La1.Text = "1"
                stp1.Text = stp1.Text + 1
                L2.Text = "1"
                n1.Text = n1.Text + "7 "
                Le1.Text += 1
            ElseIf l1.Text = "2" Then
                z2.BackgroundImage = My.Resources.zx
                ll.Location = z2.Location : z2.Location = a2.Location : a2.Location = ll.Location
                rt.Text = Lab5.Text : Lab5.Text = Lab2.Text : Lab2.Text = rt.Text
                La2.Text = "1"
                stp1.Text = stp1.Text + 1
                L2.Text = "1"
                n1.Text = n1.Text + "8 "
                Le2.Text += 1
            ElseIf l1.Text = "3" Then
                z3.BackgroundImage = My.Resources.zx
                ll.Location = z3.Location : z3.Location = a2.Location : a2.Location = ll.Location
                rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
                La3.Text = "1"
                stp1.Text = stp1.Text + 1
                L2.Text = "1"
                n1.Text = n1.Text + "9 "
                Le3.Text += 1
            ElseIf l1.Text = "7" Then
                c1.BackgroundImage = My.Resources.cv
                ll.Location = c1.Location : c1.Location = a2.Location : a2.Location = ll.Location
                l57(e)
                La7.Text = "1"
                stp2.Text = stp2.Text + 1
                L2.Text = "0"
                n1.Text = n1.Text + "10"
                Le7.Text += 1
            ElseIf l1.Text = "8" Then
                c2.BackgroundImage = My.Resources.cv
                ll.Location = c2.Location : c2.Location = a2.Location : a2.Location = ll.Location
                l58(e)
                La8.Text = "1"
                stp2.Text = stp2.Text + 1
                L2.Text = "0"
                n1.Text = n1.Text + "11"
                Le8.Text += 1
            ElseIf l1.Text = "9" Then
                c3.BackgroundImage = My.Resources.cv
                ll.Location = c3.Location : c3.Location = a2.Location : a2.Location = ll.Location
                l59(e)
                La9.Text = "1"
                stp2.Text = stp2.Text + 1
                L2.Text = "0"
                n1.Text = n1.Text + "12"
                Le9.Text += 1
            End If
            l1.Text = "0"
            r0.Text = -1 : r1.Text = ""
            rf(e) : ne(e) : ws(e) : Wn(e)
            If L2.Text = "0" Then
                PB1.BackgroundImage = My.Resources.zx
            ElseIf L2.Text = "1" Then
                PB1.BackgroundImage = My.Resources.cv
            End If
        End If
    End Sub

    Sub as3(ByVal e As EventArgs)
        If a3.Visible = True Then
            n0.Text += 2
            a1.Visible = False
            a2.Visible = False
            a3.Visible = False
            If l1.Text = "1" Then
                z1.BackgroundImage = My.Resources.zx
                ll.Location = z1.Location : z1.Location = a3.Location : a3.Location = ll.Location
                rt.Text = Lab6.Text : Lab6.Text = Lab1.Text : Lab1.Text = rt.Text
                La1.Text = "1"
                stp1.Text = stp1.Text + 1
                L2.Text = "1"
                n1.Text = n1.Text + "13"
                Le1.Text += 1
            ElseIf l1.Text = "2" Then
                z2.BackgroundImage = My.Resources.zx
                ll.Location = z2.Location : z2.Location = a3.Location : a3.Location = ll.Location
                rt.Text = Lab6.Text : Lab6.Text = Lab2.Text : Lab2.Text = rt.Text
                La2.Text = "1"
                stp1.Text = stp1.Text + 1
                L2.Text = "1"
                n1.Text = n1.Text + "14"
                Le2.Text += 1
            ElseIf l1.Text = "3" Then
                z3.BackgroundImage = My.Resources.zx
                ll.Location = z3.Location : z3.Location = a3.Location : a3.Location = ll.Location
                rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
                La3.Text = "1"
                stp1.Text = stp1.Text + 1
                L2.Text = "1"
                n1.Text = n1.Text + "15"
                Le3.Text += 1
            ElseIf l1.Text = "7" Then
                c1.BackgroundImage = My.Resources.cv
                ll.Location = c1.Location : c1.Location = a3.Location : a3.Location = ll.Location
                l67(e)
                La7.Text = "1"
                stp2.Text = stp2.Text + 1
                L2.Text = "0"
                n1.Text = n1.Text + "16"
                Le7.Text += 1
            ElseIf l1.Text = "8" Then
                c2.BackgroundImage = My.Resources.cv
                ll.Location = c2.Location : c2.Location = a3.Location : a3.Location = ll.Location
                l68(e)
                La8.Text = "1"
                stp2.Text = stp2.Text + 1
                L2.Text = "0"
                n1.Text = n1.Text + "17"
                Le8.Text += 1
            ElseIf l1.Text = "9" Then
                c3.BackgroundImage = My.Resources.cv
                ll.Location = c3.Location : c3.Location = a3.Location : a3.Location = ll.Location
                l69(e)
                La9.Text = "1"
                stp2.Text = stp2.Text + 1
                L2.Text = "0"
                n1.Text = n1.Text + "18"
                Le9.Text += 1
            End If
            l1.Text = "0"
            r0.Text = -1 : r1.Text = ""
            rf(e) : ne(e) : ws(e) : Wn(e)
            If L2.Text = "0" Then
                PB1.BackgroundImage = My.Resources.zx
            ElseIf L2.Text = "1" Then
                PB1.BackgroundImage = My.Resources.cv
            End If
        End If
    End Sub

    Private Sub sgM(sender As Object, e As EventArgs) Handles MyBase.MouseEnter, MyClass.MouseEnter, Me.MouseEnter, PB1.MouseEnter, PB2.MouseEnter, wt.MouseEnter, PB3.MouseEnter, plyr1.MouseEnter, plyr2.MouseEnter, nm1.MouseEnter, nm2.MouseEnter, wn1.MouseEnter, wn2.MouseEnter, stp1.MouseEnter, stp2.MouseEnter, Cmpt.MouseEnter, bmp.MouseEnter, ok1.MouseEnter, ok2.MouseEnter, VaH.MouseEnter, NoS.MouseEnter, lns.MouseEnter, ns.MouseEnter, wlf.MouseEnter, Lf.MouseEnter, fst.MouseEnter, nd.MouseEnter, rd.MouseEnter, rr.MouseEnter, rl.MouseEnter, rh.MouseEnter, rv.MouseEnter, sv.MouseEnter, ld.MouseEnter, Bu1.MouseEnter, Bu2.MouseEnter, Bu3.MouseEnter, Bu4.MouseEnter, Bu5.MouseEnter, Bu6.MouseEnter, Bu7.MouseEnter, Bu8.MouseEnter, Bu9.MouseEnter, B10.MouseEnter, B11.MouseEnter, a1.MouseDown, a2.MouseDown, a3.MouseDown, z1.Click, z2.Click, z3.Click, c1.Click, c2.Click, c3.Click
        If Ldu.Text = "1" Then
            Ldu.Text = "0"
        End If
    End Sub

    Private Sub z1_Click(sender As Object, e As MouseEventArgs) Handles z1.MouseDown
        If L2.Text = "0" Then
            Ldu.Text = "1"
            zx1(e)
        Else
            Ldu.Text = "0"
        End If
    End Sub

    Private Sub z2_Click(sender As Object, e As MouseEventArgs) Handles z2.MouseDown
        If L2.Text = "0" Then
            Ldu.Text = "1"
            zx2(e)
        Else
            Ldu.Text = "0"
        End If
    End Sub

    Private Sub z3_Click(sender As Object, e As MouseEventArgs) Handles z3.MouseDown
        If L2.Text = "0" Then
            Ldu.Text = "1"
            zx3(e)
        Else
            Ldu.Text = "0"
        End If
    End Sub

    Private Sub c1_Click(sender As Object, e As MouseEventArgs) Handles c1.MouseDown
        If L2.Text = "1" And Cmpt.Checked = False Then
            Ldu.Text = "1"
            cv1(e)
        Else
            Ldu.Text = "0"
        End If
    End Sub

    Private Sub c2_Click(sender As Object, e As MouseEventArgs) Handles c2.MouseDown
        If L2.Text = "1" And Cmpt.Checked = False Then
            Ldu.Text = "1"
            cv2(e)
        Else
            Ldu.Text = "0"
        End If
    End Sub

    Private Sub c3_Click(sender As Object, e As MouseEventArgs) Handles c3.MouseDown
        If L2.Text = "1" And Cmpt.Checked = False Then
            Ldu.Text = "1"
            cv3(e)
        Else
            Ldu.Text = "0"
        End If
    End Sub

    Private Sub a1_Click(sender As Object, e As EventArgs) Handles a1.Click
        as1(e)
    End Sub

    Private Sub a1_Clic(sender As Object, e As EventArgs) Handles a1.MouseMove, a1.MouseEnter, a1.MouseHover
        If Ldu.Text = "1" Then
            as1(e)
        End If
    End Sub

    Private Sub a2_Click(sender As Object, e As EventArgs) Handles a2.Click
        as2(e)
    End Sub

    Private Sub a2_Clic(sender As Object, e As EventArgs) Handles a2.MouseMove, a2.MouseEnter, a2.MouseHover
        If Ldu.Text = "1" Then
            as2(e)
        End If
    End Sub

    Private Sub a3_Click(sender As Object, e As EventArgs) Handles a3.Click
        as3(e)
    End Sub

    Private Sub a3_Clic(sender As Object, e As EventArgs) Handles a3.MouseMove, a3.MouseEnter, a3.MouseHover
        If Ldu.Text = "1" Then
            as3(e)
        End If
    End Sub

    Private Sub Bu2_Click(sender As Object, e As EventArgs) Handles Bu2.Click
        Res(e)
    End Sub

    Private Sub Bu1_Click(sender As Object, e As EventArgs) Handles Bu1.Click
        Sega2.Show()
    End Sub

    Sub ne(ByVal e As EventArgs)
        nd.Enabled = True
        nd.BackgroundImage = My.Resources.nd
    End Sub

    Sub re(ByVal e As EventArgs)
        rd.Enabled = True
        rd.BackgroundImage = My.Resources.rd
    End Sub

    Sub nf(ByVal e As EventArgs)
        nd.Enabled = False
        nd.BackgroundImage = My.Resources.undo
    End Sub

    Sub rf(ByVal e As EventArgs)
        rd.Enabled = False
        rd.BackgroundImage = My.Resources.redo
    End Sub

    Private Sub NoS_Click(sender As Object, e As EventArgs) Handles NoS.Click
        If NoS.Checked = True Then
            If Bu8.Text = "عربي" Then
                If MsgBox(("- If you activate this feature, the number of steps of both players must be equal to win one of you.
- No one likes this feature because it is difficult and boring ...
- Are you sure you want to enable this feature ?!"), vbYesNo + vbQuestion, "Warning...") = MsgBoxResult.Yes Then
                Else
                    NoS.Checked = False
                End If
            Else
                If MsgBox(("- لو قمت بتفعيل هذه الخاصية،  يجب ان تكون عدد خطوات كلا اللاعبين متساوية ليفوز واحد منكما.
- لا احد يحب هذه الخاصية لأنها صعبة ومملة ...
- هل انت متأكد من انك تريد تفعيل هذه الخاصية ?!"), vbYesNo + vbQuestion + vbMsgBoxRight + vbMsgBoxRtlReading, "تحذير...") = MsgBoxResult.Yes Then
                Else
                    NoS.Checked = False
                End If
            End If
        End If
        If (L3.Text = "0") Or (L3.Text = "1") Then
            Wn(e)
        End If
    End Sub

    Private Sub NoS_CheckedChanged(sender As Object, e As EventArgs) Handles NoS.CheckedChanged
        If NoS.Checked = True Then
            stp1.Visible = True
            stp2.Visible = True
        Else
            stp1.Visible = False
            stp2.Visible = False
        End If
    End Sub

    Sub Res(ByVal e As EventArgs)
        If bl.Text = "0" Then
            La1.Text = "0" : La2.Text = "0" : La3.Text = "0" : La7.Text = "0" : La8.Text = "0" : La9.Text = "0"
            Lab1.Text = "1" : Lab2.Text = "2" : Lab3.Text = "3" : Lab4.Text = "4" : Lab5.Text = "5" : Lab6.Text = "6" : Lab7.Text = "7" : Lab8.Text = "8" : Lab9.Text = "9"
            stp1.Text = "0" : stp2.Text = "0"
            l1.Text = "0"
            n0.Text = "-1" : r0.Text = "-1"
            n1.Text = "" : r1.Text = ""
            Le1.Text = "0" : Le2.Text = "0" : Le3.Text = "0" : Le7.Text = "0" : Le8.Text = "0" : Le9.Text = "0"
            If ok1.Checked = True Then
                o1.Text = "1"
                ok1.Text = "OK +1"
            Else
                o1.Text = "0"
                ok1.Text = "OK"
            End If
            If ok2.Checked = True Then
                o2.Text = "1"
                ok2.Text = "OK +1"
            Else
                o2.Text = "0"
                ok2.Text = "OK"
            End If
            If Bu8.Text = "English" Then
                ok1.Text = ok1.Text.Replace("OK", "موافق")
                ok2.Text = ok2.Text.Replace("OK", "موافق")
            End If
            loc(e) : nf(e) : rf(e)
            If Bu8.Text = "عربي" Then
                Bu4.Text = "Start"
            Else
                Bu4.Text = "إبدأ"
            End If
            T1.Stop()
            ll.Location = New Point(0, 0)
            L2.Text = L22.Text
            If L22.Text = "3" Then
                Bu4.Visible = True
                PB1.BackgroundImage = Nothing
            Else
                Bu4.Visible = False
                If L2.Text = "0" Then
                    PB1.BackgroundImage = My.Resources.zx
                ElseIf L2.Text = "1" Then
                    PB1.BackgroundImage = My.Resources.cv
                End If
            End If
            L3.Text = "2"
        End If
    End Sub

    Sub wn19(ByVal e As EventArgs)
        If (La1.Text = "1" And La2.Text = "1" And La3.Text = "1") And (((Lab1.Text = "1" Or Lab2.Text = "1" Or Lab3.Text = "1") And (Lab1.Text = "2" Or Lab2.Text = "2" Or Lab3.Text = "2") And (Lab1.Text = "3" Or Lab2.Text = "3" Or Lab3.Text = "3")) Or ((Lab1.Text = "4" Or Lab2.Text = "4" Or Lab3.Text = "4") And (Lab1.Text = "5" Or Lab2.Text = "5" Or Lab3.Text = "5") And (Lab1.Text = "6" Or Lab2.Text = "6" Or Lab3.Text = "6")) Or ((Lab1.Text = "7" Or Lab2.Text = "7" Or Lab3.Text = "7") And (Lab1.Text = "8" Or Lab2.Text = "8" Or Lab3.Text = "8") And (Lab1.Text = "9" Or Lab2.Text = "9" Or Lab3.Text = "9")) Or ((Lab1.Text = "1" Or Lab2.Text = "1" Or Lab3.Text = "1") And (Lab1.Text = "4" Or Lab2.Text = "4" Or Lab3.Text = "4") And (Lab1.Text = "7" Or Lab2.Text = "7" Or Lab3.Text = "7")) Or ((Lab1.Text = "2" Or Lab2.Text = "2" Or Lab3.Text = "2") And (Lab1.Text = "5" Or Lab2.Text = "5" Or Lab3.Text = "5") And (Lab1.Text = "8" Or Lab2.Text = "8" Or Lab3.Text = "8")) Or ((Lab1.Text = "3" Or Lab2.Text = "3" Or Lab3.Text = "3") And (Lab1.Text = "6" Or Lab2.Text = "6" Or Lab3.Text = "6") And (Lab1.Text = "9" Or Lab2.Text = "9" Or Lab3.Text = "9")) Or ((VaH.Checked = False) And (((Lab1.Text = "1" Or Lab2.Text = "1" Or Lab3.Text = "1") And (Lab1.Text = "5" Or Lab2.Text = "5" Or Lab3.Text = "5") And (Lab1.Text = "9" Or Lab2.Text = "9" Or Lab3.Text = "9")) Or ((Lab1.Text = "3" Or Lab2.Text = "3" Or Lab3.Text = "3") And (Lab1.Text = "5" Or Lab2.Text = "5" Or Lab3.Text = "5") And (Lab1.Text = "7" Or Lab2.Text = "7" Or Lab3.Text = "7"))))) Then
            lwz.Text = "0"
        Else
            lwz.Text = "2"
        End If
        If (La7.Text = "1" And La8.Text = "1" And La9.Text = "1") And (((Lab7.Text = "1" Or Lab8.Text = "1" Or Lab9.Text = "1") And (Lab7.Text = "2" Or Lab8.Text = "2" Or Lab9.Text = "2") And (Lab7.Text = "3" Or Lab8.Text = "3" Or Lab9.Text = "3")) Or ((Lab7.Text = "4" Or Lab8.Text = "4" Or Lab9.Text = "4") And (Lab7.Text = "5" Or Lab8.Text = "5" Or Lab9.Text = "5") And (Lab7.Text = "6" Or Lab8.Text = "6" Or Lab9.Text = "6")) Or ((Lab7.Text = "7" Or Lab8.Text = "7" Or Lab9.Text = "7") And (Lab7.Text = "8" Or Lab8.Text = "8" Or Lab9.Text = "8") And (Lab7.Text = "9" Or Lab8.Text = "9" Or Lab9.Text = "9")) Or ((Lab7.Text = "1" Or Lab8.Text = "1" Or Lab9.Text = "1") And (Lab7.Text = "4" Or Lab8.Text = "4" Or Lab9.Text = "4") And (Lab7.Text = "7" Or Lab8.Text = "7" Or Lab9.Text = "7")) Or ((Lab7.Text = "2" Or Lab8.Text = "2" Or Lab9.Text = "2") And (Lab7.Text = "5" Or Lab8.Text = "5" Or Lab9.Text = "5") And (Lab7.Text = "8" Or Lab8.Text = "8" Or Lab9.Text = "8")) Or ((Lab7.Text = "3" Or Lab8.Text = "3" Or Lab9.Text = "3") And (Lab7.Text = "6" Or Lab8.Text = "6" Or Lab9.Text = "6") And (Lab7.Text = "9" Or Lab8.Text = "9" Or Lab9.Text = "9")) Or ((VaH.Checked = False) And (((Lab7.Text = "1" Or Lab8.Text = "1" Or Lab9.Text = "1") And (Lab7.Text = "5" Or Lab8.Text = "5" Or Lab9.Text = "5") And (Lab7.Text = "9" Or Lab8.Text = "9" Or Lab9.Text = "9")) Or ((Lab7.Text = "3" Or Lab8.Text = "3" Or Lab9.Text = "3") And (Lab7.Text = "5" Or Lab8.Text = "5" Or Lab9.Text = "5") And (Lab7.Text = "7" Or Lab8.Text = "7" Or Lab9.Text = "7"))))) Then
            lwc.Text = "1"
        Else
            lwc.Text = "2"
        End If
    End Sub

    Sub wn37(ByVal e As EventArgs)
        If flw.Text = "1" Then
            If lwz.Text = "0" Then
                L2.Text = "0"
                L22.Text = "0"
            Else
                L2.Text = "1"
                L22.Text = "1"
            End If
        ElseIf flw.Text = "2" Then
            If lwz.Text = "0" Then
                L2.Text = "1"
                L22.Text = "1"
            Else
                L2.Text = "0"
                L22.Text = "0"
            End If
        ElseIf flw.Text = "3" Then
            If L22.Text = "0" Then
                L2.Text = "1"
                L22.Text = "1"
            Else
                L2.Text = "0"
                L22.Text = "0"
            End If
        ElseIf flw.Text = "4" Then
            Bu4.Visible = True
            L222.Text = "0" : L22.Text = "3" : L2.Text = "3"
            sv.Enabled = False
            Bu9.Visible = False
            ok1.Visible = False
            ok2.Visible = False
            PB1.BackgroundImage = Nothing
        ElseIf flw.Text = "5" Then
            Dim rand = New Random
            Dim x As Integer
            x = rand.Next(0, 2)
            Dim z As String = x
            If z = "0" Then
                L2.Text = "0"
                L22.Text = "0"
            Else
                L2.Text = "1"
                L22.Text = "1"
            End If
        End If
    End Sub

    Sub wlfn(ByVal e As EventArgs)
        If flw.Text = "1" Then
            If Bu8.Text = "عربي" Then
                wlf.Text = "The winner plays first"
            Else
                wlf.Text = "الفائز يلعب أولا"
            End If
        ElseIf flw.Text = "2" Then
            If Bu8.Text = "عربي" Then
                wlf.Text = "The loser plays first"
            Else
                wlf.Text = "الخاسر يلعب أولا"
            End If
        ElseIf flw.Text = "3" Then
            If Bu8.Text = "عربي" Then
                wlf.Text = "Who played first, plays second next time"
            Else
                wlf.Text = "الذي لعب أولا يلعب آخرا المرة القادمة"
            End If
        ElseIf flw.Text = "4" Then
            If Bu8.Text = "عربي" Then
                wlf.Text = "Choose who will play first by lot"
            Else
                wlf.Text = "إختيار من سيلعب أولا بالقرعة"
            End If
        ElseIf flw.Text = "5" Then
            If Bu8.Text = "عربي" Then
                wlf.Text = "Choose who will play first automatically"
            Else
                wlf.Text = "إختيار من سيلعب أولا تلقائيا"
            End If
        End If
    End Sub

    Private Sub wlf_TextChanged(sender As Object, e As EventArgs) Handles wlf.TextChanged
        wlfn(e)
    End Sub

    Private Sub wlf_SelectedIndexChanged(sender As Object, e As EventArgs) Handles wlf.SelectedIndexChanged
        If wlf.Text = "The winner plays first" Or wlf.Text = "الفائز يلعب أولا" Then
            flw.Text = "1"
        ElseIf wlf.Text = "The loser plays first" Or wlf.Text = "الخاسر يلعب أولا" Then
            flw.Text = "2"
        ElseIf wlf.Text = "Who played first, plays second next time" Or wlf.Text = "الذي لعب أولا يلعب آخرا المرة القادمة" Then
            flw.Text = "3"
        ElseIf wlf.Text = "Choose who will play first by lot" Or wlf.Text = "إختيار من سيلعب أولا بالقرعة" Then
            flw.Text = "4"
        ElseIf wlf.Text = "Choose who will play first automatically" Or wlf.Text = "إختيار من سيلعب أولا تلقائيا" Then
            flw.Text = "5"
        End If
        wlfn(e)
    End Sub

    Sub Wn(ByVal e As EventArgs)
        wn19(e)
        If (NoS.Checked = False) Or ((NoS.Checked = True) And (stp1.Text = stp2.Text) And (L3.Text = "2")) Then
            If lwz.Text = "0" Then
                wn1.Text = wn1.Text + 1
                z1.BackgroundImage = My.Resources.zx4
                z2.BackgroundImage = My.Resources.zx4
                z3.BackgroundImage = My.Resources.zx4
                If nm1.Text = "" Then
                    If Cmpt.Checked = True Then
                        If Bu8.Text = "عربي" Then
                            MsgBox(("You won, Player"), vbInformation, "Excellent")
                        Else
                            MsgBox(("انت فزت يا Player"), vbInformation + vbMsgBoxRight + vbMsgBoxRtlReading, "ممتاز")
                        End If
                    Else
                        If Bu8.Text = "عربي" Then
                            MsgBox(("You won, Player1"), vbInformation, "Excellent")
                        Else
                            MsgBox(("انت فزت يا Player1"), vbInformation + vbMsgBoxRight + vbMsgBoxRtlReading, "ممتاز")
                        End If
                    End If
                Else
                    If Bu8.Text = "عربي" Then
                        MsgBox(("You won, " + nm1.Text), vbInformation, "Excellent")
                    Else
                        MsgBox(("انت فزت يا " + nm1.Text), vbInformation + vbMsgBoxRight + vbMsgBoxRtlReading, "ممتاز")
                    End If
                End If
                wn37(e)
                Res(e)
            End If
            If lwc.Text = "1" Then
                wn2.Text = wn2.Text + 1
                c1.BackgroundImage = My.Resources.cv4
                c2.BackgroundImage = My.Resources.cv4
                c3.BackgroundImage = My.Resources.cv4
                If nm2.Text = "" Then
                    If Cmpt.Checked = True Then
                        If Bu8.Text = "عربي" Then
                            MsgBox(("You won, Computer"), vbInformation, "Excellent")
                        Else
                            MsgBox(("انت فزت يا Computer"), vbInformation + vbMsgBoxRight + vbMsgBoxRtlReading, "ممتاز")
                        End If
                    Else
                        If Bu8.Text = "عربي" Then
                            MsgBox(("You won, Player2"), vbInformation, "Excellent")
                        Else
                            MsgBox(("انت فزت يا Player2"), vbInformation + vbMsgBoxRight + vbMsgBoxRtlReading, "ممتاز")
                        End If
                    End If
                Else
                    If Bu8.Text = "عربي" Then
                        MsgBox(("You won, " + nm2.Text), vbInformation, "Excellent")
                    Else
                        MsgBox(("انت فزت يا " + nm2.Text), vbInformation + vbMsgBoxRight + vbMsgBoxRtlReading, "ممتاز")
                    End If
                End If
                wn37(e)
                Res(e)
            End If
        ElseIf (stp1.Text IsNot stp2.Text) And (NoS.Checked = True) And (L3.Text = "2") Then
            If lwz.Text = "0" Then
                L3.Text = "0"
                z1.BackgroundImage = My.Resources.zx4
                z2.BackgroundImage = My.Resources.zx4
                z3.BackgroundImage = My.Resources.zx4
            End If
            If lwc.Text = "1" Then
                L3.Text = "1"
                c1.BackgroundImage = My.Resources.cv4
                c2.BackgroundImage = My.Resources.cv4
                c3.BackgroundImage = My.Resources.cv4
            End If
        ElseIf L3.Text = "0" Or L3.Text = "1" Then
            If L3.Text = "0" Then
                If lwc.Text = "1" Then
                    La1.Text = "0" : La2.Text = "0" : La3.Text = "0" : La7.Text = "0" : La8.Text = "0" : La9.Text = "0"
                    n0.Text = "-1" : r0.Text = "-1"
                    n1.Text = "" : r1.Text = ""
                    Le1.Text = "0" : Le2.Text = "0" : Le3.Text = "0" : Le7.Text = "0" : Le8.Text = "0" : Le9.Text = "0"
                    nf(e)
                    rf(e)
                    L3.Text = "2"
                    z1.BackgroundImage = My.Resources.zx3
                    z2.BackgroundImage = My.Resources.zx3
                    z3.BackgroundImage = My.Resources.zx3
                    c1.BackgroundImage = My.Resources.cv3
                    c2.BackgroundImage = My.Resources.cv3
                    c3.BackgroundImage = My.Resources.cv3
                    If sn.Text = "1" Then
                        L2.Text = "0"
                        PB1.BackgroundImage = My.Resources.zx
                    Else
                        L2.Text = "1"
                        PB1.BackgroundImage = My.Resources.cv
                    End If
                Else
                    wn1.Text = wn1.Text + 1
                    If nm1.Text = "" Then
                        If Cmpt.Checked = True Then
                            If Bu8.Text = "عربي" Then
                                MsgBox(("You won, Player"), vbInformation, "Excellent")
                            Else
                                MsgBox(("انت فزت يا Player"), vbInformation + vbMsgBoxRight + vbMsgBoxRtlReading, "ممتاز")
                            End If
                        Else
                            If Bu8.Text = "عربي" Then
                                MsgBox(("You won, Player1"), vbInformation, "Excellent")
                            Else
                                MsgBox(("انت فزت يا Player1"), vbInformation + vbMsgBoxRight + vbMsgBoxRtlReading, "ممتاز")
                            End If
                        End If
                    Else
                        If Bu8.Text = "عربي" Then
                            MsgBox(("You won, " + nm1.Text), vbInformation, "Excellent")
                        Else
                            MsgBox(("انت فزت يا " + nm1.Text), vbInformation + vbMsgBoxRight + vbMsgBoxRtlReading, "ممتاز")
                        End If
                    End If
                    wn37(e)
                    Res(e)
                End If
            ElseIf L3.Text = "1" Then
                If lwz.Text = "0" Then
                    La1.Text = "0" : La2.Text = "0" : La3.Text = "0" : La7.Text = "0" : La8.Text = "0" : La9.Text = "0"
                    n0.Text = "-1" : r0.Text = "-1"
                    n1.Text = "" : r1.Text = ""
                    Le1.Text = "0" : Le2.Text = "0" : Le3.Text = "0" : Le7.Text = "0" : Le8.Text = "0" : Le9.Text = "0"
                    nf(e)
                    rf(e)
                    L3.Text = "2"
                    z1.BackgroundImage = My.Resources.zx3
                    z2.BackgroundImage = My.Resources.zx3
                    z3.BackgroundImage = My.Resources.zx3
                    c1.BackgroundImage = My.Resources.cv3
                    c2.BackgroundImage = My.Resources.cv3
                    c3.BackgroundImage = My.Resources.cv3
                    If sn.Text = "1" Then
                        L2.Text = "1"
                        PB1.BackgroundImage = My.Resources.cv
                    Else
                        L2.Text = "0"
                        PB1.BackgroundImage = My.Resources.zx
                    End If
                Else
                    wn2.Text = wn2.Text + 1
                    If nm2.Text = "" Then
                        If Cmpt.Checked = True Then
                            If Bu8.Text = "عربي" Then
                                MsgBox(("You won, Computer"), vbInformation, "Excellent")
                            Else
                                MsgBox(("انت فزت يا Computer"), vbInformation + vbMsgBoxRight + vbMsgBoxRtlReading, "ممتاز")
                            End If
                        Else
                            If Bu8.Text = "عربي" Then
                                MsgBox(("You won, Player2"), vbInformation, "Excellent")
                            Else
                                MsgBox(("انت فزت يا Player2"), vbInformation + vbMsgBoxRight + vbMsgBoxRtlReading, "ممتاز")
                            End If
                        End If
                    Else
                        If Bu8.Text = "عربي" Then
                            MsgBox(("You won, " + nm2.Text), vbInformation, "Excellent")
                        Else
                            MsgBox(("انت فزت يا " + nm2.Text), vbInformation + vbMsgBoxRight + vbMsgBoxRtlReading, "ممتاز")
                        End If
                    End If
                    wn37(e)
                    Res(e)
                End If
            End If
        End If
    End Sub

    Private Sub VaH_CheckedChanged(sender As Object, e As EventArgs) Handles VaH.CheckedChanged
        If VaH.Checked = False Then
            If L3.Text = "2" Then
                Wn(e)
            End If
        Else
            If (((Lab1.Text = "1" Or Lab2.Text = "1" Or Lab3.Text = "1") And (Lab1.Text = "5" Or Lab2.Text = "5" Or Lab3.Text = "5") And (Lab1.Text = "9" Or Lab2.Text = "9" Or Lab3.Text = "9")) Or ((Lab1.Text = "3" Or Lab2.Text = "3" Or Lab3.Text = "3") And (Lab1.Text = "5" Or Lab2.Text = "5" Or Lab3.Text = "5") And (Lab1.Text = "7" Or Lab2.Text = "7" Or Lab3.Text = "7"))) Or (((Lab7.Text = "1" Or Lab8.Text = "1" Or Lab9.Text = "1") And (Lab7.Text = "5" Or Lab8.Text = "5" Or Lab9.Text = "5") And (Lab7.Text = "9" Or Lab8.Text = "9" Or Lab9.Text = "9")) Or ((Lab7.Text = "3" Or Lab8.Text = "3" Or Lab9.Text = "3") And (Lab7.Text = "5" Or Lab8.Text = "5" Or Lab9.Text = "5") And (Lab7.Text = "7" Or Lab8.Text = "7" Or Lab9.Text = "7"))) Then
                L3.Text = "2"
                loc(e)
            End If
        End If
    End Sub

    Private Sub Bu3_Click(sender As Object, e As EventArgs) Handles Bu3.Click
        If bl.Text = "0" Then
            Res(e)
            wn1.Text = "0"
            wn2.Text = "0"
            L2.Text = "3"
            L22.Text = "3"
            PB1.BackgroundImage = Nothing
            nm1.Text = "Player1"
            nm2.Text = "Player2"
            sv.Enabled = False
            Bu4.Visible = True
            VaH.Checked = True
            NoS.Checked = False
            Cmpt.Checked = False
            Bu9.Visible = False
            ok1.Visible = False
            ok2.Visible = False
            ws(e)
        End If
    End Sub

    Private Sub Bu4_Click(sender As Object, e As EventArgs) Handles Bu4.Click
        If Bu4.Text = "Start" Or Bu4.Text = "إبدأ" Then
            If Bu8.Text = "عربي" Then
                Bu4.Text = "Stop"
            Else
                Bu4.Text = "توقف"
            End If
            Dim rand = New Random
            Dim x As Integer
            x = rand.Next(0, 2)
            L222.Text = x
            If L222.Text = "0" Then
                PB1.BackgroundImage = My.Resources.zx
            ElseIf L222.Text = "1" Then
                PB1.BackgroundImage = My.Resources.cv
            End If
            T1.Start()
        Else
            T1.Stop()
            Bu4.Visible = False
            If Bu8.Text = "عربي" Then
                Bu4.Text = "Start"
            Else
                Bu4.Text = "إبدأ"
            End If
            L2.Text = L222.Text
            L22.Text = L222.Text
            L222.Text = "3"
            Bu9.Visible = True
            ok1.Visible = True
            ok2.Visible = True
            sv.Enabled = True
        End If
    End Sub

    Private Sub T1_Tick(sender As Object, e As EventArgs) Handles T1.Tick
        If L222.Text = "0" Then
            L222.Text = "1"
            PB1.BackgroundImage = My.Resources.cv
        ElseIf L222.Text = "1" Then
            L222.Text = "0"
            PB1.BackgroundImage = My.Resources.zx
        End If
    End Sub

    Private Sub Cmpt_CheckedChanged(sender As Object, e As EventArgs) Handles Cmpt.CheckedChanged
        If bl.Text = "0" Then
            If Cmpt.Checked = True Then
                If L2.Text = "1" Then
                    l1.Text = "0"
                    a1.Visible = False
                    a2.Visible = False
                    a3.Visible = False
                End If
                If nm2.Text = "Player2" Or nm2.Text = "" Then
                    nm2.Text = "Computer"
                End If
                If nm1.Text = "Player1" Or nm1.Text = "" Then
                    nm1.Text = "Player"
                End If
                ok2.Enabled = False
                ok2.Checked = True
                T3.Start()
            Else
                If nm2.Text = "Computer" Or nm2.Text = "" Then
                    nm2.Text = "Player2"
                End If
                If nm1.Text = "Player" Or nm1.Text = "" Then
                    nm1.Text = "Player1"
                End If
                ok2.Enabled = True
                T2.Stop()
                T3.Stop()
            End If
        Else
            Cmpt.Checked = True
        End If
    End Sub

    Sub loc(ByVal e As EventArgs)
        If La7.Text = "1" Then
            If l1.Text = "7" Then
                c1.BackgroundImage = My.Resources.cv2
            Else
                c1.BackgroundImage = My.Resources.cv
            End If
        Else
            If l1.Text = "7" Then
                c1.BackgroundImage = My.Resources.cv23
            Else
                c1.BackgroundImage = My.Resources.cv3
            End If
        End If
        If La8.Text = "1" Then
            If l1.Text = "8" Then
                c2.BackgroundImage = My.Resources.cv2
            Else
                c2.BackgroundImage = My.Resources.cv
            End If
        Else
            If l1.Text = "8" Then
                c2.BackgroundImage = My.Resources.cv23
            Else
                c2.BackgroundImage = My.Resources.cv3
            End If
        End If
        If La9.Text = "1" Then
            If l1.Text = "9" Then
                c3.BackgroundImage = My.Resources.cv2
            Else
                c3.BackgroundImage = My.Resources.cv
            End If
        Else
            If l1.Text = "9" Then
                c3.BackgroundImage = My.Resources.cv23
            Else
                c3.BackgroundImage = My.Resources.cv3
            End If
        End If
        If La1.Text = "1" Then
            If l1.Text = "1" Then
                z1.BackgroundImage = My.Resources.zx2
            Else
                z1.BackgroundImage = My.Resources.zx
            End If
        Else
            If l1.Text = "1" Then
                z1.BackgroundImage = My.Resources.zx23
            Else
                z1.BackgroundImage = My.Resources.zx3
            End If
        End If
        If La2.Text = "1" Then
            If l1.Text = "2" Then
                z2.BackgroundImage = My.Resources.zx2
            Else
                z2.BackgroundImage = My.Resources.zx
            End If
        Else
            If l1.Text = "2" Then
                z2.BackgroundImage = My.Resources.zx23
            Else
                z2.BackgroundImage = My.Resources.zx3
            End If
        End If
        If La3.Text = "1" Then
            If l1.Text = "3" Then
                z3.BackgroundImage = My.Resources.zx2
            Else
                z3.BackgroundImage = My.Resources.zx
            End If
        Else
            If l1.Text = "3" Then
                z3.BackgroundImage = My.Resources.zx23
            Else
                z3.BackgroundImage = My.Resources.zx3
            End If
        End If
        If l1.Text = "0" Then
            a1.Visible = False
            a2.Visible = False
            a3.Visible = False
        Else
            a1.Visible = True
            a2.Visible = True
            a3.Visible = True
        End If
        Dim p1 As New Point(81, 80)
        Dim p2 As New Point(199, 80)
        Dim p3 As New Point(318, 80)
        Dim p4 As New Point(81, 192)
        Dim p5 As New Point(199, 192)
        Dim p6 As New Point(318, 192)
        Dim p7 As New Point(81, 304)
        Dim p8 As New Point(199, 304)
        Dim p9 As New Point(318, 304)
        If Lab7.Text = "1" Then
            c1.Location = p1
        ElseIf Lab7.Text = "2" Then
            c1.Location = p2
        ElseIf Lab7.Text = "3" Then
            c1.Location = p3
        ElseIf Lab7.Text = "4" Then
            c1.Location = p4
        ElseIf Lab7.Text = "5" Then
            c1.Location = p5
        ElseIf Lab7.Text = "6" Then
            c1.Location = p6
        ElseIf Lab7.Text = "7" Then
            c1.Location = p7
        ElseIf Lab7.Text = "8" Then
            c1.Location = p8
        ElseIf Lab7.Text = "9" Then
            c1.Location = p9
        End If
        If Lab8.Text = "1" Then
            c2.Location = p1
        ElseIf Lab8.Text = "2" Then
            c2.Location = p2
        ElseIf Lab8.Text = "3" Then
            c2.Location = p3
        ElseIf Lab8.Text = "4" Then
            c2.Location = p4
        ElseIf Lab8.Text = "5" Then
            c2.Location = p5
        ElseIf Lab8.Text = "6" Then
            c2.Location = p6
        ElseIf Lab8.Text = "7" Then
            c2.Location = p7
        ElseIf Lab8.Text = "8" Then
            c2.Location = p8
        ElseIf Lab8.Text = "9" Then
            c2.Location = p9
        End If
        If Lab9.Text = "1" Then
            c3.Location = p1
        ElseIf Lab9.Text = "2" Then
            c3.Location = p2
        ElseIf Lab9.Text = "3" Then
            c3.Location = p3
        ElseIf Lab9.Text = "4" Then
            c3.Location = p4
        ElseIf Lab9.Text = "5" Then
            c3.Location = p5
        ElseIf Lab9.Text = "6" Then
            c3.Location = p6
        ElseIf Lab9.Text = "7" Then
            c3.Location = p7
        ElseIf Lab9.Text = "8" Then
            c3.Location = p8
        ElseIf Lab9.Text = "9" Then
            c3.Location = p9
        End If
        If Lab1.Text = "1" Then
            z1.Location = p1
        ElseIf Lab1.Text = "2" Then
            z1.Location = p2
        ElseIf Lab1.Text = "3" Then
            z1.Location = p3
        ElseIf Lab1.Text = "4" Then
            z1.Location = p4
        ElseIf Lab1.Text = "5" Then
            z1.Location = p5
        ElseIf Lab1.Text = "6" Then
            z1.Location = p6
        ElseIf Lab1.Text = "7" Then
            z1.Location = p7
        ElseIf Lab1.Text = "8" Then
            z1.Location = p8
        ElseIf Lab1.Text = "9" Then
            z1.Location = p9
        End If
        If Lab2.Text = "1" Then
            z2.Location = p1
        ElseIf Lab2.Text = "2" Then
            z2.Location = p2
        ElseIf Lab2.Text = "3" Then
            z2.Location = p3
        ElseIf Lab2.Text = "4" Then
            z2.Location = p4
        ElseIf Lab2.Text = "5" Then
            z2.Location = p5
        ElseIf Lab2.Text = "6" Then
            z2.Location = p6
        ElseIf Lab2.Text = "7" Then
            z2.Location = p7
        ElseIf Lab2.Text = "8" Then
            z2.Location = p8
        ElseIf Lab2.Text = "9" Then
            z2.Location = p9
        End If
        If Lab3.Text = "1" Then
            z3.Location = p1
        ElseIf Lab3.Text = "2" Then
            z3.Location = p2
        ElseIf Lab3.Text = "3" Then
            z3.Location = p3
        ElseIf Lab3.Text = "4" Then
            z3.Location = p4
        ElseIf Lab3.Text = "5" Then
            z3.Location = p5
        ElseIf Lab3.Text = "6" Then
            z3.Location = p6
        ElseIf Lab3.Text = "7" Then
            z3.Location = p7
        ElseIf Lab3.Text = "8" Then
            z3.Location = p8
        ElseIf Lab3.Text = "9" Then
            z3.Location = p9
        End If
        If Lab4.Text = "1" Then
            a1.Location = p1
        ElseIf Lab4.Text = "2" Then
            a1.Location = p2
        ElseIf Lab4.Text = "3" Then
            a1.Location = p3
        ElseIf Lab4.Text = "4" Then
            a1.Location = p4
        ElseIf Lab4.Text = "5" Then
            a1.Location = p5
        ElseIf Lab4.Text = "6" Then
            a1.Location = p6
        ElseIf Lab4.Text = "7" Then
            a1.Location = p7
        ElseIf Lab4.Text = "8" Then
            a1.Location = p8
        ElseIf Lab4.Text = "9" Then
            a1.Location = p9
        End If
        If Lab5.Text = "1" Then
            a2.Location = p1
        ElseIf Lab5.Text = "2" Then
            a2.Location = p2
        ElseIf Lab5.Text = "3" Then
            a2.Location = p3
        ElseIf Lab5.Text = "4" Then
            a2.Location = p4
        ElseIf Lab5.Text = "5" Then
            a2.Location = p5
        ElseIf Lab5.Text = "6" Then
            a2.Location = p6
        ElseIf Lab5.Text = "7" Then
            a2.Location = p7
        ElseIf Lab5.Text = "8" Then
            a2.Location = p8
        ElseIf Lab5.Text = "9" Then
            a2.Location = p9
        End If
        If Lab6.Text = "1" Then
            a3.Location = p1
        ElseIf Lab6.Text = "2" Then
            a3.Location = p2
        ElseIf Lab6.Text = "3" Then
            a3.Location = p3
        ElseIf Lab6.Text = "4" Then
            a3.Location = p4
        ElseIf Lab6.Text = "5" Then
            a3.Location = p5
        ElseIf Lab6.Text = "6" Then
            a3.Location = p6
        ElseIf Lab6.Text = "7" Then
            a3.Location = p7
        ElseIf Lab6.Text = "8" Then
            a3.Location = p8
        ElseIf Lab6.Text = "9" Then
            a3.Location = p9
        End If
        wn19(e)
        If lwz.Text = "0" Then
            z1.BackgroundImage = My.Resources.zx4
            z2.BackgroundImage = My.Resources.zx4
            z3.BackgroundImage = My.Resources.zx4
        End If
        If lwc.Text = "1" Then
            c1.BackgroundImage = My.Resources.cv4
            c2.BackgroundImage = My.Resources.cv4
            c3.BackgroundImage = My.Resources.cv4
        End If
        If L2.Text = "0" Then
            PB1.BackgroundImage = My.Resources.zx
        ElseIf L2.Text = "1" Then
            PB1.BackgroundImage = My.Resources.cv
        End If
        ws(e)
    End Sub

    Sub ws(ByVal e As EventArgs)
        If wn1.Text >= 100 Then
            wn1.Location = New Point(3, 60)
        ElseIf wn1.Text >= 10 Then
            wn1.Location = New Point(11, 60)
        Else
            wn1.Location = New Point(14, 60)
        End If
        If wn2.Text >= 100 Then
            wn2.Location = New Point(412, 60)
        ElseIf wn2.Text >= 10 Then
            wn2.Location = New Point(419, 60)
        Else
            wn2.Location = New Point(422, 60)
        End If
        If stp1.Text >= 100 Then
            stp1.Location = New Point(9, 101)
        ElseIf stp1.Text >= 10 Then
            stp1.Location = New Point(14, 101)
        Else
            stp1.Location = New Point(17, 101)
        End If
        If stp2.Text >= 100 Then
            stp2.Location = New Point(417, 101)
        ElseIf stp2.Text >= 10 Then
            stp2.Location = New Point(422, 101)
        Else
            stp2.Location = New Point(425, 101)
        End If
    End Sub

    Sub l47(ByVal e As EventArgs)
        rt.Text = Lab4.Text : Lab4.Text = Lab7.Text : Lab7.Text = rt.Text
    End Sub

    Sub l48(ByVal e As EventArgs)
        rt.Text = Lab4.Text : Lab4.Text = Lab8.Text : Lab8.Text = rt.Text
    End Sub

    Sub l49(ByVal e As EventArgs)
        rt.Text = Lab4.Text : Lab4.Text = Lab9.Text : Lab9.Text = rt.Text
    End Sub

    Sub l57(ByVal e As EventArgs)
        rt.Text = Lab5.Text : Lab5.Text = Lab7.Text : Lab7.Text = rt.Text
    End Sub

    Sub l58(ByVal e As EventArgs)
        rt.Text = Lab5.Text : Lab5.Text = Lab8.Text : Lab8.Text = rt.Text
    End Sub

    Sub l59(ByVal e As EventArgs)
        rt.Text = Lab5.Text : Lab5.Text = Lab9.Text : Lab9.Text = rt.Text
    End Sub

    Sub l67(ByVal e As EventArgs)
        rt.Text = Lab6.Text : Lab6.Text = Lab7.Text : Lab7.Text = rt.Text
    End Sub

    Sub l68(ByVal e As EventArgs)
        rt.Text = Lab6.Text : Lab6.Text = Lab8.Text : Lab8.Text = rt.Text
    End Sub

    Sub l69(ByVal e As EventArgs)
        rt.Text = Lab6.Text : Lab6.Text = Lab9.Text : Lab9.Text = rt.Text
    End Sub

    Sub za(ByVal e As EventArgs)
        If (((Lab1.Text = "1" And La1.Text = "1") Or (Lab2.Text = "1" And La2.Text = "1") Or (Lab3.Text = "1" And La3.Text = "1")) And ((Lab1.Text = "2" And La1.Text = "1") Or (Lab2.Text = "2" And La2.Text = "1") Or (Lab3.Text = "2" And La3.Text = "1")) And (Lab4.Text = "3" Or Lab5.Text = "3" Or Lab6.Text = "3")) Or (((Lab1.Text = "1" And La1.Text = "1") Or (Lab2.Text = "1" And La2.Text = "1") Or (Lab3.Text = "1" And La3.Text = "1")) And ((Lab1.Text = "3" And La1.Text = "1") Or (Lab2.Text = "3" And La2.Text = "1") Or (Lab3.Text = "3" And La3.Text = "1")) And (Lab4.Text = "2" Or Lab5.Text = "2" Or Lab6.Text = "2")) Or (((Lab1.Text = "2" And La1.Text = "1") Or (Lab2.Text = "2" And La2.Text = "1") Or (Lab3.Text = "2" And La3.Text = "1")) And ((Lab1.Text = "3" And La1.Text = "1") Or (Lab2.Text = "3" And La2.Text = "1") Or (Lab3.Text = "3" And La3.Text = "1")) And (Lab4.Text = "1" Or Lab5.Text = "1" Or Lab6.Text = "1")) Or (((Lab1.Text = "4" And La1.Text = "1") Or (Lab2.Text = "4" And La2.Text = "1") Or (Lab3.Text = "4" And La3.Text = "1")) And ((Lab1.Text = "5" And La1.Text = "1") Or (Lab2.Text = "5" And La2.Text = "1") Or (Lab3.Text = "5" And La3.Text = "1")) And (Lab4.Text = "6" Or Lab5.Text = "6" Or Lab6.Text = "6")) Or (((Lab1.Text = "4" And La1.Text = "1") Or (Lab2.Text = "4" And La2.Text = "1") Or (Lab3.Text = "4" And La3.Text = "1")) And ((Lab1.Text = "6" And La1.Text = "1") Or (Lab2.Text = "6" And La2.Text = "1") Or (Lab3.Text = "6" And La3.Text = "1")) And (Lab4.Text = "5" Or Lab5.Text = "5" Or Lab6.Text = "5")) Or (((Lab1.Text = "5" And La1.Text = "1") Or (Lab2.Text = "5" And La2.Text = "1") Or (Lab3.Text = "5" And La3.Text = "1")) And ((Lab1.Text = "6" And La1.Text = "1") Or (Lab2.Text = "6" And La2.Text = "1") Or (Lab3.Text = "6" And La3.Text = "1")) And (Lab4.Text = "4" Or Lab5.Text = "4" Or Lab6.Text = "4")) Or (((Lab1.Text = "7" And La1.Text = "1") Or (Lab2.Text = "7" And La2.Text = "1") Or (Lab3.Text = "7" And La3.Text = "1")) And ((Lab1.Text = "8" And La1.Text = "1") Or (Lab2.Text = "8" And La2.Text = "1") Or (Lab3.Text = "8" And La3.Text = "1")) And (Lab4.Text = "9" Or Lab5.Text = "9" Or Lab6.Text = "9")) Or (((Lab1.Text = "7" And La1.Text = "1") Or (Lab2.Text = "7" And La2.Text = "1") Or (Lab3.Text = "7" And La3.Text = "1")) And ((Lab1.Text = "9" And La1.Text = "1") Or (Lab2.Text = "9" And La2.Text = "1") Or (Lab3.Text = "9" And La3.Text = "1")) And (Lab4.Text = "8" Or Lab5.Text = "8" Or Lab6.Text = "8")) Or (((Lab1.Text = "8" And La1.Text = "1") Or (Lab2.Text = "8" And La2.Text = "1") Or (Lab3.Text = "8" And La3.Text = "1")) And ((Lab1.Text = "9" And La1.Text = "1") Or (Lab2.Text = "9" And La2.Text = "1") Or (Lab3.Text = "9" And La3.Text = "1")) And (Lab4.Text = "7" Or Lab5.Text = "7" Or Lab6.Text = "7")) Or (((Lab1.Text = "3" And La1.Text = "1") Or (Lab2.Text = "3" And La2.Text = "1") Or (Lab3.Text = "3" And La3.Text = "1")) And ((Lab1.Text = "6" And La1.Text = "1") Or (Lab2.Text = "6" And La2.Text = "1") Or (Lab3.Text = "6" And La3.Text = "1")) And (Lab4.Text = "9" Or Lab5.Text = "9" Or Lab6.Text = "9")) Or (((Lab1.Text = "3" And La1.Text = "1") Or (Lab2.Text = "3" And La2.Text = "1") Or (Lab3.Text = "3" And La3.Text = "1")) And ((Lab1.Text = "9" And La1.Text = "1") Or (Lab2.Text = "9" And La2.Text = "1") Or (Lab3.Text = "9" And La3.Text = "1")) And (Lab4.Text = "6" Or Lab5.Text = "6" Or Lab6.Text = "6")) Or (((Lab1.Text = "6" And La1.Text = "1") Or (Lab2.Text = "6" And La2.Text = "1") Or (Lab3.Text = "6" And La3.Text = "1")) And ((Lab1.Text = "9" And La1.Text = "1") Or (Lab2.Text = "9" And La2.Text = "1") Or (Lab3.Text = "9" And La3.Text = "1")) And (Lab4.Text = "3" Or Lab5.Text = "3" Or Lab6.Text = "3")) Or (((Lab1.Text = "2" And La1.Text = "1") Or (Lab2.Text = "2" And La2.Text = "1") Or (Lab3.Text = "2" And La3.Text = "1")) And ((Lab1.Text = "5" And La1.Text = "1") Or (Lab2.Text = "5" And La2.Text = "1") Or (Lab3.Text = "5" And La3.Text = "1")) And (Lab4.Text = "8" Or Lab5.Text = "8" Or Lab6.Text = "8")) Or (((Lab1.Text = "2" And La1.Text = "1") Or (Lab2.Text = "2" And La2.Text = "1") Or (Lab3.Text = "2" And La3.Text = "1")) And ((Lab1.Text = "8" And La1.Text = "1") Or (Lab2.Text = "8" And La2.Text = "1") Or (Lab3.Text = "8" And La3.Text = "1")) And (Lab4.Text = "5" Or Lab5.Text = "5" Or Lab6.Text = "5")) Or (((Lab1.Text = "5" And La1.Text = "1") Or (Lab2.Text = "5" And La2.Text = "1") Or (Lab3.Text = "5" And La3.Text = "1")) And ((Lab1.Text = "8" And La1.Text = "1") Or (Lab2.Text = "8" And La2.Text = "1") Or (Lab3.Text = "8" And La3.Text = "1")) And (Lab4.Text = "2" Or Lab5.Text = "2" Or Lab6.Text = "2")) Or (((Lab1.Text = "1" And La1.Text = "1") Or (Lab2.Text = "1" And La2.Text = "1") Or (Lab3.Text = "1" And La3.Text = "1")) And ((Lab1.Text = "4" And La1.Text = "1") Or (Lab2.Text = "4" And La2.Text = "1") Or (Lab3.Text = "4" And La3.Text = "1")) And (Lab4.Text = "7" Or Lab5.Text = "7" Or Lab6.Text = "7")) Or (((Lab1.Text = "1" And La1.Text = "1") Or (Lab2.Text = "1" And La2.Text = "1") Or (Lab3.Text = "1" And La3.Text = "1")) And ((Lab1.Text = "7" And La1.Text = "1") Or (Lab2.Text = "7" And La2.Text = "1") Or (Lab3.Text = "7" And La3.Text = "1")) And (Lab4.Text = "4" Or Lab5.Text = "4" Or Lab6.Text = "4")) Or (((Lab1.Text = "4" And La1.Text = "1") Or (Lab2.Text = "4" And La2.Text = "1") Or (Lab3.Text = "4" And La3.Text = "1")) And ((Lab1.Text = "7" And La1.Text = "1") Or (Lab2.Text = "7" And La2.Text = "1") Or (Lab3.Text = "7" And La3.Text = "1")) And (Lab4.Text = "1" Or Lab5.Text = "1" Or Lab6.Text = "1")) Or (VaH.Checked = False And ((((Lab1.Text = "1" And La1.Text = "1") Or (Lab2.Text = "1" And La2.Text = "1") Or (Lab3.Text = "1" And La3.Text = "1")) And ((Lab1.Text = "5" And La1.Text = "1") Or (Lab2.Text = "5" And La2.Text = "1") Or (Lab3.Text = "5" And La3.Text = "1")) And (Lab4.Text = "9" Or Lab5.Text = "9" Or Lab6.Text = "9")) Or (((Lab1.Text = "1" And La1.Text = "1") Or (Lab2.Text = "1" And La2.Text = "1") Or (Lab3.Text = "1" And La3.Text = "1")) And ((Lab1.Text = "9" And La1.Text = "1") Or (Lab2.Text = "9" And La2.Text = "1") Or (Lab3.Text = "9" And La3.Text = "1")) And (Lab4.Text = "5" Or Lab5.Text = "5" Or Lab6.Text = "5")) Or (((Lab1.Text = "5" And La1.Text = "1") Or (Lab2.Text = "5" And La2.Text = "1") Or (Lab3.Text = "5" And La3.Text = "1")) And ((Lab1.Text = "9" And La1.Text = "1") Or (Lab2.Text = "9" And La2.Text = "1") Or (Lab3.Text = "9" And La3.Text = "1")) And (Lab4.Text = "1" Or Lab5.Text = "1" Or Lab6.Text = "1")) Or (((Lab1.Text = "3" And La1.Text = "1") Or (Lab2.Text = "3" And La2.Text = "1") Or (Lab3.Text = "3" And La3.Text = "1")) And ((Lab1.Text = "5" And La1.Text = "1") Or (Lab2.Text = "5" And La2.Text = "1") Or (Lab3.Text = "5" And La3.Text = "1")) And (Lab4.Text = "7" Or Lab5.Text = "7" Or Lab6.Text = "7")) Or (((Lab1.Text = "3" And La1.Text = "1") Or (Lab2.Text = "3" And La2.Text = "1") Or (Lab3.Text = "3" And La3.Text = "1")) And ((Lab1.Text = "7" And La1.Text = "1") Or (Lab2.Text = "7" And La2.Text = "1") Or (Lab3.Text = "7" And La3.Text = "1")) And (Lab4.Text = "5" Or Lab5.Text = "5" Or Lab6.Text = "5")) Or (((Lab1.Text = "5" And La1.Text = "1") Or (Lab2.Text = "5" And La2.Text = "1") Or (Lab3.Text = "5" And La3.Text = "1")) And ((Lab1.Text = "7" And La1.Text = "1") Or (Lab2.Text = "7" And La2.Text = "1") Or (Lab3.Text = "7" And La3.Text = "1")) And (Lab4.Text = "3" Or Lab5.Text = "3" Or Lab6.Text = "3")))) Then
            zn.Text = "1"
        Else
            zn.Text = "0"
        End If
    End Sub

    Sub tt2(ByVal e As EventArgs)
        Lb4.Text = Lab4.Text : Lb5.Text = Lab5.Text : Lb6.Text = Lab6.Text : Lb7.Text = Lab7.Text : Lb8.Text = Lab8.Text : Lb9.Text = Lab9.Text
        sw(e)
        If (ll.Text = "3" Or ll.Text = "4") And ((Lb7.Text = Lab7.Text) And (Lb8.Text = Lab8.Text) And (Lb9.Text = Lab9.Text)) Then
            s3(e)
        End If
        If ll.Text = "4" And (Lb7.Text = Lab7.Text) And (Lb8.Text = Lab8.Text) And (Lb9.Text = Lab9.Text) Then
            If La7.Text = "0" And La8.Text = "0" And La9.Text = "0" Then
            Else
                cmptr(e)
            End If
        End If
        If (ll.Text = "2" Or ll.Text = "3" Or ll.Text = "4") And ((Lb7.Text = Lab7.Text) And (Lb8.Text = Lab8.Text) And (Lb9.Text = Lab9.Text)) Then
            za(e)
            If zn.Text = "1" Then
                s2(e)
            End If
        End If
        If (ll.Text = "3" Or ll.Text = "4") And (Lb7.Text = Lab7.Text) And (Lb8.Text = Lab8.Text) And (Lb9.Text = Lab9.Text) Then
            If (((Lab1.Text = "1" And La1.Text = "1") Or (Lab2.Text = "1" And La2.Text = "1") Or (Lab3.Text = "1" And La3.Text = "1")) And ((Lab1.Text = "2" And La1.Text = "1") Or (Lab2.Text = "2" And La2.Text = "1") Or (Lab3.Text = "2" And La3.Text = "1")) And (Lab7.Text = "3" Or Lab8.Text = "3" Or Lab9.Text = "3")) Or (((Lab1.Text = "1" And La1.Text = "1") Or (Lab2.Text = "1" And La2.Text = "1") Or (Lab3.Text = "1" And La3.Text = "1")) And ((Lab1.Text = "3" And La1.Text = "1") Or (Lab2.Text = "3" And La2.Text = "1") Or (Lab3.Text = "3" And La3.Text = "1")) And (Lab7.Text = "2" Or Lab8.Text = "2" Or Lab9.Text = "2")) Or (((Lab1.Text = "2" And La1.Text = "1") Or (Lab2.Text = "2" And La2.Text = "1") Or (Lab3.Text = "2" And La3.Text = "1")) And ((Lab1.Text = "3" And La1.Text = "1") Or (Lab2.Text = "3" And La2.Text = "1") Or (Lab3.Text = "3" And La3.Text = "1")) And (Lab7.Text = "1" Or Lab8.Text = "1" Or Lab9.Text = "1")) Or (((Lab1.Text = "4" And La1.Text = "1") Or (Lab2.Text = "4" And La2.Text = "1") Or (Lab3.Text = "4" And La3.Text = "1")) And ((Lab1.Text = "5" And La1.Text = "1") Or (Lab2.Text = "5" And La2.Text = "1") Or (Lab3.Text = "5" And La3.Text = "1")) And (Lab7.Text = "6" Or Lab8.Text = "6" Or Lab9.Text = "6")) Or (((Lab1.Text = "4" And La1.Text = "1") Or (Lab2.Text = "4" And La2.Text = "1") Or (Lab3.Text = "4" And La3.Text = "1")) And ((Lab1.Text = "6" And La1.Text = "1") Or (Lab2.Text = "6" And La2.Text = "1") Or (Lab3.Text = "6" And La3.Text = "1")) And (Lab7.Text = "5" Or Lab8.Text = "5" Or Lab9.Text = "5")) Or (((Lab1.Text = "5" And La1.Text = "1") Or (Lab2.Text = "5" And La2.Text = "1") Or (Lab3.Text = "5" And La3.Text = "1")) And ((Lab1.Text = "6" And La1.Text = "1") Or (Lab2.Text = "6" And La2.Text = "1") Or (Lab3.Text = "6" And La3.Text = "1")) And (Lab7.Text = "4" Or Lab8.Text = "4" Or Lab9.Text = "4")) Or (((Lab1.Text = "7" And La1.Text = "1") Or (Lab2.Text = "7" And La2.Text = "1") Or (Lab3.Text = "7" And La3.Text = "1")) And ((Lab1.Text = "8" And La1.Text = "1") Or (Lab2.Text = "8" And La2.Text = "1") Or (Lab3.Text = "8" And La3.Text = "1")) And (Lab7.Text = "9" Or Lab8.Text = "9" Or Lab9.Text = "9")) Or (((Lab1.Text = "7" And La1.Text = "1") Or (Lab2.Text = "7" And La2.Text = "1") Or (Lab3.Text = "7" And La3.Text = "1")) And ((Lab1.Text = "9" And La1.Text = "1") Or (Lab2.Text = "9" And La2.Text = "1") Or (Lab3.Text = "9" And La3.Text = "1")) And (Lab7.Text = "8" Or Lab8.Text = "8" Or Lab9.Text = "8")) Or (((Lab1.Text = "8" And La1.Text = "1") Or (Lab2.Text = "8" And La2.Text = "1") Or (Lab3.Text = "8" And La3.Text = "1")) And ((Lab1.Text = "9" And La1.Text = "1") Or (Lab2.Text = "9" And La2.Text = "1") Or (Lab3.Text = "9" And La3.Text = "1")) And (Lab7.Text = "7" Or Lab8.Text = "7" Or Lab9.Text = "7")) Or (((Lab1.Text = "3" And La1.Text = "1") Or (Lab2.Text = "3" And La2.Text = "1") Or (Lab3.Text = "3" And La3.Text = "1")) And ((Lab1.Text = "6" And La1.Text = "1") Or (Lab2.Text = "6" And La2.Text = "1") Or (Lab3.Text = "6" And La3.Text = "1")) And (Lab7.Text = "9" Or Lab8.Text = "9" Or Lab9.Text = "9")) Or (((Lab1.Text = "3" And La1.Text = "1") Or (Lab2.Text = "3" And La2.Text = "1") Or (Lab3.Text = "3" And La3.Text = "1")) And ((Lab1.Text = "9" And La1.Text = "1") Or (Lab2.Text = "9" And La2.Text = "1") Or (Lab3.Text = "9" And La3.Text = "1")) And (Lab7.Text = "6" Or Lab8.Text = "6" Or Lab9.Text = "6")) Or (((Lab1.Text = "6" And La1.Text = "1") Or (Lab2.Text = "6" And La2.Text = "1") Or (Lab3.Text = "6" And La3.Text = "1")) And ((Lab1.Text = "9" And La1.Text = "1") Or (Lab2.Text = "9" And La2.Text = "1") Or (Lab3.Text = "9" And La3.Text = "1")) And (Lab7.Text = "3" Or Lab8.Text = "3" Or Lab9.Text = "3")) Or (((Lab1.Text = "2" And La1.Text = "1") Or (Lab2.Text = "2" And La2.Text = "1") Or (Lab3.Text = "2" And La3.Text = "1")) And ((Lab1.Text = "5" And La1.Text = "1") Or (Lab2.Text = "5" And La2.Text = "1") Or (Lab3.Text = "5" And La3.Text = "1")) And (Lab7.Text = "8" Or Lab8.Text = "8" Or Lab9.Text = "8")) Or (((Lab1.Text = "2" And La1.Text = "1") Or (Lab2.Text = "2" And La2.Text = "1") Or (Lab3.Text = "2" And La3.Text = "1")) And ((Lab1.Text = "8" And La1.Text = "1") Or (Lab2.Text = "8" And La2.Text = "1") Or (Lab3.Text = "8" And La3.Text = "1")) And (Lab7.Text = "5" Or Lab8.Text = "5" Or Lab9.Text = "5")) Or (((Lab1.Text = "5" And La1.Text = "1") Or (Lab2.Text = "5" And La2.Text = "1") Or (Lab3.Text = "5" And La3.Text = "1")) And ((Lab1.Text = "8" And La1.Text = "1") Or (Lab2.Text = "8" And La2.Text = "1") Or (Lab3.Text = "8" And La3.Text = "1")) And (Lab7.Text = "2" Or Lab8.Text = "2" Or Lab9.Text = "2")) Or (((Lab1.Text = "1" And La1.Text = "1") Or (Lab2.Text = "1" And La2.Text = "1") Or (Lab3.Text = "1" And La3.Text = "1")) And ((Lab1.Text = "4" And La1.Text = "1") Or (Lab2.Text = "4" And La2.Text = "1") Or (Lab3.Text = "4" And La3.Text = "1")) And (Lab7.Text = "7" Or Lab8.Text = "7" Or Lab9.Text = "7")) Or (((Lab1.Text = "1" And La1.Text = "1") Or (Lab2.Text = "1" And La2.Text = "1") Or (Lab3.Text = "1" And La3.Text = "1")) And ((Lab1.Text = "7" And La1.Text = "1") Or (Lab2.Text = "7" And La2.Text = "1") Or (Lab3.Text = "7" And La3.Text = "1")) And (Lab7.Text = "4" Or Lab8.Text = "4" Or Lab9.Text = "4")) Or (((Lab1.Text = "4" And La1.Text = "1") Or (Lab2.Text = "4" And La2.Text = "1") Or (Lab3.Text = "4" And La3.Text = "1")) And ((Lab1.Text = "7" And La1.Text = "1") Or (Lab2.Text = "7" And La2.Text = "1") Or (Lab3.Text = "7" And La3.Text = "1")) And (Lab7.Text = "1" Or Lab8.Text = "1" Or Lab9.Text = "1")) Or (VaH.Checked = False And ((((Lab1.Text = "1" And La1.Text = "1") Or (Lab2.Text = "1" And La2.Text = "1") Or (Lab3.Text = "1" And La3.Text = "1")) And ((Lab1.Text = "5" And La1.Text = "1") Or (Lab2.Text = "5" And La2.Text = "1") Or (Lab3.Text = "5" And La3.Text = "1")) And (Lab7.Text = "9" Or Lab8.Text = "9" Or Lab9.Text = "9")) Or (((Lab1.Text = "1" And La1.Text = "1") Or (Lab2.Text = "1" And La2.Text = "1") Or (Lab3.Text = "1" And La3.Text = "1")) And ((Lab1.Text = "9" And La1.Text = "1") Or (Lab2.Text = "9" And La2.Text = "1") Or (Lab3.Text = "9" And La3.Text = "1")) And (Lab7.Text = "5" Or Lab8.Text = "5" Or Lab9.Text = "5")) Or (((Lab1.Text = "5" And La1.Text = "1") Or (Lab2.Text = "5" And La2.Text = "1") Or (Lab3.Text = "5" And La3.Text = "1")) And ((Lab1.Text = "9" And La1.Text = "1") Or (Lab2.Text = "9" And La2.Text = "1") Or (Lab3.Text = "9" And La3.Text = "1")) And (Lab7.Text = "1" Or Lab8.Text = "1" Or Lab9.Text = "1")) Or (((Lab1.Text = "3" And La1.Text = "1") Or (Lab2.Text = "3" And La2.Text = "1") Or (Lab3.Text = "3" And La3.Text = "1")) And ((Lab1.Text = "5" And La1.Text = "1") Or (Lab2.Text = "5" And La2.Text = "1") Or (Lab3.Text = "5" And La3.Text = "1")) And (Lab7.Text = "7" Or Lab8.Text = "7" Or Lab9.Text = "7")) Or (((Lab1.Text = "3" And La1.Text = "1") Or (Lab2.Text = "3" And La2.Text = "1") Or (Lab3.Text = "3" And La3.Text = "1")) And ((Lab1.Text = "7" And La1.Text = "1") Or (Lab2.Text = "7" And La2.Text = "1") Or (Lab3.Text = "7" And La3.Text = "1")) And (Lab7.Text = "5" Or Lab8.Text = "5" Or Lab9.Text = "5")) Or (((Lab1.Text = "5" And La1.Text = "1") Or (Lab2.Text = "5" And La2.Text = "1") Or (Lab3.Text = "5" And La3.Text = "1")) And ((Lab1.Text = "7" And La1.Text = "1") Or (Lab2.Text = "7" And La2.Text = "1") Or (Lab3.Text = "7" And La3.Text = "1")) And (Lab7.Text = "3" Or Lab8.Text = "3" Or Lab9.Text = "3")))) Then
                s2(e)
            End If
        End If
        If (Lb7.Text = Lab7.Text) And (Lb8.Text = Lab8.Text) And (Lb9.Text = Lab9.Text) Then
            Dim rand = New Random
            Dim x As Integer
            x = rand.Next(1, 10)
            Dim z As String = x
            If (La7.Text = "0" And La8.Text = "0" And La9.Text = "0") Or (La7.Text = "1" And La8.Text = "1" And La9.Text = "1") Then
                If z = "1" Then
                    l47(e)
                ElseIf z = "2" Then
                    l48(e)
                ElseIf z = "3" Then
                    l49(e)
                ElseIf z = "4" Then
                    l57(e)
                ElseIf z = "5" Then
                    l58(e)
                ElseIf z = "6" Then
                    l59(e)
                ElseIf z = "7" Then
                    l67(e)
                ElseIf z = "8" Then
                    l68(e)
                ElseIf z = "9" Then
                    l69(e)
                ElseIf z = "10" Then
                    l69(e)
                End If
            Else
                If La7.Text = "0" Then
                    If z = "1" Or z = "2" Or z = "3" Then
                        l47(e)
                    ElseIf z = "4" Or z = "5" Or z = "6" Then
                        l57(e)
                    ElseIf z = "7" Or z = "8" Or z = "9" Or z = "10" Then
                        l67(e)
                    End If
                ElseIf La8.Text = "0" Then
                    If z = "1" Or z = "2" Or z = "3" Then
                        l48(e)
                    ElseIf z = "4" Or z = "5" Or z = "6" Then
                        l58(e)
                    ElseIf z = "7" Or z = "8" Or z = "9" Or z = "10" Then
                        l68(e)
                    End If
                ElseIf La9.Text = "0" Then
                    If z = "1" Or z = "2" Or z = "3" Then
                        l49(e)
                    ElseIf z = "4" Or z = "5" Or z = "6" Then
                        l59(e)
                    ElseIf z = "7" Or z = "8" Or z = "9" Or z = "10" Then
                        l69(e)
                    End If
                End If
            End If
        End If
    End Sub

    Sub sw(ByVal e As EventArgs)
        If see.Text = "1" Then
            l47(e)
            see.Text = "2"
        ElseIf see.Text = "2" Then
            l48(e)
            see.Text = "3"
        ElseIf see.Text = "3" Then
            l49(e)
            see.Text = "4"
        ElseIf see.Text = "4" Then
            l57(e)
            see.Text = "5"
        ElseIf see.Text = "5" Then
            l58(e)
            see.Text = "6"
        ElseIf see.Text = "6" Then
            l59(e)
            see.Text = "7"
        ElseIf see.Text = "7" Then
            l67(e)
            see.Text = "8"
        ElseIf see.Text = "8" Then
            l68(e)
            see.Text = "9"
        ElseIf see.Text = "9" Then
            l69(e)
            see.Text = "10"
        End If
        If ((La7.Text = "1" And La8.Text = "1" And (see.Text = "4" Or see.Text = "7" Or see.Text = "10")) Or (La7.Text = "1" And La9.Text = "1" And (see.Text = "3" Or see.Text = "6" Or see.Text = "9")) Or (La8.Text = "1" And La9.Text = "1" And (see.Text = "2" Or see.Text = "5" Or see.Text = "8"))) Then
            If stp1.Text = stp2.Text And NoS.Checked = True And VaH.Checked = False And gn.Text = "0" Then
                If VaH.Checked = False And (((Lab7.Text = "1" Or Lab8.Text = "1" Or Lab9.Text = "1") And (Lab7.Text = "5" Or Lab8.Text = "5" Or Lab9.Text = "5") And (Lab7.Text = "9" Or Lab8.Text = "9" Or Lab9.Text = "9")) Or ((Lab7.Text = "3" Or Lab8.Text = "3" Or Lab9.Text = "3") And (Lab7.Text = "5" Or Lab8.Text = "5" Or Lab9.Text = "5") And (Lab7.Text = "7" Or Lab8.Text = "7" Or Lab9.Text = "7"))) Then
                    gd.Text = "1"
                Else
                    gd.Text = "0"
                End If
            ElseIf (((Lab7.Text = "1" Or Lab8.Text = "1" Or Lab9.Text = "1") And (Lab7.Text = "2" Or Lab8.Text = "2" Or Lab9.Text = "2") And (Lab7.Text = "3" Or Lab8.Text = "3" Or Lab9.Text = "3")) Or ((Lab7.Text = "4" Or Lab8.Text = "4" Or Lab9.Text = "4") And (Lab7.Text = "5" Or Lab8.Text = "5" Or Lab9.Text = "5") And (Lab7.Text = "6" Or Lab8.Text = "6" Or Lab9.Text = "6")) Or ((Lab7.Text = "7" Or Lab8.Text = "7" Or Lab9.Text = "7") And (Lab7.Text = "8" Or Lab8.Text = "8" Or Lab9.Text = "8") And (Lab7.Text = "9" Or Lab8.Text = "9" Or Lab9.Text = "9")) Or ((Lab7.Text = "1" Or Lab8.Text = "1" Or Lab9.Text = "1") And (Lab7.Text = "4" Or Lab8.Text = "4" Or Lab9.Text = "4") And (Lab7.Text = "7" Or Lab8.Text = "7" Or Lab9.Text = "7")) Or ((Lab7.Text = "2" Or Lab8.Text = "2" Or Lab9.Text = "2") And (Lab7.Text = "5" Or Lab8.Text = "5" Or Lab9.Text = "5") And (Lab7.Text = "8" Or Lab8.Text = "8" Or Lab9.Text = "8")) Or ((Lab7.Text = "3" Or Lab8.Text = "3" Or Lab9.Text = "3") And (Lab7.Text = "6" Or Lab8.Text = "6" Or Lab9.Text = "6") And (Lab7.Text = "9" Or Lab8.Text = "9" Or Lab9.Text = "9")) Or ((VaH.Checked = False) And (((Lab7.Text = "1" Or Lab8.Text = "1" Or Lab9.Text = "1") And (Lab7.Text = "5" Or Lab8.Text = "5" Or Lab9.Text = "5") And (Lab7.Text = "9" Or Lab8.Text = "9" Or Lab9.Text = "9")) Or ((Lab7.Text = "3" Or Lab8.Text = "3" Or Lab9.Text = "3") And (Lab7.Text = "5" Or Lab8.Text = "5" Or Lab9.Text = "5") And (Lab7.Text = "7" Or Lab8.Text = "7" Or Lab9.Text = "7"))))) Then
                gd.Text = "1"
            Else
                gd.Text = "0"
            End If
        Else
            gd.Text = "0"
        End If
        If gd.Text = "1" Then
            gd.Text = "0"
            If see.Text = "10" Then
                s0.Text += 1
                Dim q1 As Integer = see.Text - 1
                Dim q2 As String = q1
                s1.Text += q2
                Lab4.Text = Lb4.Text : Lab5.Text = Lb5.Text : Lab6.Text = Lb6.Text : Lab7.Text = Lb7.Text : Lab8.Text = Lb8.Text : Lab9.Text = Lb9.Text
            Else
                s0.Text += 1
                Dim q1 As Integer = see.Text - 1
                Dim q2 As String = q1
                s1.Text += q2
                Lab4.Text = Lb4.Text : Lab5.Text = Lb5.Text : Lab6.Text = Lb6.Text : Lab7.Text = Lb7.Text : Lab8.Text = Lb8.Text : Lab9.Text = Lb9.Text
                sw(e)
            End If
        Else
            If see.Text = "10" Then
                Lab4.Text = Lb4.Text : Lab5.Text = Lb5.Text : Lab6.Text = Lb6.Text : Lab7.Text = Lb7.Text : Lab8.Text = Lb8.Text : Lab9.Text = Lb9.Text
            Else
                Lab4.Text = Lb4.Text : Lab5.Text = Lb5.Text : Lab6.Text = Lb6.Text : Lab7.Text = Lb7.Text : Lab8.Text = Lb8.Text : Lab9.Text = Lb9.Text
                sw(e)
            End If
        End If
        If see.Text = "10" Then
            If gn.Text = "0" And s0.Text = "-1" Then
                gn.Text = "1"
                sw(e)
            Else
                gn.Text = "0"
                see.Text = "1"
                p2(e)
            End If
        End If
    End Sub

    Sub s2(ByVal e As EventArgs)
        If see.Text = "1" Then
            l47(e)
            see.Text = "2"
        ElseIf see.Text = "2" Then
            l48(e)
            see.Text = "3"
        ElseIf see.Text = "3" Then
            l49(e)
            see.Text = "4"
        ElseIf see.Text = "4" Then
            l57(e)
            see.Text = "5"
        ElseIf see.Text = "5" Then
            l58(e)
            see.Text = "6"
        ElseIf see.Text = "6" Then
            l59(e)
            see.Text = "7"
        ElseIf see.Text = "7" Then
            l67(e)
            see.Text = "8"
        ElseIf see.Text = "8" Then
            l68(e)
            see.Text = "9"
        ElseIf see.Text = "9" Then
            l69(e)
            see.Text = "10"
        End If
        za(e)
        If zn.Text = "1" Then
            If see.Text = "10" Then
                Lab4.Text = Lb4.Text : Lab5.Text = Lb5.Text : Lab6.Text = Lb6.Text : Lab7.Text = Lb7.Text : Lab8.Text = Lb8.Text : Lab9.Text = Lb9.Text
            Else
                Lab4.Text = Lb4.Text : Lab5.Text = Lb5.Text : Lab6.Text = Lb6.Text : Lab7.Text = Lb7.Text : Lab8.Text = Lb8.Text : Lab9.Text = Lb9.Text
                s2(e)
            End If
        Else
            If see.Text = "10" Then
                s0.Text += 1
                Dim q1 As Integer = see.Text - 1
                Dim q2 As String = q1
                s1.Text += q2
                Lab4.Text = Lb4.Text : Lab5.Text = Lb5.Text : Lab6.Text = Lb6.Text : Lab7.Text = Lb7.Text : Lab8.Text = Lb8.Text : Lab9.Text = Lb9.Text
            Else
                s0.Text += 1
                Dim q1 As Integer = see.Text - 1
                Dim q2 As String = q1
                s1.Text += q2
                Lab4.Text = Lb4.Text : Lab5.Text = Lb5.Text : Lab6.Text = Lb6.Text : Lab7.Text = Lb7.Text : Lab8.Text = Lb8.Text : Lab9.Text = Lb9.Text
                s2(e)
            End If
        End If
        If see.Text = "10" Then
            see.Text = "1"
            p2(e)
        End If
    End Sub

    Sub s3(ByVal e As EventArgs)
        If see.Text = "1" Then
            l47(e)
            If La7.Text = "0" Then
                La7.Text = "2"
            End If
            see.Text = "2"
        ElseIf see.Text = "2" Then
            l48(e)
            If La8.Text = "0" Then
                La8.Text = "2"
            End If
            see.Text = "3"
        ElseIf see.Text = "3" Then
            l49(e)
            If La9.Text = "0" Then
                La9.Text = "2"
            End If
            see.Text = "4"
        ElseIf see.Text = "4" Then
            l57(e)
            If La7.Text = "0" Then
                La7.Text = "2"
            End If
            see.Text = "5"
        ElseIf see.Text = "5" Then
            l58(e)
            If La8.Text = "0" Then
                La8.Text = "2"
            End If
            see.Text = "6"
        ElseIf see.Text = "6" Then
            l59(e)
            If La9.Text = "0" Then
                La9.Text = "2"
            End If
            see.Text = "7"
        ElseIf see.Text = "7" Then
            l67(e)
            If La7.Text = "0" Then
                La7.Text = "2"
            End If
            see.Text = "8"
        ElseIf see.Text = "8" Then
            l68(e)
            If La8.Text = "0" Then
                La8.Text = "2"
            End If
            see.Text = "9"
        ElseIf see.Text = "9" Then
            l69(e)
            If La9.Text = "0" Then
                La9.Text = "2"
            End If
            see.Text = "10"
        End If
        za(e)
        If zn.Text = "1" Then
        Else
            If (((Lab7.Text = "1" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "1" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "1" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "2" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "2" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "2" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab4.Text = "3" Or Lab5.Text = "3" Or Lab6.Text = "3")) Or (((Lab7.Text = "1" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "1" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "1" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "3" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "3" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "3" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab4.Text = "2" Or Lab5.Text = "2" Or Lab6.Text = "2")) Or (((Lab7.Text = "2" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "2" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "2" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "3" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "3" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "3" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab4.Text = "1" Or Lab5.Text = "1" Or Lab6.Text = "1")) Or (((Lab7.Text = "4" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "4" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "4" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "5" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "5" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "5" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab4.Text = "6" Or Lab5.Text = "6" Or Lab6.Text = "6")) Or (((Lab7.Text = "4" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "4" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "4" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "6" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "6" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "6" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab4.Text = "5" Or Lab5.Text = "5" Or Lab6.Text = "5")) Or (((Lab7.Text = "5" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "5" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "5" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "6" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "6" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "6" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab4.Text = "4" Or Lab5.Text = "4" Or Lab6.Text = "4")) Or (((Lab7.Text = "7" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "7" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "7" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "8" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "8" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "8" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab4.Text = "9" Or Lab5.Text = "9" Or Lab6.Text = "9")) Or (((Lab7.Text = "7" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "7" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "7" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "9" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "9" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "9" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab4.Text = "8" Or Lab5.Text = "8" Or Lab6.Text = "8")) Or (((Lab7.Text = "8" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "8" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "8" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "9" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "9" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "9" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab4.Text = "7" Or Lab5.Text = "7" Or Lab6.Text = "7")) Then
                wn9.Text += 1
            End If
            If (((Lab7.Text = "3" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "3" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "3" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "6" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "6" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "6" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab4.Text = "9" Or Lab5.Text = "9" Or Lab6.Text = "9")) Or (((Lab7.Text = "3" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "3" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "3" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "9" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "9" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "9" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab4.Text = "6" Or Lab5.Text = "6" Or Lab6.Text = "6")) Or (((Lab7.Text = "6" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "6" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "6" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "9" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "9" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "9" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab4.Text = "3" Or Lab5.Text = "3" Or Lab6.Text = "3")) Or (((Lab7.Text = "2" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "2" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "2" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "5" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "5" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "5" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab4.Text = "8" Or Lab5.Text = "8" Or Lab6.Text = "8")) Or (((Lab7.Text = "2" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "2" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "2" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "8" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "8" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "8" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab4.Text = "5" Or Lab5.Text = "5" Or Lab6.Text = "5")) Or (((Lab7.Text = "5" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "5" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "5" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "8" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "8" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "8" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab4.Text = "2" Or Lab5.Text = "2" Or Lab6.Text = "2")) Or (((Lab7.Text = "1" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "1" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "1" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "4" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "4" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "4" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab4.Text = "7" Or Lab5.Text = "7" Or Lab6.Text = "7")) Or (((Lab7.Text = "1" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "1" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "1" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "7" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "7" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "7" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab4.Text = "4" Or Lab5.Text = "4" Or Lab6.Text = "4")) Or (((Lab7.Text = "4" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "4" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "4" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "7" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "7" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "7" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab4.Text = "1" Or Lab5.Text = "1" Or Lab6.Text = "1")) Then
                wn9.Text += 1
            End If
            If VaH.Checked = False Then
                If (((Lab7.Text = "1" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "1" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "1" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "5" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "5" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "5" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab4.Text = "9" Or Lab5.Text = "9" Or Lab6.Text = "9")) Or (((Lab7.Text = "1" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "1" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "1" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "9" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "9" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "9" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab4.Text = "5" Or Lab5.Text = "5" Or Lab6.Text = "5")) Or (((Lab7.Text = "5" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "5" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "5" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "9" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "9" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "9" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab4.Text = "1" Or Lab5.Text = "1" Or Lab6.Text = "1")) Then
                    wn9.Text += 1
                End If
                If (((Lab7.Text = "3" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "3" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "3" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "5" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "5" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "5" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab4.Text = "7" Or Lab5.Text = "7" Or Lab6.Text = "7")) Or (((Lab7.Text = "3" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "3" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "3" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "7" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "7" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "7" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab4.Text = "5" Or Lab5.Text = "5" Or Lab6.Text = "5")) Or (((Lab7.Text = "5" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "5" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "5" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "7" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "7" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "7" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab4.Text = "3" Or Lab5.Text = "3" Or Lab6.Text = "3")) Then
                    wn9.Text += 1
                End If
                If (((Lab7.Text = "1" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "1" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "1" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "2" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "2" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "2" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab1.Text = "3" Or Lab2.Text = "3" Or Lab3.Text = "3")) Or (((Lab7.Text = "1" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "1" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "1" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "3" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "3" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "3" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab1.Text = "2" Or Lab2.Text = "2" Or Lab3.Text = "2")) Or (((Lab7.Text = "2" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "2" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "2" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "3" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "3" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "3" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab1.Text = "1" Or Lab2.Text = "1" Or Lab3.Text = "1")) Or (((Lab7.Text = "4" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "4" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "4" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "5" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "5" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "5" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab1.Text = "6" Or Lab2.Text = "6" Or Lab3.Text = "6")) Or (((Lab7.Text = "4" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "4" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "4" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "6" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "6" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "6" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab1.Text = "5" Or Lab2.Text = "5" Or Lab3.Text = "5")) Or (((Lab7.Text = "5" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "5" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "5" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "6" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "6" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "6" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab1.Text = "4" Or Lab2.Text = "4" Or Lab3.Text = "4")) Or (((Lab7.Text = "7" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "7" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "7" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "8" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "8" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "8" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab1.Text = "9" Or Lab2.Text = "9" Or Lab3.Text = "9")) Or (((Lab7.Text = "7" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "7" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "7" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "9" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "9" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "9" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab1.Text = "8" Or Lab2.Text = "8" Or Lab3.Text = "8")) Or (((Lab7.Text = "8" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "8" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "8" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "9" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "9" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "9" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab1.Text = "7" Or Lab2.Text = "7" Or Lab3.Text = "7")) Then
                    w93.Text += 1
                End If
                If (((Lab7.Text = "3" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "3" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "3" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "6" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "6" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "6" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab1.Text = "9" Or Lab2.Text = "9" Or Lab3.Text = "9")) Or (((Lab7.Text = "3" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "3" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "3" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "9" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "9" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "9" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab1.Text = "6" Or Lab2.Text = "6" Or Lab3.Text = "6")) Or (((Lab7.Text = "6" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "6" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "6" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "9" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "9" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "9" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab1.Text = "3" Or Lab2.Text = "3" Or Lab3.Text = "3")) Or (((Lab7.Text = "2" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "2" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "2" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "5" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "5" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "5" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab1.Text = "8" Or Lab2.Text = "8" Or Lab3.Text = "8")) Or (((Lab7.Text = "2" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "2" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "2" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "8" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "8" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "8" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab1.Text = "5" Or Lab2.Text = "5" Or Lab3.Text = "5")) Or (((Lab7.Text = "5" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "5" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "5" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "8" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "8" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "8" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab1.Text = "2" Or Lab2.Text = "2" Or Lab3.Text = "2")) Or (((Lab7.Text = "1" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "1" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "1" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "4" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "4" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "4" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab1.Text = "7" Or Lab2.Text = "7" Or Lab3.Text = "7")) Or (((Lab7.Text = "1" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "1" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "1" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "7" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "7" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "7" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab1.Text = "4" Or Lab2.Text = "4" Or Lab3.Text = "4")) Or (((Lab7.Text = "4" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "4" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "4" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "7" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "7" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "7" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab1.Text = "1" Or Lab2.Text = "1" Or Lab3.Text = "1")) Then
                    w93.Text += 1
                End If
                If (((Lab7.Text = "1" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "1" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "1" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "5" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "5" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "5" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab1.Text = "9" Or Lab2.Text = "9" Or Lab3.Text = "9")) Or (((Lab7.Text = "1" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "1" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "1" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "9" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "9" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "9" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab1.Text = "5" Or Lab2.Text = "5" Or Lab3.Text = "5")) Or (((Lab7.Text = "5" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "5" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "5" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "9" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "9" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "9" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab1.Text = "1" Or Lab2.Text = "1" Or Lab3.Text = "1")) Then
                    w93.Text += 1
                End If
                If (((Lab7.Text = "3" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "3" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "3" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "5" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "5" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "5" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab1.Text = "7" Or Lab2.Text = "7" Or Lab3.Text = "7")) Or (((Lab7.Text = "3" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "3" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "3" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "7" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "7" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "7" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab1.Text = "5" Or Lab2.Text = "5" Or Lab3.Text = "5")) Or (((Lab7.Text = "5" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "5" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "5" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "7" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "7" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "7" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab1.Text = "3" Or Lab2.Text = "3" Or Lab3.Text = "3")) Then
                    w93.Text += 1
                End If
            End If
        End If
        If wn9.Text = "2" Or wn9.Text = "3" Or wn9.Text = "4" Or w93.Text = "3" Or w93.Text = "4" Then
            If see.Text = "10" Then
                s0.Text += 1
                Dim q1 As Integer = see.Text - 1
                Dim q2 As String = q1
                s1.Text += q2
                Lab4.Text = Lb4.Text : Lab5.Text = Lb5.Text : Lab6.Text = Lb6.Text : Lab7.Text = Lb7.Text : Lab8.Text = Lb8.Text : Lab9.Text = Lb9.Text
                If La9.Text = "2" Then
                    La9.Text = "0"
                End If
            Else
                s0.Text += 1
                Dim q1 As Integer = see.Text - 1
                Dim q2 As String = q1
                s1.Text += q2
                Lab4.Text = Lb4.Text : Lab5.Text = Lb5.Text : Lab6.Text = Lb6.Text : Lab7.Text = Lb7.Text : Lab8.Text = Lb8.Text : Lab9.Text = Lb9.Text
                If La7.Text = "2" Then
                    La7.Text = "0"
                End If
                If La8.Text = "2" Then
                    La8.Text = "0"
                End If
                If La9.Text = "2" Then
                    La9.Text = "0"
                End If
                wn9.Text = "0"
                w93.Text = "0"
                s3(e)
            End If
        Else
            If see.Text = "10" Then
                Lab4.Text = Lb4.Text : Lab5.Text = Lb5.Text : Lab6.Text = Lb6.Text : Lab7.Text = Lb7.Text : Lab8.Text = Lb8.Text : Lab9.Text = Lb9.Text
                If La9.Text = "2" Then
                    La9.Text = "0"
                End If
            Else
                Lab4.Text = Lb4.Text : Lab5.Text = Lb5.Text : Lab6.Text = Lb6.Text : Lab7.Text = Lb7.Text : Lab8.Text = Lb8.Text : Lab9.Text = Lb9.Text
                If La7.Text = "2" Then
                    La7.Text = "0"
                End If
                If La8.Text = "2" Then
                    La8.Text = "0"
                End If
                If La9.Text = "2" Then
                    La9.Text = "0"
                End If
                wn9.Text = "0"
                w93.Text = "0"
                s3(e)
            End If
        End If
        If see.Text = "10" Then
            wn9.Text = "0"
            w93.Text = "0"
            see.Text = "1"
            p2(e)
        End If
    End Sub

    Sub cmptr(ByVal e As EventArgs)
        If see.Text = "1" Then
            l47(e)
            If La7.Text = "0" Then
                La7.Text = "2"
            End If
            see.Text = "2"
        ElseIf see.Text = "2" Then
            l48(e)
            If La8.Text = "0" Then
                La8.Text = "2"
            End If
            see.Text = "3"
        ElseIf see.Text = "3" Then
            l49(e)
            If La9.Text = "0" Then
                La9.Text = "2"
            End If
            see.Text = "4"
        ElseIf see.Text = "4" Then
            l57(e)
            If La7.Text = "0" Then
                La7.Text = "2"
            End If
            see.Text = "5"
        ElseIf see.Text = "5" Then
            l58(e)
            If La8.Text = "0" Then
                La8.Text = "2"
            End If
            see.Text = "6"
        ElseIf see.Text = "6" Then
            l59(e)
            If La9.Text = "0" Then
                La9.Text = "2"
            End If
            see.Text = "7"
        ElseIf see.Text = "7" Then
            l67(e)
            If La7.Text = "0" Then
                La7.Text = "2"
            End If
            see.Text = "8"
        ElseIf see.Text = "8" Then
            l68(e)
            If La8.Text = "0" Then
                La8.Text = "2"
            End If
            see.Text = "9"
        ElseIf see.Text = "9" Then
            l69(e)
            If La9.Text = "0" Then
                La9.Text = "2"
            End If
            see.Text = "10"
        End If
        za(e)
        If zn.Text = "1" Then
            ss.Text = "1"
        Else
            Lx1.Text = Lab1.Text : Lx2.Text = Lab2.Text : Lx3.Text = Lab3.Text : Lx4.Text = Lab4.Text : Lx5.Text = Lab5.Text : Lx6.Text = Lab6.Text
            zxzx(e)
        End If
        Lab4.Text = Lb4.Text : Lab5.Text = Lb5.Text : Lab6.Text = Lb6.Text : Lab7.Text = Lb7.Text : Lab8.Text = Lb8.Text : Lab9.Text = Lb9.Text
        If ss.Text = "1" Then
            If see.Text = "10" Then
                If La9.Text = "2" Then
                    La9.Text = "0"
                End If
            Else
                If La7.Text = "2" Then
                    La7.Text = "0"
                End If
                If La8.Text = "2" Then
                    La8.Text = "0"
                End If
                If La9.Text = "2" Then
                    La9.Text = "0"
                End If
                cmptr(e)
            End If
        Else
            If see.Text = "10" Then
                If La9.Text = "2" Then
                    La9.Text = "0"
                End If
                s0.Text += 1
                Dim q1 As Integer = see.Text - 1
                Dim q2 As String = q1
                s1.Text += q2
            Else
                If La7.Text = "2" Then
                    La7.Text = "0"
                End If
                If La8.Text = "2" Then
                    La8.Text = "0"
                End If
                If La9.Text = "2" Then
                    La9.Text = "0"
                End If
                s0.Text += 1
                Dim q1 As Integer = see.Text - 1
                Dim q2 As String = q1
                s1.Text += q2
                cmptr(e)
            End If
        End If
        If see.Text = "10" Then
            see.Text = "1"
            If er.Text = "1" And s0.Text = "-1" Then
                er.Text = "2"
                cmptr(e)
            Else
                er.Text = "1"
                p2(e)
            End If
        End If
    End Sub

    Sub zxzx(ByVal e As EventArgs)
        If see2.Text = "1" Then
            rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
            If La1.Text = "0" Then
                La1.Text = "2"
            End If
            see2.Text = "2"
        ElseIf see2.Text = "2" Then
            rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
            If La2.Text = "0" Then
                La2.Text = "2"
            End If
            see2.Text = "3"
        ElseIf see2.Text = "3" Then
            rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
            If La3.Text = "0" Then
                La3.Text = "2"
            End If
            see2.Text = "4"
        ElseIf see2.Text = "4" Then
            rt.Text = Lab5.Text : Lab5.Text = Lab1.Text : Lab1.Text = rt.Text
            If La1.Text = "0" Then
                La1.Text = "2"
            End If
            see2.Text = "5"
        ElseIf see2.Text = "5" Then
            rt.Text = Lab5.Text : Lab5.Text = Lab2.Text : Lab2.Text = rt.Text
            If La2.Text = "0" Then
                La2.Text = "2"
            End If
            see2.Text = "6"
        ElseIf see2.Text = "6" Then
            rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
            If La3.Text = "0" Then
                La3.Text = "2"
            End If
            see2.Text = "7"
        ElseIf see2.Text = "7" Then
            rt.Text = Lab6.Text : Lab6.Text = Lab1.Text : Lab1.Text = rt.Text
            If La1.Text = "0" Then
                La1.Text = "2"
            End If
            see2.Text = "8"
        ElseIf see2.Text = "8" Then
            rt.Text = Lab6.Text : Lab6.Text = Lab2.Text : Lab2.Text = rt.Text
            If La2.Text = "0" Then
                La2.Text = "2"
            End If
            see2.Text = "9"
        ElseIf see2.Text = "9" Then
            rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
            If La3.Text = "0" Then
                La3.Text = "2"
            End If
            see2.Text = "10"
        End If
        If (((Lab7.Text = "1" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "1" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "1" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "2" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "2" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "2" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab4.Text = "3" Or Lab5.Text = "3" Or Lab6.Text = "3")) Or (((Lab7.Text = "1" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "1" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "1" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "3" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "3" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "3" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab4.Text = "2" Or Lab5.Text = "2" Or Lab6.Text = "2")) Or (((Lab7.Text = "2" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "2" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "2" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "3" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "3" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "3" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab4.Text = "1" Or Lab5.Text = "1" Or Lab6.Text = "1")) Or (((Lab7.Text = "4" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "4" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "4" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "5" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "5" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "5" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab4.Text = "6" Or Lab5.Text = "6" Or Lab6.Text = "6")) Or (((Lab7.Text = "4" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "4" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "4" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "6" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "6" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "6" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab4.Text = "5" Or Lab5.Text = "5" Or Lab6.Text = "5")) Or (((Lab7.Text = "5" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "5" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "5" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "6" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "6" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "6" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab4.Text = "4" Or Lab5.Text = "4" Or Lab6.Text = "4")) Or (((Lab7.Text = "7" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "7" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "7" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "8" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "8" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "8" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab4.Text = "9" Or Lab5.Text = "9" Or Lab6.Text = "9")) Or (((Lab7.Text = "7" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "7" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "7" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "9" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "9" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "9" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab4.Text = "8" Or Lab5.Text = "8" Or Lab6.Text = "8")) Or (((Lab7.Text = "8" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "8" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "8" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "9" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "9" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "9" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab4.Text = "7" Or Lab5.Text = "7" Or Lab6.Text = "7")) Or (((Lab7.Text = "3" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "3" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "3" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "6" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "6" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "6" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab4.Text = "9" Or Lab5.Text = "9" Or Lab6.Text = "9")) Or (((Lab7.Text = "3" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "3" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "3" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "9" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "9" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "9" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab4.Text = "6" Or Lab5.Text = "6" Or Lab6.Text = "6")) Or (((Lab7.Text = "6" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "6" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "6" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "9" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "9" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "9" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab4.Text = "3" Or Lab5.Text = "3" Or Lab6.Text = "3")) Or (((Lab7.Text = "2" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "2" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "2" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "5" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "5" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "5" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab4.Text = "8" Or Lab5.Text = "8" Or Lab6.Text = "8")) Or (((Lab7.Text = "2" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "2" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "2" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "8" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "8" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "8" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab4.Text = "5" Or Lab5.Text = "5" Or Lab6.Text = "5")) Or (((Lab7.Text = "5" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "5" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "5" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "8" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "8" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "8" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab4.Text = "2" Or Lab5.Text = "2" Or Lab6.Text = "2")) Or (((Lab7.Text = "1" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "1" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "1" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "4" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "4" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "4" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab4.Text = "7" Or Lab5.Text = "7" Or Lab6.Text = "7")) Or (((Lab7.Text = "1" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "1" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "1" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "7" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "7" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "7" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab4.Text = "4" Or Lab5.Text = "4" Or Lab6.Text = "4")) Or (((Lab7.Text = "4" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "4" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "4" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "7" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "7" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "7" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab4.Text = "1" Or Lab5.Text = "1" Or Lab6.Text = "1")) Or (VaH.Checked = False And ((((Lab7.Text = "1" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "1" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "1" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "5" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "5" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "5" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab4.Text = "9" Or Lab5.Text = "9" Or Lab6.Text = "9")) Or (((Lab7.Text = "1" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "1" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "1" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "9" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "9" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "9" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab4.Text = "5" Or Lab5.Text = "5" Or Lab6.Text = "5")) Or (((Lab7.Text = "5" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "5" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "5" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "9" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "9" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "9" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab4.Text = "1" Or Lab5.Text = "1" Or Lab6.Text = "1")) Or (((Lab7.Text = "3" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "3" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "3" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "5" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "5" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "5" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab4.Text = "7" Or Lab5.Text = "7" Or Lab6.Text = "7")) Or (((Lab7.Text = "3" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "3" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "3" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "7" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "7" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "7" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab4.Text = "5" Or Lab5.Text = "5" Or Lab6.Text = "5")) Or (((Lab7.Text = "5" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "5" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "5" And (La9.Text = "1" Or La9.Text = "2"))) And ((Lab7.Text = "7" And (La7.Text = "1" Or La7.Text = "2")) Or (Lab8.Text = "7" And (La8.Text = "1" Or La8.Text = "2")) Or (Lab9.Text = "7" And (La9.Text = "1" Or La9.Text = "2"))) And (Lab4.Text = "3" Or Lab5.Text = "3" Or Lab6.Text = "3")))) Then
        Else
            If (((Lab1.Text = "1" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "1" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "1" And (La3.Text = "1" Or La3.Text = "2"))) And ((Lab1.Text = "2" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "2" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "2" And (La3.Text = "1" Or La3.Text = "2"))) And (Lab4.Text = "3" Or Lab5.Text = "3" Or Lab6.Text = "3")) Or (((Lab1.Text = "1" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "1" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "1" And (La3.Text = "1" Or La3.Text = "2"))) And ((Lab1.Text = "3" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "3" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "3" And (La3.Text = "1" Or La3.Text = "2"))) And (Lab4.Text = "2" Or Lab5.Text = "2" Or Lab6.Text = "2")) Or (((Lab1.Text = "2" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "2" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "2" And (La3.Text = "1" Or La3.Text = "2"))) And ((Lab1.Text = "3" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "3" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "3" And (La3.Text = "1" Or La3.Text = "2"))) And (Lab4.Text = "1" Or Lab5.Text = "1" Or Lab6.Text = "1")) Or (((Lab1.Text = "4" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "4" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "4" And (La3.Text = "1" Or La3.Text = "2"))) And ((Lab1.Text = "5" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "5" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "5" And (La3.Text = "1" Or La3.Text = "2"))) And (Lab4.Text = "6" Or Lab5.Text = "6" Or Lab6.Text = "6")) Or (((Lab1.Text = "4" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "4" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "4" And (La3.Text = "1" Or La3.Text = "2"))) And ((Lab1.Text = "6" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "6" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "6" And (La3.Text = "1" Or La3.Text = "2"))) And (Lab4.Text = "5" Or Lab5.Text = "5" Or Lab6.Text = "5")) Or (((Lab1.Text = "5" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "5" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "5" And (La3.Text = "1" Or La3.Text = "2"))) And ((Lab1.Text = "6" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "6" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "6" And (La3.Text = "1" Or La3.Text = "2"))) And (Lab4.Text = "4" Or Lab5.Text = "4" Or Lab6.Text = "4")) Or (((Lab1.Text = "7" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "7" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "7" And (La3.Text = "1" Or La3.Text = "2"))) And ((Lab1.Text = "8" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "8" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "8" And (La3.Text = "1" Or La3.Text = "2"))) And (Lab4.Text = "9" Or Lab5.Text = "9" Or Lab6.Text = "9")) Or (((Lab1.Text = "7" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "7" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "7" And (La3.Text = "1" Or La3.Text = "2"))) And ((Lab1.Text = "9" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "9" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "9" And (La3.Text = "1" Or La3.Text = "2"))) And (Lab4.Text = "8" Or Lab5.Text = "8" Or Lab6.Text = "8")) Or (((Lab1.Text = "8" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "8" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "8" And (La3.Text = "1" Or La3.Text = "2"))) And ((Lab1.Text = "9" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "9" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "9" And (La3.Text = "1" Or La3.Text = "2"))) And (Lab4.Text = "7" Or Lab5.Text = "7" Or Lab6.Text = "7")) Then
                wn3.Text += 1
            End If
            If (((Lab1.Text = "3" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "3" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "3" And (La3.Text = "1" Or La3.Text = "2"))) And ((Lab1.Text = "6" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "6" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "6" And (La3.Text = "1" Or La3.Text = "2"))) And (Lab4.Text = "9" Or Lab5.Text = "9" Or Lab6.Text = "9")) Or (((Lab1.Text = "3" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "3" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "3" And (La3.Text = "1" Or La3.Text = "2"))) And ((Lab1.Text = "9" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "9" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "9" And (La3.Text = "1" Or La3.Text = "2"))) And (Lab4.Text = "6" Or Lab5.Text = "6" Or Lab6.Text = "6")) Or (((Lab1.Text = "6" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "6" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "6" And (La3.Text = "1" Or La3.Text = "2"))) And ((Lab1.Text = "9" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "9" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "9" And (La3.Text = "1" Or La3.Text = "2"))) And (Lab4.Text = "3" Or Lab5.Text = "3" Or Lab6.Text = "3")) Or (((Lab1.Text = "2" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "2" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "2" And (La3.Text = "1" Or La3.Text = "2"))) And ((Lab1.Text = "5" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "5" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "5" And (La3.Text = "1" Or La3.Text = "2"))) And (Lab4.Text = "8" Or Lab5.Text = "8" Or Lab6.Text = "8")) Or (((Lab1.Text = "2" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "2" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "2" And (La3.Text = "1" Or La3.Text = "2"))) And ((Lab1.Text = "8" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "8" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "8" And (La3.Text = "1" Or La3.Text = "2"))) And (Lab4.Text = "5" Or Lab5.Text = "5" Or Lab6.Text = "5")) Or (((Lab1.Text = "5" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "5" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "5" And (La3.Text = "1" Or La3.Text = "2"))) And ((Lab1.Text = "8" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "8" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "8" And (La3.Text = "1" Or La3.Text = "2"))) And (Lab4.Text = "2" Or Lab5.Text = "2" Or Lab6.Text = "2")) Or (((Lab1.Text = "1" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "1" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "1" And (La3.Text = "1" Or La3.Text = "2"))) And ((Lab1.Text = "4" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "4" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "4" And (La3.Text = "1" Or La3.Text = "2"))) And (Lab4.Text = "7" Or Lab5.Text = "7" Or Lab6.Text = "7")) Or (((Lab1.Text = "1" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "1" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "1" And (La3.Text = "1" Or La3.Text = "2"))) And ((Lab1.Text = "7" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "7" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "7" And (La3.Text = "1" Or La3.Text = "2"))) And (Lab4.Text = "4" Or Lab5.Text = "4" Or Lab6.Text = "4")) Or (((Lab1.Text = "4" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "4" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "4" And (La3.Text = "1" Or La3.Text = "2"))) And ((Lab1.Text = "7" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "7" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "7" And (La3.Text = "1" Or La3.Text = "2"))) And (Lab4.Text = "1" Or Lab5.Text = "1" Or Lab6.Text = "1")) Then
                wn3.Text += 1
            End If
            If VaH.Checked = False Then
                If (((Lab1.Text = "1" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "1" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "1" And (La3.Text = "1" Or La3.Text = "2"))) And ((Lab1.Text = "5" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "5" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "5" And (La3.Text = "1" Or La3.Text = "2"))) And (Lab4.Text = "9" Or Lab5.Text = "9" Or Lab6.Text = "9")) Or (((Lab1.Text = "1" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "1" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "1" And (La3.Text = "1" Or La3.Text = "2"))) And ((Lab1.Text = "9" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "9" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "9" And (La3.Text = "1" Or La3.Text = "2"))) And (Lab4.Text = "5" Or Lab5.Text = "5" Or Lab6.Text = "5")) Or (((Lab1.Text = "5" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "5" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "5" And (La3.Text = "1" Or La3.Text = "2"))) And ((Lab1.Text = "9" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "9" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "9" And (La3.Text = "1" Or La3.Text = "2"))) And (Lab4.Text = "1" Or Lab5.Text = "1" Or Lab6.Text = "1")) Then
                    wn3.Text += 1
                End If
                If (((Lab1.Text = "3" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "3" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "3" And (La3.Text = "1" Or La3.Text = "2"))) And ((Lab1.Text = "5" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "5" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "5" And (La3.Text = "1" Or La3.Text = "2"))) And (Lab4.Text = "7" Or Lab5.Text = "7" Or Lab6.Text = "7")) Or (((Lab1.Text = "3" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "3" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "3" And (La3.Text = "1" Or La3.Text = "2"))) And ((Lab1.Text = "7" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "7" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "7" And (La3.Text = "1" Or La3.Text = "2"))) And (Lab4.Text = "5" Or Lab5.Text = "5" Or Lab6.Text = "5")) Or (((Lab1.Text = "5" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "5" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "5" And (La3.Text = "1" Or La3.Text = "2"))) And ((Lab1.Text = "7" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "7" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "7" And (La3.Text = "1" Or La3.Text = "2"))) And (Lab4.Text = "3" Or Lab5.Text = "3" Or Lab6.Text = "3")) Then
                    wn3.Text += 1
                End If
                If (((Lab1.Text = "1" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "1" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "1" And (La3.Text = "1" Or La3.Text = "2"))) And ((Lab1.Text = "2" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "2" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "2" And (La3.Text = "1" Or La3.Text = "2"))) And (Lab7.Text = "3" Or Lab8.Text = "3" Or Lab9.Text = "3")) Or (((Lab1.Text = "1" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "1" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "1" And (La3.Text = "1" Or La3.Text = "2"))) And ((Lab1.Text = "3" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "3" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "3" And (La3.Text = "1" Or La3.Text = "2"))) And (Lab7.Text = "2" Or Lab8.Text = "2" Or Lab9.Text = "2")) Or (((Lab1.Text = "2" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "2" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "2" And (La3.Text = "1" Or La3.Text = "2"))) And ((Lab1.Text = "3" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "3" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "3" And (La3.Text = "1" Or La3.Text = "2"))) And (Lab7.Text = "1" Or Lab8.Text = "1" Or Lab9.Text = "1")) Or (((Lab1.Text = "4" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "4" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "4" And (La3.Text = "1" Or La3.Text = "2"))) And ((Lab1.Text = "5" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "5" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "5" And (La3.Text = "1" Or La3.Text = "2"))) And (Lab7.Text = "6" Or Lab8.Text = "6" Or Lab9.Text = "6")) Or (((Lab1.Text = "4" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "4" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "4" And (La3.Text = "1" Or La3.Text = "2"))) And ((Lab1.Text = "6" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "6" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "6" And (La3.Text = "1" Or La3.Text = "2"))) And (Lab7.Text = "5" Or Lab8.Text = "5" Or Lab9.Text = "5")) Or (((Lab1.Text = "5" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "5" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "5" And (La3.Text = "1" Or La3.Text = "2"))) And ((Lab1.Text = "6" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "6" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "6" And (La3.Text = "1" Or La3.Text = "2"))) And (Lab7.Text = "4" Or Lab8.Text = "4" Or Lab9.Text = "4")) Or (((Lab1.Text = "7" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "7" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "7" And (La3.Text = "1" Or La3.Text = "2"))) And ((Lab1.Text = "8" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "8" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "8" And (La3.Text = "1" Or La3.Text = "2"))) And (Lab7.Text = "9" Or Lab8.Text = "9" Or Lab9.Text = "9")) Or (((Lab1.Text = "7" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "7" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "7" And (La3.Text = "1" Or La3.Text = "2"))) And ((Lab1.Text = "9" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "9" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "9" And (La3.Text = "1" Or La3.Text = "2"))) And (Lab7.Text = "8" Or Lab8.Text = "8" Or Lab9.Text = "8")) Or (((Lab1.Text = "8" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "8" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "8" And (La3.Text = "1" Or La3.Text = "2"))) And ((Lab1.Text = "9" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "9" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "9" And (La3.Text = "1" Or La3.Text = "2"))) And (Lab7.Text = "7" Or Lab8.Text = "7" Or Lab9.Text = "7")) Then
                    w39.Text += 1
                End If
                If (((Lab1.Text = "3" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "3" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "3" And (La3.Text = "1" Or La3.Text = "2"))) And ((Lab1.Text = "6" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "6" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "6" And (La3.Text = "1" Or La3.Text = "2"))) And (Lab7.Text = "9" Or Lab8.Text = "9" Or Lab9.Text = "9")) Or (((Lab1.Text = "3" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "3" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "3" And (La3.Text = "1" Or La3.Text = "2"))) And ((Lab1.Text = "9" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "9" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "9" And (La3.Text = "1" Or La3.Text = "2"))) And (Lab7.Text = "6" Or Lab8.Text = "6" Or Lab9.Text = "6")) Or (((Lab1.Text = "6" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "6" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "6" And (La3.Text = "1" Or La3.Text = "2"))) And ((Lab1.Text = "9" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "9" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "9" And (La3.Text = "1" Or La3.Text = "2"))) And (Lab7.Text = "3" Or Lab8.Text = "3" Or Lab9.Text = "3")) Or (((Lab1.Text = "2" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "2" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "2" And (La3.Text = "1" Or La3.Text = "2"))) And ((Lab1.Text = "5" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "5" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "5" And (La3.Text = "1" Or La3.Text = "2"))) And (Lab7.Text = "8" Or Lab8.Text = "8" Or Lab9.Text = "8")) Or (((Lab1.Text = "2" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "2" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "2" And (La3.Text = "1" Or La3.Text = "2"))) And ((Lab1.Text = "8" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "8" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "8" And (La3.Text = "1" Or La3.Text = "2"))) And (Lab7.Text = "5" Or Lab8.Text = "5" Or Lab9.Text = "5")) Or (((Lab1.Text = "5" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "5" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "5" And (La3.Text = "1" Or La3.Text = "2"))) And ((Lab1.Text = "8" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "8" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "8" And (La3.Text = "1" Or La3.Text = "2"))) And (Lab7.Text = "2" Or Lab8.Text = "2" Or Lab9.Text = "2")) Or (((Lab1.Text = "1" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "1" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "1" And (La3.Text = "1" Or La3.Text = "2"))) And ((Lab1.Text = "4" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "4" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "4" And (La3.Text = "1" Or La3.Text = "2"))) And (Lab7.Text = "7" Or Lab8.Text = "7" Or Lab9.Text = "7")) Or (((Lab1.Text = "1" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "1" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "1" And (La3.Text = "1" Or La3.Text = "2"))) And ((Lab1.Text = "7" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "7" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "7" And (La3.Text = "1" Or La3.Text = "2"))) And (Lab7.Text = "4" Or Lab8.Text = "4" Or Lab9.Text = "4")) Or (((Lab1.Text = "4" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "4" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "4" And (La3.Text = "1" Or La3.Text = "2"))) And ((Lab1.Text = "7" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "7" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "7" And (La3.Text = "1" Or La3.Text = "2"))) And (Lab7.Text = "1" Or Lab8.Text = "1" Or Lab9.Text = "1")) Then
                    w39.Text += 1
                End If
                If (((Lab1.Text = "1" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "1" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "1" And (La3.Text = "1" Or La3.Text = "2"))) And ((Lab1.Text = "5" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "5" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "5" And (La3.Text = "1" Or La3.Text = "2"))) And (Lab7.Text = "9" Or Lab8.Text = "9" Or Lab9.Text = "9")) Or (((Lab1.Text = "1" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "1" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "1" And (La3.Text = "1" Or La3.Text = "2"))) And ((Lab1.Text = "9" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "9" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "9" And (La3.Text = "1" Or La3.Text = "2"))) And (Lab7.Text = "5" Or Lab8.Text = "5" Or Lab9.Text = "5")) Or (((Lab1.Text = "5" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "5" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "5" And (La3.Text = "1" Or La3.Text = "2"))) And ((Lab1.Text = "9" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "9" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "9" And (La3.Text = "1" Or La3.Text = "2"))) And (Lab7.Text = "1" Or Lab8.Text = "1" Or Lab9.Text = "1")) Then
                    w39.Text += 1
                End If
                If (((Lab1.Text = "3" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "3" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "3" And (La3.Text = "1" Or La3.Text = "2"))) And ((Lab1.Text = "5" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "5" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "5" And (La3.Text = "1" Or La3.Text = "2"))) And (Lab7.Text = "7" Or Lab8.Text = "7" Or Lab9.Text = "7")) Or (((Lab1.Text = "3" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "3" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "3" And (La3.Text = "1" Or La3.Text = "2"))) And ((Lab1.Text = "7" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "7" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "7" And (La3.Text = "1" Or La3.Text = "2"))) And (Lab7.Text = "5" Or Lab8.Text = "5" Or Lab9.Text = "5")) Or (((Lab1.Text = "5" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "5" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "5" And (La3.Text = "1" Or La3.Text = "2"))) And ((Lab1.Text = "7" And (La1.Text = "1" Or La1.Text = "2")) Or (Lab2.Text = "7" And (La2.Text = "1" Or La2.Text = "2")) Or (Lab3.Text = "7" And (La3.Text = "1" Or La3.Text = "2"))) And (Lab7.Text = "3" Or Lab8.Text = "3" Or Lab9.Text = "3")) Then
                    w39.Text += 1
                End If
            End If
        End If
        '  MsgBox(er.Text + " . " + see.Text + " . " + see2.Text + " . " + wn3.Text + " . " + w39.Text)
        Lab4.Text = Lx4.Text : Lab5.Text = Lx5.Text : Lab6.Text = Lx6.Text : Lab1.Text = Lx1.Text : Lab2.Text = Lx2.Text : Lab3.Text = Lx3.Text
        If (wn3.Text = "0" Or wn3.Text = "1") And w39.Text <= er.Text Then
            ss.Text = "0"
            wn3.Text = "0"
            w39.Text = "0"
            If see2.Text = "10" Then
                If La3.Text = "2" Then
                    La3.Text = "0"
                End If
                see2.Text = "1"
            Else
                If La1.Text = "2" Then
                    La1.Text = "0"
                End If
                If La2.Text = "2" Then
                    La2.Text = "0"
                End If
                If La3.Text = "2" Then
                    La3.Text = "0"
                End If
                zxzx(e)
            End If
        Else
            ss.Text = "1"
            wn3.Text = "0"
            w39.Text = "0"
            If see2.Text = "10" Then
                If La3.Text = "2" Then
                    La3.Text = "0"
                End If
            Else
                If La1.Text = "2" Then
                    La1.Text = "0"
                End If
                If La2.Text = "2" Then
                    La2.Text = "0"
                End If
                If La3.Text = "2" Then
                    La3.Text = "0"
                End If
            End If
            see2.Text = "1"
        End If
    End Sub

    Sub p2(ByVal e As EventArgs)
        If s0.Text = "-1" Then
        Else
            Dim rand = New Random
            Dim x As Integer
            x = rand.Next(0, s0.Text + 1)
            Dim z As String = s1.Text.ToList(x)
            Dim u1 As String = s1.Text.Replace("2", "").Replace("3", "").Replace("4", "").Replace("5", "").Replace("6", "").Replace("7", "").Replace("8", "").Replace("9", "")
            Dim u2 As String = s1.Text.Replace("1", "").Replace("3", "").Replace("4", "").Replace("5", "").Replace("6", "").Replace("7", "").Replace("8", "").Replace("9", "")
            Dim u3 As String = s1.Text.Replace("2", "").Replace("1", "").Replace("4", "").Replace("5", "").Replace("6", "").Replace("7", "").Replace("8", "").Replace("9", "")
            Dim u4 As String = s1.Text.Replace("2", "").Replace("3", "").Replace("1", "").Replace("5", "").Replace("6", "").Replace("7", "").Replace("8", "").Replace("9", "")
            Dim u5 As String = s1.Text.Replace("2", "").Replace("3", "").Replace("4", "").Replace("1", "").Replace("6", "").Replace("7", "").Replace("8", "").Replace("9", "")
            Dim u6 As String = s1.Text.Replace("2", "").Replace("3", "").Replace("4", "").Replace("5", "").Replace("1", "").Replace("7", "").Replace("8", "").Replace("9", "")
            Dim u7 As String = s1.Text.Replace("2", "").Replace("3", "").Replace("4", "").Replace("5", "").Replace("6", "").Replace("1", "").Replace("8", "").Replace("9", "")
            Dim u8 As String = s1.Text.Replace("2", "").Replace("3", "").Replace("4", "").Replace("5", "").Replace("6", "").Replace("7", "").Replace("1", "").Replace("9", "")
            Dim u9 As String = s1.Text.Replace("2", "").Replace("3", "").Replace("4", "").Replace("5", "").Replace("6", "").Replace("7", "").Replace("8", "").Replace("1", "")
            If ((La7.Text = "1" And (z = "1" Or z = "4" Or z = "7")) Or (La8.Text = "1" And (z = "2" Or z = "5" Or z = "8")) Or (La9.Text = "1" And (z = "3" Or z = "6" Or z = "9"))) And ((La7.Text = "0" And (z = "2" Or z = "3" Or z = "5" Or z = "6" Or z = "8" Or z = "9") And (u1 = "1" Or u4 = "4" Or u7 = "7")) Or (La8.Text = "0" And (z = "1" Or z = "3" Or z = "4" Or z = "6" Or z = "7" Or z = "9") And (u2 = "2" Or u5 = "5" Or u8 = "8")) Or (La9.Text = "0" And (z = "1" Or z = "2" Or z = "4" Or z = "5" Or z = "7" Or z = "8") And (u3 = "3" Or u6 = "6" Or u9 = "9"))) Then
                If La7.Text = "0" Then
                    If u1 = "1" Then
                        l47(e)
                    ElseIf u4 = "4" Then
                        l57(e)
                    ElseIf u7 = "7" Then
                        l67(e)
                    End If
                ElseIf La8.Text = "0" Then
                    If u2 = "2" Then
                        l48(e)
                    ElseIf u5 = "5" Then
                        l58(e)
                    ElseIf u8 = "8" Then
                        l68(e)
                    End If
                ElseIf La9.Text = "0" Then
                    If u3 = "3" Then
                        l49(e)
                    ElseIf u6 = "6" Then
                        l59(e)
                    ElseIf u9 = "9" Then
                        l69(e)
                    End If
                End If
            Else
                If z = "1" Then
                    l47(e)
                ElseIf z = "2" Then
                    l48(e)
                ElseIf z = "3" Then
                    l49(e)
                ElseIf z = "4" Then
                    l57(e)
                ElseIf z = "5" Then
                    l58(e)
                ElseIf z = "6" Then
                    l59(e)
                ElseIf z = "7" Then
                    l67(e)
                ElseIf z = "8" Then
                    l68(e)
                ElseIf z = "9" Then
                    l69(e)
                End If
            End If
        End If
        s0.Text = "-1"
        s1.Text = ""
    End Sub

    Sub t22(ByVal e As EventArgs)
        T2.Stop()
        tt2(e)
        L2.Text = "0"
        stp2.Text += 1
        If Lab7.Text = Lb7.Text Then
        Else
            La7.Text = "1"
        End If
        If Lab8.Text = Lb8.Text Then
        Else
            La8.Text = "1"
        End If
        If Lab9.Text = Lb9.Text Then
        Else
            La9.Text = "1"
        End If
        n0.Text += 2
        If Lab4.Text = Lb7.Text Then
            n1.Text = n1.Text + "4 "
            Le7.Text += 1
        ElseIf Lab4.Text = Lb8.Text Then
            n1.Text = n1.Text + "5 "
            Le8.Text += 1
        ElseIf Lab4.Text = Lb9.Text Then
            n1.Text = n1.Text + "6 "
            Le9.Text += 1
        ElseIf Lab5.Text = Lb7.Text Then
            n1.Text = n1.Text + "10"
            Le7.Text += 1
        ElseIf Lab5.Text = Lb8.Text Then
            n1.Text = n1.Text + "11"
            Le8.Text += 1
        ElseIf Lab5.Text = Lb9.Text Then
            n1.Text = n1.Text + "12"
            Le9.Text += 1
        ElseIf Lab6.Text = Lb7.Text Then
            n1.Text = n1.Text + "16"
            Le7.Text += 1
        ElseIf Lab6.Text = Lb8.Text Then
            n1.Text = n1.Text + "17"
            Le8.Text += 1
        ElseIf Lab6.Text = Lb9.Text Then
            n1.Text = n1.Text + "18"
            Le9.Text += 1
        End If
        r0.Text = "-1"
        r1.Text = ""
        Lb7.Text = Lab7.Text : Lb8.Text = Lab8.Text : Lb9.Text = Lab9.Text
        l1.Text = "0"
        rf(e)
        ne(e)
        PB2.Visible = False : wt.Visible = False
        Cmpt.Enabled = True
        loc(e)
        bl.Text = "0"
        Wn(e)
        T3.Start()
    End Sub

    Private Sub T2_Tick(sender As Object, e As EventArgs) Handles T2.Tick
        t22(e)
    End Sub

    Private Sub T3_Tick(sender As Object, e As EventArgs) Handles T3.Tick
        If Cmpt.Checked = True And Bu4.Visible = False And L2.Text = "1" Then
            If L3.Text = "2" Then
                wn19(e)
                If lwz.Text = "0" Then
                Else
                    PB2.Visible = True
                    wt.Visible = True
                    T3.Stop()
                    bl.Text = "1"
                    T2.Start()
                End If
            Else
                If L3.Text = "0" Then
                    PB2.Visible = True
                    wt.Visible = True
                    T3.Stop()
                    bl.Text = "1"
                    T2.Start()
                End If
            End If
        Else
            If Cmpt.Checked = False Then
                T3.Stop()
            End If
        End If
    End Sub

    Private Sub Bu6_Click(sender As Object, e As EventArgs) Handles Bu6.Click
        If sfh.Text = "1" Then
            Bu1.Visible = False
            Bu2.Visible = False
            Bu3.Visible = False
            Bu7.Visible = True
            Bu8.Visible = True
            sv.Visible = True
            ld.Visible = True
            sfh.Text = "2"
        ElseIf sfh.Text = "2" Then
            Bu8.Visible = False
            sv.Visible = False
            ld.Visible = False
            wlf.Visible = True
            sfh.Text = "3"
        ElseIf sfh.Text = "3" Then
            wlf.Visible = False
            rl.Visible = True
            rr.Visible = True
            rh.Visible = True
            rv.Visible = True
            sfh.Text = "4"
        ElseIf sfh.Text = "4" Then
            rl.Visible = False
            rr.Visible = False
            rh.Visible = False
            rv.Visible = False
            Lf.Visible = True
            fst.Visible = True
            sfh.Text = "5"
        ElseIf sfh.Text = "5" Then
            Bu6.Visible = False
            Lf.Visible = False
            fst.Visible = False
            Bu5.Visible = True
            sfh.Text = "6"
        End If
    End Sub

    Private Sub Bu7_Click(sender As Object, e As EventArgs) Handles Bu7.Click
        If sfh.Text = "2" Then
            Bu7.Visible = False
            Bu8.Visible = False
            sv.Visible = False
            ld.Visible = False
            Bu1.Visible = True
            Bu2.Visible = True
            Bu3.Visible = True
            sfh.Text = "1"
        ElseIf sfh.Text = "3" Then
            wlf.Visible = False
            Bu8.Visible = True
            sv.Visible = True
            ld.Visible = True
            sfh.Text = "2"
        ElseIf sfh.Text = "4" Then
            rl.Visible = False
            rr.Visible = False
            rh.Visible = False
            rv.Visible = False
            wlf.Visible = True
            sfh.Text = "3"
        ElseIf sfh.Text = "5" Then
            Lf.Visible = False
            fst.Visible = False
            rl.Visible = True
            rr.Visible = True
            rh.Visible = True
            rv.Visible = True
            sfh.Text = "4"
        ElseIf sfh.Text = "6" Then
            Bu5.Visible = False
            Bu6.Visible = True
            Lf.Visible = True
            fst.Visible = True
            sfh.Text = "5"
        End If
    End Sub

    Private Sub Bu5_Click(sender As Object, e As EventArgs) Handles Bu5.Click
        If Bu8.Text = "عربي" Then
            MsgBox("- If you want to play with the keyboard, Press the 1, 2, 3, 4, 5, 6, 7, 8, 9, z, x, c, a, s, d, q, w or e buttons.
- Arabic: G    - Save: F2 or O    - Load: F4 or L
- Help: F10 or H    - Undo: U    - Redo: I    - OK: F5 & F7
- Computer: T     - Change the computer's intelligence level: Y
- Download latest version  and  About the designer : M
- Reduce the lighting: J or F6 - Raise the lighting: K or F8 ... Press long.
- Use numbers and letters on the keyboard as if they were game boxes.
- If you want to continue playing with the keyboard, Do not press the writing boxes.", vbInformation, "How ?!")
        Else
            MsgBox("- لو اردت اللعب بلوحة المفاتيح، إضغط على ازرار 1، 2، 3، 4، 5، 6، 7، 8، 9، ئ، ء، ؤ، ش، س، ي، ض، ص أو ث.
- إنجليزي: ل    - حفظ: F2 أو خ    - تحميل: F4 أو م
- مساعدة: F10 أو أ    - تراجع: ع    - إعادة: هـ    - موافق: F5 و F7
- الحاسوب: ف     - تغيير مستوى ذكاء الحاسوب: غ
- تحميل آخر إصدار  و  عن المصمم : ة
- خفض الإضاءة: ت أو F6 - رفع الإضاءة: ن أو F8 ... إضغط مطولاً.
- إستخدم الأرقام والحروف التي في لوحة المفاتيح كما لو كانت مربعات اللعبة.
- لو اردت الاستمرار في اللعب بلوحة المفاتيح، لا تضغط على مربعات الكتابة.", vbInformation + vbMsgBoxRight + vbMsgBoxRtlReading, "كيف؟!")
        End If
    End Sub

    Sub g(ByVal e As EventArgs)
        If Bu8.Text = "عربي" Then
            Bu1.Text = "حول"
            Bu2.Text = "إعادة بدء"
            Bu3.Text = "إعادة بدء الكل"
            If Bu4.Text = "Start" Then
                Bu4.Text = "إبدأ"
            Else
                Bu4.Text = "توقف"
            End If
            Bu5.Text = "كيفية إستخدام لوحة المفاتيح للعب"
            Bu8.Text = "English"
            VaH.Text = "عمودي وأفقي فقط"
            NoS.Text = "خطوات كلا اللاعبين تكون متساوية"
            Cmpt.Text = "الحاسوب"
            wt.Text = "...إنتظر"
            Sega2.Text = "حول"
            Sega2.ckh.Text = "إضغط هنا  لتحميل آخر إصدار من اللعبة"
            Sega2.ckh.Location = New Point(120, 9)
            bmp.Items.Clear()
            bmp.Items.AddRange(New Object() {"مبتدئ", "متوسط", "متقدم", "محترف"})
            bmpn(e)
            wlf.Items.Clear()
            wlf.Items.AddRange(New Object() {"الفائز يلعب أولا", "الخاسر يلعب أولا", "الذي لعب أولا يلعب آخرا المرة القادمة", "إختيار من سيلعب أولا بالقرعة", "إختيار من سيلعب أولا تلقائيا"})
            wlfn(e)
            ns.Items.Clear()
            ns.Items.AddRange(New Object() {"أولا", "آخرا"})
            nsn(e)
            lns.Location = New Point(111, 482)
            lns.Text = "عندما لا يفز أحد: الذي قام باللعب أولاً، يلعب"
            ns.Location = New Point(34, 479)
            sv.Text = "حفظ"
            ld.Text = "تحميل"
            Lf.Location = New Point(145, 519)
            Lf.Text = "سرعة الحاسوب بالملي ثانية :"
            Lf.RightToLeft = RightToLeft.Yes
            fst.Location = New Point(47, 515)
            fst.Size = New Size(85, 32)
            Bu9.Text = "مساعدة"
            ok1.Text = ok1.Text.Replace("OK", "موافق")
            ok2.Text = ok2.Text.Replace("OK", "موافق")
        Else
            Bu1.Text = "About"
            Bu2.Text = "Restart"
            Bu3.Text = "Restart All"
            If Bu4.Text = "إبدأ" Then
                Bu4.Text = "Start"
            Else
                Bu4.Text = "Stop"
            End If
            Bu5.Text = "How to use the keyboard to play"
            Bu8.Text = "عربي"
            VaH.Text = "Vertical and Horizontal only"
            NoS.Text = "The steps of both players be equal"
            Cmpt.Text = "Computer"
            wt.Text = "Wait..."
            Sega2.Text = "About"
            Sega2.ckh.Text = "Click here  to download the latest version of the game"
            Sega2.ckh.Location = New Point(58, 9)
            bmp.Items.Clear()
            bmp.Items.AddRange(New Object() {"Beginner", "Medium", "Advanced", "Professional"})
            bmpn(e)
            wlf.Items.Clear()
            wlf.Items.AddRange(New Object() {"The winner plays first", "The loser plays first", "Who played first, plays second next time", "Choose who will play first by lot", "Choose who will play first automatically"})
            wlfn(e)
            ns.Items.Clear()
            ns.Items.AddRange(New Object() {"first", "second"})
            nsn(e)
            lns.Location = New Point(34, 482)
            lns.Text = "When no one wins: who played first, plays"
            ns.Location = New Point(383, 479)
            sv.Text = "Save"
            ld.Text = "Load"
            Lf.Location = New Point(42, 519)
            Lf.Text = "Computer speed in milliseconds:"
            Lf.RightToLeft = RightToLeft.No
            fst.Location = New Point(347, 515)
            fst.Size = New Size(75, 32)
            Bu9.Text = "Help"
            ok1.Text = ok1.Text.Replace("موافق", "OK")
            ok2.Text = ok2.Text.Replace("موافق", "OK")
        End If
    End Sub

    Private Sub Bu8_Click(sender As Object, e As EventArgs) Handles Bu8.Click
        g(e)
    End Sub

    Sub u(ByVal e As EventArgs)
        If bl.Text = "0" Then
            If ok1.Checked = True And ok2.Checked = True Then
                Dim fgh As String = n1.Text.ToList(n0.Text - 1)
                Dim ghj As String = n1.Text.ToList(n0.Text)
                gh3 = fgh + ghj
                r1.Text = r1.Text + fgh + ghj
                r0.Text += 2
                n0.Text -= 2
                n1.Text = n1.Text.ToCharArray(0, n0.Text + 1)
                If gh3 = "1 " Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
                    Le1.Text -= 1
                ElseIf gh3 = "2 " Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
                    Le2.Text -= 1
                ElseIf gh3 = "3 " Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
                    Le3.Text -= 1
                ElseIf gh3 = "4 " Then
                    l47(e)
                    Le7.Text -= 1
                ElseIf gh3 = "5 " Then
                    l48(e)
                    Le8.Text -= 1
                ElseIf gh3 = "6 " Then
                    l49(e)
                    Le9.Text -= 1
                ElseIf gh3 = "7 " Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab1.Text : Lab1.Text = rt.Text
                    Le1.Text -= 1
                ElseIf gh3 = "8 " Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab2.Text : Lab2.Text = rt.Text
                    Le2.Text -= 1
                ElseIf gh3 = "9 " Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
                    Le3.Text -= 1
                ElseIf gh3 = "10" Then
                    l57(e)
                    Le7.Text -= 1
                ElseIf gh3 = "11" Then
                    l58(e)
                    Le8.Text -= 1
                ElseIf gh3 = "12" Then
                    l59(e)
                    Le9.Text -= 1
                ElseIf gh3 = "13" Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab1.Text : Lab1.Text = rt.Text
                    Le1.Text -= 1
                ElseIf gh3 = "14" Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab2.Text : Lab2.Text = rt.Text
                    Le2.Text -= 1
                ElseIf gh3 = "15" Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
                    Le3.Text -= 1
                ElseIf gh3 = "16" Then
                    l67(e)
                    Le7.Text -= 1
                ElseIf gh3 = "17" Then
                    l68(e)
                    Le8.Text -= 1
                ElseIf gh3 = "18" Then
                    l69(e)
                    Le9.Text -= 1
                End If
                If Le1.Text = "0" Then
                    La1.Text = "0"
                End If
                If Le2.Text = "0" Then
                    La2.Text = "0"
                End If
                If Le3.Text = "0" Then
                    La3.Text = "0"
                End If
                If Le7.Text = "0" Then
                    La7.Text = "0"
                End If
                If Le8.Text = "0" Then
                    La8.Text = "0"
                End If
                If Le9.Text = "0" Then
                    La9.Text = "0"
                End If
                L3.Text = "2"
                If L2.Text = "0" Then
                    L2.Text = "1"
                    l1.Text = "0"
                    stp2.Text = stp2.Text - 1
                ElseIf L2.Text = "1" Then
                    L2.Text = "0"
                    l1.Text = "0"
                    stp1.Text = stp1.Text - 1
                End If
                If n0.Text = -1 Then
                    nf(e)
                End If
                re(e)
                loc(e)
                If VaH.Checked = False Then
                    Wn(e)
                End If
            Else
                If Bu8.Text = "عربي" Then
                    MsgBox(("Both of you should agree to this feature by pressing OK"), vbInformation, "warning...")
                Else
                    MsgBox(("على كليكما ان توافقا معا على هذه الخاصية بالضغط على موافق"), vbInformation + vbMsgBoxRight + vbMsgBoxRtlReading, "تحذير...")
                End If
            End If
        End If
    End Sub

    Private Sub nd_Click(sender As Object, e As EventArgs) Handles nd.Click
        u(e)
    End Sub

    Sub r(ByVal e As EventArgs)
        If bl.Text = "0" Then
            If ok1.Checked = True And ok2.Checked = True Then
                Dim fgh As String = r1.Text.ToList(r0.Text - 1)
                Dim ghj As String = r1.Text.ToList(r0.Text)
                gh4 = fgh + ghj
                n1.Text = n1.Text + fgh + ghj
                n0.Text += 2
                r0.Text -= 2
                r1.Text = r1.Text.ToCharArray(0, r0.Text + 1)
                If gh4 = 1 Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab1.Text : Lab1.Text = rt.Text
                    Le1.Text += 1
                ElseIf gh4 = 2 Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab2.Text : Lab2.Text = rt.Text
                    Le2.Text += 1
                ElseIf gh4 = 3 Then
                    rt.Text = Lab4.Text : Lab4.Text = Lab3.Text : Lab3.Text = rt.Text
                    Le3.Text += 1
                ElseIf gh4 = 4 Then
                    l47(e)
                    Le7.Text += 1
                ElseIf gh4 = 5 Then
                    l48(e)
                    Le8.Text += 1
                ElseIf gh4 = 6 Then
                    l49(e)
                    Le9.Text += 1
                ElseIf gh4 = 7 Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab1.Text : Lab1.Text = rt.Text
                    Le1.Text += 1
                ElseIf gh4 = 8 Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab2.Text : Lab2.Text = rt.Text
                    Le2.Text += 1
                ElseIf gh4 = 9 Then
                    rt.Text = Lab5.Text : Lab5.Text = Lab3.Text : Lab3.Text = rt.Text
                    Le3.Text += 1
                ElseIf gh4 = 10 Then
                    l57(e)
                    Le7.Text += 1
                ElseIf gh4 = 11 Then
                    l58(e)
                    Le8.Text += 1
                ElseIf gh4 = 12 Then
                    l59(e)
                    Le9.Text += 1
                ElseIf gh4 = 13 Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab1.Text : Lab1.Text = rt.Text
                    Le1.Text += 1
                ElseIf gh4 = 14 Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab2.Text : Lab2.Text = rt.Text
                    Le2.Text += 1
                ElseIf gh4 = 15 Then
                    rt.Text = Lab6.Text : Lab6.Text = Lab3.Text : Lab3.Text = rt.Text
                    Le3.Text += 1
                ElseIf gh4 = 16 Then
                    l67(e)
                    Le7.Text += 1
                ElseIf gh4 = 17 Then
                    l68(e)
                    Le8.Text += 1
                ElseIf gh4 = 18 Then
                    l69(e)
                    Le9.Text += 1
                End If
                If Le1.Text > 0 Then
                    La1.Text = "1"
                End If
                If Le2.Text > 0 Then
                    La2.Text = "1"
                End If
                If Le3.Text > 0 Then
                    La3.Text = "1"
                End If
                If Le7.Text > 0 Then
                    La7.Text = "1"
                End If
                If Le8.Text > 0 Then
                    La8.Text = "1"
                End If
                If Le9.Text > 0 Then
                    La9.Text = "1"
                End If
                If L2.Text = "0" Then
                    L2.Text = "1"
                    l1.Text = "0"
                    stp1.Text = stp1.Text + 1
                ElseIf L2.Text = "1" Then
                    L2.Text = "0"
                    l1.Text = "0"
                    stp2.Text = stp2.Text + 1
                End If
                If r0.Text = -1 Then
                    rf(e)
                End If
                ne(e)
                loc(e)
                Wn(e)
            Else
                If Bu8.Text = "عربي" Then
                    MsgBox(("Both of you should agree to this feature by pressing OK"), vbInformation, "warning...")
                Else
                    MsgBox(("على كليكما ان توافقا معا على هذه الخاصية بالضغط على موافق"), vbInformation + vbMsgBoxRight + vbMsgBoxRtlReading, "تحذير...")
                End If
            End If
        End If
    End Sub

    Private Sub rd_Click(sender As Object, e As EventArgs) Handles rd.Click
        r(e)
    End Sub

    Sub sve(ByVal e As EventArgs)
        If bl.Text = "0" Then
            My.Computer.FileSystem.CreateDirectory(sg + "NewSave")
            Dim ss As String = sg + "NewSave\"
            My.Computer.FileSystem.WriteAllText(ss + "1.sg", wn1.Text, False)
            My.Computer.FileSystem.WriteAllText(ss + "2.sg", wn2.Text, False)
            My.Computer.FileSystem.WriteAllText(ss + "3.sg", stp1.Text, False)
            My.Computer.FileSystem.WriteAllText(ss + "4.sg", stp2.Text, False)
            My.Computer.FileSystem.WriteAllText(ss + "5.sg", L2.Text, False)
            My.Computer.FileSystem.WriteAllText(ss + "6.sg", L22.Text, False)
            My.Computer.FileSystem.WriteAllText(ss + "8.sg", nm1.Text, False)
            My.Computer.FileSystem.WriteAllText(ss + "9.sg", nm2.Text, False)
            My.Computer.FileSystem.WriteAllText(ss + "10.sg", La1.Text, False)
            My.Computer.FileSystem.WriteAllText(ss + "11.sg", La2.Text, False)
            My.Computer.FileSystem.WriteAllText(ss + "12.sg", La3.Text, False)
            My.Computer.FileSystem.WriteAllText(ss + "13.sg", La7.Text, False)
            My.Computer.FileSystem.WriteAllText(ss + "14.sg", La8.Text, False)
            My.Computer.FileSystem.WriteAllText(ss + "15.sg", La9.Text, False)
            My.Computer.FileSystem.WriteAllText(ss + "16.sg", Lab1.Text, False)
            My.Computer.FileSystem.WriteAllText(ss + "17.sg", Lab2.Text, False)
            My.Computer.FileSystem.WriteAllText(ss + "18.sg", Lab3.Text, False)
            My.Computer.FileSystem.WriteAllText(ss + "19.sg", Lab4.Text, False)
            My.Computer.FileSystem.WriteAllText(ss + "20.sg", Lab5.Text, False)
            My.Computer.FileSystem.WriteAllText(ss + "21.sg", Lab6.Text, False)
            My.Computer.FileSystem.WriteAllText(ss + "22.sg", Lab7.Text, False)
            My.Computer.FileSystem.WriteAllText(ss + "23.sg", Lab8.Text, False)
            My.Computer.FileSystem.WriteAllText(ss + "24.sg", Lab9.Text, False)
            My.Computer.FileSystem.WriteAllText(ss + "32.sg", n0.Text, False)
            My.Computer.FileSystem.WriteAllText(ss + "33.sg", n1.Text, False)
            My.Computer.FileSystem.WriteAllText(ss + "34.sg", r0.Text, False)
            My.Computer.FileSystem.WriteAllText(ss + "35.sg", r1.Text, False)
            My.Computer.FileSystem.WriteAllText(ss + "36.sg", Le1.Text, False)
            My.Computer.FileSystem.WriteAllText(ss + "37.sg", Le2.Text, False)
            My.Computer.FileSystem.WriteAllText(ss + "38.sg", Le3.Text, False)
            My.Computer.FileSystem.WriteAllText(ss + "39.sg", Le7.Text, False)
            My.Computer.FileSystem.WriteAllText(ss + "40.sg", Le8.Text, False)
            My.Computer.FileSystem.WriteAllText(ss + "41.sg", Le9.Text, False)
            If VaH.Checked = True Then
                My.Computer.FileSystem.WriteAllText(ss + "25.sg", 1, False)
            Else
                My.Computer.FileSystem.WriteAllText(ss + "25.sg", 0, False)
            End If
            If NoS.Checked = False Then
                My.Computer.FileSystem.WriteAllText(ss + "26.sg", 0, False)
            Else
                My.Computer.FileSystem.WriteAllText(ss + "26.sg", 1, False)
            End If
            My.Computer.FileSystem.WriteAllText(ss + "27.sg", ll.Text, False)
            If Cmpt.Checked = False Then
                My.Computer.FileSystem.WriteAllText(ss + "28.sg", 0, False)
            Else
                My.Computer.FileSystem.WriteAllText(ss + "28.sg", 1, False)
            End If
            If ok1.Checked = True And ok2.Checked = True Then
                My.Computer.FileSystem.WriteAllText(ss + "29.sg", 1, False)
            Else
                My.Computer.FileSystem.WriteAllText(ss + "29.sg", 0, False)
            End If
            My.Computer.FileSystem.WriteAllText(ss + "30.sg", l1.Text, False)
            My.Computer.FileSystem.WriteAllText(ss + "31.sg", L3.Text, False)
            My.Computer.FileSystem.WriteAllText(ss + "42.sg", o1.Text, False)
            My.Computer.FileSystem.WriteAllText(ss + "43.sg", o2.Text, False)
            My.Computer.FileSystem.WriteAllText(ss + "44.sg", flw.Text, False)
            My.Computer.FileSystem.WriteAllText(ss + "45.sg", sn.Text, False)
            ld.Enabled = True
        End If
    End Sub

    Private Sub sv_Click(sender As Object, e As EventArgs) Handles sv.Click
        sve(e)
    End Sub

    Sub lde(ByVal e As EventArgs)
        If bl.Text = "0" Then
            Dim ss As String = sg + "NewSave\"
            If Bu8.Text = "عربي" Then
                Bu4.Text = "Start"
            Else
                Bu4.Text = "إبدأ"
            End If
            T1.Stop()
            If My.Computer.FileSystem.ReadAllText(ss + "26.sg") = "0" Then
                NoS.Checked = False
            Else
                NoS.Checked = True
            End If
            If My.Computer.FileSystem.ReadAllText(ss + "25.sg") = "1" Then
                VaH.Checked = True
            Else
                VaH.Checked = False
            End If
            Bu4.Visible = False
            wn1.Text = My.Computer.FileSystem.ReadAllText(ss + "1.sg")
            wn2.Text = My.Computer.FileSystem.ReadAllText(ss + "2.sg")
            stp1.Text = My.Computer.FileSystem.ReadAllText(ss + "3.sg")
            stp2.Text = My.Computer.FileSystem.ReadAllText(ss + "4.sg")
            L2.Text = My.Computer.FileSystem.ReadAllText(ss + "5.sg")
            L22.Text = My.Computer.FileSystem.ReadAllText(ss + "6.sg")
            nm1.Text = My.Computer.FileSystem.ReadAllText(ss + "8.sg")
            nm2.Text = My.Computer.FileSystem.ReadAllText(ss + "9.sg")
            La1.Text = My.Computer.FileSystem.ReadAllText(ss + "10.sg")
            La2.Text = My.Computer.FileSystem.ReadAllText(ss + "11.sg")
            La3.Text = My.Computer.FileSystem.ReadAllText(ss + "12.sg")
            La7.Text = My.Computer.FileSystem.ReadAllText(ss + "13.sg")
            La8.Text = My.Computer.FileSystem.ReadAllText(ss + "14.sg")
            La9.Text = My.Computer.FileSystem.ReadAllText(ss + "15.sg")
            Lab1.Text = My.Computer.FileSystem.ReadAllText(ss + "16.sg")
            Lab2.Text = My.Computer.FileSystem.ReadAllText(ss + "17.sg")
            Lab3.Text = My.Computer.FileSystem.ReadAllText(ss + "18.sg")
            Lab4.Text = My.Computer.FileSystem.ReadAllText(ss + "19.sg")
            Lab5.Text = My.Computer.FileSystem.ReadAllText(ss + "20.sg")
            Lab6.Text = My.Computer.FileSystem.ReadAllText(ss + "21.sg")
            Lab7.Text = My.Computer.FileSystem.ReadAllText(ss + "22.sg")
            Lab8.Text = My.Computer.FileSystem.ReadAllText(ss + "23.sg")
            Lab9.Text = My.Computer.FileSystem.ReadAllText(ss + "24.sg")
            If My.Computer.FileSystem.FileExists(ss + "32.sg") Then
                n0.Text = My.Computer.FileSystem.ReadAllText(ss + "32.sg")
                n1.Text = My.Computer.FileSystem.ReadAllText(ss + "33.sg")
                r0.Text = My.Computer.FileSystem.ReadAllText(ss + "34.sg")
                r1.Text = My.Computer.FileSystem.ReadAllText(ss + "35.sg")
                Le1.Text = My.Computer.FileSystem.ReadAllText(ss + "36.sg")
                Le2.Text = My.Computer.FileSystem.ReadAllText(ss + "37.sg")
                Le3.Text = My.Computer.FileSystem.ReadAllText(ss + "38.sg")
                Le7.Text = My.Computer.FileSystem.ReadAllText(ss + "39.sg")
                Le8.Text = My.Computer.FileSystem.ReadAllText(ss + "40.sg")
                Le9.Text = My.Computer.FileSystem.ReadAllText(ss + "41.sg")
            Else
                n0.Text = -1
                r0.Text = -1
                n1.Text = ""
                r1.Text = ""
                Le1.Text = La1.Text
                Le2.Text = La2.Text
                Le3.Text = La3.Text
                Le7.Text = La7.Text
                Le8.Text = La8.Text
                Le9.Text = La9.Text
            End If
            ll.Text = My.Computer.FileSystem.ReadAllText(ss + "27.sg")
            l1.Text = 0
            If My.Computer.FileSystem.FileExists(ss + "30.sg") Then
                l1.Text = My.Computer.FileSystem.ReadAllText(ss + "30.sg")
            End If
            If My.Computer.FileSystem.ReadAllText(ss + "28.sg") = "0" Then
                Cmpt.Checked = False
            Else
                Cmpt.Checked = True
            End If
            If My.Computer.FileSystem.ReadAllText(ss + "29.sg") = "1" Then
                ok1.Checked = True
                ok2.Checked = True
            End If
            nf(e)
            rf(e)
            ok1.Visible = True
            ok2.Visible = True
            If n0.Text = -1 Then
            Else
                ne(e)
            End If
            If r0.Text = -1 Then
            Else
                re(e)
            End If
            bmpn(e)
            L3.Text = "2"
            If My.Computer.FileSystem.FileExists(ss + "31.sg") Then
                L3.Text = My.Computer.FileSystem.ReadAllText(ss + "31.sg")
            Else
                Wn(e)
            End If
            Bu9.Visible = True
            If My.Computer.FileSystem.FileExists(ss + "42.sg") Then
                o1.Text = My.Computer.FileSystem.ReadAllText(ss + "42.sg")
                o2.Text = My.Computer.FileSystem.ReadAllText(ss + "43.sg")
                If o1.Text > 0 Then
                    ok1.Text = "OK +" + o1.Text
                Else
                    If ok1.Checked = True Then
                        o1.Text = "1"
                        ok1.Text = "OK +1"
                    Else
                        o1.Text = "0"
                        ok1.Text = "OK"
                    End If
                End If
                If o2.Text > 0 Then
                    ok2.Text = "OK +" + o2.Text
                Else
                    If ok2.Checked = True Then
                        o2.Text = "1"
                        ok2.Text = "OK +1"
                    Else
                        o2.Text = "0"
                        ok2.Text = "OK"
                    End If
                End If
                If Bu8.Text = "English" Then
                    ok1.Text = ok1.Text.Replace("OK", "موافق")
                    ok2.Text = ok2.Text.Replace("OK", "موافق")
                End If
            End If
            If My.Computer.FileSystem.FileExists(ss + "44.sg") Then
                flw.Text = My.Computer.FileSystem.ReadAllText(ss + "44.sg")
                sn.Text = My.Computer.FileSystem.ReadAllText(ss + "45.sg")
                wlfn(e)
                nsn(e)
            End If
            loc(e)
            sv.Enabled = True
        End If
    End Sub

    Private Sub ld_Click(sender As Object, e As EventArgs) Handles ld.Click
        lde(e)
    End Sub

    Private Sub rl_Click(sender As Object, e As EventArgs) Handles rl.Click
        If bl.Text = "0" Then
            If Lab1.Text = "3" Then
                Lab1.Text = "1"
            ElseIf Lab1.Text = "6" Then
                Lab1.Text = "2"
            ElseIf Lab1.Text = "9" Then
                Lab1.Text = "3"
            ElseIf Lab1.Text = "8" Then
                Lab1.Text = "6"
            ElseIf Lab1.Text = "7" Then
                Lab1.Text = "9"
            ElseIf Lab1.Text = "4" Then
                Lab1.Text = "8"
            ElseIf Lab1.Text = "1" Then
                Lab1.Text = "7"
            ElseIf Lab1.Text = "2" Then
                Lab1.Text = "4"
            End If
            If Lab2.Text = "3" Then
                Lab2.Text = "1"
            ElseIf Lab2.Text = "6" Then
                Lab2.Text = "2"
            ElseIf Lab2.Text = "9" Then
                Lab2.Text = "3"
            ElseIf Lab2.Text = "8" Then
                Lab2.Text = "6"
            ElseIf Lab2.Text = "7" Then
                Lab2.Text = "9"
            ElseIf Lab2.Text = "4" Then
                Lab2.Text = "8"
            ElseIf Lab2.Text = "1" Then
                Lab2.Text = "7"
            ElseIf Lab2.Text = "2" Then
                Lab2.Text = "4"
            End If
            If Lab3.Text = "3" Then
                Lab3.Text = "1"
            ElseIf Lab3.Text = "6" Then
                Lab3.Text = "2"
            ElseIf Lab3.Text = "9" Then
                Lab3.Text = "3"
            ElseIf Lab3.Text = "8" Then
                Lab3.Text = "6"
            ElseIf Lab3.Text = "7" Then
                Lab3.Text = "9"
            ElseIf Lab3.Text = "4" Then
                Lab3.Text = "8"
            ElseIf Lab3.Text = "1" Then
                Lab3.Text = "7"
            ElseIf Lab3.Text = "2" Then
                Lab3.Text = "4"
            End If
            If Lab4.Text = "3" Then
                Lab4.Text = "1"
            ElseIf Lab4.Text = "6" Then
                Lab4.Text = "2"
            ElseIf Lab4.Text = "9" Then
                Lab4.Text = "3"
            ElseIf Lab4.Text = "8" Then
                Lab4.Text = "6"
            ElseIf Lab4.Text = "7" Then
                Lab4.Text = "9"
            ElseIf Lab4.Text = "4" Then
                Lab4.Text = "8"
            ElseIf Lab4.Text = "1" Then
                Lab4.Text = "7"
            ElseIf Lab4.Text = "2" Then
                Lab4.Text = "4"
            End If
            If Lab5.Text = "3" Then
                Lab5.Text = "1"
            ElseIf Lab5.Text = "6" Then
                Lab5.Text = "2"
            ElseIf Lab5.Text = "9" Then
                Lab5.Text = "3"
            ElseIf Lab5.Text = "8" Then
                Lab5.Text = "6"
            ElseIf Lab5.Text = "7" Then
                Lab5.Text = "9"
            ElseIf Lab5.Text = "4" Then
                Lab5.Text = "8"
            ElseIf Lab5.Text = "1" Then
                Lab5.Text = "7"
            ElseIf Lab5.Text = "2" Then
                Lab5.Text = "4"
            End If
            If Lab6.Text = "3" Then
                Lab6.Text = "1"
            ElseIf Lab6.Text = "6" Then
                Lab6.Text = "2"
            ElseIf Lab6.Text = "9" Then
                Lab6.Text = "3"
            ElseIf Lab6.Text = "8" Then
                Lab6.Text = "6"
            ElseIf Lab6.Text = "7" Then
                Lab6.Text = "9"
            ElseIf Lab6.Text = "4" Then
                Lab6.Text = "8"
            ElseIf Lab6.Text = "1" Then
                Lab6.Text = "7"
            ElseIf Lab6.Text = "2" Then
                Lab6.Text = "4"
            End If
            If Lab7.Text = "3" Then
                Lab7.Text = "1"
            ElseIf Lab7.Text = "6" Then
                Lab7.Text = "2"
            ElseIf Lab7.Text = "9" Then
                Lab7.Text = "3"
            ElseIf Lab7.Text = "8" Then
                Lab7.Text = "6"
            ElseIf Lab7.Text = "7" Then
                Lab7.Text = "9"
            ElseIf Lab7.Text = "4" Then
                Lab7.Text = "8"
            ElseIf Lab7.Text = "1" Then
                Lab7.Text = "7"
            ElseIf Lab7.Text = "2" Then
                Lab7.Text = "4"
            End If
            If Lab8.Text = "3" Then
                Lab8.Text = "1"
            ElseIf Lab8.Text = "6" Then
                Lab8.Text = "2"
            ElseIf Lab8.Text = "9" Then
                Lab8.Text = "3"
            ElseIf Lab8.Text = "8" Then
                Lab8.Text = "6"
            ElseIf Lab8.Text = "7" Then
                Lab8.Text = "9"
            ElseIf Lab8.Text = "4" Then
                Lab8.Text = "8"
            ElseIf Lab8.Text = "1" Then
                Lab8.Text = "7"
            ElseIf Lab8.Text = "2" Then
                Lab8.Text = "4"
            End If
            If Lab9.Text = "3" Then
                Lab9.Text = "1"
            ElseIf Lab9.Text = "6" Then
                Lab9.Text = "2"
            ElseIf Lab9.Text = "9" Then
                Lab9.Text = "3"
            ElseIf Lab9.Text = "8" Then
                Lab9.Text = "6"
            ElseIf Lab9.Text = "7" Then
                Lab9.Text = "9"
            ElseIf Lab9.Text = "4" Then
                Lab9.Text = "8"
            ElseIf Lab9.Text = "1" Then
                Lab9.Text = "7"
            ElseIf Lab9.Text = "2" Then
                Lab9.Text = "4"
            End If
            loc(e)
        End If
    End Sub

    Private Sub rr_Click(sender As Object, e As EventArgs) Handles rr.Click
        If bl.Text = "0" Then
            If Lab1.Text = "1" Then
                Lab1.Text = "3"
            ElseIf Lab1.Text = "2" Then
                Lab1.Text = "6"
            ElseIf Lab1.Text = "3" Then
                Lab1.Text = "9"
            ElseIf Lab1.Text = "6" Then
                Lab1.Text = "8"
            ElseIf Lab1.Text = "9" Then
                Lab1.Text = "7"
            ElseIf Lab1.Text = "8" Then
                Lab1.Text = "4"
            ElseIf Lab1.Text = "7" Then
                Lab1.Text = "1"
            ElseIf Lab1.Text = "4" Then
                Lab1.Text = "2"
            End If
            If Lab2.Text = "1" Then
                Lab2.Text = "3"
            ElseIf Lab2.Text = "2" Then
                Lab2.Text = "6"
            ElseIf Lab2.Text = "3" Then
                Lab2.Text = "9"
            ElseIf Lab2.Text = "6" Then
                Lab2.Text = "8"
            ElseIf Lab2.Text = "9" Then
                Lab2.Text = "7"
            ElseIf Lab2.Text = "8" Then
                Lab2.Text = "4"
            ElseIf Lab2.Text = "7" Then
                Lab2.Text = "1"
            ElseIf Lab2.Text = "4" Then
                Lab2.Text = "2"
            End If
            If Lab3.Text = "1" Then
                Lab3.Text = "3"
            ElseIf Lab3.Text = "2" Then
                Lab3.Text = "6"
            ElseIf Lab3.Text = "3" Then
                Lab3.Text = "9"
            ElseIf Lab3.Text = "6" Then
                Lab3.Text = "8"
            ElseIf Lab3.Text = "9" Then
                Lab3.Text = "7"
            ElseIf Lab3.Text = "8" Then
                Lab3.Text = "4"
            ElseIf Lab3.Text = "7" Then
                Lab3.Text = "1"
            ElseIf Lab3.Text = "4" Then
                Lab3.Text = "2"
            End If
            If Lab4.Text = "1" Then
                Lab4.Text = "3"
            ElseIf Lab4.Text = "2" Then
                Lab4.Text = "6"
            ElseIf Lab4.Text = "3" Then
                Lab4.Text = "9"
            ElseIf Lab4.Text = "6" Then
                Lab4.Text = "8"
            ElseIf Lab4.Text = "9" Then
                Lab4.Text = "7"
            ElseIf Lab4.Text = "8" Then
                Lab4.Text = "4"
            ElseIf Lab4.Text = "7" Then
                Lab4.Text = "1"
            ElseIf Lab4.Text = "4" Then
                Lab4.Text = "2"
            End If
            If Lab5.Text = "1" Then
                Lab5.Text = "3"
            ElseIf Lab5.Text = "2" Then
                Lab5.Text = "6"
            ElseIf Lab5.Text = "3" Then
                Lab5.Text = "9"
            ElseIf Lab5.Text = "6" Then
                Lab5.Text = "8"
            ElseIf Lab5.Text = "9" Then
                Lab5.Text = "7"
            ElseIf Lab5.Text = "8" Then
                Lab5.Text = "4"
            ElseIf Lab5.Text = "7" Then
                Lab5.Text = "1"
            ElseIf Lab5.Text = "4" Then
                Lab5.Text = "2"
            End If
            If Lab6.Text = "1" Then
                Lab6.Text = "3"
            ElseIf Lab6.Text = "2" Then
                Lab6.Text = "6"
            ElseIf Lab6.Text = "3" Then
                Lab6.Text = "9"
            ElseIf Lab6.Text = "6" Then
                Lab6.Text = "8"
            ElseIf Lab6.Text = "9" Then
                Lab6.Text = "7"
            ElseIf Lab6.Text = "8" Then
                Lab6.Text = "4"
            ElseIf Lab6.Text = "7" Then
                Lab6.Text = "1"
            ElseIf Lab6.Text = "4" Then
                Lab6.Text = "2"
            End If
            If Lab7.Text = "1" Then
                Lab7.Text = "3"
            ElseIf Lab7.Text = "2" Then
                Lab7.Text = "6"
            ElseIf Lab7.Text = "3" Then
                Lab7.Text = "9"
            ElseIf Lab7.Text = "6" Then
                Lab7.Text = "8"
            ElseIf Lab7.Text = "9" Then
                Lab7.Text = "7"
            ElseIf Lab7.Text = "8" Then
                Lab7.Text = "4"
            ElseIf Lab7.Text = "7" Then
                Lab7.Text = "1"
            ElseIf Lab7.Text = "4" Then
                Lab7.Text = "2"
            End If
            If Lab8.Text = "1" Then
                Lab8.Text = "3"
            ElseIf Lab8.Text = "2" Then
                Lab8.Text = "6"
            ElseIf Lab8.Text = "3" Then
                Lab8.Text = "9"
            ElseIf Lab8.Text = "6" Then
                Lab8.Text = "8"
            ElseIf Lab8.Text = "9" Then
                Lab8.Text = "7"
            ElseIf Lab8.Text = "8" Then
                Lab8.Text = "4"
            ElseIf Lab8.Text = "7" Then
                Lab8.Text = "1"
            ElseIf Lab8.Text = "4" Then
                Lab8.Text = "2"
            End If
            If Lab9.Text = "1" Then
                Lab9.Text = "3"
            ElseIf Lab9.Text = "2" Then
                Lab9.Text = "6"
            ElseIf Lab9.Text = "3" Then
                Lab9.Text = "9"
            ElseIf Lab9.Text = "6" Then
                Lab9.Text = "8"
            ElseIf Lab9.Text = "9" Then
                Lab9.Text = "7"
            ElseIf Lab9.Text = "8" Then
                Lab9.Text = "4"
            ElseIf Lab9.Text = "7" Then
                Lab9.Text = "1"
            ElseIf Lab9.Text = "4" Then
                Lab9.Text = "2"
            End If
            loc(e)
        End If
    End Sub

    Private Sub rh_Click(sender As Object, e As EventArgs) Handles rh.Click
        If bl.Text = "0" Then
            If Lab1.Text = "1" Then
                Lab1.Text = "3"
            ElseIf Lab1.Text = "4" Then
                Lab1.Text = "6"
            ElseIf Lab1.Text = "7" Then
                Lab1.Text = "9"
            ElseIf Lab1.Text = "3" Then
                Lab1.Text = "1"
            ElseIf Lab1.Text = "6" Then
                Lab1.Text = "4"
            ElseIf Lab1.Text = "9" Then
                Lab1.Text = "7"
            End If
            If Lab2.Text = "1" Then
                Lab2.Text = "3"
            ElseIf Lab2.Text = "4" Then
                Lab2.Text = "6"
            ElseIf Lab2.Text = "7" Then
                Lab2.Text = "9"
            ElseIf Lab2.Text = "3" Then
                Lab2.Text = "1"
            ElseIf Lab2.Text = "6" Then
                Lab2.Text = "4"
            ElseIf Lab2.Text = "9" Then
                Lab2.Text = "7"
            End If
            If Lab3.Text = "1" Then
                Lab3.Text = "3"
            ElseIf Lab3.Text = "4" Then
                Lab3.Text = "6"
            ElseIf Lab3.Text = "7" Then
                Lab3.Text = "9"
            ElseIf Lab3.Text = "3" Then
                Lab3.Text = "1"
            ElseIf Lab3.Text = "6" Then
                Lab3.Text = "4"
            ElseIf Lab3.Text = "9" Then
                Lab3.Text = "7"
            End If
            If Lab4.Text = "1" Then
                Lab4.Text = "3"
            ElseIf Lab4.Text = "4" Then
                Lab4.Text = "6"
            ElseIf Lab4.Text = "7" Then
                Lab4.Text = "9"
            ElseIf Lab4.Text = "3" Then
                Lab4.Text = "1"
            ElseIf Lab4.Text = "6" Then
                Lab4.Text = "4"
            ElseIf Lab4.Text = "9" Then
                Lab4.Text = "7"
            End If
            If Lab5.Text = "1" Then
                Lab5.Text = "3"
            ElseIf Lab5.Text = "4" Then
                Lab5.Text = "6"
            ElseIf Lab5.Text = "7" Then
                Lab5.Text = "9"
            ElseIf Lab5.Text = "3" Then
                Lab5.Text = "1"
            ElseIf Lab5.Text = "6" Then
                Lab5.Text = "4"
            ElseIf Lab5.Text = "9" Then
                Lab5.Text = "7"
            End If
            If Lab6.Text = "1" Then
                Lab6.Text = "3"
            ElseIf Lab6.Text = "4" Then
                Lab6.Text = "6"
            ElseIf Lab6.Text = "7" Then
                Lab6.Text = "9"
            ElseIf Lab6.Text = "3" Then
                Lab6.Text = "1"
            ElseIf Lab6.Text = "6" Then
                Lab6.Text = "4"
            ElseIf Lab6.Text = "9" Then
                Lab6.Text = "7"
            End If
            If Lab7.Text = "1" Then
                Lab7.Text = "3"
            ElseIf Lab7.Text = "4" Then
                Lab7.Text = "6"
            ElseIf Lab7.Text = "7" Then
                Lab7.Text = "9"
            ElseIf Lab7.Text = "3" Then
                Lab7.Text = "1"
            ElseIf Lab7.Text = "6" Then
                Lab7.Text = "4"
            ElseIf Lab7.Text = "9" Then
                Lab7.Text = "7"
            End If
            If Lab8.Text = "1" Then
                Lab8.Text = "3"
            ElseIf Lab8.Text = "4" Then
                Lab8.Text = "6"
            ElseIf Lab8.Text = "7" Then
                Lab8.Text = "9"
            ElseIf Lab8.Text = "3" Then
                Lab8.Text = "1"
            ElseIf Lab8.Text = "6" Then
                Lab8.Text = "4"
            ElseIf Lab8.Text = "9" Then
                Lab8.Text = "7"
            End If
            If Lab9.Text = "1" Then
                Lab9.Text = "3"
            ElseIf Lab9.Text = "4" Then
                Lab9.Text = "6"
            ElseIf Lab9.Text = "7" Then
                Lab9.Text = "9"
            ElseIf Lab9.Text = "3" Then
                Lab9.Text = "1"
            ElseIf Lab9.Text = "6" Then
                Lab9.Text = "4"
            ElseIf Lab9.Text = "9" Then
                Lab9.Text = "7"
            End If
            loc(e)
        End If
    End Sub

    Private Sub rv_Click(sender As Object, e As EventArgs) Handles rv.Click
        If bl.Text = "0" Then
            If Lab1.Text = "1" Then
                Lab1.Text = "7"
            ElseIf Lab1.Text = "2" Then
                Lab1.Text = "8"
            ElseIf Lab1.Text = "3" Then
                Lab1.Text = "9"
            ElseIf Lab1.Text = "7" Then
                Lab1.Text = "1"
            ElseIf Lab1.Text = "8" Then
                Lab1.Text = "2"
            ElseIf Lab1.Text = "9" Then
                Lab1.Text = "3"
            End If
            If Lab2.Text = "1" Then
                Lab2.Text = "7"
            ElseIf Lab2.Text = "2" Then
                Lab2.Text = "8"
            ElseIf Lab2.Text = "3" Then
                Lab2.Text = "9"
            ElseIf Lab2.Text = "7" Then
                Lab2.Text = "1"
            ElseIf Lab2.Text = "8" Then
                Lab2.Text = "2"
            ElseIf Lab2.Text = "9" Then
                Lab2.Text = "3"
            End If
            If Lab3.Text = "1" Then
                Lab3.Text = "7"
            ElseIf Lab3.Text = "2" Then
                Lab3.Text = "8"
            ElseIf Lab3.Text = "3" Then
                Lab3.Text = "9"
            ElseIf Lab3.Text = "7" Then
                Lab3.Text = "1"
            ElseIf Lab3.Text = "8" Then
                Lab3.Text = "2"
            ElseIf Lab3.Text = "9" Then
                Lab3.Text = "3"
            End If
            If Lab4.Text = "1" Then
                Lab4.Text = "7"
            ElseIf Lab4.Text = "2" Then
                Lab4.Text = "8"
            ElseIf Lab4.Text = "3" Then
                Lab4.Text = "9"
            ElseIf Lab4.Text = "7" Then
                Lab4.Text = "1"
            ElseIf Lab4.Text = "8" Then
                Lab4.Text = "2"
            ElseIf Lab4.Text = "9" Then
                Lab4.Text = "3"
            End If
            If Lab5.Text = "1" Then
                Lab5.Text = "7"
            ElseIf Lab5.Text = "2" Then
                Lab5.Text = "8"
            ElseIf Lab5.Text = "3" Then
                Lab5.Text = "9"
            ElseIf Lab5.Text = "7" Then
                Lab5.Text = "1"
            ElseIf Lab5.Text = "8" Then
                Lab5.Text = "2"
            ElseIf Lab5.Text = "9" Then
                Lab5.Text = "3"
            End If
            If Lab6.Text = "1" Then
                Lab6.Text = "7"
            ElseIf Lab6.Text = "2" Then
                Lab6.Text = "8"
            ElseIf Lab6.Text = "3" Then
                Lab6.Text = "9"
            ElseIf Lab6.Text = "7" Then
                Lab6.Text = "1"
            ElseIf Lab6.Text = "8" Then
                Lab6.Text = "2"
            ElseIf Lab6.Text = "9" Then
                Lab6.Text = "3"
            End If
            If Lab7.Text = "1" Then
                Lab7.Text = "7"
            ElseIf Lab7.Text = "2" Then
                Lab7.Text = "8"
            ElseIf Lab7.Text = "3" Then
                Lab7.Text = "9"
            ElseIf Lab7.Text = "7" Then
                Lab7.Text = "1"
            ElseIf Lab7.Text = "8" Then
                Lab7.Text = "2"
            ElseIf Lab7.Text = "9" Then
                Lab7.Text = "3"
            End If
            If Lab8.Text = "1" Then
                Lab8.Text = "7"
            ElseIf Lab8.Text = "2" Then
                Lab8.Text = "8"
            ElseIf Lab8.Text = "3" Then
                Lab8.Text = "9"
            ElseIf Lab8.Text = "7" Then
                Lab8.Text = "1"
            ElseIf Lab8.Text = "8" Then
                Lab8.Text = "2"
            ElseIf Lab8.Text = "9" Then
                Lab8.Text = "3"
            End If
            If Lab9.Text = "1" Then
                Lab9.Text = "7"
            ElseIf Lab9.Text = "2" Then
                Lab9.Text = "8"
            ElseIf Lab9.Text = "3" Then
                Lab9.Text = "9"
            ElseIf Lab9.Text = "7" Then
                Lab9.Text = "1"
            ElseIf Lab9.Text = "8" Then
                Lab9.Text = "2"
            ElseIf Lab9.Text = "9" Then
                Lab9.Text = "3"
            End If
            loc(e)
        End If
    End Sub

    Sub h(ByVal e As EventArgs)
        If bl.Text = "0" Then
            If ok1.Checked = True And ok2.Checked = True Then
                If L2.Text = "0" Then
                    bl.Text = "1"
                    T3.Stop()
                    L4.Text = ll.Text
                    ll.Text = "4"
                    rt.Text = Lab1.Text : Lab1.Text = Lab7.Text : Lab7.Text = rt.Text
                    rt.Text = Lab2.Text : Lab2.Text = Lab8.Text : Lab8.Text = rt.Text
                    rt.Text = Lab3.Text : Lab3.Text = Lab9.Text : Lab9.Text = rt.Text
                    rt.Text = La1.Text : La1.Text = La7.Text : La7.Text = rt.Text
                    rt.Text = La2.Text : La2.Text = La8.Text : La8.Text = rt.Text
                    rt.Text = La3.Text : La3.Text = La9.Text : La9.Text = rt.Text
                    tt2(e)
                    If Lab7.Text = Lb7.Text Then
                    Else
                        La7.Text = "1"
                    End If
                    If Lab8.Text = Lb8.Text Then
                    Else
                        La8.Text = "1"
                    End If
                    If Lab9.Text = Lb9.Text Then
                    Else
                        La9.Text = "1"
                    End If
                    rt.Text = Lab1.Text : Lab1.Text = Lab7.Text : Lab7.Text = rt.Text
                    rt.Text = Lab2.Text : Lab2.Text = Lab8.Text : Lab8.Text = rt.Text
                    rt.Text = Lab3.Text : Lab3.Text = Lab9.Text : Lab9.Text = rt.Text
                    rt.Text = La1.Text : La1.Text = La7.Text : La7.Text = rt.Text
                    rt.Text = La2.Text : La2.Text = La8.Text : La8.Text = rt.Text
                    rt.Text = La3.Text : La3.Text = La9.Text : La9.Text = rt.Text
                    L2.Text = "1"
                    stp1.Text += 1
                    n0.Text += 2
                    If Lab4.Text = Lb7.Text Then
                        n1.Text = n1.Text + "1 "
                        Le1.Text += 1
                    ElseIf Lab4.Text = Lb8.Text Then
                        n1.Text = n1.Text + "2 "
                        Le2.Text += 1
                    ElseIf Lab4.Text = Lb9.Text Then
                        n1.Text = n1.Text + "3 "
                        Le3.Text += 1
                    ElseIf Lab5.Text = Lb7.Text Then
                        n1.Text = n1.Text + "7 "
                        Le1.Text += 1
                    ElseIf Lab5.Text = Lb8.Text Then
                        n1.Text = n1.Text + "8 "
                        Le2.Text += 1
                    ElseIf Lab5.Text = Lb9.Text Then
                        n1.Text = n1.Text + "9 "
                        Le3.Text += 1
                    ElseIf Lab6.Text = Lb7.Text Then
                        n1.Text = n1.Text + "13"
                        Le1.Text += 1
                    ElseIf Lab6.Text = Lb8.Text Then
                        n1.Text = n1.Text + "14"
                        Le2.Text += 1
                    ElseIf Lab6.Text = Lb9.Text Then
                        n1.Text = n1.Text + "15"
                        Le3.Text += 1
                    End If
                    r0.Text = "-1"
                    r1.Text = ""
                    Lb7.Text = Lab7.Text : Lb8.Text = Lab8.Text : Lb9.Text = Lab9.Text
                    l1.Text = "0"
                    rf(e)
                    ne(e)
                    loc(e)
                    bl.Text = "0"
                    Wn(e)
                    ll.Text = L4.Text
                    If Cmpt.Checked = True Then
                        T3.Start()
                    End If
                ElseIf L2.Text = "1" And Cmpt.Checked = False Then
                    L4.Text = ll.Text
                    ll.Text = "4"
                    bl.Text = "1"
                    t22(e)
                    ll.Text = L4.Text
                End If
            Else
                If Bu8.Text = "عربي" Then
                    MsgBox(("Both of you should agree to this feature by pressing OK"), vbInformation, "warning...")
                Else
                    MsgBox(("على كليكما ان توافقا معا على هذه الخاصية بالضغط على موافق"), vbInformation + vbMsgBoxRight + vbMsgBoxRtlReading, "تحذير...")
                End If
            End If
        End If
    End Sub

    Private Sub Bu9_Click(sender As Object, e As EventArgs) Handles Bu9.Click
        h(e)
    End Sub

    Private Sub fst_Text(sender As Object, e As EventArgs) Handles fst.TextChanged
        On Error Resume Next
        Dim zz As Integer = fst.Text
        If fst.Text = "" Then
        Else
            If zz < 1 Or zz > 350 Then
                If zz < 1 Then
                    fst.Text = 1
                ElseIf zz > 350 Then
                    fst.Text = 350
                End If
            Else
                If zz >= 1 Or zz <= 350 Then
                    T2.Interval = fst.Text
                End If
            End If
        End If
    End Sub

    Private Sub ok1_CheckedChanged(sender As Object, e As EventArgs) Handles ok1.CheckedChanged
        If ok1.Checked = True Then
            o1.Text += 1
            ok1.Text = "OK +" + o1.Text
        End If
        If Bu8.Text = "English" Then
            ok1.Text = ok1.Text.Replace("OK", "موافق")
        End If
    End Sub

    Private Sub ok2_CheckedChanged(sender As Object, e As EventArgs) Handles ok2.CheckedChanged
        If ok2.Checked = True Then
            o2.Text += 1
            ok2.Text = "OK +" + o2.Text
        End If
        If Bu8.Text = "English" Then
            ok2.Text = ok2.Text.Replace("OK", "موافق")
        End If
    End Sub

    Private Sub B10_Click(sender As Object, e As EventArgs) Handles B10.Click
        B10.Visible = False
        NoS.Visible = False
        B11.Visible = True
        ns.Visible = True
        lns.Visible = True
    End Sub

    Private Sub B11_Click(sender As Object, e As EventArgs) Handles B11.Click
        B11.Visible = False
        ns.Visible = False
        lns.Visible = False
        B10.Visible = True
        NoS.Visible = True
    End Sub

    Sub nsn(ByVal e As EventArgs)
        If sn.Text = "1" Then
            If Bu8.Text = "عربي" Then
                ns.Text = "first"
            Else
                ns.Text = "أولا"
            End If
        ElseIf sn.Text = "2" Then
            If Bu8.Text = "عربي" Then
                ns.Text = "second"
            Else
                ns.Text = "آخرا"
            End If
        End If
    End Sub

    Private Sub ns_TextChanged(sender As Object, e As EventArgs) Handles ns.TextChanged
        nsn(e)
    End Sub

    Private Sub ns_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ns.SelectedIndexChanged
        If ns.Text = "first" Or ns.Text = "أولا" Then
            sn.Text = "1"
        ElseIf ns.Text = "second" Or ns.Text = "آخرا" Then
            sn.Text = "2"
        End If
        nsn(e)
    End Sub
End Class
